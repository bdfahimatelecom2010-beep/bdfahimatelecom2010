# BONGSHOKOTHA Professional 15.1.0 — Master Requirements

## 1. Product direction
একটি সহজ, সুন্দর, দ্রুত, আধুনিক, data-integrity-first genealogy + family archive platform; একই source থেকে Windows ও Android/mobile build.

## 2. Navigation
- Login
- Dashboard
- সকল সদস্য
- বংশলতিকা বৃক্ষ
- বিবাহ
- পারিবারিক Hub/Book/Calendar/Relationship Finder
- পারিবারিক মহাফেজখানা
- Import/Export/Print
- Settings
- Owner/Admin Center (role অনুযায়ী)
- Logout
- **Family Statistics নামে আলাদা menu নেই।** Family Statistics-এর প্রয়োজনীয় metrics/widgets Dashboard-এ থাকে।

## 3. Dashboard rule
Dashboard widget registry-ই authoritative list। প্রতিটি widget:
- Settings থেকে ON/OFF
- order পরিবর্তনযোগ্য
- layout density পরিবর্তনযোগ্য
- per-family persisted
- result-এ click করলে সংক্ষিপ্ত ফলাফল তালিকা
- প্রাসঙ্গিক result থেকে member/profile/tree/archive-এ navigation

Family Statistics-এর সম্ভাব্য dashboard widgets:
- মোট/জীবিত/মৃত সদস্য
- gender
- generation
- branch
- marriage status/count
- multiple marriage
- age/life profile
- profile completeness
- missing parents/identity/date
- documents/archive
- research/evidence
- OCR review pending
- upcoming birthday/memorial/anniversary
- recent changes
- family overview

## 4. Permanent identity
- Permanent internal Person ID immutable.
- UI-তে Person ID বা Serial No. দেখানো/চাওয়া যাবে না।
- Legacy serial field থাকলে migration compatibility only.
- নাম বদলালেও relationships, documents, marriages, backup links অক্ষুণ্ণ থাকবে।

## 5. Member profile
ব্যবহারকারীর তথ্য দেওয়ার সুবিধার জন্য এক পৃষ্ঠায় পরিষ্কার section:
1. Photo/basic identity
2. বাংলা/English/previous/alternative names
3. Gender
4. Birth origin: জন্মসূত্রে / বিবাহসূত্রে / দত্তক / অজানা
5. Living/deceased
6. Marital status
7. Generation automatic/manual override
8. Birth order among biological parents' children
9. Branch
10. Father/mother
11. Paternal/maternal grandparents
12. Spouse(s)
13. Children grouped by marriage and ordered by birth order
14. Birth date/precision/place
15. Death date/precision/age at death/burial/memorial
16. Current/permanent address
17. Phone/email
18. Education summary + repeatable education history
19. Current profession + repeatable career history
20. Residence history
21. NID/BRN/Passport/other identity
22. Documents/photos
23. OCR review/apply
24. Nationality/religion/blood group/languages
25. Service/migration/physical description
26. Research status/notes/evidence
27. Biography/family origin/memorial story
28. Notes/tags

## 6. Member card / Family Tree card
প্রাসঙ্গিক compact view-তে:
- Name
- Generation
- Father/Mother
- Birth date
- Death date when deceased
- Living/deceased status
- Current age when living
- Age at death when deceased
- Photo
- Occupation
- Short address
- Birth-origin / marriage-origin / adopted
- Spouse name when married
- Total marriage count

একটি marriage থাকা অবস্থায় spouse name duplicate দেখানো যাবে না।

## 7. Ordering and generation
- Parent generation + 1 = child generation.
- Parent links পরে দেওয়া হলেও member immediately correct sibling/generation list-এ যায়।
- Sibling order = birthOrder, never save-time or alphabetical order.
- Married-in spouse = spouse-এর generation and immediately after spouse in family display.
- Married-in member-এর own paternal/maternal family data profile-এ রাখা যাবে কিন্তু spouse-family birth-line nodes-এ স্বয়ংক্রিয়ভাবে ঢুকবে না।
- External in-law parent কেবল independently connected legitimate family relationship থাকলে family visibility পাবে।

## 8. Marriage
- Immutable MarriageRecord ID/history.
- Multiple marriages.
- Union-specific children.
- Two-way spouse link.
- Marriage count derived from actual records.
- Unmarried state does not show misleading spouse panel.

## 9. OCR and document archive
- Original document is preserved as evidence.
- OCR text/extracted fields/provenance/verification separate.
- NID, BRN and Passport separate fields.
- OCR field review has per-field selection before apply.
- Existing verified data is never silently overwritten.
- NID extraction is label-bound and digit-normalized.
- Passport extraction supports label form and MRZ first field.
- DOB supports numeric and English-month formats.
- Parent/address/place fields are label/context based.
- PDF first page is rendered locally before OCR.
- OCR language models are prepared locally by PowerShell and served from `/tessdata`.
- Profile document deletion does not delete canonical Family Archive record.

## 10. Family Archive
- NID
- Birth Registration
- Passport
- stamps/letters/historical documents
- certificates
- marriage/death documents
- land records
- education/employment records
- photos
- audio/oral history
- stories/memories
- automatic document type detection
- member-name linking
- OCR extraction
- evidence/provenance
- verification state
- audit history

## 11. Roles and owner
- Login by phone or email.
- Owner, Super Admin, Admin, Editor, Contributor, Viewer.
- Owner controls role assignment/revocation and server/recovery settings.
- Admin cannot exceed Owner-assigned authority.
- Owner-only Admin/Server controls hidden from ordinary users.

## 12. Succession
- Up to five candidates.
- Priority 1–5.
- Candidate death warning.
- Priority preserved exactly.
- If no designation exists, software warns and defers to applicable law/family policy; it does not invent a legal rule.

## 13. Gmail recovery
- Admin/Owner may configure a custom/device Gmail account.
- Password is never stored.
- Recovery backup is private to the authorized Owner/Admin recovery workflow.
- Backup integrity and restore verification required.

## 14. Server registry
- Predefined compatible server profiles.
- User selects a server and uses its connect/open action.
- Login/authorization handled by provider/server.
- Role snapshot is sent according to Owner-assigned role.
- Later Owner role changes can be synchronized.
- Server does not override Owner permissions.
- Local-only mode always remains usable.

## 15. Data quality/research
- Missing information detection.
- Duplicate detection.
- Broken relationship detection.
- Chronology conflict detection.
- Evidence/source reference.
- Research status.
- Audit trail.

## 16. Interoperability
- Bongshokotha archive JSON
- CSV
- GEDCOM foundation
- safe merge/restore
- checksum/integrity
- recycle bin

## 17. Performance
- Responsive UI.
- IndexedDB-first persistence with local fallback.
- Avoid unnecessary rendering.
- Heavy OCR/archive work isolated from ordinary navigation.
- Dashboard widgets lazy/conditional where practical.
- Desktop/mobile layout adapts to device dimensions.

## 18. Verification requirement
A feature is complete only when source contract + runtime path + persistence + UI behavior are checked. Final package must pass version, consistency, master requirements, quality, theme, relationship, generation, age, member-data, archive/OCR, dashboard, family-visibility, deep integration, TypeScript and production build checks.

## 2026-10-08 Account & Co-Admin Addendum

### Account Separation
- Every authenticated user has a dedicated **My Account / আমার অ্যাকাউন্ট** menu.
- The user may change account name, login mobile, Gmail/email and password.
- Account changes MUST NOT mutate genealogy Member records, relationships, generations, marriages, documents or archive records.
- A user with no elevated role may manage only their own account plus any explicitly assigned permissions.

### Co-Admin
- `co_admin` is a first-class role.
- Co-Admin receives normal administrative genealogy permissions, including member/marriage/archive management, import/export, integrity repair and role management.
- Co-Admin MUST NOT have:
  - Gmail/Google Drive family backup
  - Server management
  - Complete genealogy deletion
- These restrictions MUST be enforced at operation/permission level, not only by hiding menu items.
- Admin may grant Co-Admin to another account; Co-Admin may not escalate another account to Admin/Co-Admin/Super Admin/Owner.
