# BONGSHOKOTHA Professional — নিজে সংরক্ষণ ও তৈরি করার নির্দেশনা

## ১. এই ফোল্ডারটি সংরক্ষণ করুন

এই পুরো project folder-টি একটি নিরাপদ জায়গায় রাখুন। ZIP-টিও আলাদা করে সংরক্ষণ করুন।

**Family data/source code একই জিনিস নয়।** ভবিষ্যৎ আপডেটের আগে আপনার backup আলাদা রাখুন।

## ২. Windows-এ প্রথমবার চালানো

PowerShell খুলে:

```powershell
Set-Location -LiteralPath "C:\Bongshokotha-Professional"
Set-ExecutionPolicy -Scope Process Bypass -Force
node -v
npm.cmd -v
npm.cmd install
npm.cmd run audit:version
npm.cmd run verify
```

PowerShell-এ `npm` বন্ধ থাকলে `npm.cmd` ব্যবহার করুন।

## ৩. সফটওয়্যার চালু

```powershell
npm.cmd run dev
```

তারপর ব্রাউজারে:

```text
http://localhost:3000
```

## ৪. Windows build

```powershell
npm.cmd run build
```

Desktop build-এর জন্য:

```powershell
npm.cmd run desktop:build
```

## ৫. Android build

Android/Capacitor environment প্রস্তুত থাকলে:

```powershell
npm.cmd run mobile:build
```

## ৬. নিজের পরিবর্তন করার নিয়ম

- `src/components` = UI
- `src/types` = data model
- `src/engine` = genealogy/relationship logic
- `src/services` = storage/server/integration
- `src/hooks` বা context = shared state
- `scripts` = automated regression checks

কোনো feature শুধু UI-তে যোগ করবেন না। সম্পূর্ণ flow হবে:

**UI → State → Engine/Service → Storage → Reload → UI**

## ৭. নিরাপদ আপডেট

নতুন version বসানোর আগে:
1. Family data backup নিন।
2. পুরোনো project folder-এর copy রাখুন।
3. নতুন source-এ `npm.cmd run audit:version` চালান।
4. `npm.cmd run verify` চালান।
5. তারপর পুরোনো backup থেকে restore test করুন।

## ৮. গুরুত্বপূর্ণ

`npm audit fix --force` ব্যবহার করবেন না, কারণ এটি dependency version বদলে working genealogy code ভেঙে দিতে পারে।
