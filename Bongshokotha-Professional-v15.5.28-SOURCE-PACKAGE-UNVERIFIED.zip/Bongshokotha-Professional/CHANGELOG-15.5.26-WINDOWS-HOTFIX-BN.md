# Bongshokotha Professional 15.5.26 hotfix — সংশোধনী

- Browser Back navigation-এ `NavTab`-এর মধ্যে নেই এমন `integrity` tab তুলনা সরানো হয়েছে।
- History state-এর tab মান runtime allow-list দিয়ে যাচাই করা হয়; অচেনা/অবৈধ মান হলে `dashboard` খোলে।
- Windows PowerShell build guide আপডেট করা হয়েছে; `npm.cmd` ব্যবহার এবং typecheck/build আলাদা করে যাচাই করার নির্দেশনা যোগ হয়েছে।

## যাচাইয়ের সীমা
- 15.5.26 সোর্সে typecheck-এর একটি নিশ্চিত TS2367 ত্রুটি পাওয়া গিয়েছিল এবং এই রিলিজে তা সংশোধন করা হয়েছে।
- এই build environment-এ dependency installation 5 মিনিটে শেষ হয়নি; তাই এই প্যাকেজের পূর্ণ `npm run typecheck` ও production build-কে সফল বলে দাবি করা হচ্ছে না। ব্যবহারকারীর Windows মেশিনে dependencies install হওয়ার পর `npm.cmd run typecheck` এবং `npm.cmd run build` চালিয়ে যাচাই করতে হবে।
