# রিলিজ যাচাই প্রতিবেদন — 15.5.26 hotfix

## পরিবর্তন
- `src/App.tsx`: browser history থেকে আসা tab মান allow-list দিয়ে যাচাই করে অবৈধ মানে dashboard fallback।
- `BUILD-COMMANDS-WINDOWS.md`: PowerShell-এর জন্য আপডেট করা নির্দেশনা।

## যাচাইয়ের অবস্থা
- ZIP source থেকে extract: PASS
- আগের রিপোর্টে থাকা regression suites: 8+ পৃথক suites আগে 8/8, 16/16, 116 themes, 7/7, 8/8, 47/47, 20/20, 22/22, 11/11 এবং version 15.5.26 হিসেবে পাস করেছিল; সেগুলো আগের 15.5.26 সোর্সের ফল, এই নতুন ZIP-এর পুনরায় চালানো ফল নয়।
- Typecheck/build: NOT VERIFIED in this environment; `npm install --ignore-scripts --no-audit --no-fund` timed out.

## Windows-এ যাচাই
`npm.cmd install` → `npm.cmd run typecheck` → `npm.cmd run build`। Typecheck-এ ত্রুটি থাকলে সম্পূর্ণ output সংগ্রহ করুন।
