# বংশকথা প্রফেশনাল — মাস্টার কনসোলিডেটেড প্যাকেজ হ্যান্ডঅফ

## কী আছে
- পূর্ববর্তী 15.5.7 সোর্স কোড বেসলাইন।
- 1–34 নম্বর ব্যবহারকারী-অনুমোদিত মাস্টার সিদ্ধান্তের একীভূত রেজিস্টার।
- বিস্তারিত মাস্টার requirements, smart member form spec, implementation plan, theme references এবং dictionary draft।
- আগের release verification রিপোর্ট ও regression scripts।

## গুরুত্বপূর্ণ পার্থক্য
এই প্যাকেজটি `1.0.0`-এর **চাহিদা-সমন্বিত কাজের প্যাকেজ**, সম্পূর্ণ যাচাইকৃত 1.0.0 production release নয়। `package.json`-এ কোড বেসলাইনের version `15.5.7` রাখা হয়েছে যাতে বাস্তব source version ভুলভাবে দাবি না হয়। সব 1–34 শর্ত বাস্তবে কাজ করছে বলে ধরে নেওয়া যাবে না।

## Windows PowerShell-এ যাচাই
```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
Set-Location -LiteralPath "C:\Bongshokotha-Professional"
npm.cmd install
npm.cmd run prepare:ocr
npm.cmd run verify
npm.cmd run build
```

`verify` বা `build` ব্যর্থ হলে ত্রুটির মূল কারণ সমাধান করতে হবে; পরীক্ষার script বাদ দিয়ে বা ব্যর্থতা লুকিয়ে release ঘোষণা করা যাবে না। Desktop/Android build আলাদাভাবে পরীক্ষা করুন:
```powershell
npm.cmd run desktop:build
npm.cmd run mobile:init   # প্রথম Android setup-এ একবার
npm.cmd run mobile:build
```

## আগে যাচাইযোগ্য গুরুত্বপূর্ণ ঝুঁকি
- পুরোনো release report-এ full typecheck/production build এবং browser E2E সম্পন্ন হয়নি বলে উল্লেখ আছে।
- address catalogue প্রথমবার ব্যবহার করতে internet প্রয়োজন হতে পারে এবং catalogue-টি সরকারি পূর্ণাঙ্গ উৎস দিয়ে যাচাই করা বাকি।
- draft system dictionary পূর্ণ জাতীয় ঠিকানা dataset নয়।
- নতুন master register-এ থাকা প্রতিটি feature-এর status আলাদাভাবে প্রমাণসহ পূরণ করতে হবে।
