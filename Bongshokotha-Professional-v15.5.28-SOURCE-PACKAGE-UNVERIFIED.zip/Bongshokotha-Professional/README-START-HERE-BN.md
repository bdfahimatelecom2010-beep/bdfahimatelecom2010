# বংশকথা প্রফেশনাল — শুরু করার নির্দেশনা (v15.5.25)

এই সংস্করণে Role অনুযায়ী মেনু নিয়ন্ত্রণ, Admin Center-এ অনুমতিনির্ভর Data Health/Repair, সদস্য Save ব্যর্থতার ধাপভিত্তিক error diagnostics এবং Android-এ লগআউটের পর অ্যাপ বন্ধ করার চেষ্টা সরানোর সংশোধন অন্তর্ভুক্ত। পূর্ববর্তী Dashboard, Smart Member Form, 116-theme catalog, genealogy relationships, marriage details, Family Archive, OCR, map, sharing, backup/server এবং account/role features এই সোর্সে অন্তর্ভুক্ত আছে। বিস্তারিত `CHANGELOG-15.5.25-BN.md` ও `RELEASE-VERIFICATION-REPORT-15.5.25-BN.md` দেখুন।

## Windows PowerShell-এ চালানো
1. ZIP Extract করুন `C:\Bongshokotha-Professional`-এ।
2. PowerShell-এ ওই ফোল্ডারে যান।
3. `npm.cmd install`
4. `npm.cmd run typecheck`
5. `npm.cmd run member-save-diagnostics:test`
6. `npm.cmd run navigation:visibility:test`
7. `npm.cmd run verify` — সম্পূর্ণ নির্ধারিত regression suite চালাতে
8. `npm.cmd run build`
9. `npm.cmd run dev`

## গুরুত্বপূর্ণ Role ও Save আচরণ
- Role Menu-এর নির্বাচন প্রতিটি Role-এর জন্য কার্যকর; তবে মেনু নির্বাচন নিজে থেকে কোনো Permission দেয় না। Admin Center, Gmail Backup, Server/Sync, Data Health/Repair ও Factory Reset-এর কাজ আলাদা permission check-এর অধীন।
- সদস্য Save ব্যর্থ হলে alert-এ কোন ধাপে ব্যর্থ হয়েছে ও মূল error message দেখা যাবে; বিস্তারিত error/stack console-এ থাকবে। ব্যক্তিগত তথ্যসহ console log শেয়ার করার আগে তা পর্যালোচনা করুন।
- লগআউটের ৫ মিনিট পর `bongshokotha_temp_` prefix-যুক্ত sessionStorage key পরিষ্কার হয়। Android WebView-তে `window.close()` দিয়ে অ্যাপ বন্ধ করা হয় না।

## যাচাইয়ের সীমা
এই ZIP তৈরির পরিবেশে `npm install` সময়সীমার মধ্যে শেষ হয়নি। ফলে পূর্ণ TypeScript typecheck ও Vite production build চালানো যায়নি। সোর্স-ভিত্তিক বহু regression/audit test পাস করেছে; তবে বাস্তব Android ডিভাইসে APK তৈরি/চালানো এবং সদস্য Save failure পুনরুৎপাদন করা হয়নি। Windows কম্পিউটারে উপরের ধাপগুলো চালিয়ে typecheck/build সম্পন্ন করুন এবং APK-তে সদস্য সম্পাদনা, একাধিক বিবাহ, দলিল সংরক্ষণ ও অ্যাপ পুনরায় চালু করে persistence পরীক্ষা করুন।
