# Bongshokotha Professional — সমন্বিত রিলিজ অডিট

তারিখ: ১৬ অক্টোবর ২০২৬
ভিত্তি: `v15.5.26-WINDOWS-TYPECHECK-FIX` সোর্স প্যাকেজ এবং এর মধ্যে থাকা `MASTER-REQUIREMENTS-CONSOLIDATED.md`, OCR specification, theme catalog, release notes ও regression scripts।

## গুরুত্বপূর্ণ সীমা
এই প্যাকেজটি অডিট ও regression-script চালানোর ভিত্তি; এটিকে সব user requirement সম্পূর্ণ বাস্তবায়িত/production-tested বলে ঘোষণা করা হচ্ছে না। `node_modules` প্যাকেজে ছিল না। তাই TypeScript typecheck, production Vite build, Windows installer, Android build, বাস্তব OCR image/PDF, real Google OAuth/Drive backup এবং বাস্তব server restore এই পরিবেশে যাচাই করা যায়নি।

## সোর্স regression script-এর ফল
Node.js 22.16.0 দিয়ে `scripts/*regression-test.mjs`-এর প্রতিটি স্ক্রিপ্ট চালানো হয়েছে। ৫৮টি স্ক্রিপ্টের মধ্যে ৫৫টি exit code 0 এবং ৩টি সরাসরি Node চালনায় ব্যর্থ হয়েছে:

- `age-regression-test.mjs` — `.ts` source import চালাতে প্রয়োজনীয় TypeScript runner ছাড়া চালানো হয়েছিল; এটি product failure-এর নিশ্চিত প্রমাণ নয়, আবার pass-ও নয়।
- `nid-ocr-runtime-regression-test.mjs` — `.ts` runtime dependency সরাসরি Node-এ চালাতে গিয়ে `ERR_UNKNOWN_FILE_EXTENSION`।
- `universal-ocr-runtime-regression-test.mjs` — `.ts` runtime dependency সরাসরি Node-এ চালাতে গিয়ে `ERR_UNKNOWN_FILE_EXTENSION`।

নির্বাচিত pass করা স্ক্রিপ্টে স্মার্ট সদস্য ফর্ম 13/13, ঠিকানা ফর্ম 16/16, ড্যাশবোর্ড 16/16, ম্যাপ/জেনারেশন 7টি, থিম 116টি unique theme, universal OCR runtime 21/21 (যথাযথ `--experimental-strip-types` দিয়ে), এবং অন্যান্য account/role, alternate name, marriage details, security, archive/OCR, responsive/navigation, family visibility, share-safety স্ক্রিপ্ট exit code 0 দিয়েছে। এগুলো source-level regression checks; end-to-end UI বা real document accuracy-র নিশ্চয়তা নয়।

## Requirement coverage checklist

| বিষয় | এই অডিটে যা নিশ্চিত | বাকি যাচাই |
|---|---|---|
| স্মার্ট সদস্য ফর্ম | source regression 13/13 | বাস্তব save/reopen এবং সব conditional edge case |
| ঠিকানা | source regression 16/16; comma-joined পূর্ণ ঠিকানা, postal code, ward/union/municipality fields | authoritative পূর্ণ বাংলাদেশ প্রশাসনিক catalog, manual override sync, বাস্তব data migration |
| পারিবারিক ম্যাপ/ভিউ | map-generation source regression 7টি | real browser navigation, large family data, geocoding/map provider integration |
| থিম | 116 unique themes-এর source test pass | সব screen-এ visual contrast, clipping, persistence/restart বাস্তবে দেখা |
| ড্যাশবোর্ড | source regression 16/16 | actual UI responsive visual test ও saved preferences after restart |
| মেম্বার কার্ড | existing source/spec present | ছয়টি card type, fixed dimensions, spouse-wise children/status, owner-only ID, share button—visual/e2e verification বাকি |
| বিবাহ/সন্তান/সম্পর্ক | source regression scripts pass করেছে | real data end-to-end, edit-save, reciprocal links, migration/edge cases |
| বিকল্প নাম/ডকুমেন্ট উৎস | source regression pass | OCR থেকে actual profile transfer ও duplicate handling বাস্তব নমুনায় যাচাই বাকি |
| OCR / archive | parser ও selected source/runtime tests pass | বাস্তব NID/passport/birth-certificate scans, PDF/barcode, profile + archive transfer এবং overwrite prompts যাচাই বাকি |
| role/security/Co-Admin | role/security source regression scripts exit 0 | আটটি role-এর বাস্তব permission matrix, direct-route/API authorization, backup/delete restrictions e2e test বাকি |
| Backup/restore | source/spec present | live Google OAuth/Drive, server sync, restore integrity বাস্তবে পরীক্ষা করা হয়নি |
| Import/export | source/spec present | JSON/CSV/GEDCOM round-trip ও loss report বাস্তবে যাচাই বাকি |
| Windows/Android | project scripts/config present | typecheck/build/installer/APK/device test এই অডিটে চালানো হয়নি |
| clipped text/buttons | responsive regression scripts exist | desktop/mobile screenshots ও manual visual audit বাকি |

## Release recommendation
এই archive-কে **audited source candidate** হিসেবে বিবেচনা করুন, “সব requirement সমাধান এবং সম্পূর্ণ release verified” হিসেবে নয়। Production release-এর আগে `npm ci`, `npm run typecheck`, `npm run build`, `npm run verify` (Windows PowerShell-এ), বাস্তব নমুনা-ভিত্তিক OCR, সব role-এর end-to-end test, এবং desktop/mobile visual QA প্রয়োজন। `npm audit fix --force` চালাবেন না; dependency changes আলাদা করে পর্যালোচনা করতে হবে।
