Bongshokotha offline OCR language data

Run from the project root before the first production build:
  powershell -ExecutionPolicy Bypass -File .\scripts\prepare-ocr-data.ps1

The script downloads the official Tesseract fast Bengali and English traineddata once and stores compressed local copies here. After that, OCR can run without an OCR-model network request.
