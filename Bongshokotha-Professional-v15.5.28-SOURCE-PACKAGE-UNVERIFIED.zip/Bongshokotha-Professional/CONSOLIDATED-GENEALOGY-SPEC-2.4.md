# Bongshokotha 2.4 — Consolidated Genealogy Requirements

## Member profile
- Gender, marital status, living/deceased and generation are dropdown/select controls.
- Generation defaults to automatic relationship-derived calculation; manual override is optional and does not alter the graph.
- No member serial/ক্রমিক number is shown or entered. Legacy serialNumber is retained only for backward compatibility and must never be displayed.
- Permanent internal Person ID is immutable and hidden from ordinary member UI.
- Father/mother links drive automatic paternal/maternal grandparent discovery.
- Spouse and children are canonical relationship records; selecting an existing member must reuse that member rather than create duplicates.
- Photos and documents may be attached at any time.
- Birth registration, NID and other documents may be OCR-scanned; extracted values require review before applying to verified profile data.
- Profession, mobile, email, current/permanent address and education are supported.
- Optional life events, education history, profession history, residence history, evidence references, family-origin story and memorial story are supported in the domain model.

## Archive
- A family archive record can be related to one or more members. The same canonical document appears in the member profile's document/archive area without duplicating the underlying record.

## Reset
- Settings reset changes only preferences. It must never inject demo/sample family data.
- Factory reset creates an empty family workspace only after explicit destructive confirmation. Demo/sample data is opt-in through a separate Load Demo Data action.

## Reports and tree
- Names are displayed without member serial numbers.
- Generation, spouse, children, grandparents and relationship paths use the canonical relationship graph.
- Birth order is separate from member serial number and may be used only for sibling ordering.

## Release rule
The presence of UI controls alone is not proof of a completed feature. Typecheck/build and real functional regression testing are required before calling the package production-ready.
