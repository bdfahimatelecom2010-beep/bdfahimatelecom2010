import express from 'express';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { version: APP_VERSION } = require('../package.json');
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const app = express();
const PORT = Number(process.env.PORT || 8787);
const DATA_DIR = process.env.BONGSHOKOTHA_DATA_DIR || path.resolve('data');
const FILE = path.join(DATA_DIR, 'sync-store.json');
const SERVER_TOKEN = String(process.env.BONGSHOKOTHA_SERVER_TOKEN || '').trim();
const ALLOW_ORIGIN = String(process.env.BONGSHOKOTHA_CORS_ORIGIN || '').trim();
const MAX_BODY = process.env.BONGSHOKOTHA_MAX_BODY || '25mb';

if (!SERVER_TOKEN) console.warn('SECURITY WARNING: BONGSHOKOTHA_SERVER_TOKEN is not configured. API access will be DENIED until it is set.');

app.disable('x-powered-by');
app.use(express.json({ limit: MAX_BODY, strict: true }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cache-Control', 'no-store');
  if (ALLOW_ORIGIN) {
    res.setHeader('Access-Control-Allow-Origin', ALLOW_ORIGIN);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Request-Id');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use((req, res, next) => { req.requestId = crypto.randomUUID(); res.setHeader('X-Request-Id', req.requestId); next(); });

const buckets = new Map();
app.use((req, res, next) => {
  const key = `${req.ip || 'unknown'}:${req.path}`;
  const now = Date.now();
  const bucket = buckets.get(key) || { count: 0, reset: now + 60_000 };
  if (now >= bucket.reset) { bucket.count = 0; bucket.reset = now + 60_000; }
  bucket.count++;
  buckets.set(key, bucket);
  if (bucket.count > 120) return res.status(429).json({ error: 'Too many requests', requestId: req.requestId });
  next();
});

const constantTimeTokenEqual = (received) => {
  if (!SERVER_TOKEN || !received) return false;
  const a = Buffer.from(received);
  const b = Buffer.from(SERVER_TOKEN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};
const requireApiAuth = (req, res, next) => {
  if (!SERVER_TOKEN) return res.status(503).json({ error: 'Server authentication is not configured', requestId: req.requestId });
  const auth = String(req.headers.authorization || '');
  if (!auth.startsWith('Bearer ') || !constantTimeTokenEqual(auth.slice(7))) return res.status(401).json({ error: 'Authentication required', requestId: req.requestId });
  next();
};

fs.mkdirSync(DATA_DIR, { recursive: true });
const load = () => { try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return { invites: {}, families: {} }; } };
const save = data => { const tmp = `${FILE}.${process.pid}.tmp`; fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8'); fs.renameSync(tmp, FILE); };
const ensureStore = data => { data.invites ||= {}; data.families ||= {}; return data; };
const familyKey = value => String(value || '').trim();
const validateArchive = archive => Boolean(archive && archive.format === 'BONGSHOKOTHA_ARCHIVE' && Array.isArray(archive.members) && Array.isArray(archive.marriages) && archive.family?.id);
const normalize = code => String(code || '').trim().toUpperCase();
const secureCode = () => crypto.randomBytes(24).toString('base64url').toUpperCase();

app.get('/login', (req, res) => {
  const redirectOrigin = String(req.query.origin || '').trim();
  const serverId = String(req.query.serverId || 'custom').trim();
  const safeOrigin = redirectOrigin === 'file://' ? '*' : (/^[a-z][a-z0-9+.-]*:\/\/[^\s]+$/i.test(redirectOrigin) ? redirectOrigin : '');
  res.type('html').send(`<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BONGSHOKOTHA Server Login</title><style>body{font-family:system-ui,sans-serif;background:#f5f5f4;margin:0;padding:32px;color:#292524}.card{max-width:460px;margin:auto;background:white;border:1px solid #e7e5e4;border-radius:24px;padding:24px;box-shadow:0 10px 30px #0001}input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #d6d3d1;border-radius:12px;margin:8px 0 14px}button{width:100%;padding:12px;border:0;border-radius:12px;background:#a16207;color:white;font-weight:700;cursor:pointer}.muted{font-size:12px;color:#78716c}.ok{color:#047857;font-weight:700}.err{color:#b91c1c;font-size:13px}</style></head><body><div class="card"><h2>বংশকথা Server Login</h2><p class="muted">এই server-এর access key দিয়ে নিরাপদে সংযোগ করুন। Password/token অ্যাপে ফেরত পাঠানো হবে কেবল সফল যাচাইয়ের পরে।</p><label>Server Access Key<input id="token" type="password" autocomplete="current-password" placeholder="BONGSHOKOTHA_SERVER_TOKEN"></label><button id="login">Login & Connect</button><p id="msg" class="muted"></p></div><script>
const origin=${JSON.stringify(safeOrigin)}, serverId=${JSON.stringify(serverId)};
document.getElementById('login').onclick=async()=>{const token=document.getElementById('token').value.trim();const msg=document.getElementById('msg');if(!token){msg.className='err';msg.textContent='Access key দিন।';return;}msg.textContent='যাচাই হচ্ছে…';try{const r=await fetch('/api/auth/session',{headers:{Authorization:'Bearer '+token}});const body=await r.json().catch(()=>({}));if(!r.ok||body.authenticated!==true)throw new Error(body.error||'Login failed');if(window.opener&&origin){window.opener.postMessage({type:'BKS_SERVER_AUTH',serverId,token},origin);msg.className='ok';msg.textContent='Login সফল। এই পেজটি বন্ধ করা যাবে।';setTimeout(()=>window.close(),500);}else{msg.className='err';msg.textContent='মূল BONGSHOKOTHA window পাওয়া যায়নি।'} }catch(e){msg.className='err';msg.textContent=e?.message||'Login failed';}};
</script></body></html>`);
});

app.get('/health', (_req,res) => res.json({ ok:true, service:'BONGSHOKOTHA sync', appVersion:APP_VERSION, apiVersion:'2.0.0' }));
app.get('/api/auth/session', requireApiAuth, (_req,res) => res.json({ ok:true, authenticated:true, appVersion:APP_VERSION, time:new Date().toISOString() }));

app.post('/api/invites', requireApiAuth, (req,res) => {
  const { familyId, archive, expiresAt = null, maxUses = 1 } = req.body || {};
  if (!familyId || !archive || !validateArchive(archive) || archive.family.id !== familyId) return res.status(400).json({ error:'Invalid invite payload', requestId:req.requestId });
  const data = ensureStore(load());
  const code = secureCode();
  data.invites[code] = { code, familyId, archive, createdAt:new Date().toISOString(), expiresAt, maxUses: Math.max(1, Math.min(Number(maxUses) || 1, 10)), uses:0 };
  save(data); res.json({ ok:true, code, familyId, expiresAt, maxUses:data.invites[code].maxUses });
});
app.get('/api/invites/:code', (req,res) => {
  const data = ensureStore(load()); const invite = data.invites[normalize(req.params.code)];
  if (!invite) return res.status(404).json({ error:'Invite not found' });
  if (invite.expiresAt && Date.now() > new Date(invite.expiresAt).getTime()) return res.status(410).json({ error:'Invite expired' });
  if (Number(invite.uses || 0) >= Number(invite.maxUses || 1)) return res.status(410).json({ error:'Invite already used' });
  invite.uses = Number(invite.uses || 0) + 1; save(data);
  res.json({ ok:true, code:invite.code, familyId:invite.familyId, archive:invite.archive, expiresAt:invite.expiresAt });
});
app.delete('/api/invites/:code', requireApiAuth, (req,res) => { const data=ensureStore(load()); delete data.invites[normalize(req.params.code)]; save(data); res.json({ ok:true }); });

app.get('/api/families/:familyId/snapshot', requireApiAuth, (req,res) => {
  const data = ensureStore(load()); const key = familyKey(req.params.familyId); const record = data.families[key];
  if (!record) return res.status(404).json({ error:'Family snapshot not found', requestId:req.requestId });
  return res.json({ ok:true, familyId:key, revision:record.revision, updatedAt:record.updatedAt, archive:record.archive });
});
app.put('/api/families/:familyId/snapshot', requireApiAuth, (req,res) => {
  const key = familyKey(req.params.familyId); const archive = req.body?.archive;
  if (!key || !validateArchive(archive) || archive.family.id !== key) return res.status(400).json({ error:'Invalid family snapshot', requestId:req.requestId });
  const data = ensureStore(load()); const previous = data.families[key];
  const revision = Number(previous?.revision || 0) + 1; const updatedAt = new Date().toISOString();
  data.families[key] = { familyId:key, revision, updatedAt, archive }; save(data);
  return res.json({ ok:true, familyId:key, revision, updatedAt });
});
app.delete('/api/families/:familyId/snapshot', requireApiAuth, (req,res) => {
  const data = ensureStore(load()); const key = familyKey(req.params.familyId); delete data.families[key]; save(data); return res.json({ ok:true });
});

app.get('/api/status', requireApiAuth, (_req,res) => res.json({ ok:true, appVersion:APP_VERSION, dataFile:FILE, time:new Date().toISOString() }));
app.listen(PORT, () => console.log(`BONGSHOKOTHA sync server listening on http://0.0.0.0:${PORT}`));
