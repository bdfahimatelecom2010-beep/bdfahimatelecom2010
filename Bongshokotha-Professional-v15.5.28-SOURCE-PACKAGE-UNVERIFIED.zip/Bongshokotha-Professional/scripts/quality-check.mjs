import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const required = [
 'package.json','src/App.tsx','src/context/GenealogyContext.tsx','src/context/ThemeRegistry.tsx',
 'src/services/storage.ts','src/types/genealogy.ts','src/engine/generationEngine.ts',
 'src/engine/relationshipEngine.ts','src/engine/validationEngine.ts','src/engine/ocrEngine.ts',
 'src/components/MemberModal.tsx','src/components/MemberProfileModal.tsx','src/components/FamilyTreeView.tsx',
 'src/components/FamilyArchiveView.tsx','src/components/FamilyBookView.tsx','src/components/ImportExportView.tsx',
 'src/components/SettingsView.tsx','src/components/AdminCenterView.tsx','src/components/FamilyHubView.tsx','src/components/RecycleBinView.tsx','src/services/googleDriveBackup.ts','src/services/syncClient.ts','src/services/serverRegistry.ts','server/sync-server.mjs','src/components/LoginView.tsx','src/services/security.ts','src/services/authRbac.ts','src/components/Sidebar.tsx','src/theme/themeEngine.ts','src/index.css','src/components/DashboardView.tsx'
];
for (const f of required) if (!fs.existsSync(path.join(root,f))) throw new Error(`Missing required source: ${f}`);
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
if (!/^\d+\.\d+\.\d+$/.test(pkg.version)) throw new Error('Unexpected package version');
const types=fs.readFileSync(path.join(root,'src/types/genealogy.ts'),'utf8');
for (const token of ['profilePhoto','memberDocuments','paternalGrandfatherId','paternalGrandmotherId','maternalGrandfatherId','maternalGrandmotherId','birthOrder','generationMode','educationHistory','professionHistory','residenceHistory','evidenceReferences','familyOriginStory','memorialStory']) if (!types.includes(token)) throw new Error(`Missing model capability: ${token}`);
const memberModal=fs.readFileSync(path.join(root,'src/components/MemberModal.tsx'),'utf8');
for (const token of ['childGenderDrafts','paternalGrandfatherFromFather','maternalGrandfatherFromMother',"maritalStatus === 'unmarried'"]) if (!memberModal.includes(token)) throw new Error(`Relationship editor safeguard missing: ${token}`);
const profile=fs.readFileSync(path.join(root,'src/components/MemberProfileModal.tsx'),'utf8');
for (const token of ['সদস্য পরিচিতি ও মৌলিক তথ্য','সদস্যের ছবি ও ডকুমেন্ট','দাদা-দাদি ও নানা-নানি','বিবাহভিত্তিক সন্তান (জন্মক্রম অনুসারে)','identityDocs','memberDocuments']) if (!profile.includes(token)) throw new Error(`Profile capability missing: ${token}`);
const admin=fs.readFileSync(path.join(root,'src/components/AdminCenterView.tsx'),'utf8');
for (const token of ['এ্যাডমিন ও রোলস','Gmail Backup ও Share','Server ও Sync','Contributor Proposals','Data Integrity ও Repair','Audit ও Activity Log','Role Menu Management']) if (!admin.includes(token)) throw new Error(`Admin capability missing: ${token}`);
const hub=fs.readFileSync(path.join(root,'src/components/FamilyHubView.tsx'),'utf8');
for (const token of ['নতুন বংশ','ডেমো বংশ','শেয়ার করা বংশ গ্রহণ করুন','Join Code','QR Code']) if (!hub.includes(token)) throw new Error(`Family Hub capability missing: ${token}`);
const login=fs.readFileSync(path.join(root,'src/components/LoginView.tsx'),'utf8');
for (const token of ['নিরাপদ লগইন','Create Family Account','isSessionAuthenticated','Sign in']) if (!login.includes(token)) throw new Error(`Login capability missing: ${token}`);
const storage=fs.readFileSync(path.join(root,'src/services/storage.ts'),'utf8');
if (!storage.includes('familyId')) throw new Error('Family isolation field missing from storage');
if (!storage.includes('IndexedDB copy is intact')) throw new Error('Durable storage fallback safeguard missing');
if (!storage.includes('Legacy records without familyId are safe to migrate only when exactly one family exists')) throw new Error('Legacy family isolation migration safeguard missing');
const theme=fs.readFileSync(path.join(root,'src/theme/themeEngine.ts'),'utf8');
if (!theme.includes("dataset.themeMode")) throw new Error('Theme mode synchronization missing');
const generation=fs.readFileSync(path.join(root,'src/engine/generationEngine.ts'),'utf8');
for (const token of [
  "member.marriageOrigin || member.birthOrigin === 'joined_by_marriage'",
  "wife.marriageOrigin || wife.birthOrigin === 'joined_by_marriage'",
  "husband.marriageOrigin || husband.birthOrigin === 'joined_by_marriage'",
  "married-in person's biological parents",
  "child = Gen 5, parents = Gen 4, spouse = Gen 5"
]) if (!generation.includes(token)) throw new Error(`Generation regression safeguard missing: ${token}`);
console.log(`QUALITY PASS: ${required.length} required source contracts verified.`);

const recycle=fs.readFileSync(path.join(root,'src/components/RecycleBinView.tsx'),'utf8');
for (const token of ['মুছে ফেলা রেকর্ড','পুনরুদ্ধার','Permanent Delete','Empty Recycle Bin']) if (!recycle.includes(token)) throw new Error(`Recycle Bin capability missing: ${token}`);

const sync=fs.readFileSync(path.join(root,'server/sync-server.mjs'),'utf8');
for (const token of ['/api/invites','/health','BONGSHOKOTHA sync']) if (!sync.includes(token)) throw new Error(`Sync server capability missing: ${token}`);

const sidebar=fs.readFileSync(path.join(root,'src/components/Sidebar.tsx'),'utf8');
const app=fs.readFileSync(path.join(root,'src/App.tsx'),'utf8');
if (!sidebar.includes("'print-export'") || !app.includes("activeTab === 'print-export'") || !app.includes('<PrintExportView')) throw new Error('Print/Publication feature is not reachable from the main UI');
const dashboard=fs.readFileSync(path.join(root,'src/components/DashboardView.tsx'),'utf8');
for (const token of ['dashboardWidgets','dashboardWidgetOrder','dashboardLayout','Profile Completeness','Upcoming Dates']) if (!dashboard.includes(token)) throw new Error(`Dashboard capability missing: ${token}`);
const settings=fs.readFileSync(path.join(root,'src/components/SettingsView.tsx'),'utf8');
for (const token of ['dashboardWidgetOrder','dashboardLayout','Reset Dashboard Defaults','116 HD Premium Themes']) if (!settings.includes(token)) throw new Error(`Dashboard/theme settings capability missing: ${token}`);
if ((theme.match(/\bid:\s*['\"][^'\"]+['\"]/g) || []).length < 112) throw new Error('Theme catalog must contain at least 72 themes');
if (!profile.includes('member.birth?.date?.month == null ? undefined : Number(member.birth.date.month)') || !profile.includes('member.birth?.date?.day == null ? undefined : Number(member.birth.date.day)')) throw new Error('Nullable birth date normalization missing');
const memberModel=fs.readFileSync(path.join(root,'src/types/genealogy.ts'),'utf8');
for (const token of ['computedGeneration','dashboardWidgets','dashboardWidgetOrder','dashboardLayout']) if (!memberModel.includes(token)) throw new Error(`Persistence field missing: ${token}`);
