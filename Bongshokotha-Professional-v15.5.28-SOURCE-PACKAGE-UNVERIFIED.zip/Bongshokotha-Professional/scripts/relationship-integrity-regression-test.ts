import { getCanonicalChildren, getCanonicalChildrenForMarriage, getCanonicalSiblings, reconcileCanonicalRelationships } from '../src/engine/relationshipIntegrity';
import { calculateGenerations, getMemberChildren } from '../src/engine/generationEngine';

const base = (id: string, gender: any, extra: any = {}) => ({
  id, familyId:'f1', fullName:id, banglaName:id, englishName:id, gender,
  isLiving:true, birthOrigin:'born_in_family', marriageOrigin:false, branchId:'b1',
  birth:{date:{precision:'unknown'},place:{}}, death:{isDeceased:false}, identityDocs:{verificationStatus:'unverified'},
  marriageIds:[], isUnmarried:true, createdAt:'2026-01-01', updatedAt:'2026-01-01', ...extra
});

const father=base('father','male');
const mother1=base('mother1','female');
const mother2=base('mother2','female');
const child1=base('child1','male',{fatherId:'father',motherId:'mother1',birthOrder:1});
const child2=base('child2','female',{fatherId:'father',motherId:'mother2',birthOrder:2});
const child3=base('child3','male',{fatherId:'father',motherId:'mother1',birthOrder:3});
const spouseChildUnknown=base('child4','female');
const members=[father,mother1,mother2,child1,child2,child3,spouseChildUnknown];
const m1:any={id:'m1',familyId:'f1',serialNumber:'MR-001',husbandId:'father',wifeId:'mother1',marriageDate:{precision:'unknown'},marriagePlace:{},status:'divorced',childrenIds:['child1','child3','child1'],createdAt:'',updatedAt:''};
const m2:any={id:'m2',familyId:'f1',serialNumber:'MR-002',husbandId:'father',wifeId:'mother2',marriageDate:{precision:'unknown'},marriagePlace:{},status:'current',childrenIds:['child2','child1'],createdAt:'',updatedAt:''};

const childrenM1=getCanonicalChildrenForMarriage(m1,members);
if (!childrenM1.some(x=>x.id==='child1') || !childrenM1.some(x=>x.id==='child3') || childrenM1.some(x=>x.id==='child2')) throw new Error('Marriage 1 leaked marriage-2 child');
const childrenM2=getCanonicalChildrenForMarriage(m2,members);
if (!childrenM2.some(x=>x.id==='child2') || childrenM2.some(x=>x.id==='child1')) throw new Error('Marriage 2 accepted conflicting child');

const fatherChildren=getCanonicalChildren('father',members,[m1,m2]).map(x=>x.id).sort();
if (fatherChildren.join(',')!=='child1,child2,child3') throw new Error(`Canonical father children wrong: ${fatherChildren}`);

const sib=getCanonicalSiblings('child1',members,[m1,m2]);
if (!sib.fullSiblings.some(x=>x.id==='child3')) throw new Error('Full sibling derivation failed');
if (sib.fullSiblings.some(x=>x.id==='child2')) throw new Error('Half sibling incorrectly classified as full');
if (!sib.halfSiblings.some(x=>x.id==='child2')) throw new Error('Half sibling derivation failed');

const reconciled=reconcileCanonicalRelationships(members,[m1,m2]);
if (!reconciled.marriages.find(x=>x.id==='m1')?.childrenIds.includes('child3')) throw new Error('Repair lost valid child');
if (!reconciled.marriages.find(x=>x.id==='m2')?.childrenIds.includes('child1')) throw new Error('Repair incorrectly deleted conflicting evidence');
if (!reconciled.conflicts.length) throw new Error('Expected marriage-child conflict to be retained for review');

const gen=calculateGenerations(reconciled.members,reconciled.marriages,'father');
if (gen.get('father')!==1 || gen.get('child1')!==2 || gen.get('child2')!==2) throw new Error('Generation calculation failed on multi-marriage tree');

const grouped=getMemberChildren('father',reconciled.members,reconciled.marriages);
const g1=grouped.find(x=>x.marriageId==='m1')?.children.map(x=>x.id).sort().join(',');
const g2=grouped.find(x=>x.marriageId==='m2')?.children.map(x=>x.id).sort().join(',');
if (g1!=='child1,child3' || g2!=='child2') throw new Error(`Marriage grouping failed: ${g1} / ${g2}`);

console.log('RELATIONSHIP INTEGRITY PASS: parent/child reciprocity, multi-marriage isolation, marriage-specific children, siblings and generation regression verified.');
