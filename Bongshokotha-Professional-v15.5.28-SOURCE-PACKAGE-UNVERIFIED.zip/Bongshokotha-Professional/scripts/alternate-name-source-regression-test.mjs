import fs from 'node:fs';
const types=fs.readFileSync('src/types/genealogy.ts','utf8');
const form=fs.readFileSync('src/components/MemberModal.tsx','utf8');
const checks=[
 ['Member model stores source-labeled alternate names',types.includes('alternativeNameRecords?: Array<{ id: string; name: string; language:') && types.includes('sourceType?: string')],
 ['Alternate name source field is editable',form.includes('alternativeNameSources') && form.includes('নথি/উৎস')],
 ['Source rows parse name, source type, reference and note',form.includes("line.split('|').map(v => v.trim())") && form.includes('sourceReference: parts[2]') && form.includes('note: parts[3]')],
 ['Alternate name source records load when editing',form.includes('setAlternativeNameSources((memberToEdit.alternativeNameRecords || [])')],
 ['Legacy alternate name arrays remain supported',form.includes('alternativeBanglaNames: alternativeNames.split') && form.includes('alternativeEnglishNames: alternativeEnglishNames.split')]
];
let fail=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} | ${name}`); if(!ok)fail++;}
if(fail)process.exit(1); console.log(`ALTERNATE NAME SOURCE REGRESSION: ${checks.length}/${checks.length} PASS`);
