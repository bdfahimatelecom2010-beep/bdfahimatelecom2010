import fs from 'node:fs';
const parserSource = fs.readFileSync('src/engine/ocrFieldParser.ts', 'utf8');
const engineSource = fs.readFileSync('src/engine/ocrEngine.ts', 'utf8');
const sample = `গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
জাতীয় পরিচয়পত্র / National ID Card
নাম
নেছা
Name
SOBURON NESSA
আঃ আজিজ গাজী
আছিয়া বেগম
Date of Birth 10 May 1962
NID No.
820 337 6192
ঠিকানা: বাসা/হোল্ডিং: --, গ্রাম/রাস্তা: পর ডাংগা, ডাকঘর: --, পৌরসভা: টুঙ্গিপাড়া, উপজেলা: টুঙ্গিপাড়া পৌরসভা, গোপালগঞ্জ ১২১
I<BGD820337619<27<<<<<<<<<<<<<`;

const checks = [
  ['NID MRZ is parsed separately from passport MRZ', parserSource.includes("documentKind === 'nid'") && parserSource.includes('I<BGD') && parserSource.includes("documentKind === 'passport' && passportMrzIndexes.length")],
  ['Standalone/inline NID labels are supported', parserSource.includes('valueAfterLabel') && parserSource.includes('নাম')],
  ['NID front/back side detection exists', parserSource.includes('detectSide') && parserSource.includes("return 'front'") && parserSource.includes("return 'back'")],
  ['OCR uses sparse-text PSM 11', engineSource.includes("tessedit_pageseg_mode: '11'")],
  ['NID focused identity/address second pass exists', engineSource.includes('prepareNidFocusedSources')],
  ['NID focused pass can run when title OCR fails but MRZ/title signal exists', engineSource.includes('hasNidSignal') && engineSource.includes('/I\\s*<\\s*BGD')],
  ['Parser test sample is NID', /জাতীয় পরিচয়পত্র/.test(sample)],
  ['Parser source contains date extraction', parserSource.includes('dateOfBirth')],
  ['Parser source contains father/mother extraction', parserSource.includes('fatherName') && parserSource.includes('motherName') && parserSource.includes('parentInline') && parserSource.includes('পিতাঃ') && parserSource.includes('মাতাঃ')],
  ['Parser source contains structured address extraction', parserSource.includes('postalCode') && parserSource.includes('upazila') && parserSource.includes('district')],
  ['Passport MRZ is explicitly P< gated', parserSource.includes("/^P</") && parserSource.includes('mrz2.slice(0, 9)')],
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
if (checks.some(([, ok]) => !ok)) process.exit(1);
console.log(`NID OCR SOURCE REGRESSION PASS: ${checks.length}/${checks.length}`);
