import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
const context = read('src/context/GenealogyContext.tsx');
const modal = read('src/components/MemberModal.tsx');
const checks = [
  ['import normalizes members and marriages', context.includes('rawImportedMembers.map((m, index) =>') && context.includes('normalizeMarriageRecord(m)')],
  ['missing legacy IDs get deterministic import IDs', context.includes('stableLegacyId(m, index, \'legacy\')')],
  ['duplicate non-empty imported member IDs fail closed', context.includes('ব্যাকআপে একই Unique ID একাধিক সদস্যের জন্য আছে')],
  ['import result reports generated IDs', context.includes('নতুন ID তৈরি: ${importedMembersMissingId}')],
  ['child candidates use exact target generation', modal.includes('relationCandidates(childTargetGeneration, [\'male\', \'female\', \'other\', \'unknown\'], childIds, false, true)')],
  ['existing child row displays gender label', modal.includes("child.gender === 'male' ? 'পুত্র' : child.gender === 'female' ? 'কন্যা'")],
  ['unmarried child form is hidden unless linked data exists', modal.includes("(maritalStatus !== 'unmarried' || spouseIds.length > 0 || childIds.length > 0) && <div className=\"mt-4 rounded-2xl border border-emerald-200")],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`); if (!ok) failed++; }
if (failed) process.exit(1);
console.log(`IMPORT ID + CHILD UI REGRESSION PASS: ${checks.length}/${checks.length}`);
