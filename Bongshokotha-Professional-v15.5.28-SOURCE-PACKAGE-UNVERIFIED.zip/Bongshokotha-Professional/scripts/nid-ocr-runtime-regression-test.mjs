import { parseDocumentFields } from '../src/engine/ocrFieldParser.ts';
const sample = `গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
জাতীয় পরিচয়পত্র / National ID Card
নাম
নেছা
Name
SOBURON NESSA
আঃ আজিজ গাজী
আছিয়া বেগম
Date of Birth 10 May 1962
NID No.
820 337 6192
ঠিকানা: বাসা/হোল্ডিং: --, গ্রাম/রাস্তা: পর ডাংগা, ডাকঘর: --, পৌরসভা: টুঙ্গিপাড়া, উপজেলা: টুঙ্গিপাড়া পৌরসভা, গোপালগঞ্জ ১২১
Blood Group: Place of Birth: GOPALGANJ issue Date: 02 Nov 2017
I<BGD820337619<27<<<<<<<<<<<<<`;
const r=parseDocumentFields(sample,90);
const checks=[
 ['document kind is NID',r.documentKind==='nid'],
 ['no false passport number from NID MRZ',!r.passportNumber],
 ['English name extracted',r.fullNameEn==='SOBURON NESSA'],
 ['Bangla name extracted',r.fullNameBn==='নেছা'],
 ['DOB extracted',r.dateOfBirth==='10 May 1962'],
 ['NID extracted',r.nidNumber==='8203376192'],
 ['father extracted',r.fatherName==='আঃ আজিজ গাজী'],
 ['mother extracted',r.motherName==='আছিয়া বেগম'],
 ['inline father label extracted',parseDocumentFields('জাতীয় পরিচয়পত্র\nনাম: নাজমা\nName: NAZMA\nপিতা: মোঃ রহিম\nমাতা: রোকেয়া\nDate of Birth 12 Mar 1985').fatherName==='মোঃ রহিম'],
 ['inline mother label extracted',parseDocumentFields('জাতীয় পরিচয়পত্র\nনাম: নাজমা\nName: NAZMA\nপিতা: মোঃ রহিম\nমাতা: রোকেয়া\nDate of Birth 12 Mar 1985').motherName==='রোকেয়া'],
 ['address extracted',Boolean(r.address && r.address.includes('টুঙ্গিপাড়া'))],
];
for(const [n,ok] of checks) console.log(`${ok?'PASS':'FAIL'} | ${n}`);
if(checks.some(([,ok])=>!ok)) process.exit(1);
console.log(`NID OCR RUNTIME REGRESSION PASS: ${checks.length}/${checks.length}`);
