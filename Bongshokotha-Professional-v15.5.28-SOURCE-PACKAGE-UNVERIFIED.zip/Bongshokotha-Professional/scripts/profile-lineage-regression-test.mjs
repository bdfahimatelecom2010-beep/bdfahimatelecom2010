import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const modal = fs.readFileSync(path.join(root, 'src/components/MemberModal.tsx'), 'utf8');
const profile = fs.readFileSync(path.join(root, 'src/components/MemberProfileModal.tsx'), 'utf8');
const generation = fs.readFileSync(path.join(root, 'src/engine/generationEngine.ts'), 'utf8');
const checks = [
  ['generation dropdown', modal.includes("Generation *") && modal.includes("generationMode === 'automatic'")],
  ['gender-filtered father', modal.includes("potentialFathers = relationCandidates") && modal.includes("['male']")],
  ['gender-filtered mother', modal.includes("potentialMothers = relationCandidates") && modal.includes("['female']")],
  ['generation-filtered spouse', modal.includes('potentialSpouses = relationCandidates(relationshipTargetGeneration, spouseGenders')],
  ['gender-filtered children', modal.includes('childGenderFilter') && modal.includes('filteredPotentialChildren')],
  ['grandparent links', modal.includes('potentialPaternalGrandfathers') && modal.includes('potentialMaternalGrandmothers')],
  ['in-law links', modal.includes('potentialInLawMen') && modal.includes('potentialInLawWomen')],
  ['profile hides serial', !profile.includes('Personal Serial Number') && !profile.includes("member.serialNumber || '—'")],
  ['profile generation mode', profile.includes('generationMode === \'manual\'') && profile.includes('Automatic generation')],
  ['profile completeness', profile.includes('profileCompletion') && profile.includes('Profile Information Summary')],
  ['grandparent derivation', generation.includes('export function getGrandparents')],
  ['manual generation safety', generation.includes('generationMode === \'manual\'')],
];
const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  for (const [name] of failed) console.error(`FAIL: ${name}`);
  process.exit(1);
}
console.log(`PROFILE + LINEAGE REGRESSION PASS: ${checks.length}/${checks.length}`);
