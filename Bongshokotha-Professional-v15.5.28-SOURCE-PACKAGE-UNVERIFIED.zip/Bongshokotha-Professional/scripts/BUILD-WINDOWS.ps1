$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
Write-Host '=== BONGSHOKOTHA WINDOWS BUILD ===' -ForegroundColor Cyan
npm.cmd install
npm.cmd run prepare:ocr
npm.cmd run verify
npm.cmd run desktop:build
Write-Host 'WINDOWS BUILD PASSED' -ForegroundColor Green
