import { calculateGenerations } from '../src/engine/generationEngine';
import type { Member, MarriageRecord } from '../src/types/genealogy';
import { getCanonicalGenealogyOrder } from '../src/engine/genealogyOrdering';

const now = new Date().toISOString();
const member = (id: string, extra: Partial<Member> = {}): Member => ({
  id,
  fullName: id,
  banglaName: id,
  englishName: id,
  gender: 'other',
  isLiving: true,
  birthOrigin: 'born_in_family',
  marriageOrigin: false,
  branchId: 'branch-main',
  birth: { date: { precision: 'unknown' }, place: {} },
  death: { isDeceased: false, date: { precision: 'unknown' } },
  identityDocs: { verificationStatus: 'unverified' },
  marriageIds: [],
  isUnmarried: false,
  createdAt: now,
  updatedAt: now,
  ...extra
});

const marriage = (id: string, husbandId: string, wifeId: string, childrenIds: string[] = []): MarriageRecord => ({
  id,
  serialNumber: id,
  husbandId,
  wifeId,
  marriageDate: { precision: 'unknown' },
  marriagePlace: {},
  status: 'current',
  childrenIds,
  createdAt: now,
  updatedAt: now
});

// Family chain: root(1) -> gen2 -> gen3 -> father(4) -> child(5).
// The child's mother has her own biological parents in the dataset, but is
// married-in and therefore must display at the father's generation (4).
// The child's wife also has biological parents, but must display at gen5.
const members: Member[] = [
  member('root'),
  member('gen2', { fatherId: 'root' }),
  member('gen3', { fatherId: 'gen2' }),
  member('paternal-gp-missing-parent', { fatherId: 'gen2' }),
  member('father', { fatherId: 'gen3' }),
  member('mother-parent', { fatherId: 'root' }),
  member('mother', {
    fatherId: 'mother-parent',
    birthOrigin: 'joined_by_marriage',
    marriageOrigin: true,
    gender: 'female'
  }),
  member('child', { fatherId: 'father', motherId: 'mother' }),
  member('wife-parent', { fatherId: 'root' }),
  member('wife', {
    fatherId: 'wife-parent',
    birthOrigin: 'joined_by_marriage',
    marriageOrigin: true,
    gender: 'female'
  })
];

const marriages: MarriageRecord[] = [
  marriage('mar-father-mother', 'father', 'mother', ['child']),
  marriage('mar-child-wife', 'child', 'wife')
];

const generations = calculateGenerations(members, marriages, 'root');
const expected: Record<string, number> = {
  root: 1,
  gen2: 2,
  gen3: 3,
  father: 4,
  mother: 4,
  child: 5,
  wife: 5
};

for (const [id, expectedGeneration] of Object.entries(expected)) {
  const actual = generations.get(id);
  if (actual !== expectedGeneration) {
    throw new Error(`Generation regression failed for ${id}: expected ${expectedGeneration}, got ${actual}`);
  }
}

console.log('GENERATION REGRESSION PASS: parents/spouses align correctly (4/5/5).');
// Grandparent-link recovery: parent has no parent links, child explicitly records
// both paternal grandparents. The engine should infer parent = grandparent + 1
// and child = grandparent + 2.
const gpMembers: Member[] = [
  member('gp-root', { gender: 'male' }),
  member('gp-spouse', { gender: 'female' }),
  member('incomplete-parent', { gender: 'male' }),
  member('gp-child', { fatherId: 'incomplete-parent', paternalGrandfatherId: 'gp-root', paternalGrandmotherId: 'gp-spouse' })
];
const gpGenerations = calculateGenerations(gpMembers, [], 'gp-root');
if (gpGenerations.get('incomplete-parent') !== 2 || gpGenerations.get('gp-child') !== 3) {
  throw new Error(`Grandparent generation recovery failed: parent=${gpGenerations.get('incomplete-parent')}, child=${gpGenerations.get('gp-child')}`);
}
console.log('GRANDPARENT GENERATION RECOVERY PASS: parent=2, child=3.');



// Canonical branch-order regression: elder sibling branch must be fully exhausted
// before the next sibling branch begins. A married-in spouse follows the member
// they married and never uses the spouse's own birthOrder to change branch order.
const branchMembers: Member[] = [
  member('chan-mia', { birthOrder: 1 }),
  member('abul-hashem', { birthOrder: 1, fatherId: 'chan-mia' }),
  member('noabali', { birthOrder: 2, fatherId: 'chan-mia' }),
  member('kabir', { birthOrder: 3, fatherId: 'chan-mia' }),
  member('aminur', { birthOrder: 1, fatherId: 'abul-hashem' }),
  member('mizanur', { birthOrder: 2, fatherId: 'abul-hashem' }),
  member('mukul', { birthOrder: 3, fatherId: 'abul-hashem' }),
  member('aminur-child', { birthOrder: 1, fatherId: 'aminur' }),
  member('mizanur-child', { birthOrder: 1, fatherId: 'mizanur' }),
  member('mukul-child', { birthOrder: 1, fatherId: 'mukul' }),
  member('abul-spouse', { birthOrder: 99, birthOrigin: 'joined_by_marriage', marriageOrigin: true, gender: 'female' })
];
const branchMarriages: MarriageRecord[] = [
  marriage('mar-abul', 'abul-hashem', 'abul-spouse', ['aminur', 'mizanur', 'mukul'])
];
const branchOrder = getCanonicalGenealogyOrder(branchMembers, branchMarriages);
const expectedBranchOrder = [
  'chan-mia',
  'abul-hashem',
  'abul-spouse',
  'aminur',
  'aminur-child',
  'mizanur',
  'mizanur-child',
  'mukul',
  'mukul-child',
  'noabali',
  'kabir'
];
if (JSON.stringify(branchOrder) !== JSON.stringify(expectedBranchOrder)) {
  throw new Error(`CANONICAL BRANCH ORDER FAILED: ${JSON.stringify(branchOrder)}`);
}
console.log('CANONICAL BRANCH ORDER PASS: elder branch completes before next sibling (11/11).');


// Additional canonical invariants: married-in spouse aligns with spouse; spouse parents do not pull them into birth line.
{
  const root: any = { id:'g-root', fullName:'Root', banglaName:'Root', englishName:'Root', gender:'male', birthOrigin:'born_in_family', marriageOrigin:false, fatherId:undefined, motherId:undefined, branchId:'b', isLiving:true, birth:{date:{precision:'unknown'},place:{fullAddress:''}}, death:{isDeceased:false} };
  const child: any = { ...root, id:'g-child', fullName:'Child', fatherId:'g-root', birthOrigin:'born_in_family' };
  const spouseParent: any = { ...root, id:'g-sp-parent', fullName:'Spouse Parent' };
  const spouse: any = { ...root, id:'g-spouse', fullName:'Spouse', gender:'female', birthOrigin:'joined_by_marriage', marriageOrigin:true, fatherId:'g-sp-parent' };
  const grand: any = { ...root, id:'g-grand', fullName:'Grand', fatherId:'g-child', birthOrigin:'born_in_family' };
  const ms: any[] = [{id:'gm1',familyId:'f',serialNumber:'1',husbandId:'g-child',wifeId:'g-spouse',childrenIds:['g-grand'],status:'current',marriageDate:{precision:'unknown'},marriagePlace:{fullAddress:''}}];
  const map = calculateGenerations([root,child,spouseParent,spouse,grand], ms, 'g-root');
  if (map.get('g-root') !== 1 || map.get('g-child') !== 2 || map.get('g-spouse') !== 2 || map.get('g-grand') !== 3) throw new Error('Canonical generation invariant failed');
}
