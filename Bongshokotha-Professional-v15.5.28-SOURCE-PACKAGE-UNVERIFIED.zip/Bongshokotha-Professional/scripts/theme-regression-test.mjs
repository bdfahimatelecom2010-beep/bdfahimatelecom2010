import fs from 'node:fs';

const source = fs.readFileSync(new URL('../src/theme/themeEngine.ts', import.meta.url), 'utf8');
const start = source.indexOf('export const BONGSHO_THEMES');
const end = source.indexOf('];', start);
if (start < 0 || end < 0) throw new Error('Theme registry not found');
const block = source.slice(start, end);
const themes = [...block.matchAll(/\bid:\s*['"]([^'"]+)['"]/g)].map(m => m[1]);
const required = ['primary','primaryHover','accent','bg','surface','card','text','textMuted','border','ring'];
const duplicateIds = themes.filter((id, i) => themes.indexOf(id) !== i);
if (themes.length !== 116) throw new Error(`THEME COUNT FAIL: expected 116, found ${themes.length}`);
if (new Set(themes).size !== 116) throw new Error(`THEME ID FAIL: duplicate IDs found: ${[...new Set(duplicateIds)].join(', ')}`);
for (const key of required) {
  const count = [...block.matchAll(new RegExp(`\\b${key}\\s*:`,'g'))].length;
  if (count < 116) throw new Error(`THEME TOKEN FAIL: ${key} appears only ${count} times`);
}
console.log('THEME REGRESSION PASS: 116 unique themes and required core color tokens are present.');
