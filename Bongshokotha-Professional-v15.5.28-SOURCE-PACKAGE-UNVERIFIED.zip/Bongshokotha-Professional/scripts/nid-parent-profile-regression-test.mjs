import fs from 'node:fs';
const type=fs.readFileSync('src/types/genealogy.ts','utf8');
const modal=fs.readFileSync('src/components/MemberModal.tsx','utf8');
const profile=fs.readFileSync('src/components/MemberProfileModal.tsx','utf8');
const parser=fs.readFileSync('src/engine/ocrFieldParser.ts','utf8');
const checks=[
 ['Member stores unmatched biological father name',type.includes('fatherNameBn?: string')],
 ['Member stores unmatched biological mother name',type.includes('motherNameBn?: string')],
 ['English parent names are optional',type.includes('fatherNameEn?: string')&&type.includes('motherNameEn?: string')],
 ['Edit UI has father biological name fields',modal.includes('পিতার নাম (বাংলা)')&&modal.includes('Father Name (English')],
 ['Edit UI has mother biological name fields',modal.includes('মাতার নাম (বাংলা)')&&modal.includes('Mother Name (English')],
 ['OCR apply preserves unmatched father',modal.includes('setFatherNameBn(String(fatherName))')],
 ['OCR apply preserves unmatched mother',modal.includes('setMotherNameBn(String(motherName))')],
 ['Profile renders recorded father name',profile.includes('recordedFatherName')],
 ['Profile renders recorded mother name',profile.includes('recordedMotherName')],
 ['NID parser has inline parent recovery',parser.includes('parentInline')&&parser.includes('পিতাঃ')&&parser.includes('মাতাঃ')]
];
for(const [n,ok] of checks) console.log(`${ok?'PASS':'FAIL'} | ${n}`);
if(checks.some(([,ok])=>!ok)) process.exit(1);
console.log(`NID PARENT PROFILE REGRESSION PASS: ${checks.length}/${checks.length}`);
