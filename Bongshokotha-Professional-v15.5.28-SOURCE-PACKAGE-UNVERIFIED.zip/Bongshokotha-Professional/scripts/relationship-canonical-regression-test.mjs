import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const modal = fs.readFileSync(path.join(root, 'src/components/MemberModal.tsx'), 'utf8');
const profile = fs.readFileSync(path.join(root, 'src/components/MemberProfileModal.tsx'), 'utf8');
const tree = fs.readFileSync(path.join(root, 'src/components/FamilyTreeView.tsx'), 'utf8');
const context = fs.readFileSync(path.join(root, 'src/context/GenealogyContext.tsx'), 'utf8');

const checks = [
  ['updateMember returns persisted member', /updateMember: \(member: Member\) => Promise<Member>/],
  ['spouse list is generation filtered', /potentialSpouses/],
  ['spouse list is gender filtered', /spouseGenders/],
  ['multiple spouses are retained', /spouseIds/],
  ['in-married spouse is not birth-line', /birthOrigin: .*joined_by_marriage/],
  ['child editor remains available even when unmarried', /সন্তানদের নাম/],
  ['existing children are linked to parents', /linkExistingChildrenToParents/],
  ['children are linked to the correct marriage union', /unionChildIds/],
  ['birth-line male/female spouse appears after name in profile', /headerSpouses\.map/],
  ['birth-line male/female spouse appears after name in tree', /member\.birthOrigin === 'born_in_family' && memberMarriages\.length > 0/],
];

const missing = checks.filter(([name, re]) => !re.test(modal) && !re.test(profile) && !re.test(tree) && !re.test(context));
if (missing.length) throw new Error('RELATIONSHIP CANONICAL REGRESSION FAIL: ' + missing.map(x => x[0]).join(', '));
console.log(`RELATIONSHIP CANONICAL REGRESSION PASS: ${checks.length} canonical relationship/display rules verified.`);

const integritySource = fs.readFileSync('src/engine/relationshipIntegrity.ts','utf8');
const relationshipSource = fs.readFileSync('src/engine/relationshipEngine.ts','utf8');
const extraChecks = [
  ['canonical children use deterministic birth ordering', /compareCanonicalChildren/.test(integritySource) && /sort\(compareCanonicalChildren\)/.test(integritySource)],
  ['shared marriage alone is not classified as full sibling', /shared marriage\/union alone is not proof of biological siblinghood/.test(integritySource)],
  ['relationship graph does not synthesize a second parent from marriage child listing', /Parent\/child graph edges are created only from/.test(relationshipSource) && /canonical fatherId\/motherId/.test(relationshipSource)],
];
for (const [name, ok] of extraChecks) console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
if (extraChecks.some(([, ok]) => !ok)) process.exit(1);
console.log(`RELATIONSHIP SAFETY EXTENSIONS PASS: ${extraChecks.length}/${extraChecks.length}`);
