import fs from 'node:fs';
const parser = fs.readFileSync('src/engine/ocrFieldParser.ts','utf8');
const engine = fs.readFileSync('src/engine/ocrEngine.ts','utf8');
const types = fs.readFileSync('src/types/genealogy.ts','utf8');
const checks = [
  ['multi-file OCR batch API exists', engine.includes('runDocumentOcrBatch')],
  ['front/back merge exists', parser.includes('mergeExtractedDocumentFields')],
  ['document side classification exists', parser.includes("documentSide: 'front' | 'back' | 'unknown'") || parser.includes('detectSide')],
  ['structured Bangladesh address fields exist', types.includes('holding?: string') && types.includes('postalCode?: string') && types.includes('union?: string')],
  ['passport personal/issue/expiry/authority fields exist', types.includes('passportPersonalNumber?: string') && types.includes('passportExpiryDate?: string')],
  ['additional extracted fields are preserved', types.includes('additionalFields?: ExtractedFieldCandidate[]') && parser.includes('additionalFields')],
  ['raw unmapped OCR lines are preserved', types.includes('rawUnmappedLines?: string[]')],
  ['extraction conflicts are preserved', types.includes('conflicts?: DocumentExtractionConflict[]') && parser.includes('conflicts.push')],
  ['NID MRZ cannot become passport', parser.includes("documentKind === 'nid'") && parser.includes("documentKind === 'passport' && passportMrzIndexes.length") && !/if\s*\(documentKind\s*===\s*['\"]nid['\"]\)[\s\S]{0,500}passportNumber\s*=/.test(parser)],
  ['profile/archive multi-file source preservation exists', types.includes('sourceFiles?: Array<{ fileName: string')],
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
if (checks.some(([,ok]) => !ok)) process.exit(1);
console.log(`UNIVERSAL OCR SOURCE REGRESSION PASS: ${checks.length}/${checks.length}`);
