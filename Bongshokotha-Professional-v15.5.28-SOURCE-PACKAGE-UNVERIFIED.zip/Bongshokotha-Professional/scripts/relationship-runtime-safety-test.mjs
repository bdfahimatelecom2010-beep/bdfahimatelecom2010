import assert from 'node:assert/strict';
import { buildGenealogyGraph } from '../src/engine/relationshipEngine.ts';
import { getCanonicalSiblings } from '../src/engine/relationshipIntegrity.ts';

const person = (id, gender, extra={}) => ({
  id, fullName:id, banglaName:id, englishName:id, gender,
  isLiving:true, birthOrigin:'born_in_family', marriageOrigin:false,
  branchId:'b', birth:{date:{precision:'unknown'},place:{}}, death:{isDeceased:false},
  identityDocs:{verificationStatus:'unverified'}, marriageIds:[], isUnmarried:true,
  createdAt:'2026-01-01T00:00:00Z', updatedAt:'2026-01-01T00:00:00Z', ...extra
});

const father=person('F','male');
const mother=person('M','female');
const otherMother=person('M2','female');
const child=person('C','male',{fatherId:'F'}); // only one biological parent known
const child2=person('C2','female',{fatherId:'F'});
const adopted=person('A','male',{birthOrigin:'adopted', fatherId:undefined, motherId:undefined});
const members=[father,mother,otherMother,child,child2,adopted];
const marriages=[
  {id:'U1',serialNumber:'U1',husbandId:'F',wifeId:'M',marriageDate:{precision:'unknown'},marriagePlace:{},status:'current',childrenIds:['C'],createdAt:'',updatedAt:''},
  {id:'U2',serialNumber:'U2',husbandId:'F',wifeId:'M2',marriageDate:{precision:'unknown'},marriagePlace:{},status:'current',childrenIds:[],createdAt:'',updatedAt:''},
];
const graph=buildGenealogyGraph(members,marriages);
assert.equal(graph.get('C')?.some(e=>e.targetId==='M' && e.relation==='mother'), false, 'marriage listing must not fabricate mother');
assert.equal(graph.get('C')?.some(e=>e.targetId==='F' && e.relation==='father'), true, 'known father must remain');
const sib=getCanonicalSiblings('A', members, marriages);
assert.equal(sib.fullSiblings.length,0);
assert.equal(sib.halfSiblings.length,0);
console.log('RELATIONSHIP RUNTIME SAFETY PASS: one-parent marriage child does not gain a false parent; adopted child is not misclassified as sibling.');
