import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const assets = [
  ['public/tessdata/ben.traineddata.gz','Bengali'],
  ['public/tessdata/eng.traineddata.gz','English']
];
let pass = 0;
for (const [rel,label] of assets) {
  const file = path.join(root,rel);
  if (fs.existsSync(file) && fs.statSync(file).size > 100000) {
    console.log(`PASS | Offline OCR ${label} model bundled | ${rel}`); pass++;
  } else console.log(`FAIL | Offline OCR ${label} model missing or too small | ${rel}`);
}
if (pass !== assets.length) process.exit(1);
console.log(`OFFLINE OCR ASSET REGRESSION PASS: ${pass}/${assets.length}`);
