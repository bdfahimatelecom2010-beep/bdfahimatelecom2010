import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const modal = fs.readFileSync(path.join(root, 'src/components/MemberModal.tsx'), 'utf8');
const profile = fs.readFileSync(path.join(root, 'src/components/MemberProfileModal.tsx'), 'utf8');
const required = [
  ['multiple spouse state', /spouseIds/],
  ['spouse generation selector', /relationshipGeneration/],
  ['spouse gender filtering', /spouseGenders/],
  ['new spouse quick-add', /quickAddRelatedMember\('spouse'\)/],
  ['child generation selector', /childTargetGeneration/],
  ['child gender filter', /childGenderFilter/],
  ['existing child parent linking', /linkExistingChildrenToParents/],
  ['profile photo persistence', /profilePhoto:/],
  ['live/file photo modal', /AvatarUploadModal/],
  ['father-in-law selector', /fatherInLawId/],
  ['mother-in-law selector', /motherInLawId/],
  ['member document storage', /memberDocuments/],
  ['profile spouse display', /spouseId/],
  ['profile children display', /biologicalChildren/],
  ['birth-line spouse placement', /birthOrigin === 'born_in_family'/],
  ['in-married spouse origin', /birthOrigin: .*joined_by_marriage/],
  ['married status reveals children controls', /maritalStatus !== 'unmarried'/],
  ['new child quick-add', /quickAddRelatedMember\('child'\)/],
];
const missing = required.filter(([, re]) => !re.test(modal) && !re.test(profile));
if (missing.length) throw new Error('RELATIONSHIP UI REGRESSION FAIL: ' + missing.map(x => x[0]).join(', '));
console.log(`RELATIONSHIP UI REGRESSION PASS: ${required.length} member relation/photo/document contracts verified.`);
