import fs from 'node:fs';
const modal=fs.readFileSync('src/components/MemberModal.tsx','utf8');
const profile=fs.readFileSync('src/components/MemberProfileModal.tsx','utf8');
const ocr=fs.readFileSync('src/engine/ocrEngine.ts','utf8');
const parser=fs.readFileSync('src/engine/ocrFieldParser.ts','utf8');
const types=fs.readFileSync('src/types/genealogy.ts','utf8');
const checks=[
 ['child creation returns persisted member', /const child = await addMember/.test(modal) && /created.push\(child\)/.test(modal)],
 ['first created child is captured and parent profile is refreshed after edit', /firstCreatedChildId = createdChildren\[0\]\?\.id/.test(modal) && /profileToReopen = currentMember\?\.id/.test(modal) && /onSavedMemberId\?\.\(profileToReopen\)/.test(modal)],
 ['quick-added child is canonically linked', /fatherIdForChild/.test(modal) && /const linkedChild =/.test(modal) && modal.includes('await updateMember(linkedChild)')],
 ['quick-added child for new parent is retained until parent save', /pendingChildIdsRef/.test(modal) && /pendingIds/.test(modal)],
 ['profile archive stores extracted OCR fields', /extractedFields: ocr\.extractedFields/.test(profile)],
 ['OCR does not auto-write profile fields during upload', /pendingProfileOcr/.test(profile) && /updateMember\(next\)/.test(profile) && /User review required/.test(profile)],
 ['profile has explicit OCR apply workflow', /applyPendingProfileOcr/.test(profile) && /Apply selected fields/.test(profile)],
 ['OCR conflicts are retained as research notes', /OCR conflict\/review/.test(profile)],
 ['OCR apply marks archive verified with history', /ocrVerification: 'verified'/.test(profile) && /ocr_verified/.test(profile)],
 ['multipage PDF is processed', /prepareOcrSources/.test(ocr) && /for \(let pageNumber = 1; pageNumber <= pdf\.numPages/.test(ocr) && /enhancedImages\.length/.test(ocr)],
 ['children names can be extracted as evidence', /childrenNames/.test(parser) && /childrenNames\?: string\[\]/.test(types)],
];
for(const [n,ok] of checks) console.log(`${ok?'PASS':'FAIL'} | ${n}`);
if(checks.some(([,ok])=>!ok)) process.exit(1);
console.log(`CHILD + DOCUMENT DEEP REGRESSION PASS: ${checks.length}/${checks.length}`);
