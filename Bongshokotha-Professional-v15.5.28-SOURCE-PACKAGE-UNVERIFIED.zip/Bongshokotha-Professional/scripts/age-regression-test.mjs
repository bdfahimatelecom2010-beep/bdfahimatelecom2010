import { ageYears } from '../src/engine/ageEngine.ts';
const checks = [
  ['current age after birthday', ageYears({year:1990,month:1,day:1}, new Date(2026,9,3)), 36],
  ['current age before birthday', ageYears({year:1990,month:12,day:1}, new Date(2026,9,3)), 35],
  ['leap day', ageYears({year:2000,month:2,day:29}, new Date(2026,1,28)), 25],
  ['age at death', ageYears({year:1950,month:3,day:10}, new Date(2020,1,20)), 69],
];
for (const [name, actual, expected] of checks) { if (actual !== expected) throw new Error(`${name}: expected ${expected}, got ${actual}`); }
console.log(`AGE REGRESSION PASS: ${checks.length}/${checks.length}`);
