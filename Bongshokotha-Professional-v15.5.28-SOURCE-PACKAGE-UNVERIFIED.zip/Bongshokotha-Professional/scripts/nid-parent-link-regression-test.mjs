import fs from 'node:fs';
const source = fs.readFileSync('src/components/MemberModal.tsx', 'utf8');
const checks = [
  ['OCR extracts father name into reviewable text field', source.includes("if (fatherName) setFatherNameBn(String(fatherName))")],
  ['OCR does not silently assign canonical father relationship', !/const father\s*=\s*findUnique\(fatherName\)[\s\S]{0,100}setFatherId\(father\.id\)/.test(source)],
  ['OCR does not silently assign canonical mother relationship', !/const mother\s*=\s*findUnique\(motherName\)[\s\S]{0,100}setMotherId\(mother\.id\)/.test(source)],
  ['Existing linked parent remains selectable during legacy generation mismatch', source.includes('if (linkedIds.includes(m.id)) return true;')],
  ['Existing-member parent candidates must be from an earlier generation', source.includes('return memberToEdit ? candidateGeneration < currentGeneration : candidateGeneration === targetGeneration;')],
  ['Parent dropdown labels explain previous-generation restriction', source.includes('পূর্ববর্তী প্রজন্মের পুরুষ') && source.includes('পূর্ববর্তী প্রজন্মের নারী')],
  ['OCR relationship application explicitly requires user review', source.includes('the user must explicitly') && source.includes('relationship dropdown')],
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
if (checks.some(([, ok]) => !ok)) process.exit(1);
console.log(`NID PARENT-LINK REGRESSION PASS: ${checks.length}/${checks.length}`);
