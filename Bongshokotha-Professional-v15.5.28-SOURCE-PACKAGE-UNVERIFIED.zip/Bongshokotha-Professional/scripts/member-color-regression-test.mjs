import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = f => fs.readFileSync(path.join(root,f),'utf8');
const color = read('src/engine/memberColor.ts');
const members = read('src/components/MembersView.tsx');
const tree = read('src/components/FamilyTreeView.tsx');
const book = read('src/components/FamilyBookView.tsx');
const profile = read('src/components/MemberProfileModal.tsx');
const search = read('src/components/GlobalSearchModal.tsx');
const context = read('src/context/GenealogyContext.tsx');
const keys = ['living-born-male','deceased-born-male','living-married-male','deceased-married-male','living-born-female','deceased-born-female','living-married-female','deceased-married-female','living-other','deceased-other'];
for (const k of keys) if (!color.includes(`'${k}'`)) throw new Error(`Missing member color key: ${k}`);
for (const token of ['birthOrigin === \'joined_by_marriage\'','marriageOrigin','isLiving','gender === \'male\'','gender === \'female\'']) if (!color.includes(token)) throw new Error(`Missing color rule: ${token}`);
for (const [name, src] of [['MembersView',members],['FamilyTreeView',tree],['FamilyBookView',book],['MemberProfileModal',profile],['GlobalSearchModal',search]]) {
  if (!src.includes('getMemberColor')) throw new Error(`${name} does not use central member color engine`);
}
if (!context.includes('marriagesRef.current = updatedMarriages') || !context.includes('setMarriages(updatedMarriages)')) throw new Error('Marriage state/ref synchronization missing');
if (!/Children grouped by marriage|বিবাহভিত্তিক সন্তান/.test(profile) || !/getCanonicalChildrenForMarriage\(mar/.test(profile)) throw new Error('Marriage-specific child grouping missing');
if (!members.includes('MEMBER_COLOR_LEGEND')) throw new Error('Member color legend missing');
console.log(`MEMBER COLOR REGRESSION PASS: ${keys.length} status colors + central UI integration + marriage-state synchronization verified.`);
