import fs from 'node:fs';
import assert from 'node:assert/strict';
const modal = fs.readFileSync('src/components/MemberModal.tsx', 'utf8');
const profile = fs.readFileSync('src/components/MemberProfileModal.tsx', 'utf8');
const types = fs.readFileSync('src/types/genealogy.ts', 'utf8');
const checks = [
  ['member model stores external father-in-law name', /fatherInLawName\?: string/.test(types)],
  ['member model stores external mother-in-law name', /motherInLawName\?: string/.test(types)],
  ['form exposes father-in-law name field', /শ্বশুরের নাম \(সদস্য না হলেও লিখুন\)/.test(modal)],
  ['form exposes mother-in-law name field', /শাশুড়ির নাম \(সদস্য না হলেও লিখুন\)/.test(modal)],
  ['external in-law names are saved on member', /fatherInLawName: fatherInLawName\.trim\(\)/.test(modal) && /motherInLawName: motherInLawName\.trim\(\)/.test(modal)],
  ['profile reads saved external in-law names', /savedFatherInLawName = member\?\.fatherInLawName/.test(profile) && /savedMotherInLawName = member\?\.motherInLawName/.test(profile)],
  ['address catalogue loads bilingual Bangladesh hierarchy', /bangladesh-geo-json\/bangladesh-geo\.json/.test(modal)],
  ['address catalogue is cached for reuse', /bongshokotha:bd-location-catalog:v1/.test(modal)],
  ['division/district/upazila/union are dropdowns', /\['division','district','upazila','union'\]\.includes\(f\.key\)/.test(modal)],
  ['cascading fields reset lower-level selections', /const clearAfter/.test(modal)],
];
let failures = 0;
for (const [label, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} | ${label}`); if (!ok) failures++; }
console.log(`In-law and address catalogue source checks: ${checks.length - failures}/${checks.length}`);
if (failures) process.exitCode = 1;
