import fs from 'node:fs';

const memberModal = fs.readFileSync('src/components/MemberModal.tsx', 'utf8');
const profile = fs.readFileSync('src/components/MemberProfileModal.tsx', 'utf8');
const app = fs.readFileSync('src/App.tsx', 'utf8');
const parser = fs.readFileSync('src/engine/ocrFieldParser.ts', 'utf8');

const checks = [
  ['Member form exposes saved-child callback', /onSavedMemberId\?: \(id: string\) => void/.test(memberModal)],
  ['New child ID is captured after creation', /firstCreatedChildId = createdChildren\[0\]\?\.id/.test(memberModal)],
  ['Saved child/parent profile refresh callback is wired', /onSavedMemberId\?\.\(profileToReopen\)/.test(memberModal)],
  ['App routes saved child to profile', /onSavedMemberId=\{\(id\) => setInspectingMemberId\(id\)\}/.test(app)],
  ['Profile OCR review state exists', /pendingProfileOcr/.test(profile)],
  ['Profile OCR has explicit apply action', /applyPendingProfileOcr/.test(profile) && /Apply selected fields/.test(profile)],
  ['Profile OCR maps identity/contact/profile fields', /next\.profession = fields\.occupation/.test(profile) && /next\.mobileNumber = fields\.mobileNumber/.test(profile) && /next\.bloodGroup = fields\.bloodGroup/.test(profile)],
  ['OCR parser extracts occupation/contact fields', /occupation/.test(parser) && /mobileNumber/.test(parser) && /bloodGroup/.test(parser)],
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
if (checks.some(([, ok]) => !ok)) process.exit(1);
console.log('CHILD PROFILE + OCR APPLY REGRESSION PASS');
