import fs from 'node:fs';
const read = f => fs.readFileSync(f, 'utf8');
const css = read('src/index.css');
const theme = read('src/theme/themeEngine.ts');
const registry = read('src/context/ThemeRegistry.tsx');
const genealogy = read('src/context/GenealogyContext.tsx');
const app = read('src/App.tsx');
const settings = read('src/components/SettingsView.tsx');
const sidebar = read('src/components/Sidebar.tsx');
const checks = [
  ['Neutral surface bridge exists', css.includes('.bg-stone-50') && css.includes('.bg-stone-900')],
  ['Neutral text bridge exists', css.includes('.text-stone-500') && css.includes('.text-stone-900')],
  ['Brand bridge exists', css.includes('.bg-amber-600') && css.includes('.text-amber-700')],
  ['Dark variant bridge exists', css.includes('html.dark .dark\\:bg-stone-900')],
  ['Theme overlay token exists', theme.includes("--theme-overlay")],
  ['Input tokens exist', theme.includes("--theme-input-bg") && theme.includes("--theme-input-border")],
  ['Family theme event emitted on load', genealogy.includes("bongshokotha:family-theme-changed")],
  ['Theme registry listens to family event', registry.includes("bongshokotha:family-theme-changed")],
  ['Settings persists theme through family setter', settings.includes('themeRegistry.switchTheme(t.id)') && settings.includes('setTheme(t.id)')],
  ['Custom background uses active theme overlay', app.includes('var(--theme-overlay)')],
  ['Semantic status colors are not globally remapped', css.includes('Semantic status colors')],
  ['Print/Publication is reachable from UI', sidebar.includes("'print-export'") && app.includes("activeTab === 'print-export'") && app.includes('<PrintExportView')],
];
const failed = checks.filter(([,ok]) => !ok);
for (const [name,ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
if (failed.length) process.exit(1);
console.log(`UI THEME RUNTIME REGRESSION PASS: ${checks.length}/${checks.length}`);
