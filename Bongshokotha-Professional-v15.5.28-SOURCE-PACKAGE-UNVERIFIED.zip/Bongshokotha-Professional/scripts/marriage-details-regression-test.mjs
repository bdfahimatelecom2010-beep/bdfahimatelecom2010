import fs from 'node:fs';
const type = fs.readFileSync(new URL('../src/types/genealogy.ts', import.meta.url), 'utf8');
const modal = fs.readFileSync(new URL('../src/components/MarriageModal.tsx', import.meta.url), 'utf8');
const profile = fs.readFileSync(new URL('../src/components/MemberProfileModal.tsx', import.meta.url), 'utf8');
const checks = [
  ['marriage model stores separate husband/wife addresses', type.includes('husbandAddress?: LocationInfo') && type.includes('wifeAddress?: LocationInfo')],
  ['marriage model stores both sides’ parents separately', ['husbandFatherName?: string','husbandMotherName?: string','wifeFatherName?: string','wifeMotherName?: string'].every(k=>type.includes(k))],
  ['edit form restores per-marriage address and parent values', ['setHusbandAddress(marriageToEdit.husbandAddress?.fullAddress','setWifeAddress(marriageToEdit.wifeAddress?.fullAddress','setHusbandFatherName(marriageToEdit.husbandFatherName','setWifeMotherName(marriageToEdit.wifeMotherName'].every(k=>modal.includes(k))],
  ['create and edit save each marriage’s separate details', (modal.match(/husbandAddress: husbandAddress\.trim\(\)/g)||[]).length===2 && (modal.match(/wifeFatherName: wifeFatherName\.trim\(\)/g)||[]).length===2],
  ['marriage form exposes all per-marriage fields', ['স্বামীর ঠিকানা','স্ত্রীর ঠিকানা','স্বামীর পিতার নাম','স্বামীর মাতার নাম','স্ত্রীর পিতার নাম','স্ত্রীর মাতার নাম'].every(k=>modal.includes(k))],
  ['member profile displays marriage-specific addresses and parents', profile.includes('mar.husbandAddress?.fullAddress') && profile.includes('mar.wifeAddress?.fullAddress') && profile.includes('mar.husbandFatherName') && profile.includes('mar.wifeMotherName')],
  ['profile displays source context for alternate identity records', profile.includes('member.alternativeNameRecords?.map') && profile.includes('record.sourceType') && profile.includes('record.sourceReference')]
];
let failures=0; for(const [label,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${label}`); if(!ok) failures++;}
if(failures) process.exit(1); console.log(`MARRIAGE DETAILS REGRESSION: PASS ${checks.length}/${checks.length}`);
