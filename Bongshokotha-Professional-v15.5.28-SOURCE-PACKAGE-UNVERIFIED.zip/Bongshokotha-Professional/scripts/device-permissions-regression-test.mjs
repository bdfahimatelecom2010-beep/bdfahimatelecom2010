import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const checks = [
  ['device permission service exists', fs.existsSync(path.join(root, 'src/services/devicePermissions.ts'))],
  ['native camera permission request exists', /requestCameraPermission/.test(read('src/services/devicePermissions.ts'))],
  ['native photo/media permission request exists', /requestPhotoMediaPermission/.test(read('src/services/devicePermissions.ts'))],
  ['document scanner gates camera access', /ensureCameraPermission/.test(read('src/components/archive/DocumentScannerModal.tsx'))],
  ['avatar camera gates camera access', /ensureCameraPermission/.test(read('src/components/AvatarUploadModal.tsx'))],
  ['settings exposes permission controls', /Allow Camera|ক্যামেরার অনুমতি দিন/.test(read('src/components/SettingsView.tsx'))],
  ['PWA manifest exists', fs.existsSync(path.join(root, 'public/manifest.webmanifest'))],
  ['user logo source included', fs.existsSync(path.join(root, 'assets/Nafsan-Logo-source.jpg'))],
  ['application icon exists', fs.existsSync(path.join(root, 'assets/icon.png'))],
  ['Windows icon exists', fs.existsSync(path.join(root, 'assets/icon.ico'))],
  ['Electron builder uses supplied icon', /assets\/icon\.ico/.test(read('package.json'))],
  ['package/app version is consistent', JSON.parse(read('package.json')).version === read('src/appVersion.ts').match(/APP_VERSION\s*=\s*['"]([^'"]+)['"]/u)?.[1]],
];
let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
console.log(`DEVICE PERMISSIONS + ICON REGRESSION PASS: ${checks.length}/${checks.length}`);
