import fs from 'node:fs';
const dashboard = fs.readFileSync('src/components/DashboardView.tsx','utf8');
const types = fs.readFileSync('src/types/genealogy.ts','utf8');
const checks = [
  ['Dashboard offers five accent palettes', ['amber','blue','green','violet','slate'].every(x => dashboard.includes(`id:'${x}'`))],
  ['Dashboard offers four card styles', ['elevated','outlined','flat','square'].every(x => dashboard.includes(`id:'${x}'`))],
  ['Accent selection persists in family settings', dashboard.includes("setDashboard({dashboardAccent:c.id})")],
  ['Card style selection persists in family settings', dashboard.includes("setDashboard({dashboardCardStyle:c.id})")],
  ['Selected accent styles dashboard header', dashboard.includes('bg-gradient-to-br ${accent.header}')],
  ['Selected accent styles progress bars', dashboard.includes('${accent.bar}')],
  ['Dashboard reset restores visual defaults', dashboard.includes("dashboardAccent: 'amber', dashboardCardStyle: 'elevated'")],
  ['Visual settings are typed in FamilySettings', types.includes("dashboardAccent?: 'amber' | 'blue' | 'green' | 'violet' | 'slate'") && types.includes("dashboardCardStyle?: 'elevated' | 'outlined' | 'flat' | 'square'")],
];
let failed = 0;
for (const [name, pass] of checks) { console.log(`${pass?'PASS':'FAIL'} | ${name}`); if (!pass) failed++; }
console.log(`RESULT | ${checks.length-failed}/${checks.length} passed`);
process.exitCode = failed ? 1 : 0;
