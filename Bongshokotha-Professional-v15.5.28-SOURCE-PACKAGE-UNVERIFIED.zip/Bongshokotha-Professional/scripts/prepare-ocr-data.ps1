$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $root 'public\tessdata'
New-Item -ItemType Directory -Force -Path $dest | Out-Null

$models = @(
  @{ Name = 'eng'; Url = 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/eng.traineddata' },
  @{ Name = 'ben'; Url = 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/ben.traineddata' }
)

function Save-Gzip($source, $target) {
  $input = [System.IO.File]::OpenRead($source)
  try {
    $output = [System.IO.File]::Create($target)
    try {
      $gzip = [System.IO.Compression.GZipStream]::new($output, [System.IO.Compression.CompressionMode]::Compress)
      try { $input.CopyTo($gzip) } finally { $gzip.Dispose() }
    } finally { $output.Dispose() }
  } finally { $input.Dispose() }
}

foreach ($model in $models) {
  $raw = Join-Path $dest ($model.Name + '.traineddata')
  $gz = $raw + '.gz'
  if ((Test-Path $gz) -and ((Get-Item $gz).Length -gt 100000)) {
    Write-Host "OCR model ready: $($model.Name)"
    continue
  }
  Write-Host "Downloading OCR model: $($model.Name)"
  Invoke-WebRequest -Uri $model.Url -OutFile $raw -UseBasicParsing
  if ((Get-Item $raw).Length -lt 100000) { throw "Downloaded OCR model is unexpectedly small: $($model.Name)" }
  Save-Gzip $raw $gz
  Remove-Item $raw -Force
  Write-Host "Prepared: $gz"
}
Write-Host 'Offline OCR data preparation completed.'
