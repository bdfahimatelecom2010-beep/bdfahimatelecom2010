import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const types=fs.readFileSync(path.join(root,'src/types/genealogy.ts'),'utf8');
const modal=fs.readFileSync(path.join(root,'src/components/MemberModal.tsx'),'utf8');
const validation=fs.readFileSync(path.join(root,'src/engine/validationEngine.ts'),'utf8');
const profile=fs.readFileSync(path.join(root,'src/components/MemberProfileModal.tsx'),'utf8');
const checks=[
 ['extended identity fields', /alternativeNames\?: string\[\]/.test(types) && /nationality\?: string/.test(types) && /bloodGroup\?: BloodGroup/.test(types)],
 ['research status', /ResearchStatus/.test(types) && /researchStatus\?: ResearchStatus/.test(types)],
 ['new records unverified by default', /useState<VerificationStatus>\('unverified'\)/.test(modal)],
 ['approximate birth-year confirmation', /inferredBirthYear/.test(modal) && /approximate/.test(modal)],
 ['existing linked parents retained', /linkedIds/.test(modal) && /fatherId \? \[fatherId\]/.test(modal)],
 ['adopted child protected from biological auto-repair', /child\.birthOrigin !== 'adopted'/.test(validation)],
 ['marriage status detail', /divorce_pending:'বিচ্ছেদ প্রক্রিয়াধীন'/.test(profile) && /talaq:'তালাকপ্রাপ্ত'/.test(profile) && /widowed:'বিধবা\/বিপত্নীক'/.test(profile)],
 ['child gender/date display', /child\.gender === 'male'/.test(profile) && /formatGenealogyDate\(child\.birth\.date/.test(profile)],
];
const missing=checks.filter(([,ok])=>!ok);
if(missing.length) throw new Error('MEMBER DATA INTEGRITY FAIL: '+missing.map(x=>x[0]).join(', '));
console.log(`MEMBER DATA INTEGRITY PASS: ${checks.length} core data-integrity contracts verified.`);
