import fs from 'node:fs';
const modal = fs.readFileSync(new URL('../src/components/MemberModal.tsx', import.meta.url), 'utf8');
const checks = [
  ['complete address formatter uses labelled postal code and comma joining', modal.includes('পোস্ট কোড: ${a.postalCode}') && modal.includes("parts.join(', ')")],
  ['union council, municipality and city corporation have explicit field', modal.includes('ইউনিয়ন পরিষদ / পৌরসভা / সিটি কর্পোরেশন')],
  ['post office and postal code are separate fields', modal.includes("key: 'postOffice'") && modal.includes("key: 'postalCode'")],
  ['address suggestions reuse saved genealogy addresses offline', modal.includes('const addressSources = React.useMemo') && modal.includes('members.flatMap(m => [m.currentAddress, m.permanentAddress])')],
  ['cascading location changes clear dependent fields', modal.includes('const clearAfter') && modal.includes("division: ['district', 'upazila', 'union', 'postOffice', 'postalCode'")],
  ['live current address preview exists', modal.includes('Complete address — review before saving') && modal.includes('addressPreview(currentAddressDetails, currentAddress)')],
  ['live permanent address preview exists', modal.includes('Complete permanent address') && modal.includes('addressPreview(permanentAddressDetails, permanentAddress)')],
  ['copy current to permanent uses structured address', modal.includes('setPermanentAddressDetails({...currentAddressDetails})')],
  ['parents-in-law section is conditionally hidden for unmarried member', modal.includes("(maritalStatus !== 'unmarried' || spouseIds.length > 0) && <div className=\"mt-2 rounded-2xl border border-rose-200")],
  ['structured formatted address is saved on create and edit', (modal.match(/fullAddress: formatLocationInfo\(/g) || []).length >= 4],
  ['new Smart Form v3 layout replaces the old visual treatment', modal.includes('data-smart-member-form=\"v3\"') && modal.includes('smart-member-form') && modal.includes('স্মার্ট সদস্য ফর্ম')],
  ['form clearly communicates optional fields to reduce entry burden', modal.includes('Only fields marked (*) are required') && modal.includes('বাকিটা পরে যোগ করতে পারবেন')],
  ['responsive section cards and reduced spacing are used', modal.includes('smart-form-section rounded-2xl') && modal.includes('p-3 sm:p-5 lg:p-7 space-y-4')],
];
let failures=0; for (const [label, ok] of checks) { console.log(`${ok?'PASS':'FAIL'} ${label}`); if(!ok) failures++; }
if(failures) process.exit(1); console.log(`SMART MEMBER FORM: PASS ${checks.length}/${checks.length}`);
