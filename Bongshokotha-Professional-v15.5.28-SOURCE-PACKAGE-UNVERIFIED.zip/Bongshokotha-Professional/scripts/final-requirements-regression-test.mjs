import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
const hub = read('src/components/FamilyHubView.tsx');
const settings = read('src/components/SettingsView.tsx');
const member = read('src/components/MemberModal.tsx');
const profile = read('src/components/MemberProfileModal.tsx');
const types = read('src/types/genealogy.ts');
const checks = [
  ['server-returned invite code is used', hub.includes('published.code') && hub.includes('record = { ...record, code: published.code }')],
  ['local join opens stored family instead of validation-only notice', hub.includes('await openFamily(local.familyId)') && !hub.includes('Join Code is valid.')],
  ['remote join accepts a server URL on the join screen', hub.includes('joinServerUrl') && hub.includes('joinServerUrl.trim() || family.settings?.syncEndpoint')],
  ['QR image scanning is implemented when browser API exists', hub.includes('BarcodeDetector') && hub.includes('detector.detect(bitmap)')],
  ['QR placeholder was removed', !hub.includes('Scan screen অ্যাপে থাকবে।') && !hub.includes('The scanner screen is part of the app.')],
  ['personal settings categories are explicitly separated', settings.includes('personalCategoryIds') && settings.includes("'language', 'theme', 'display', 'dashboard', 'accessibility', 'storage', 'privacy', 'security', 'about'")],
  ['admin settings are gated by role permissions', settings.includes('if (!canManageRoles) return false;')],
  ['adoptive parents are separate model fields', types.includes('adoptiveFatherNameBn') && types.includes('adoptiveMotherNameBn')],
  ['adoptive parent fields persist on create and edit', (member.match(/adoptiveFatherNameBn: adoptiveFatherNameBn\.trim\(\)/g) || []).length >= 2],
  ['profile shows adoptive parents separately', profile.includes('Adoptive parents (separate relationship)') && profile.includes('পালক পিতা-মাতা (আলাদা সম্পর্ক)')],
  ['legacy marriage-origin flag takes priority in profile label', profile.includes("member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin")],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`); if (!ok) failed++; }
console.log(`FINAL REQUIREMENTS REGRESSION: ${checks.length-failed}/${checks.length}`);
if (failed) process.exit(1);
