import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = f => fs.readFileSync(path.join(root,f),'utf8');
const checks = [
  ['Admin can manage family settings', read('src/services/authRbac.ts').includes("admin: {\n    canManageFamily: true")],
  ['Co-Admin can manage family settings', read('src/services/authRbac.ts').includes("co_admin: {\n    canManageFamily: true")],
  ['Family Identity explicit Save button', read('src/components/SettingsView.tsx').includes("saveFamilyIdentity") && read('src/components/SettingsView.tsx').includes('সংরক্ষণ করুন')],
  ['Genealogy Rules explicit Save', read('src/components/SettingsView.tsx').includes("saveGenealogyRules")],
  ['Memorial notification uses remembranceNotifications', read('src/components/SettingsView.tsx').includes('remembranceNotifications: e.target.checked')],
  ['Account photo persists', read('src/components/MyAccountView.tsx').includes('target.avatarUrl = avatarUrl || undefined')],
  ['Admin has My Account section', read('src/components/AdminCenterView.tsx').includes("'my-account'") && /আমার অ্যাকাউন্ট|My Account/.test(read('src/components/AdminCenterView.tsx'))],
  ['English field stays optional in storage', read('src/services/storage.ts').includes("englishName: member.englishName || ''")],
  ['Family switch refreshes refs', read('src/context/GenealogyContext.tsx').includes('membersRef.current = newMembers') && read('src/context/GenealogyContext.tsx').includes('marriagesRef.current = newMarriages')],
  ['Archive update callback has dependencies', !read('src/context/GenealogyContext.tsx').includes('    },\n    []\n  );\n\n  const deleteArchiveRecord')],
];
let failed=0; for(const [name,ok] of checks){ console.log(`${ok?'PASS':'FAIL'} ${name}`); if(!ok) failed++; }
process.exitCode=failed?1:0;
