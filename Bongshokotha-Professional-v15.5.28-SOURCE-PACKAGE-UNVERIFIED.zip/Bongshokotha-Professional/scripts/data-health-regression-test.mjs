import fs from 'node:fs';
const app=fs.readFileSync('src/App.tsx','utf8');
const sidebar=fs.readFileSync('src/components/Sidebar.tsx','utf8');
const dash=fs.readFileSync('src/components/DashboardView.tsx','utf8');
const admin=fs.readFileSync('src/components/AdminCenterView.tsx','utf8');
const view=fs.readFileSync('src/components/IntegrityRepairView.tsx','utf8');
const checks=[
 ['Data Health is removed from the main sidebar and lives in Admin Center', !sidebar.includes("id: 'integrity' as NavTab") && admin.includes("'integrity'") && admin.includes('<IntegrityRepairView')],
 ['Dashboard data-health alert navigates to Admin Center', dash.includes("onNavigate('admin')")],
 ['Integrity view has duplicate NID detection', view.includes('duplicateNidGroups')],
 ['Integrity view has name+DOB duplicate detection', view.includes('duplicateNameDobGroups')],
 ['Integrity view has incomplete profile detection', view.includes('incompleteProfiles')],
 ['Duplicate detection is non-destructive', view.includes('no member is automatically deleted or merged')],
 ['Safe repair remains available', view.includes('runRepair') && view.includes('নিরাপদ মেরামত')],
];
for (const [name,ok] of checks) console.log(`${ok?'PASS':'FAIL'} | ${name}`);
if (checks.some(([,ok])=>!ok)) process.exit(1);
console.log(`DATA HEALTH REGRESSION PASS: ${checks.length}/${checks.length}`);
