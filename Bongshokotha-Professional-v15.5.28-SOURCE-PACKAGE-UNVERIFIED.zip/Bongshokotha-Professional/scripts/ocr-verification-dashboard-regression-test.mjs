import fs from 'node:fs';
const dash=fs.readFileSync('src/components/DashboardView.tsx','utf8');
const detail=fs.readFileSync('src/components/archive/ArchiveRecordDetailModal.tsx','utf8');
const member=fs.readFileSync('src/components/MemberModal.tsx','utf8');
const checks=[
 ['dashboard counts archive OCR records', dash.includes("archiveRecords.forEach(r =>")],
 ['dashboard deduplicates profile/archive records', dash.includes('d.archiveRecordId || `member-doc:${m.id}:${d.id}`')],
 ['dashboard pending statuses are unverified/disputed', dash.includes("status === 'unverified' || status === 'disputed'")],
 ['dashboard ignores rejected as pending', !dash.includes("status !== 'verified'")],
 ['clean OCR verification marks archive verified', detail.includes("ocrVerification: 'verified'") && detail.includes('No conflicts detected')],
 ['OCR conflict review marks archive verified', detail.includes('OCR conflict review completed')],
 ['verification writes audit event', detail.includes("action: 'ocr_verified'")],
 ['member OCR apply uses supported verification status', member.includes("ocrVerification: 'verified' as const")],
 ['no unsupported reviewed OCR status remains', !member.includes("ocrVerification: 'reviewed'")],
];
let pass=0; for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} | ${n}`); if(ok) pass++;}
if(pass!==checks.length) process.exit(1);
console.log(`OCR VERIFICATION + DASHBOARD REGRESSION PASS: ${pass}/${checks.length}`);
