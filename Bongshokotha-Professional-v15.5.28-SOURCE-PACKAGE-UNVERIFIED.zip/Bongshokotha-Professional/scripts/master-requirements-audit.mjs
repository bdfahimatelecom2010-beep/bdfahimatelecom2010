import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const files = {
  spec: read('MASTER-REQUIREMENTS-CONSOLIDATED.md'),
  types: read('src/types/genealogy.ts'),
  modal: read('src/components/MemberModal.tsx'),
  profile: read('src/components/MemberProfileModal.tsx'),
  tree: read('src/components/FamilyTreeView.tsx'),
  members: read('src/components/MembersView.tsx'),
  admin: read('src/components/AdminCenterView.tsx'),
  settings: read('src/components/SettingsView.tsx'),
  ocr: read('src/engine/ocrEngine.ts'),
  parser: read('src/engine/ocrFieldParser.ts'),
};
const checks = [
 ['master spec exists', files.spec.includes('Master Requirements')],
 ['hidden permanent person ID rule documented', files.spec.includes('Permanent internal Person ID immutable') || files.spec.includes('Permanent internal Person ID')],
 ['no visible serial rule documented', files.spec.includes('Serial No.') && files.spec.includes('UI-তে Person ID')],
 ['birth order rule documented', files.spec.includes('Sibling order = birthOrder') || files.spec.includes('birthOrder')],
 ['generation rule documented', files.spec.includes('Parent generation + 1')],
 ['multiple marriage rule documented', files.spec.includes('Multiple marriages')],
 ['in-law visibility rule documented', files.spec.includes('spouse-family birth-line nodes') && files.spec.includes('External in-law parent')],
 ['NID and BRN separate', files.types.includes('nidNumber?: string') && files.types.includes('birthRegistrationNumber?: string')],
 ['passport field exists', files.types.includes('passportNumber?: string')],
 ['education history exists', files.types.includes('educationHistory?: EducationRecord[]')],
 ['profession history exists', files.types.includes('professionHistory?: ProfessionRecord[]')],
 ['residence history exists', files.types.includes('residenceHistory?: ResidenceRecord[]')],
 ['succession 1-5 model exists', files.types.includes('priority: 1|2|3|4|5')],
 ['OCR passport extraction exists', files.parser.includes('passportNumber') && files.parser.includes('MRZ')],
 ['profile hides person id', !files.profile.includes("{member.id}</p>")],
 ['profile hides serial', !files.profile.includes("member.serialNumber || '—'")],
 ['profile marriage count', files.profile.includes('memberMarriages.length')],
 ['tree marriage count', files.tree.includes("isBn ? 'বিবাহ' : 'Marriages'")],
 ['directory marriage count', files.members.includes('marriageCount')],
 ['admin owner-only section', files.admin.includes('owner') && files.admin.includes('succession')],
 ['settings dashboard family overview', files.settings.includes('familyOverview')],
 ['settings Gmail/server controls', files.settings.includes('googleAccountEmail') && files.settings.includes('syncEndpoint')],
 ['document archive linkage', files.modal.includes('addArchiveRecord') && files.profile.includes('memberArchiveRecords')],
 ['single-page smart member form v3', /data-smart-member-form=\"v3\"/.test(files.modal) && /data-single-page=\"true\"/.test(files.modal) && files.modal.includes('data-smart-form-intro=\"true\"')],
];
let failed=0;
for (const [label, ok] of checks) { console.log(`${ok?'PASS':'FAIL'} ${label}`); if(!ok) failed++; }
if (failed) process.exit(1);
console.log(`MASTER REQUIREMENTS AUDIT: PASS ${checks.length}/${checks.length}`);
