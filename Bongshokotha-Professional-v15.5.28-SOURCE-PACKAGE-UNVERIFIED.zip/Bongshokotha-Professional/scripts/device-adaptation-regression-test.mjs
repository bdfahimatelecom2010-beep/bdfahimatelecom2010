import fs from 'node:fs';
import assert from 'node:assert/strict';
const main = fs.readFileSync('src/main.tsx', 'utf8');
const css = fs.readFileSync('src/index.css', 'utf8');
const html = fs.readFileSync('index.html', 'utf8');
const checks = [
  ['capability detection is guarded', main.includes('navigator as Navigator') && main.includes('catch { /* Feature detection')],
  ['low-resource tier is detected', main.includes("? 'lite'") && main.includes("dataset.deviceTier")],
  ['viewport supports safe areas', html.includes('viewport-fit=cover') && css.includes('safe-area-inset-bottom')],
  ['small phone layout exists', css.includes('@media (max-width: 380px)')],
  ['mobile layout exists', css.includes('@media (max-width: 640px)')],
  ['tablet layout exists', css.includes('@media (min-width: 641px) and (max-width: 1024px)')],
  ['large display layout exists', css.includes('@media (min-width: 1600px)')],
  ['touch targets are adapted', css.includes('@media (pointer: coarse)')],
  ['reduced motion is respected', css.includes('@media (prefers-reduced-motion: reduce)')],
  ['lite devices avoid expensive effects', css.includes('html[data-device-tier="lite"]') && css.includes('backdrop-filter: none')],
  ['forced-colors accessibility exists', css.includes('@media (forced-colors: active)')],
];
for (const [name, ok] of checks) { assert.ok(ok, name); console.log(`PASS ${name}`); }
console.log(`${checks.length}/${checks.length} device-adaptation checks passed`);
