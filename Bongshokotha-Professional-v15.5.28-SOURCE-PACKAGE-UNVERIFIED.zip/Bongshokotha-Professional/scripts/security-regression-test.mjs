import fs from 'node:fs';
import assert from 'node:assert/strict';

const read = p => fs.readFileSync(p, 'utf8');
const context = read('src/context/GenealogyContext.tsx');
const auth = read('src/services/authRbac.ts');
const login = read('src/components/LoginView.tsx');
const security = read('src/services/security.ts');
const server = read('server/sync-server.mjs');
const archive = read('src/components/archive/FamilyArchiveView.tsx');
const app = read('src/App.tsx');
const audit = read('src/services/auditLogger.ts');

const requiredGuards = [
  ["addBranch", "canManageFamily"], ["updateFamily", "canManageFamily"], ["switchFamily", "canSwitchFamilies"],
  ["addArchiveRecord", "canUploadArchive"], ["updateArchiveRecord", "canUploadArchive"], ["deleteArchiveRecord", "canDeleteArchive"],
  ["batchAddArchiveRecords", "canUploadArchive"], ["linkDocumentToMember", "canUploadArchive"], ["unlinkDocumentFromMember", "canDeleteArchive"],
  ["createNewFamily", "canCreateFamily"], ["importArchiveJSON", "canImportData"], ["importUniversalDataset", "canImportData"],
  ["resetToFreshState", "canFactoryReset"]
];
for (const [fn, perm] of requiredGuards) {
  const chunk = context.slice(context.indexOf(`const ${fn}`), context.indexOf(`const ${fn}`) + 1800);
  assert.ok(chunk.includes(`requirePermission('${perm}')`) || (fn.startsWith('import') && chunk.includes('requirePermission(strategy ===')), `${fn} missing authorization guard`);
}
assert.match(auth, /interface FamilyMembership/);
assert.match(auth, /getEffectiveRole/);
assert.match(login, /hashPassword\(password\)/);
assert.match(login, /verifyPassword\(password/);
assert.match(login, /isSessionAuthenticated/);
assert.match(security, /PBKDF2_ITERATIONS = 120000/);
assert.match(security, /MAX_FAILURES = 8/);
assert.match(app, /touchSession\(15\)/);
assert.match(archive, /accessPermission === 'restricted'/);
assert.match(server, /requireApiAuth/);
assert.match(server, /if \(!SERVER_TOKEN\) return res\.status\(503\)/);
assert.match(server, /timingSafeEqual/);
assert.match(server, /crypto\.randomBytes\(24\)/);
assert.doesNotMatch(server, /if \(!SERVER_TOKEN \|\| !req\.path\.startsWith\('\/api\/'\)\) return next\(\)/);
assert.doesNotMatch(audit, /acc-superadmin-001/);
console.log('SECURITY REGRESSION PASS: authentication/session hardening, family-aware RBAC guards, archive privacy filtering, secure invite generation, and fail-closed server authorization verified.');
