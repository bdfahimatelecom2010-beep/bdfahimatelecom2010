import fs from 'node:fs';
const modal = fs.readFileSync('src/components/MemberModal.tsx', 'utf8');
const context = fs.readFileSync('src/context/GenealogyContext.tsx', 'utf8');
const checks = [
  ['save failure includes the precise stage in diagnostics', modal.includes("console.error('[Bongshokotha] Member save failed', { stage: saveStage")],
  ['save failure includes the underlying error message', modal.includes("const detail = error instanceof Error ? error.message : String(error")],
  ['archive and member persistence are separate stages', modal.includes("saveStage = 'archive-documents'") && modal.includes("saveStage = 'member-and-marriage-persistence'")],
  ['spouse-parent reconciliation is separately diagnosed', modal.includes("saveStage = 'spouse-parent-reconciliation'")],
  ['marriage and child-link operations have separate stages', modal.includes("saveStage = 'create-marriage'") && modal.includes("saveStage = 'link-existing-children'")],
  ['user receives actionable stage and underlying error', modal.includes('ব্যর্থ ধাপ: ${stageBn[saveStage] || saveStage}') && modal.includes('${detail}')],
  ['member update persists members and marriages before state refresh', /Promise\.all\(\[storage\.saveMembers\([\s\S]*?storage\.saveMarriages\(/.test(context)],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`); if (!ok) failed++; }
if (failed) process.exit(1);
console.log(`MEMBER SAVE DIAGNOSTICS PASS: ${checks.length}/${checks.length}`);
