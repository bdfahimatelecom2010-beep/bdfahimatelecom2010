import fs from 'node:fs';

const source = fs.readFileSync('src/engine/familyVisibility.ts', 'utf8');
const membersView = fs.readFileSync('src/components/MembersView.tsx', 'utf8');
const treeView = fs.readFileSync('src/components/FamilyTreeView.tsx', 'utf8');

const assert = (condition, message) => {
  if (!condition) throw new Error(`FAIL | ${message}`);
  console.log(`PASS | ${message}`);
};

assert(source.includes('isMarriedInMember'), 'Married-in members have an explicit origin predicate');
assert(source.includes('isParentOfJoinedMember'), 'Parents of married-in members are detected');
assert(source.includes('hasBirthLineChild'), 'External in-law parents remain visible when independently connected by a birth-line child');
assert(source.includes('hasBirthLineMarriage'), 'External in-law parents remain visible when independently connected by a birth-line marriage');
assert(source.includes('if (!hasBirthLineChild && !hasBirthLineMarriage) return false'), 'Unconnected biological parents of married-in members are hidden from family member nodes');
assert(source.includes('if (isMarriedInMember(member)) return true'), 'Married-in spouses themselves remain visible as family members');
assert(membersView.includes('getVisibleFamilyMembers(members, marriages)'), 'Members Directory uses canonical family visibility');
assert(treeView.includes('getVisibleFamilyMembers(members, marriages)'), 'Family Tree uses the same canonical family visibility');

console.log('FAMILY VISIBILITY REGRESSION PASS: married-in parents stay profile data but do not become birth-line members.');
