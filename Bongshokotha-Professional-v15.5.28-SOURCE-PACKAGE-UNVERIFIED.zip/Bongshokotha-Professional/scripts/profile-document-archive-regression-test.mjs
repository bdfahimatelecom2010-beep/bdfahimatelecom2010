import fs from 'node:fs';
import assert from 'node:assert/strict';

const memberModal = fs.readFileSync('src/components/MemberModal.tsx', 'utf8');
const profile = fs.readFileSync('src/components/MemberProfileModal.tsx', 'utf8');
const types = fs.readFileSync('src/types/genealogy.ts', 'utf8');

assert.match(memberModal, /runDocumentOcr\(dataUrl, 'ben\+eng'/);
assert.match(memberModal, /archivePendingMemberDocuments/);
assert.match(memberModal, /Canonical Family Archive record created from member profile document/);
assert.match(memberModal, /archiveRecordId: archiveRecord\.id/);
assert.match(profile, /Saved to Family Archive from member profile/);
assert.match(profile, /runDocumentOcr(?:Batch)?\(/);
assert.match(profile, /OCR পিতা:|OCR মাতা:|OCR স্বামী\/স্ত্রী:/);
assert.match(types, /ocrText\?: string/);
assert.match(types, /extractedFields\?: ExtractedDocumentFields/);
console.log('PROFILE DOCUMENT + OCR ARCHIVE REGRESSION: PASS');
