import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const modal = fs.readFileSync(path.join(root, 'src/components/MemberModal.tsx'), 'utf8');
const profile = fs.readFileSync(path.join(root, 'src/components/MemberProfileModal.tsx'), 'utf8');
const tree = fs.readFileSync(path.join(root, 'src/components/FamilyTreeView.tsx'), 'utf8');
const memberCard = fs.readFileSync(path.join(root, 'src/components/MembersView.tsx'), 'utf8');
const type = fs.readFileSync(path.join(root, 'src/types/genealogy.ts'), 'utf8');

const checks = [
  ['smart member form is a single continuous page', /data-smart-member-form=\"v3\"/.test(modal) && /data-single-page=\"true\"/.test(modal) && modal.includes('overflow-y-auto')],
  ['smart form has guided responsive intro and status summary', modal.includes('data-smart-form-intro=\"true\"') && modal.includes('SMART FORM v3') && modal.includes('maritalStatus') && modal.includes('childIds.length')],
  ['relationship sections are conditionally displayed', modal.includes("(maritalStatus !== 'unmarried' || spouseIds.length > 0)") && modal.includes('childIds.length > 0')],
  ['profile has dedicated contact/current-life section', modal.includes('id="sec-contact"') && modal.includes('Contact, Current Life')],
  ['quick jump includes history', modal.includes("scrollToSection('sec-history')")],
  ['education history input exists', modal.includes('educationHistory') && modal.includes('addEducationRecord')],
  ['profession history input exists', modal.includes('professionHistory') && modal.includes('addProfessionRecord')],
  ['residence history input exists', modal.includes('residenceHistory') && modal.includes('addResidenceRecord')],
  ['family origin story input exists', modal.includes('familyOriginStory')],
  ['memorial story input exists', modal.includes('memorialStory')],
  ['notes and tags input exists', modal.includes('memberNotes') && modal.includes('tags')],
  ['structured history persisted on edit', /educationHistory, professionHistory, residenceHistory/.test(modal)],
  ['Person ID not rendered in profile', !profile.includes("{member.id}</p>")],
  ['serial number not rendered in profile', !profile.includes("member.serialNumber || '—'")],
  ['profile shows marriage count', profile.includes('Marriage Count') && profile.includes('memberMarriages.length')],
  ['tree card shows marriage count', tree.includes("isBn ? 'বিবাহ' : 'Marriages'")],
  ['member directory shows marriage count', memberCard.includes('বিবাহ: ${toBanglaDigits(marriageCount)}টি')],
  ['education type exists', type.includes('interface EducationRecord')],
  ['profession type exists', type.includes('interface ProfessionRecord')],
  ['residence type exists', type.includes('interface ResidenceRecord')],
  ['OCR apply supports passport and full date', fs.readFileSync(path.join(root, 'src/components/archive/DocumentScannerModal.tsx'), 'utf8').includes('identityDocs.passportNumber') && fs.readFileSync(path.join(root, 'src/components/archive/DocumentScannerModal.tsx'), 'utf8').includes('parseOcrDate')],
  ['archive is canonical and profile pointer is separate', fs.readFileSync(path.join(root, 'src/components/MemberModal.tsx'), 'utf8').includes('archiveRecordId') && /canonical|আর্কাইভ/i.test(fs.readFileSync(path.join(root, 'src/components/archive/FamilyArchiveView.tsx'), 'utf8'))],
];
let failed = 0;
for (const [label, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${label}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
console.log(`PROFILE FORM REGRESSION: PASS ${checks.length}/${checks.length}`);

// 13.2.0 regression: marriage-origin members must follow their birth-origin spouse.
const membersView = fs.readFileSync(path.join(root, 'src/components/MembersView.tsx'), 'utf8');
const familyTree = fs.readFileSync(path.join(root, 'src/components/FamilyTreeView.tsx'), 'utf8');
const marriageOrderChecks = [
  ['Members directory uses spouse-adjacent marriage-origin ordering', membersView.includes('spouseAdjacentRank') && membersView.includes('birthLineSpouse')],
  ['Family tree uses spouse-adjacent marriage-origin ordering', familyTree.includes('spouseAdjacentRank') && familyTree.includes('birth-origin spouse')]
];
for (const [label, ok] of marriageOrderChecks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${label}`); if (!ok) process.exit(1); }
