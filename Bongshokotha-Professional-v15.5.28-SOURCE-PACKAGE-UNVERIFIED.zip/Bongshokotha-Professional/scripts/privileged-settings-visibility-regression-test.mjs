import fs from 'node:fs';
const settings = fs.readFileSync('src/components/SettingsView.tsx', 'utf8');
const sidebar = fs.readFileSync('src/components/Sidebar.tsx', 'utf8');
const member = fs.readFileSync('src/components/MemberModal.tsx', 'utf8');
const checks = [
  ['repair settings category requires repair permission', /if \(cat\.id === 'repair'\) return canRunIntegrityRepair/.test(settings)],
  ['repair panel itself is permission-gated', /activeCategory === 'repair' && canRunIntegrityRepair/.test(settings)],
  ['roles settings category requires role-management permission', /if \(cat\.id === 'permissions'\) return canManageRoles/.test(settings)],
  ['roles panel itself is permission-gated', /activeCategory === 'permissions' && canManageRoles/.test(settings)],
  ['sync settings category requires sync permission', /if \(cat\.id === 'sync'\) return canConfigureSync/.test(settings)],
  ['factory reset category and panel require factory-reset permission', /if \(cat\.id === 'reset'\) return canFactoryReset/.test(settings) && /activeCategory === 'reset' && canFactoryReset/.test(settings)],
  ['data health is grouped in Admin Center and permission-gated', sidebar.includes("id: 'admin' as NavTab") && !sidebar.includes("id: 'integrity' as NavTab") && /section === 'integrity' && \(checkPermission\('canRunIntegrityRepair'\)/.test(fs.readFileSync('src/components/AdminCenterView.tsx', 'utf8'))],
  ['NID parent claims remain review-only', member.includes('OCR supplies identity-document claims, not proof of a canonical parent link')]
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`); if (!ok) failed++; }
if (failed) process.exit(1);
console.log(`PRIVILEGED UI VISIBILITY PASS: ${checks.length}/${checks.length}`);
