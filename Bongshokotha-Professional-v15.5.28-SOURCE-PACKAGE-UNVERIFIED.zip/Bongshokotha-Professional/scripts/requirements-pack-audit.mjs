import fs from 'node:fs';
import path from 'node:path';
const required = [
  'docs/requirements/MASTER-REQUIREMENTS-V5.0-BN.md',
  'docs/requirements/MASTER-REQUIREMENTS-V5.0-BN.docx',
  'docs/V5.0-INTEGRATION-STATUS-BN.md',
  'README-START-HERE-BN.md',
  'public/tessdata/ben.traineddata.gz',
  'public/tessdata/eng.traineddata.gz',
  'scripts/universal-ocr-regression-test.mjs',
  'scripts/smart-member-form-regression-test.mjs',
  'scripts/relationship-canonical-regression-test.mjs',
  'scripts/dashboard-regression-test.mjs',
  'scripts/security-regression-test.mjs',
];
const missing = required.filter((f) => !fs.existsSync(path.resolve(f)));
if (missing.length) { console.error('PACK AUDIT FAIL: missing required files\n' + missing.join('\n')); process.exit(1); }
const spec = fs.readFileSync(required[0], 'utf8');
const sections = ['সর্বজনীন OCR', 'স্কেল', 'নিরাপত্তা', 'acceptance', 'Traceability'];
const missingSections = sections.filter((s) => !spec.toLowerCase().includes(s.toLowerCase()));
if (missingSections.length) { console.error('PACK AUDIT WARN: expected topic not found in specification: ' + missingSections.join(', ')); process.exitCode = 1; }
console.log(`PACK AUDIT PASS: ${required.length} required artifacts found; v5.0 specification attached.`);
console.log('Note: pack audit checks package completeness only, not feature correctness or runtime behavior.');
