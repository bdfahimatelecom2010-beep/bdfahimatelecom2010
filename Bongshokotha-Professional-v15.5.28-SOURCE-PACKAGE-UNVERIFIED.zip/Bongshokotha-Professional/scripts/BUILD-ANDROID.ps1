$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
Write-Host '=== BONGSHOKOTHA ANDROID BUILD ===' -ForegroundColor Cyan
npm.cmd run verify
npm.cmd run mobile:sync
Push-Location android
try { .\gradlew.bat assembleDebug } finally { Pop-Location }
Write-Host 'ANDROID DEBUG BUILD PASSED' -ForegroundColor Green
