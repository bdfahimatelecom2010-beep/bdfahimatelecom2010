import { parseDocumentFields, mergeExtractedDocumentFields, buildExtractedFieldCandidates } from '../src/engine/ocrFieldParser.ts';

const front = `জাতীয় পরিচয়পত্র / National ID Card\nনাম\nসোবুরন নেছা\nName\nSOBURON NESSA\nপিতা\nআঃ আজিজ গাজী\nমাতা\nআছিয়া বেগম\nDate of Birth\n10 May 1962\nNID No\n820 337 6192`;
const back = `জাতীয় পরিচয়পত্র\nঠিকানা\nবাসা/হোল্ডিং: --\nগ্রাম/রাস্তা: ঘোষেরতাংসা\nডাকঘর: পাটগাতি - ৮১২১\nউপজেলা/থানা: টুঙ্গিপাড়া পৌরসভা\nজেলা: গোপালগঞ্জ\nI<BGD8203376192<<<<<<<<<<<<<<<<<<<<`;
const passport = `PERSONAL DATA AND EMERGENCY CONTACT\nName: MD TARIQUL ISLAM\nFather's Name: MD HASEM SHIKDER\nMother's Name: SOBURON NESA\nPermanent Address - GOWHARDANGA, TUNGIPARA, KHADEMUL ISLAMIA MADRASA -8121, GOPALGANJ\nEmergency Contact:\nName: MD AMINUL ISLAM\nRelationship: BROTHER\nTelephone No: +8801713042310\nPassport Number A13036709\nNationality BANGLADESHI\nPersonal No 9550835194\nDate of Birth 23 FEB 1993\nPlace of Birth GOPALGANJ\nDate of Issue 02 NOV 2023\nDate of Expiry 01 NOV 2033\nIssuing Authority DIP/DHAKA\nPrevious Passport No BP0141153\nP<BGDISLAM<<MD<TARIQUL<<<<<<<<<<<<<<<<<<<<\nA130367099BGD9302235M33110199550835194<<<56`;

const f = parseDocumentFields(front, 92);
const b = parseDocumentFields(back, 81);
const merged = mergeExtractedDocumentFields([f,b]);
const p = parseDocumentFields(passport, 94);
const candidates = buildExtractedFieldCandidates(p);

const checks = [
  ['front is NID', f.documentKind === 'nid'],
  ['front is classified as NID front', f.documentSide === 'front'],
  ['back is classified as NID back', b.documentSide === 'back'],
  ['front extracts NID', f.nidNumber === '8203376192'],
  ['front extracts father', f.fatherName === 'আঃ আজিজ গাজী'],
  ['front extracts mother', f.motherName === 'আছিয়া বেগম'],
  ['back extracts village/road', b.road === 'ঘোষেরতাংসা'],
  ['back extracts post office', b.postOffice?.includes('পাটগাতি')],
  ['back extracts postal code', b.postOffice?.includes('৮১২১')],
  ['back extracts upazila', b.upazila === 'টুঙ্গিপাড়া পৌরসভা'],
  ['back extracts district', b.district === 'গোপালগঞ্জ'],
  ['merged front+back retains identity', merged.fullNameEn === 'SOBURON NESSA' && merged.nidNumber === '8203376192'],
  ['merged front+back retains structured address', merged.presentAddress?.district === 'গোপালগঞ্জ'],
  ['NID MRZ does not create passport', !merged.passportNumber],
  ['passport number is correct', p.passportNumber === 'A13036709'],
  ['passport personal number is extracted', p.passportPersonalNumber === '9550835194'],
  ['passport issue date is extracted', p.passportIssueDate === '02 NOV 2023'],
  ['passport expiry date is extracted', p.passportExpiryDate === '01 NOV 2033'],
  ['previous passport is cleaned', p.previousPassportNumber === 'BP0141153'],
  ['passport father/mother are extracted', p.fatherName === 'MD HASEM SHIKDER' && p.motherName === 'SOBURON NESA'],
  ['emergency contact remains visible as additional data', candidates.some(x => x.labelEn === 'Relationship' && x.value === 'BROTHER') && candidates.some(x => x.labelEn === 'Telephone No' && x.value.includes('8801713042310'))],
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
if (checks.some(([,ok]) => !ok)) process.exit(1);
console.log(`UNIVERSAL OCR RUNTIME REGRESSION PASS: ${checks.length}/${checks.length}`);
