import fs from 'node:fs';
import assert from 'node:assert/strict';

const root = new URL('../', import.meta.url);
const modal = fs.readFileSync(new URL('src/components/MemberModal.tsx', root), 'utf8');
const profile = fs.readFileSync(new URL('src/components/MemberProfileModal.tsx', root), 'utf8');
const generation = fs.readFileSync(new URL('src/engine/generationEngine.ts', root), 'utf8');
const visibility = fs.readFileSync(new URL('src/engine/familyVisibility.ts', root), 'utf8');

assert.match(modal, /setFatherId\(memberToEdit\.birthOrigin === 'joined_by_marriage' \|\| memberToEdit\.marriageOrigin \? ''/,
  'editing a married-in member must not preselect external biological parents as family members');
assert.match(modal, /fatherId: birthOrigin === 'joined_by_marriage' \? undefined/,
  'saving a married-in member must not create a canonical in-family father link');
assert.match(modal, /motherId: birthOrigin === 'joined_by_marriage' \? undefined/,
  'saving a married-in member must not create a canonical in-family mother link');
assert.match(modal, /paternalGrandfatherId: birthOrigin === 'joined_by_marriage' \? undefined/,
  'external biological grandparents must not be linked as in-family members');
assert.match(modal, /return preferred \? \[preferred\] : \[\]/,
  'in-law selector must not offer every unrelated family member');
assert.match(modal, /Spouse's recorded father/,
  'external spouse parent name must remain available as informational in-law data');
assert.match(profile, /fatherExternalName/,
  'profile must display external biological parent names through the marriage context');
assert.match(profile, /external record/,
  'profile must distinguish external parent records from family-member nodes');
assert.match(generation, /if \(joinedByMarriage\)/,
  'generation engine must retain the married-in spouse-anchor rule');
assert.match(visibility, /if \(!hasBirthLineChild && !hasBirthLineMarriage\) return false/,
  'external parents must stay hidden from the primary family tree when no independent birth-line link exists');

console.log('PASS: married-in external parent names persist as facts without becoming family-tree members');
console.log('PASS: in-law options no longer include unrelated members or misleading generations');
console.log('PASS: external parent names remain visible from the spouse/marriage profile context');
