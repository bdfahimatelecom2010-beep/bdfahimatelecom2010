import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const metadata = JSON.parse(fs.readFileSync(path.join(root,'metadata.json'),'utf8'));
const appVersion = fs.readFileSync(path.join(root,'src/appVersion.ts'),'utf8').match(/APP_VERSION\s*=\s*['"]([^'"]+)['"]/u)?.[1];
const currentVersion = fs.readFileSync(path.join(root,'CURRENT-VERSION.txt'),'utf8').trim();
const expected = pkg.version;
const checks = [
  ['package.json', pkg.version],
  ['metadata.json', metadata.version],
  ['src/appVersion.ts', appVersion],
  ['CURRENT-VERSION.txt', currentVersion],
];
let failed = false;
for (const [name, value] of checks) {
  const ok = value === expected;
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name} | ${value ?? 'missing'} | expected=${expected}`);
  if (!ok) failed = true;
}
if (failed) process.exit(1);
console.log(`VERSION CONSISTENCY PASS: ${expected}`);
