import fs from 'node:fs';
import assert from 'node:assert/strict';
const sidebar = fs.readFileSync(new URL('../src/components/Sidebar.tsx', import.meta.url), 'utf8');
const app = fs.readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const dashboard = fs.readFileSync(new URL('../src/components/DashboardView.tsx', import.meta.url), 'utf8');
const admin = fs.readFileSync(new URL('../src/components/AdminCenterView.tsx', import.meta.url), 'utf8');
const checks = [
 ['sidebar has a separate family map group', /key:\s*'map'.*ids:\s*\['map'\]/s.test(sidebar)],
 ['map tab routes to MapView', /activeTab === 'map'\s*&&\s*<MapView\s*\/>/.test(app)],
 ['family tree sharing has its own route', /activeTab === 'share'\s*&&\s*<FamilyTreeSharingView\s*\/>/.test(app)],
 ['dashboard sharing shortcut routes to share', /onNavigate\('share'\)/.test(dashboard)],
 ['social media menu is absent', !sidebar.includes("id: 'social' as NavTab") && !sidebar.includes('পারিবারিক সামাজিক মাধ্যম')],
 ['mobile bottom navigation is absent', !sidebar.includes('MOBILE FIXED BOTTOM NAVIGATION BAR')],
 ['logout button exists in sidebar', sidebar.includes('LogOut') && sidebar.includes('লগআউট')],
 ['data health and repair remains an admin center section', admin.includes("'integrity'") && admin.includes('<IntegrityRepairView') && !sidebar.includes("id: 'integrity' as NavTab")],
 ['15-minute inactivity timeout, popstate handling, and safe logout cleanup exist', app.includes('15 * 60_000') && app.includes("'popstate'") && app.includes('5 * 60_000') && !app.includes('window.close()')],
 ['role menu editor includes share but no social menu', admin.includes("['share', 'বংশতালিকা শেয়ার']") && !admin.includes("['social', 'পারিবারিক সামাজিক মাধ্যম']")],
 ['role menu assignments apply to privileged and ordinary roles', /const visibleNavItems = navItems\.filter/.test(sidebar) && sidebar.includes('assignedRoleMenus.includes(item.id)') && sidebar.includes("if (item.id === 'admin') return canOpenAdminCenter")],
];
for (const [name, pass] of checks) { console.log(`${pass ? 'PASS' : 'FAIL'} | ${name}`); assert.ok(pass, name); }
console.log(`NAVIGATION AND SESSION REGRESSION PASS: ${checks.length}/${checks.length}`);
