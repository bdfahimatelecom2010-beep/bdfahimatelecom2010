import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const registry=fs.readFileSync(path.join(root,'src/services/serverRegistry.ts'),'utf8');
const admin=fs.readFileSync(path.join(root,'src/components/AdminCenterView.tsx'),'utf8');
const server=fs.readFileSync(path.join(root,'server/sync-server.mjs'),'utf8');
const member=fs.readFileSync(path.join(root,'src/components/MemberModal.tsx'),'utf8');
const archive=fs.readFileSync(path.join(root,'src/components/archive/DocumentScannerModal.tsx'),'utf8');
const checks=[
 ['default server catalogue',/DEFAULT_SERVERS/.test(registry)],
 ['server login URL helper',/getServerLoginUrl/.test(registry)],
 ['admin server login page action',/openServerLogin/.test(admin)],
 ['server auth postMessage',/BKS_SERVER_AUTH/.test(admin)&&/BKS_SERVER_AUTH/.test(server)],
 ['automatic active server after auth',/setActiveServerId\(profile\.id\)/.test(admin)],
 ['automatic sync settings after auth',/syncEndpoint:\s*profile\.endpoint/.test(admin)],
 ['member OCR field selection',/selectedOcrFieldsByDoc/.test(member)],
 ['member OCR apply action',/applyOcrFieldsToProfile/.test(member)&&/Apply Selected to Profile/.test(member)],
 ['OCR does not silently save',/OCR never silently writes/.test(member)],
 ['archive Bengali label corrected',/পারিবারিক আর্কাইভে সংরক্ষণ করুন/.test(archive)],
];
let pass=0;for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(ok)pass++;}
if(pass!==checks.length) process.exit(1); console.log(`server-list regression: ${pass}/${checks.length} PASS`);
