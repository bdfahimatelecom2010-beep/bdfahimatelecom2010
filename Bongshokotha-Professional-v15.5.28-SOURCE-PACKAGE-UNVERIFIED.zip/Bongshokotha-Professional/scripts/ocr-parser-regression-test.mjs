import fs from 'node:fs';
const source=fs.readFileSync('src/engine/ocrEngine.ts','utf8');
const parser=fs.readFileSync('src/engine/ocrFieldParser.ts','utf8');
const typeSource=fs.readFileSync('src/types/genealogy.ts','utf8');
const checks=[
 ['OCR parser exports parser + merge + field candidates', source.includes("export { parseDocumentFields, parseDocumentDate, mergeExtractedDocumentFields, buildExtractedFieldCandidates } from './ocrFieldParser'")],
 ['NID number extraction is context/label-bound', parser.includes('nidNumber') && parser.includes('documentKind === \'nid\'')],
 ['NID supports 10/13/17 digits', parser.includes('[10, 13, 17]')],
 ['Passport document kind exists', typeSource.includes("'passport'") && parser.includes("documentKind = 'passport'" )],
 ['Passport number extraction exists', parser.includes('passportNumber') && parser.includes('Passport Number')],
 ['Passport MRZ extraction uses P< and TD3 line 2', parser.includes('P<') && parser.includes('mrz2.slice(0, 9)')],
 ['English name extraction exists', parser.includes('fullNameEn')],
 ['DOB extraction exists', parser.includes('datePatternMatch') && parser.includes('dateOfBirth')],
 ['Father/mother extraction exists', parser.includes('fatherName') && parser.includes('motherName')],
 ['OCR confidence is retained', parser.includes('confidence: defaultConfidence')]
];
for(const [n,ok] of checks) console.log(`${ok?'PASS':'FAIL'} | ${n}`);
if(checks.some(([,ok])=>!ok)) process.exit(1); console.log(`OCR PARSER SOURCE REGRESSION PASS: ${checks.length}/${checks.length}`);
