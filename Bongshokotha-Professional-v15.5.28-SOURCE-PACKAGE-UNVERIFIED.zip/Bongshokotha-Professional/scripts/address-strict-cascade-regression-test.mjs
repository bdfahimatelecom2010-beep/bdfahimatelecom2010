import fs from 'node:fs';
import assert from 'node:assert/strict';
const source = fs.readFileSync(new URL('../src/components/MemberModal.tsx', import.meta.url), 'utf8');
assert.match(source, /Never fall back to the entire saved-address list/);
assert.match(source, /const relevant = addressSources\.filter\(source => deps\.every\(dep =>/);
assert.match(source, /return Boolean\(saved\).*localeCompare/);
assert.doesNotMatch(source, /const sourceRows = relevant\.length \? relevant : addressSources/);
const rows = [
  { division: 'ঢাকা', district: 'গোপালগঞ্জ', upazila: 'টুঙ্গিপাড়া' },
  { division: 'ঢাকা', district: 'ঢাকা', upazila: 'সাভার' },
  { division: 'খুলনা', district: 'খুলনা', upazila: 'দাকোপ' },
  { division: '', district: 'অজানা', upazila: 'অন্য উপজেলা' },
];
const filter = (items, selected) => items.filter(row => ['division','district'].every(key => {
  const wanted = (selected[key] || '').trim();
  if (!wanted) return true;
  const actual = (row[key] || '').trim();
  return Boolean(actual) && actual === wanted;
}));
const result = filter(rows, { division: 'ঢাকা', district: 'গোপালগঞ্জ' }).map(x => x.upazila);
assert.deepEqual(result, ['টুঙ্গিপাড়া']);
console.log('PASS | selected division/district strictly filters saved address suggestions');
console.log('PASS | missing parent values cannot leak unrelated upazilas');
console.log('PASS | global fallback removed when a location is selected');
console.log('STRICT ADDRESS CASCADE REGRESSION: PASS 3/3');
