$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
Write-Host '=== BONGSHOKOTHA ULTIMATE VERIFY ===' -ForegroundColor Cyan
Write-Host "Node: $(node -v)"
npm.cmd -v
npm.cmd run verify
Write-Host 'VERIFY PASSED' -ForegroundColor Green
