import fs from 'node:fs';
const modal=fs.readFileSync('src/components/MemberModal.tsx','utf8');
const profile=fs.readFileSync('src/components/MemberProfileModal.tsx','utf8');
const marriage=fs.readFileSync('src/components/MarriageModal.tsx','utf8');
const checks=[
 ['multiple spouse selection is supported', /spouseIds/.test(modal) && /multiple marriages supported/.test(modal)],
 ['spouse generation/gender filtering exists', /potentialSpouses/.test(modal) && /relationshipGeneration/.test(modal)],
 ['multiple child name rows are supported', /childNameDrafts/.test(modal) && /addChildNameRow/.test(modal)],
 ['child gender is captured per row', /childGenderDrafts/.test(modal) && /updateChildGenderRow/.test(modal)],
 ['existing children can be selected', /filteredPotentialChildren/.test(modal) && /Select child from list|তালিকা থেকে সন্তান নির্বাচন করুন/.test(modal)],
 ['children remain available for unmarried members', /সন্তানদের নাম/.test(modal) && !/\(spouseId \|\| spouseIds\.length > 0 \|\| maritalStatus !== 'unmarried'\)/.test(modal)],
 ['marriage-specific child groups are shown in profile', /getCanonicalChildrenForMarriage\(mar/.test(profile) && /বিবাহভিত্তিক সন্তান/.test(profile)],
 ['existing marriage children are preserved during edit', /Preserve existing marriage-specific children/.test(modal) && /linkedMarriage\.childrenIds/.test(modal)],
 ['new children are added only to selected union', /createdChildIds/.test(modal) && /selectedSpouseId === spouseId \? createdChildIds/.test(modal)],
 ['marriage modal supports childrenIds', /childrenIds/.test(marriage)],
];
for(const [name,ok] of checks) console.log(`${ok?'PASS':'FAIL'} | ${name}`);
if(checks.some(([,ok])=>!ok)) process.exit(1);
console.log(`LEGACY RELATIONSHIP UI REGRESSION PASS: ${checks.length}/${checks.length}`);
