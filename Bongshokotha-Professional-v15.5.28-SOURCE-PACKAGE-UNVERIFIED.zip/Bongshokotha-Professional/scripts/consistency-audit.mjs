import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const pkg = JSON.parse(read('package.json'));
const versionSource = read('src/appVersion.ts');
const checks = [];
const ok = (name, pass, detail='') => checks.push({name, pass, detail});

ok('Package version matches centralized app version', versionSource.includes(`'${pkg.version}'`) || versionSource.includes(`"${pkg.version}"`), `package=${pkg.version}`);
const sidebar = read('src/components/Sidebar.tsx');
ok('Sidebar does not contain stale v2.5 Pro', !sidebar.includes('v2.5 Pro'));
const settings = read('src/components/SettingsView.tsx');
ok('Settings theme count is registry-driven', settings.includes('filteredThemes.length} / {themeRegistry.allThemes.length'));
ok('Production self-role switch is dev-only', settings.includes('import.meta.env.DEV') && settings.includes('Production builds do not allow self-role switching'));
const context = read('src/context/GenealogyContext.tsx');
ok('Factory reset enforces canFactoryReset', /resetToFactoryState[\s\S]*requirePermission\('canFactoryReset'\)/.test(context));
ok('Safe reset preserves privacy masking default', /enablePrivacyMasking: true/.test(context));
for (const f of ['src/components/SettingsView.tsx']) {
  const t=read(f);
  ok(`${f}: no hardcoded fake storage size`, !t.includes('~4.8 MB'));
  ok(`${f}: no hardcoded fake offline readiness`, !t.includes('100% Ready'));
}
const failures = checks.filter(x=>!x.pass);
for (const c of checks) console.log(`${c.pass?'PASS':'FAIL'} | ${c.name}${c.detail?` | ${c.detail}`:''}`);
if (failures.length) process.exit(1);
console.log(`Consistency audit passed: ${checks.length}/${checks.length}`);
