import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const profile = fs.readFileSync(path.join(root,'src/components/MemberProfileModal.tsx'),'utf8');
const modal = fs.readFileSync(path.join(root,'src/components/MemberModal.tsx'),'utf8');
const scanner = fs.readFileSync(path.join(root,'src/components/archive/DocumentScannerModal.tsx'),'utf8');
const registry = fs.readFileSync(path.join(root,'src/services/serverRegistry.ts'),'utf8');
const checks = [
  ['profile derives in-laws per marriage', /inLawByMarriage/.test(profile)],
  ['profile has scanner-first action', /স্ক্যান \+ তথ্য নিন/.test(profile)],
  ['profile direct upload accepts PDF', /accept="image\/\*,\.pdf,\.doc,\.docx"/.test(profile)],
  ['profile direct upload sends PDF to OCR', /runDocumentOcrBatch/.test(profile) && /application\/pdf/.test(profile) && /\.pdf\$/i.test(profile)],
  ['scanner can apply OCR to selected member', /applyOcrToSelectedMember/.test(scanner)],
  ['scanner accepts PDF', /accept="image\/\*,\.pdf/.test(scanner)],
  ['member editor syncs spouse parent when missing', /syncSelectedSpouseParents/.test(modal)],
  ['in-law candidate uses spouse canonical parents', /spouseFather.*spouseMother/s.test(modal)],
  ['server registry includes Neon', /id: 'neon'/.test(registry)],
  ['server registry includes Supabase', /id: 'supabase'/.test(registry)],
  ['server registry includes Firebase', /id: 'firebase'/.test(registry)],
  ['server registry includes Appwrite', /id: 'appwrite'/.test(registry)],
  ['Cloudflare is not an active default server', !/id:\s*'cloudflare'/i.test(registry)]
];
let failed=0;
for (const [name, ok] of checks) { console.log(`${ok?'PASS':'FAIL'} — ${name}`); if(!ok) failed++; }
if(failed) process.exit(1);
console.log(`All ${checks.length} in-law/OCR/server profile checks passed.`);
