import fs from 'node:fs';
const auth = fs.readFileSync('src/services/authRbac.ts','utf8');
const account = fs.readFileSync('src/components/MyAccountView.tsx','utf8');
const sidebar = fs.readFileSync('src/components/Sidebar.tsx','utf8');
const settings = fs.readFileSync('src/components/SettingsView.tsx','utf8');
const context = fs.readFileSync('src/context/GenealogyContext.tsx','utf8');
const admin = fs.readFileSync('src/components/AdminCenterView.tsx','utf8');
const checks = [
 ['Co-Admin role exists', /'co_admin'/.test(auth)],
 ['Tester role exists in role union and permission matrix', /'tester'/.test(auth) && /tester:\s*\{/.test(auth)],
 ['Equal-role assignment is denied', /role === actorRole/.test(auth)],
 ['Higher-role assignment is denied using strict rank', /rank\[role\] >= rank\[actorRole\]/.test(auth)],
 ['Role hierarchy includes all eight roles', /viewer:0, contributor:1, editor:2, tester:3, co_admin:4, admin:5, super_admin:6, owner:7/.test(auth)],
 ['Co-Admin has normal admin capabilities', /co_admin:\s*\{[\s\S]*canAddMember: true[\s\S]*canEditMember: true[\s\S]*canDeleteMember: true[\s\S]*canManageRoles: true/.test(auth)],
 ['Co-Admin Gmail backup denied', /co_admin:\s*\{[\s\S]*canGmailBackup: false/.test(auth)],
 ['Co-Admin server management denied', /co_admin:\s*\{[\s\S]*canManageServers: false/.test(auth)],
 ['Co-Admin full genealogy deletion denied', /co_admin:\s*\{[\s\S]*canDeleteEntireGenealogy: false/.test(auth)],
 ['Admin can assign roles', /admin:\s*\{[\s\S]*canManageRoles: true/.test(auth)],
 ['My Account menu exists', /my-account/.test(sidebar) && /My Account/.test(account)],
 ['Account changes use stored accounts', /listStoredAccounts\(\)/.test(account) && /saveStoredAccounts\(accounts\)/.test(account)],
 ['Account update does not update genealogy member', /never mutate genealogy data|বংশতালিকার Member Profile অপরিবর্তিত থাকবে/.test(account)],
 ['Gmail backup checks permission', /canGmailBackup/.test(settings)],
 ['Server checks permission', /canManageServers/.test(settings)],
 ['Full-family delete checks dedicated permission', /clearCurrentFamilyData[\s\S]*requirePermission\('canDeleteEntireGenealogy'\)/.test(context)],
 ['Admin hides restricted Gmail/Server sections', /canGmailBackup \?/.test(admin) && /canManageServers \?/.test(admin)]
];
let failed=0;
for (const [name,ok] of checks) { console.log(`${ok?'PASS':'FAIL'} | ${name}`); if(!ok) failed++; }
if(failed) process.exit(1);
console.log(`ACCOUNT/CO-ADMIN REGRESSION: ${checks.length}/${checks.length} PASS`);
