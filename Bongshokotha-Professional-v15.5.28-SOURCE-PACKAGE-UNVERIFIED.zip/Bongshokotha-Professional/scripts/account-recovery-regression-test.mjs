import fs from 'node:fs';
const login=fs.readFileSync('src/components/LoginView.tsx','utf8');
const account=fs.readFileSync('src/components/MyAccountView.tsx','utf8');
const admin=fs.readFileSync('src/components/AdminCenterView.tsx','utf8');
const auth=fs.readFileSync('src/services/authRbac.ts','utf8');
const checks=[
 ['Username is part of the account model',auth.includes('username?: string')],
 ['Registration requires a unique username',login.includes('!username.trim()') && login.includes('a.username && a.username.toLowerCase()')],
 ['Login accepts username and legacy contact identifiers',login.includes('a.username?.toLowerCase() === value.toLowerCase()') && login.includes('a.mobile === normalizeMobile(value)') && login.includes('a.email?.toLowerCase()')],
 ['Forgot password option is present',login.includes('Forgot password?') && login.includes('পাসওয়ার্ড ভুলে গেছেন?')],
 ['Recovery does not falsely claim OTP was sent',login.includes('Email/SMS OTP delivery is not configured')],
 ['Admin has authorized password reset action',admin.includes('resetAccountPassword') && admin.includes('target.passwordDigest = await hashPassword(nextPassword)')],
 ['Password reset is audited without logging password',admin.includes("eventType:'password_reset'") && admin.includes('logAuditEvent')],
 ['User can update their username in My Account',account.includes('setUsername') && account.includes('target.username = username.trim()')]
];
let fail=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} | ${name}`); if(!ok)fail++;}
if(fail)process.exit(1); console.log(`ACCOUNT RECOVERY REGRESSION: ${checks.length}/${checks.length} PASS`);
