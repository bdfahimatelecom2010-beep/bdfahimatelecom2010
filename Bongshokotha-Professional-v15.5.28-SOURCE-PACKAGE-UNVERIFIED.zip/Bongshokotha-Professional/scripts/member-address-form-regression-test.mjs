import fs from 'node:fs';
const source = fs.readFileSync(new URL('../src/components/MemberModal.tsx', import.meta.url), 'utf8');
const checks = [
  ['separate structured current address fields', source.includes('currentAddressDetails')],
  ['separate structured permanent address fields', source.includes('permanentAddressDetails')],
  ['holding field', new RegExp(`\\{\\s*key:\\s*['\"]holding['\"]`).test(source)],
  ['road field', new RegExp(`\\{\\s*key:\\s*['\"]road['\"]`).test(source)],
  ['village/locality field', new RegExp(`\\{\\s*key:\\s*['\"]village['\"]`).test(source)],
  ['union/municipality field', new RegExp(`\\{\\s*key:\\s*['\"]union['\"]`).test(source)],
  ['ward field', new RegExp(`\\{\\s*key:\\s*['\"]ward['\"]`).test(source)],
  ['post office field', new RegExp(`\\{\\s*key:\\s*['\"]postOffice['\"]`).test(source)],
  ['postal code field', new RegExp(`\\{\\s*key:\\s*['\"]postalCode['\"]`).test(source)],
  ['upazila/thana field', new RegExp(`\\{\\s*key:\\s*['\"]upazila['\"]`).test(source)],
  ['district field', new RegExp(`\\{\\s*key:\\s*['\"]district['\"]`).test(source)],
  ['division field', new RegExp(`\\{\\s*key:\\s*['\"]division['\"]`).test(source)],
  ['country field', new RegExp(`\\{\\s*key:\\s*['\"]country['\"]`).test(source)],
  ['copy-current-to-permanent action', source.includes('setPermanentAddressDetails({...currentAddressDetails})')],
  ['structured address persisted to fullAddress', source.includes('formatLocationInfo(currentAddressDetails, currentAddress)') && source.includes('formatLocationInfo(permanentAddressDetails, permanentAddress)') && source.includes('a.holding') && source.includes('a.road') && source.includes('a.postalCode')],
  ['legacy address compatibility helper', source.includes('normalizeAddressInfo')],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed++; }
console.log(`MEMBER ADDRESS FORM REGRESSION: ${checks.length - failed}/${checks.length}`);
if (failed) process.exit(1);
