import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const modal = fs.readFileSync(path.join(root,'src/components/MemberModal.tsx'),'utf8');
const ordering = fs.readFileSync(path.join(root,'src/engine/genealogyOrdering.ts'),'utf8');
const checks = [
  ['marriage-origin is explicit', /birthOrigin,/],
  ['marriage-origin flag mirrors origin', /marriageOrigin: birthOrigin === 'joined_by_marriage'/],
  ['quick-added spouse is marriage-origin', /birthOrigin: \(isSpouseRelation \|\| isInLawRelation\) \? 'joined_by_marriage' : 'born_in_family'/],
  ['spouse is linked to selected member', /setSpouseIds\(prev => \[\.\.\.new Set\(\[\.\.\.prev, newMember\.id\]\)\]\)/],
  ['canonical order documents spouse-adjacent rule', /Spouses are presentation companions/],
  ['canonical order excludes marriage-origin roots', /m\.birthOrigin !== 'joined_by_marriage' && !m\.marriageOrigin/],
  ['canonical order does not use spouse birth order', /A married-in person's own birthOrder never controls/],
  ['child branch completes before next sibling', /entire first child's branch before moving/],
];
let failed = false;
for (const [name,re] of checks) {
  const ok = (name.startsWith('canonical') || name.includes('spouse') || name.includes('child')) ? re.test(ordering + '\n' + modal) : re.test(modal);
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`); failed ||= !ok;
}
if (failed) process.exit(1);
console.log(`MARRIAGE-ORIGIN REGRESSION PASS: ${checks.length}/${checks.length}`);
