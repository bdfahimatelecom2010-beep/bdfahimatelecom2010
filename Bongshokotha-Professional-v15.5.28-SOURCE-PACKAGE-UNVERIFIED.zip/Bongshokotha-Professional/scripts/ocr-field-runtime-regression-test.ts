import { parseDocumentFields } from '../src/engine/ocrFieldParser.ts';

const cases = [
  {
    name: 'Bangla NID + DOB + names',
    text: `জাতীয় পরিচয়পত্র\nNID No: 1987654321\nনাম: মোঃ রহিম উদ্দিন\nName in English: MD RAHIM UDDIN\nপিতা: মোঃ করিম উদ্দিন\nমাতা: রহিমা বেগম\nজন্ম তারিখ: 12/05/1985`,
    expect: (x: ReturnType<typeof parseDocumentFields>) => x.documentKind === 'nid' && x.nidNumber === '1987654321' && x.fullNameEn === 'MD RAHIM UDDIN' && x.dateOfBirth === '12/05/1985'
  },
  {
    name: 'Passport label + DOB',
    text: `PASSPORT\nPassport No: BG1234567\nName: RAHIM UDDIN\nDate of Birth: 05/11/1985`,
    expect: (x: ReturnType<typeof parseDocumentFields>) => x.documentKind === 'passport' && x.passportNumber === 'BG1234567' && x.dateOfBirth === '05/11/1985'
  },
  {
    name: 'Passport MRZ',
    text: `P<BGDRAHIM<<UDDIN<<<<<<<<<<<<<<<<<<<<\nBG1234567<8BGD8505119M3001012<<<<<<<<<<<<<<00`,
    expect: (x: ReturnType<typeof parseDocumentFields>) => x.passportNumber === 'BG1234567'
  },
  {
    name: 'BRN + parents',
    text: `Birth Registration Certificate\nBirth Registration No: 19851234567890123\nName: রহিমা আক্তার\nFather's Name: Karim Uddin\nMother's Name: Rahima Begum\nDate of Birth: 1985-05-12`,
    expect: (x: ReturnType<typeof parseDocumentFields>) => x.documentKind === 'birth_registration' && x.brnNumber === '19851234567890123' && x.fatherName === 'Karim Uddin' && x.motherName === 'Rahima Begum'
  }
];

let failed = 0;
for (const c of cases) {
  const result = parseDocumentFields(c.text, 92);
  const ok = c.expect(result);
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${c.name} | ${JSON.stringify(result)}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
console.log(`OCR FIELD RUNTIME REGRESSION PASS: ${cases.length}/${cases.length}`);
