import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const required = [
  'src/engine/genealogyOrdering.ts','src/engine/generationEngine.ts','src/engine/relationshipEngine.ts',
  'src/engine/ocrEngine.ts','src/engine/ocrFieldParser.ts','src/components/MemberModal.tsx',
  'src/components/MemberProfileModal.tsx','src/components/FamilyTreeView.tsx','src/components/FamilyArchiveView.tsx',
  'src/components/FamilyBookView.tsx','src/components/DashboardView.tsx','src/components/SettingsView.tsx',
  'src/components/ImportExportView.tsx','src/services/storage.ts','src/services/succession.ts',
  'src/services/serverRegistry.ts','src/services/googleDriveBackup.ts','electron/main.cjs','BUILD-WINDOWS.ps1',
  'scripts/prepare-ocr-data.ps1','public/tessdata/ben.traineddata.gz','public/tessdata/eng.traineddata.gz'
];
let failed=false;
for(const f of required){const ok=fs.existsSync(path.join(root,f));console.log(`${ok?'PASS':'FAIL'} | required consolidated artifact | ${f}`);failed ||= !ok;}
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const expectedVersion=pkg.version; console.log(`PASS | package version ${expectedVersion}`);
const app=fs.readFileSync(path.join(root,'src/appVersion.ts'),'utf8');
const appOk=app.includes(`APP_VERSION = '${expectedVersion}'`); console.log(`${appOk?'PASS':'FAIL'} | app version ${expectedVersion}`); failed ||= !appOk;
if(failed) process.exit(1);
console.log('CONSOLIDATION AUDIT PASS');
