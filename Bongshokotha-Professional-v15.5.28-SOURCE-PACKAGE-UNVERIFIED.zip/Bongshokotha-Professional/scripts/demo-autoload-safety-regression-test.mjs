import fs from 'node:fs';
const source = fs.readFileSync('src/context/GenealogyContext.tsx', 'utf8');
const checks = [
  ['sample family is explicitly identified as demo-only', source.includes("f.id !== 'family-sample-choudhury'")],
  ['empty non-demo workspace creates a fresh family', source.includes('if (nonDemoFamilies.length === 0)') && source.includes('await storage.saveFamily(fresh)')],
  ['fresh family is selected as the fallback, not sample data', source.includes(': nonDemoFamilies[0]')],
  ['active family is persisted after safe selection', source.includes('storage.setActiveFamilyId(activeFamily.id)')],
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}`);
if (checks.some(([, ok]) => !ok)) process.exit(1);
console.log(`DEMO AUTO-LOAD SAFETY PASS: ${checks.length}/${checks.length}`);
