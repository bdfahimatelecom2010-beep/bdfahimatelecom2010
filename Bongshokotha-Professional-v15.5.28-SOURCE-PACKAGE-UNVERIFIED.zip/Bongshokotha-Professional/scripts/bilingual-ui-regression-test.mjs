import fs from 'node:fs';
const t=fs.readFileSync('src/i18n/translations.ts','utf8');
const app=fs.readFileSync('src/App.tsx','utf8');
const header=fs.readFileSync('src/components/Header.tsx','utf8');
const settings=fs.readFileSync('src/components/SettingsView.tsx','utf8');
const admin=fs.readFileSync('src/components/AdminCenterView.tsx','utf8');
const checks=[
 ['Bengali language is registered', /code: 'bn'.*nativeName: 'বাংলা'/s.test(t)],
 ['English language is registered', /code: 'en'.*nativeName: 'English'/s.test(t)],
 ['language persists in family settings', /settings:\s*\{\s*\.\.\.prev\.settings,\s*language: lang/s.test(fs.readFileSync('src/context/GenealogyContext.tsx','utf8'))],
 ['header can switch Bengali/English', /setLanguage\(isBn \? 'en' : 'bn'\)/.test(header)],
 ['settings exposes language selector', /SUPPORTED_LANGUAGES/.test(settings) && /setLanguage\(lang\.code\)/.test(settings)],
 ['admin server buttons are bilingual', /isBn \? 'লগইন পেজ' : 'Login Page'/.test(admin) && /isBn \? 'সংযোগ যাচাই' : 'Test Connection'/.test(admin)],
 ['footer is bilingual', /language === 'bn'/.test(app) && /BONGSHOKOTHA/.test(app)],
];
for(const [name,ok] of checks) console.log(`${ok?'PASS':'FAIL'} | ${name}`);
if(checks.some(([,ok])=>!ok)) process.exit(1);
console.log(`BILINGUAL UI REGRESSION PASS: ${checks.length}/${checks.length}`);
