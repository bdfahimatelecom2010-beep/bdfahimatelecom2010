# BONGSHOKOTHA PROFESSIONAL 15.4.1 — Universal OCR & Human Review

## Release goal

A document is evidence first. OCR extracts information and shows it to the user;
only user-selected information is allowed to become Profile data.

## Workflow

Upload / Camera / PDF / multi-file session
→ preprocess
→ Bengali + English OCR
→ document type + side detection
→ structured field extraction
→ generic labelled-field extraction
→ raw OCR preservation
→ confidence
→ conflict detection
→ duplicate/member matching
→ user review
→ Apply Selected Fields / Evidence Only
→ canonical Profile update + audit

## Implemented in this release

- NID front-only, back-only and front+back session support.
- Multi-file OCR session with front/back merge.
- NID MRZ-like `I<BGD...` is never treated as Passport MRZ.
- Passport MRZ requires Passport context and `P<` marker.
- Passport number, personal number, issue date, expiry date, issuing authority,
  previous passport and nationality are extracted where visible/readable.
- Bangladesh address components: holding, road/village, union/municipality,
  ward, post office, postal code, upazila/thana, district, division, country.
- Present and permanent address are kept separately when the document provides them.
- Generic labelled fields such as emergency-contact Name/Relationship/Telephone
  are preserved as evidence even when no matching Profile field exists.
- Unmapped OCR lines remain visible instead of being discarded.
- Conflicting values from multiple pages/sides are retained for review.
- Original source files are preserved for a multi-file archive session.
- Profile review UI shows every extracted field and marks Profile-writable vs
  Evidence/Review-only information.
- OCR never silently overwrites verified canonical Profile data.
- Relationship suggestions remain separate from OCR field extraction.

## Verification rule

A source file existing in the ZIP is not treated as tested. This release is
considered ready only after the source/runtime OCR regression tests and the
normal dependency-backed build/typecheck pass.
