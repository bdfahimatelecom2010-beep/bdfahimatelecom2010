# বংশকথা Professional — সম্পূর্ণ মাস্টার চাহিদা ও গ্রহণযোগ্যতা তালিকা

**প্রকল্প:** Bongshokotha Professional / বংশকথা Professional  
**এই প্যাকেজের সংস্করণ:** 15.5.6  
**মূল নীতি:** তালিকাভুক্ত থাকা মানেই ফিচারটি সম্পূর্ণ হয়েছে নয়; প্রতিটি আইটেমের বাস্তব পরীক্ষা ও প্রমাণ প্রয়োজন।

## ১. সদস্য পরিচিতি ও প্রোফাইল
- [ ] প্রতিটি ব্যক্তির স্থায়ী, অনন্য internal ID; একই নামের ব্যক্তিকে আলাদা শনাক্তকরণ।
- [ ] বাংলা নাম বাধ্যতামূলক/প্রধান; English name ঐচ্ছিক ও আলাদা ফিল্ড।
- [ ] বিকল্প নাম, বানান ও ডাকনাম; প্রতিটি নামের উৎস (জন্ম নিবন্ধন, NID, পাসপোর্ট, স্কুল/কলেজ, জমি/দলিল ইত্যাদি), রেফারেন্স ও নোট।
- [ ] শুধু বানান মিল দেখে দুই ব্যক্তিকে কখনো স্বয়ংক্রিয়ভাবে একীভূত করা যাবে না।
- [ ] জন্মতারিখ, জন্মস্থান, নিজ জন্ম-ক্রমিক নম্বর, প্রজন্ম, পেশা, শিক্ষা, যোগাযোগ, ছবি, নথি, বর্তমান/স্থায়ী ঠিকানা।
- [ ] জীবন-অবস্থা: জীবিত/মৃত; ডিফল্ট জীবিত। বৈবাহিক অবস্থা: ডিফল্ট অবিবাহিত; একই তথ্যের জন্য দ্বৈত/বিভ্রান্তিকর কন্ট্রোল নয়।
- [ ] সদস্যের সম্পাদনা সেভ হবে; রিফ্রেশ/লগআউট/পুনরায় চালুর পরও তথ্য থাকবে।
- [ ] প্রোফাইলে সব সম্পর্ক, প্রজন্ম, ছবি, দলিল, বিবাহ ও সন্তান স্পষ্টভাবে দেখা যাবে।

## ২. পারিবারিক সম্পর্ক ও বংশগাছ
- [ ] বাবা-মা এবং বাবা-মায়ের বিপরীত দিকের সন্তান-লিংক একই canonical relationship data থেকে নির্ণয়।
- [ ] দাদা-দাদি, নানা-নানি, ভাই-বোন, চাচা/ফুফু/মামা/খালা ইত্যাদি সম্পর্ক যথাসম্ভব সঠিকভাবে নির্ণয়।
- [ ] পিতৃবংশ ও মাতৃবংশ আলাদা অনুসরণ এবং সম্পর্কের উৎস দেখানো।
- [ ] জন্মপরিবার, বিবাহসূত্রে আসা সদস্য এবং দত্তক সম্পর্ক আলাদা ধরনের হিসেবে সংরক্ষণ।
- [ ] বিবাহসূত্রে আসা সদস্যের জন্ম-পিতা-মাতা রাখা যাবে; তারা অনুমতি ছাড়া নতুন পরিবারের সদস্য হয়ে যাবে না।
- [ ] প্রজন্ম ও জন্ম-ক্রমিক হিসাব ম্যানুয়াল ও আমদানি করা ডেটা দিয়ে যাচাই।
- [ ] নিজের পূর্বপুরুষ নিজেই হয়ে যাওয়া, circular relationship, duplicate child ও broken parent link শনাক্ত/প্রতিরোধ।
- [ ] ইন্টার‌্যাক্টিভ বংশগাছ: পূর্বপুরুষ, বংশধর, শাখা, মাতৃবংশ/পিতৃবংশ, zoom/expand/collapse, print/PDF/export।

## ৩. বিবাহ ও সন্তান
- [ ] একই ব্যক্তির একাধিক বিবাহ; প্রতিটি বিবাহের আলাদা স্থায়ী Marriage ID।
- [ ] প্রতিটি বিবাহের স্বামী/স্ত্রী, তারিখ, অবস্থা, ঠিকানা, উভয় পক্ষের পিতা-মাতার নাম আলাদাভাবে সংরক্ষণ।
- [ ] প্রতিটি বিবাহের সন্তান শুধু সঠিক বিবাহ/দম্পতির সঙ্গে লিংক হবে; অন্য বিবাহের সন্তান মিশবে না।
- [ ] সন্তান যোগ/সম্পাদনার পর প্রোফাইলে সঙ্গে সঙ্গে দেখা যাবে; পুরোনো সন্তানের নাম নতুন ইনপুটে অনিচ্ছাকৃতভাবে থাকবে না।
- [ ] ছেলে/মেয়ে/অন্যান্য সমর্থিত লিঙ্গ-তথ্য অনুযায়ী সম্পর্কের লেবেল; অজানা হলে অনুমান নয়।
- [ ] অবিবাহিত, বিবাহিত, বিধবা/বিপত্নীক, তালাকপ্রাপ্ত ও অন্যান্য প্রয়োজনীয় অবস্থা; জীবন-অবস্থা থেকে আলাদা।
- [ ] স্বামী/স্ত্রীর মৃত্যু বা বিবাহের অবস্থা বদলালে ঐতিহাসিক সন্তান/সম্পর্ক মুছে যাবে না।
- [ ] শ্বশুর-শাশুড়ি ও ইন-ল সম্পর্ক প্রতিটি বিবাহ অনুযায়ী দেখা/সম্পাদনা।

## ৪. ঠিকানা ও আন্তর্জাতিক সেটিংস
- [ ] বর্তমান ও স্থায়ী ঠিকানা আলাদা; বর্তমান থেকে স্থায়ী ঠিকানায় কপি করার সুবিধা।
- [ ] বিভাগ → জেলা → উপজেলা/থানা → ইউনিয়ন/পৌরসভা/সিটি করপোরেশন → গ্রাম/এলাকা → ওয়ার্ড/রাস্তা/বাড়ি/হোল্ডিং।
- [ ] পোস্ট অফিস ও পোস্টকোড; বাংলা ও English প্রদর্শন।
- [ ] নির্বাচনের সঙ্গে সামঞ্জস্যপূর্ণ cascade; উপরের স্তর পাল্টালে অকার্যকর নিচের নির্বাচন মুছে যাবে।
- [ ] ঠিকানার লাইভ প্রিভিউ ও পুরোনো free-text ঠিকানার backward compatibility।
- [ ] সম্পূর্ণ ও যাচাইকৃত বাংলাদেশ প্রশাসনিক/ডাক-ঠিকানা ডেটাসেট লাইসেন্স/উৎসসহ যোগ ও পরীক্ষা।
- [ ] আন্তর্জাতিক সেটিংসে দেশ, ভাষা, তারিখ, সংখ্যা ও সময়-ফরম্যাট।

## ৫. দলিল, OCR ও পারিবারিক আর্কাইভ
- [ ] সদস্য-প্রোফাইল ও Family Archive থেকে ছবি/PDF এবং সমর্থিত ডকুমেন্ট আপলোড।
- [ ] মূল ফাইল অক্ষত রাখা; OCR টেক্সট ও যাচাইকৃত প্রোফাইল ডেটা আলাদা রাখা।
- [ ] বাংলা/English OCR; PDF-এর একাধিক পৃষ্ঠা প্রসেস; সমর্থিত ফরম্যাটের সীমা স্পষ্টভাবে জানানো।
- [ ] নাম, জন্মতারিখ, NID, জন্ম নিবন্ধন নম্বর, বাবা-মায়ের নাম ও অন্যান্য পাওয়া তথ্য confidence/verification সহ দেখানো।
- [ ] ব্যবহারকারী ফলাফল review/edit/accept না করা পর্যন্ত verified profile field নীরবে overwrite নয়।
- [ ] OCR থেকে বিকল্প নাম/প্রমাণের উৎস তৈরি; সঠিক সদস্যের সঙ্গে যুক্ত করার আগে নিশ্চিতকরণ।
- [ ] নথি duplicate শনাক্ত, archive থেকে profile link, bulk upload, scan/camera, oral history/audio support যেখানে বাস্তবায়িত।
- [ ] OCR আর্কাইভে কী তথ্য পেয়েছে তা স্পষ্ট দেখানো; গ্রহণ/বাতিল/পরবর্তীতে যাচাইয়ের ব্যবস্থা।

## ৬. ড্যাশবোর্ড ও থিম
- [ ] সদস্য সংখ্যা, প্রজন্ম, শাখা, জীবিত/মৃত, বৈবাহিক অবস্থা, ছেলে/মেয়ে, তথ্য-অসম্পূর্ণতা, duplicate, archive/OCR, ব্যাকআপ/সার্ভার, জন্মদিন/বার্ষিকী ও সাম্প্রতিক কার্যক্রম।
- [ ] ড্যাশবোর্ডের প্রতিটি কার্ড সঠিক বিস্তারিত ফলাফলে নিয়ে যাবে; demo/static সংখ্যা নয়।
- [ ] Settings থেকে widget ON/OFF, সাজানোর ক্রম ও layout নিয়ন্ত্রণ; সেটিংস রিফ্রেশের পরও থাকবে।
- [ ] Light/Dark/System theme বাস্তবে কার্যকর; বাংলা ফন্ট, contrast ও responsive layout যাচাই।
- [ ] আলাদা অপ্রয়োজনীয় Static/Family Statistics মেনু নয়; প্রাসঙ্গিক পরিসংখ্যান ড্যাশবোর্ডে।

## ৭. অ্যাকাউন্ট, ভূমিকা ও নিরাপত্তা
- [ ] My Account-এ নিজের নাম, username, মোবাইল, Gmail/email, পাসওয়ার্ড ও ছবি সম্পাদনা।
- [ ] অ্যাকাউন্ট পরিচিতি genealogy member profile থেকে সম্পূর্ণ পৃথক; account পরিবর্তন বংশের তথ্য বদলাবে না।
- [ ] নির্ধারিত আটটি role: Owner, Super Admin, Admin, Co-Admin, Tester, Editor, Contributor, Viewer।
- [ ] কেউ নিজের সমান বা উচ্চতর role কাউকে দিতে পারবে না; অনুমতি সার্ভার/backend-এ enforce করতে হবে, শুধু UI-তে নয়।
- [ ] Co-Admin সাধারণ admin কাজ করতে পারবে, কিন্তু Gmail Backup, Server management ও সম্পূর্ণ বংশ মুছতে পারবে না।
- [ ] Viewer শুধু নিজের অ্যাকাউন্ট/নিজস্ব প্রোফাইলের অনুমোদিত অংশ পরিবর্তন করতে পারবে; অন্য সদস্য, canonical relationship, role, import/export, backup/server বা genealogy delete নয়।
- [ ] Contributor-এর পরিবর্তন প্রস্তাব/অনুমোদন workflow; অনুমোদন ছাড়া canonical relationship বদল নয়।
- [ ] Tester/Editor/Admin/Super Admin/Owner permissions আলাদাভাবে login-to-logout পরীক্ষা।
- [ ] প্রকৃত password reset link/OTP provider কনফিগার; provider না থাকলে OTP পাঠানো হয়েছে এমন মিথ্যা বার্তা নয়।
- [ ] session expiry/revocation, brute-force mitigation, invite safety, audit log ও ব্যক্তিগত নথির privacy filtering।

## ৮. ডেটা সংরক্ষণ, ব্যাকআপ, Sync ও পুনরুদ্ধার
- [ ] local persistence; browser refresh, browser restart ও app restart-এ ডেটা অক্ষত।
- [ ] demo/sample genealogy কখনো ব্যবহারকারীর আসল ডেটার জায়গায় স্বয়ংক্রিয়ভাবে লোড হবে না।
- [ ] Recycle Bin/restore, প্রয়োজনীয় ক্ষেত্রে Undo, পরিবর্তনের audit history।
- [ ] Backup-এ সদস্য, সম্পর্ক, বিবাহ, বিকল্প নাম, ছবি, archive evidence ও metadata অক্ষত।
- [ ] restore-এর আগে diff/preview; duplicate/invalid data শনাক্ত; rollback বা নিরাপদ ব্যর্থতা।
- [ ] Gmail/cloud backup ও server configuration প্রকৃত provider/credentials দিয়ে পরীক্ষা; secrets log-এ নয়।
- [ ] offline changes ও online sync conflict শনাক্ত/সমাধান; network failure-এ user warning।
- [ ] Import/export: JSON, CSV, GEDCOM এবং ঘোষিত সমর্থিত format; import ID, duplicate, malformed data ও lossless round-trip পরীক্ষা।

## ৯. গতি, প্ল্যাটফর্ম ও ব্যবহারযোগ্যতা
- [ ] Android ফোন, tablet, Windows desktop ও browser-এ responsive layout।
- [ ] বড় পরিবারে হাজার/দশ-হাজার রেকর্ডের search, profile ও tree performance পরিমাপ।
- [ ] দুর্বল ইন্টারনেট ও offline অবস্থায় স্পষ্ট অবস্থা; pending save হারাবে না।
- [ ] keyboard navigation, form validation, error boundary এবং ব্যবহারকারী-বোধ্য বাংলা error message।
- [ ] supported file type/size এবং unsupported ফাইলের জন্য নিরাপদ error।

## ১০. রিলিজ গ্রহণযোগ্যতা পরীক্ষা
- [ ] ZIP integrity, dependency install, version audit, TypeScript typecheck ও production build।
- [ ] সব source regression tests পাস; failing test লুকিয়ে বা সরিয়ে নয়, কারণ সমাধান করে।
- [ ] বাস্তব browser E2E: login, create/edit/save/reload, marriage/children, archive/OCR, backup/restore, import/export।
- [ ] আটটি role-এর positive ও negative permission tests।
- [ ] Android/mobile এবং desktop-এর বাস্তব পরীক্ষা।
- [ ] console/network error, accessibility, performance ও security review।
- [ ] known bugs: edit/save, data persistence/demo auto-load, child duplication/list refresh, in-law save, marriage-origin generation, OCR accept-to-profile, dashboard undefined data—সব পুনরায় পরীক্ষা।
- [ ] release report-এ প্রতিটি পরীক্ষার ফল PASS/FAIL/NOT RUN এবং প্রমাণ/সীমাবদ্ধতা লেখা।

---

## বর্তমান রিলিজের নিয়ম
এই নথির checkbox গুলো acceptance criteria। এগুলো নিজে থেকে কোনো ফিচার বাস্তবে সম্পূর্ণ হয়েছে বা runtime-এ পাস করেছে—এমন প্রমাণ নয়। প্রকৃত অবস্থা `REQUIREMENTS-STATUS-15.5.6.md` এবং `RELEASE-TEST-REPORT-15.5.6.md`-এ দেখুন।
