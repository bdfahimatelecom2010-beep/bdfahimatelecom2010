$ErrorActionPreference = "Stop"
Set-ExecutionPolicy -Scope Process Bypass -Force
Write-Host "BONGSHOKOTHA Professional Self-Build"
node -v
npm.cmd -v
npm.cmd install
npm.cmd run audit:version
npm.cmd run prepare:ocr
npm.cmd run verify
Write-Host "BUILD COMPLETE"
Write-Host "Run: npm.cmd run dev"
