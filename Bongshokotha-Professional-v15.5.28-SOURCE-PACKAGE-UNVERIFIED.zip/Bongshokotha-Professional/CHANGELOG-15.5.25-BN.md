# বংশকথা প্রফেশনাল v15.5.25 — Role Menu ও Save Diagnostics সংশোধন

## সংশোধন
- Role Menu assignment এখন Owner/Admin/Co-Admin-সহ সব Role-এর জন্য কার্যকর; উচ্চতর প্রশাসনিক অনুমতি থাকলেই Admin Center দেখা যাবে। শুধু Role Menu-তে কোনো মেনু চালু করলেই প্রশাসনিক Permission পাওয়া যায় না।
- Data Health ও Integrity Repair-কে আলাদা সাধারণ Sidebar মেনু না করে Admin Center-এর অনুমতিনির্ভর বিভাগে রাখা হয়েছে।
- সদস্য Save ব্যর্থ হলে শুধু সাধারণ বার্তা নয়, কোন ধাপে ব্যর্থ হয়েছে এবং মূল ত্রুটি কী—তা লগে রাখা হয় এবং ব্যবহারকারীকে ধাপসহ দেখানো হয়। এতে Android WebView-তে Save ব্যর্থতার কারণ শনাক্ত করা সহজ হবে।
- সদস্য/দলিল সংরক্ষণ, spouse-parent reconciliation, marriage update এবং child-link ধাপ আলাদাভাবে চিহ্নিত করা হয়েছে।
- লগআউটের পাঁচ মিনিট পর সাময়িক sessionStorage ডেটা পরিষ্কার হয়; Android-এ `window.close()` দিয়ে অ্যাপ বন্ধ করার চেষ্টা সরানো হয়েছে, যাতে লগআউটের পর অ্যাপ নিজেই বন্ধ না হয়ে যায়।
- বর্তমান আর্কাইভ-কাঠামোর সঙ্গে সামঞ্জস্য রেখে রিগ্রেশন পরীক্ষাগুলো সংশোধন করা হয়েছে; পুরোনো Release History ও Verification Report মুছে ফেলা হয়নি।
- Member Save failure diagnostics-এর জন্য নতুন regression test যোগ করা হয়েছে এবং `verify` স্ক্রিপ্টে যুক্ত করা হয়েছে।

## যাচাই
- Privileged settings visibility: 8/8 PASS
- Navigation/session/role-menu: 11/11 PASS
- Member Save diagnostics: 7/7 PASS
- Deep integration audit: 22/22 PASS
- Integrated release audit: 20/20 PASS
- Profile form regression: 22/22 PASS
- Master audit: 47/47 PASS
- Quality contracts: 31 PASS
- Theme regression: 116 unique themes PASS
- অন্যান্য Node-ভিত্তিক regression/audit স্ক্রিপ্টের 62টি পাস করেছে; TypeScript stripping-সহ চলা OCR/age পরীক্ষাগুলোও আলাদাভাবে পাস করেছে।

## সীমাবদ্ধতা
এই পরিবেশে `npm install` সময়সীমার মধ্যে সম্পন্ন হয়নি, তাই `tsc`-এর পূর্ণ typecheck এবং Vite production build চালানো যায়নি। `relationship-runtime-safety` পরীক্ষাটিও `tsx` dependency অনুপস্থিত থাকায় চালানো যায়নি। বাস্তব Android ডিভাইসে APK চালিয়ে Save failure পুনরুৎপাদন/যাচাই করা হয়নি। তাই এগুলোকে পাস বলে দাবি করা হচ্ছে না।
