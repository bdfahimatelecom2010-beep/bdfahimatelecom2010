# BONGSHOKOTHA / বংশকথা — Master Consolidated Genealogy Pack 11.5.1

This release continues the 11.5.0 consolidated genealogy base and adds a safer, richer member relationship editor.

## Member Profile / Relationship additions
- Multiple canonical spouse selection using marriage records.
- Spouse list filtering by generation and gender.
- New spouse quick-add.
- Existing spouses shown together without silently deleting historical marriages when removed from the editor selection.
- Children can be selected from existing members using generation and gender filters.
- New children can be entered in multiple rows with per-child gender selection.
- Existing selected children are linked to empty parent slots on save; conflicting existing parent links are not silently overwritten.
- Father/mother and grandparent relationships remain canonical and generation-aware.
- Father-in-law and mother-in-law remain explicit non-birth-line links.

## Photos
- Member profile photo can be captured from a live camera or selected from a file.
- Photo is stored on the member record and does not alter genealogy relationships.

## Documents
- Existing member document storage remains attached to Member ID.
- Original file data is retained in the member document record; OCR/QR workflows remain separate from the canonical relationship graph.

## Verification in this build environment
- Quality contracts: PASS (28).
- Theme regression: PASS (80 unique themes + core color tokens).
- Relationship UI regression: PASS (14 contracts).
- TypeScript/TSX transpile syntax scan: PASS (55 files, 0 syntax diagnostics).
- Full dependency-backed typecheck/build was not completed in this sandbox because the project dependencies were not available and npm installation timed out.
