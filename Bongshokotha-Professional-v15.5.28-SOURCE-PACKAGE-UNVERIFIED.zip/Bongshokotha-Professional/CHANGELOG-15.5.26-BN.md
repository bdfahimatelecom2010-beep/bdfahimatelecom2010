# বংশকথা প্রফেশনাল v15.5.26 — Sharing Safety & Theme Distinction

## এই সংস্করণে সংশোধন
- Family Tree Sharing-এ পরিচিতি শেয়ার, Native Share Sheet, clipboard এবং Print/PDF workflow স্পষ্ট করা হয়েছে।
- নির্বাচিত শাখা, নির্বাচিত সদস্য অথবা সব সদস্যের সীমিত তথ্য নিয়ে Safe Share JSON তৈরি করা যায়।
- Safe Share-এ ফোন, ইমেইল, পরিচয়পত্র, সদস্যের দলিল, ছবি, নোট/জীবনী ও Family Archive রেকর্ড ডিফল্টভাবে বাদ থাকে।
- পিতা-মাতা/বিবাহ লিংক কেবল নির্বাচিত সদস্যদের ভেতরে সীমিত করা হয়; জন্ম/মৃত্যুর সাল ও সম্পর্ক ঐচ্ছিক।
- পূর্ণ ব্যক্তিগত প্যাকেজ আলাদা Permission (`canExportFullData`) এবং নিশ্চিতকরণ চায়।
- Family Hub-এ নতুন Invite-এর ডিফল্ট মেয়াদ ৭ দিন এবং একবার ব্যবহারযোগ্য নীতি দেওয়া হয়েছে; দূরবর্তী Invite এখনও কনফিগার করা sync server-এর ওপর নির্ভরশীল।
- একই নামের Copper Heritage থিমের একটি নকশা `Bronze Sunrise` করা হয়েছে, যাতে একই নামের কাছাকাছি-ডুপ্লিকেট থিম না থাকে এবং মোট থিম সংখ্যা ১১৬ থাকে।
- Sharing safety regression test `npm run verify`-এ যুক্ত হয়েছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই সোর্স পরিবর্তন নিজে থেকে public web share URL বা hosted public family page তৈরি করে না।
- Access Request/approval workflow, per-field server-enforced permission, remote revocation/expiry-এর সার্ভার বাস্তব আচরণ, সামাজিক পোস্টিং, এবং ছবি/PDF export-এর সব runtime পথ বাস্তব server/device-এ যাচাই করা হয়নি। Print/PDF হলো browser/system print dialog-নির্ভর।
- পূর্ণ TypeScript check/build এই পরিবেশে চালানো হয়নি, কারণ `node_modules` নেই। Android APK-তে বাস্তব পরীক্ষা করা হয়নি।
