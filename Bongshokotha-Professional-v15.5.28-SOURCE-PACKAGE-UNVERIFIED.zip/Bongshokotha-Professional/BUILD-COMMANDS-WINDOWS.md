# Windows PowerShell — Bongshokotha Professional 15.5.26 hotfix

## 1. Extract and open the project
Extract the ZIP first. In PowerShell, change the path below if you extracted it somewhere else.

```powershell
Set-Location -LiteralPath "C:\Bongshokotha-Professional"
```

## 2. Install dependencies
Run this once after extraction, and again only when dependencies change:

```powershell
npm.cmd install
```

If installation fails, keep the complete error output. Do not run `npm audit fix --force` blindly because it can install breaking dependency versions.

## 3. Verify and build (run one at a time)

```powershell
npm.cmd run typecheck
node scripts/version-consistency-audit.mjs
node scripts/master-audit.mjs
node scripts/dashboard-regression-test.mjs
node scripts/theme-regression-test.mjs
npm.cmd run build
```

The TypeScript check should pass before considering the build verified. A successful Vite build alone does not prove typecheck passed.

## 4. Start the app

```powershell
npm.cmd run dev
```

Open `http://localhost:3000`. Keep the terminal open while using the app. Stop the server with `Ctrl+C`.

If port 3000 is already in use, stop the old Vite process or use:

```powershell
npm.cmd run dev -- --port 5173
```

Then open `http://localhost:5173`.

## Desktop EXE
After the web build succeeds and Windows build prerequisites are installed:

```powershell
npm.cmd run desktop:build
```

## Android debug APK
Install a compatible JDK and Android SDK/Android Studio first, then run each command separately:

```powershell
npm.cmd run mobile:init
npm.cmd run mobile:sync
npm.cmd run mobile:build
```

## PowerShell notes
- Use `npm.cmd`, not `npm`, if PowerShell blocks `npm.ps1`.
- TypeScript expressions such as `previousTab ?? 'dashboard'` are source code, not PowerShell commands. Do not paste them into the terminal.
- Do not approve all npm install scripts automatically; inspect package names first.
