# বংশকথা প্রফেশনাল — পুরোনো সংস্করণ ও মেরামত ইতিহাসের সমন্বিত নথি

এই ফাইলে আগের ZIP-এ ছড়িয়ে থাকা পুনরাবৃত্ত সংস্করণ-নোট, মেরামত নোট ও পুরোনো যাচাই-প্রতিবেদন একত্র করা হয়েছে। বর্তমান সোর্স কোডের আচরণ যাচাই করতে শুধু এই ইতিহাসকে প্রমাণ হিসেবে ধরবেন না; বর্তমান টেস্ট ও বর্তমান সংস্করণের রিপোর্ট দেখুন।


---

## উৎস নথি: `CHANGELOG-15.5.14-SMART-FORM-ROLE-MENUS-BN.md`

# Bongshokotha Professional v15.5.14 — Smart Form & Role Menus

## পরিবর্তন
- সদস্য নিবন্ধন/সম্পাদনা ফর্মের দৃশ্যমান নকশা compact, responsive Smart Form v2 করা হয়েছে; বিদ্যমান সদস্য-তথ্য ও save logic অক্ষত রাখার লক্ষ্য রাখা হয়েছে।
- ফর্মের শুরুতে প্রয়োজনীয়/ঐচ্ছিক তথ্য স্পষ্ট করা হয়েছে। শুধু বাংলা নাম বাধ্যতামূলক; অতিরিক্ত তথ্য পরে পূরণ করা যায়।
- ফর্মের section, spacing, input density ও quick-jump bar মোবাইল/ডেস্কটপে সহজ ব্যবহারের জন্য পুনর্বিন্যাস করা হয়েছে।
- Role Menu editor-এ Family Map, Social Media, Print & Publication, Recycle Bin এবং Data Health module যোগ করা হয়েছে।
- সাধারণ ব্যবহারকারীদের কাছে Map/Social menu স্বয়ংক্রিয়ভাবে দেখানো বন্ধ; Admin নির্ধারিত Role Menu-তে থাকলে তবেই প্রদর্শিত হবে। Settings ও My Account নিজস্ব প্রয়োজনীয় মেনু হিসেবে থাকে।
- সংস্করণ 15.5.14 করা হয়েছে।

## যাচাইয়ের সীমা
Source regression tests এই ZIP তৈরির সময় চালানো হবে। Windows-এ পূর্ণ `npm.cmd run verify`, `npm.cmd run build` ও বাস্তব UI পরীক্ষা না চালিয়ে release-টিকে সম্পূর্ণ production-verified বলা যাবে না।


---

## উৎস নথি: `CHANGELOG-15.5.15-SMART-MEMBER-FORM-V3-BN.md`

# Bongshokotha Professional 15.5.15

## স্মার্ট সদস্য ফর্ম v3
- সদস্য ফর্মের এক-পৃষ্ঠার নকশা আরও responsive ও মোবাইল-সহায়ক করা হয়েছে।
- ফর্মের পরিচিতি অংশে এক-পৃষ্ঠা নির্দেশনা, বর্তমান বৈবাহিক অবস্থা ও সন্তানের সংখ্যা দেখানো হয়।
- নতুন/সম্পাদনা ফর্মের একই smart form contract `data-smart-member-form="v3"` এবং `data-single-page="true"` দিয়ে চিহ্নিত।
- `profile-form-regression-test.mjs`-এর পুরোনো `Single-Page Complete Form` লেখা-নির্ভর পরীক্ষা বদলে বাস্তব smart form marker, responsive layout, history fields, OCR/archive linkage ও marriage-origin ordering পরীক্ষা করা হয়েছে।
- `master-requirements-audit.mjs`-এর একই stale form-label assertion সংশোধন করা হয়েছে।

## যাচাইয়ের সীমা
- এই প্যাকেজে regression scripts চালানো হয়েছে। পূর্ণ dependency install, TypeScript/Vite production build এবং browser/device UI test এই পরিবেশে সম্পন্ন হয়নি; এগুলোকে সফল বলে দাবি করা হচ্ছে না।


---

## উৎস নথি: `CHANGELOG-15.5.16-ADDRESS-MAP-TEST-FIX-BN.md`

# Bongshokotha Professional 15.5.16 — Address, Map & Test Path Fixes

## Fixes
- Fixed Windows-compatible project-root resolution in `profile-form-regression-test.mjs` and `master-requirements-audit.mjs` using `fileURLToPath(import.meta.url)`.
- Address dropdowns now fail closed: if a selected division or district cannot be resolved, the next dropdown is empty rather than incorrectly showing other divisions' districts or other districts' upazilas.
- Family Map now includes a district-wise count of members based on the saved current address, falling back to permanent address. This is an address-based count, not GPS/geocoded mapping.
- Version metadata updated to 15.5.16.

## Known gaps not represented as complete
- The current social page still contains external social-sharing links; this is not a private, internal family-member social network. That feature needs a real feed, member identity/permissions, comments/reactions, moderation, and shared persistence before it can be called complete.
- The Bangladesh location catalogue is still downloaded from a remote JSON source on first use and cached locally. Offline-first use requires bundling a verified national division/district/upazila/union/village/post-office dataset with provenance and regular update strategy. This release does not claim that every village/post office is already in a bundled dictionary.
- The full smart-form interaction still needs manual browser testing beyond source-level regression checks.


---

## উৎস নথি: `CHANGELOG-15.5.17-STRICT-ADDRESS-CASCADE-BN.md`

# Bongshokotha Professional v15.5.17 — ঠিকানা তালিকার কঠোর এলাকা-ফিল্টার

## বাস্তব কোড পরিবর্তন
- ঠিকানার প্রশাসনিক তালিকা অনুপস্থিত থাকলে আর সব সংরক্ষিত ঠিকানার জেলা/উপজেলা একসঙ্গে দেখানো হয় না।
- নির্বাচিত বিভাগ/জেলার সঙ্গে প্যারেন্ট-লোকেশন মেলে না বা সংরক্ষিত ঠিকানায় প্যারেন্ট তথ্য নেই—এমন সারি বাদ যায়।
- UI-তে পরিষ্কারভাবে বলা হয় যে জাতীয় তালিকা না থাকলে শুধু একই এলাকার সংরক্ষিত ঠিকানা থেকে পরামর্শ দেখানো হবে; এটিকে পূর্ণাঙ্গ জাতীয় অভিধান বলে দেখানো হয় না।
- কঠোর ক্যাসকেডের জন্য regression test যোগ করা হয়েছে এবং `npm run verify`-তে যুক্ত হয়েছে।

## সীমাবদ্ধতা
এই রিলিজে পূর্ণাঙ্গ, যাচাইকৃত অফলাইন বাংলাদেশ ঠিকানা অভিধান যুক্ত হয়নি। সেটি যোগ করতে যাচাইকৃত প্রশাসনিক ডেটাসেট ও গ্রাম/ডাকঘরের নির্ভরযোগ্য উৎস দরকার। একইভাবে নিজস্ব সামাজিক নেটওয়ার্কের জন্য প্রকৃত পোস্ট/কমেন্ট/রিঅ্যাকশন ও পারিবারিক অনুমতিসহ ব্যাকএন্ড দরকার; বাহ্যিক শেয়ার-লিংক সেটির বিকল্প নয়।


---

## উৎস নথি: `CHANGELOG-15.5.19-REPAIR-AND-DECISIONS-BN.md`

# সংস্করণ 15.5.19 — মেরামত ও সিদ্ধান্তসমূহ

তারিখ: 2026-10-14

## এই সংস্করণে সংশোধন
- `src/components/Sidebar.tsx`-এ Settings-এর আগে থাকা অতিরিক্ত `{` সরানো হয়েছে; এটি TypeScript/TSX parse/build failure-এর কারণ ছিল।
- সামাজিক মাধ্যম শেয়ারিং ভিউ-এর route এবং Sidebar menu item পুনঃস্থাপন করা হয়েছে। এতে নেভিগেশন ও সামাজিক শেয়ারিং regression tests-এর প্রত্যাশা মেলে।
- `package.json`, `src/appVersion.ts`, `metadata.json`, `CURRENT-VERSION.txt`-এ সংস্করণ নম্বর 15.5.19 এক করা হয়েছে।

## চলমান প্রকল্পের কার্যকরী নিয়ম (পরবর্তী কোড যাচাইয়ের মানদণ্ড)
- অজানা তথ্য অজানা থাকবে; আনুমানিক, যাচাই-অপেক্ষমাণ ও যাচাইকৃত তথ্য পৃথক থাকবে। অজানা তথ্য অনুমান করে পূরণ করা যাবে না।
- প্রজন্ম নির্ধারণে বয়স নয়, বংশগত সম্পর্ক প্রাধান্য পাবে। জন্মক্রম, সদস্য নম্বর ও স্থায়ী অভ্যন্তরীণ পরিচয় আলাদা।
- সদস্য মারা গেলে তাঁর পরিচয়, ছবি, বিবাহ, সন্তান ও সম্পর্ক অক্ষত থাকবে; অন্য সদস্যের জীবিত/মৃত অবস্থা স্বতন্ত্র।
- নাম/ঠিকানা পরিবর্তনে স্থায়ী অভ্যন্তরীণ পরিচয় অপরিবর্তিত থাকবে।
- NID, মোবাইল, ইমেইল, পরিচয়পত্র ও সংবেদনশীল পারিবারিক তথ্যের জন্য পৃথক অনুমতি, নিরাপদ সংরক্ষণ এবং অডিট রেকর্ড আবশ্যক।
- সদৃশ রেকর্ড কেবল সম্ভাব্য সদৃশ হিসেবে দেখানো হবে; অনুমোদিত পর্যালোচনা ছাড়া স্বয়ংক্রিয় merge নয়।
- ব্যাকআপে ছবি, নথি ও সম্পর্ক থাকা এবং restore সফল হওয়া আলাদাভাবে পরীক্ষা করতে হবে।
- ভুল সংশোধন, soft-delete/restore, যৌথ সম্পাদনার conflict এবং GEDCOM রপ্তানির সামঞ্জস্য গ্রহণযোগ্যতা পরীক্ষায় অন্তর্ভুক্ত থাকবে।
- প্রতিটি release-এ changelog, build report, test results এবং অবশিষ্ট ঝুঁকি রাখা হবে।

## সততার নোট
উপরের নিয়মগুলোর সবগুলো এই ZIP-এ সম্পূর্ণ বাস্তবায়িত হয়েছে—এমন দাবি করা হচ্ছে না। এই সংস্করণে নিশ্চিতভাবে করা কোড পরিবর্তনগুলো উপরের “সংশোধন” অংশে তালিকাভুক্ত। সম্পূর্ণ feature acceptance ও end-to-end পরীক্ষা এখনো বাকি।


---

## উৎস নথি: `CHANGELOG-15.5.21-REQUIREMENTS-REVIEW-BN.md`

# Changelog 15.5.21
- Added `MASTER-NEW-REQUIREMENTS-15.5.21-BN.md`, consolidating the latest user-approved usability, progressive member form, role-limited share invitations, expiry, archive, data-integrity and verification rules.
- Added `RELEASE-VERIFICATION-REPORT-15.5.21-BN.md` documenting checks run and known implementation gaps.
- Updated version metadata to 15.5.21.
- This is a requirements/review candidate, not a claim that all functional features are implemented or production verified.


---

## উৎস নথি: `BUILD-REPORT-15.5.19-BN.md`

# Build ও পরীক্ষার রিপোর্ট — 15.5.19

তারিখ: 2026-10-14

## কোড পরিবর্তন
- Sidebar TSX-এ parse-breaking অতিরিক্ত brace সরানো হয়েছে।
- Social Sharing navigation item এবং App route পুনঃস্থাপন করা হয়েছে।
- চারটি version source-এ 15.5.19 এক করা হয়েছে।

## চালানো পরীক্ষা
- `node scripts/navigation-visibility-regression-test.mjs` — PASS (10/10)
- `node scripts/social-sharing-regression-test.mjs` — PASS
- `node scripts/version-consistency-audit.mjs` — PASS (4/4 version sources)

## চালানো যায়নি / অসম্পূর্ণ
- `npm install --no-audit --no-fund` এই পরিবেশে সময়সীমা অতিক্রম করেছে; `node_modules` তৈরি হয়নি।
- তাই TypeScript typecheck, production Vite build, সম্পূর্ণ `npm run verify`, Windows PowerShell build, এবং extracted-ZIP থেকে পুনরায় build **চালানো/যাচাই করা হয়নি**।
- বাস্তব NID front/back OCR accuracy, OCR field-by-field apply, backup/restore round-trip, role-based sensitive-data enforcement, edit/reload persistence এবং mobile/desktop end-to-end এখনও এই release-এ প্রমাণিত নয়।

## Release status
**সোর্স-সংশোধিত পরীক্ষার্থী ZIP; পূর্ণ production-verified release নয়।** Build/typecheck gate সফলভাবে চালানো ছাড়া একে production-ready বলা যাবে না।


---

## উৎস নথি: `CHANGELOG-MASTER-CONSOLIDATION-1.0.0-PLAN.md`

# Master consolidation handoff — 2026-10-12

- Added one master register containing user-approved requirements 1–34.
- Added detailed copies of the Bengali master requirements, smart member form specification, non-member-form implementation plan, theme ID list and dictionary draft under `docs/requirements/`.
- Added an explicit handoff note that distinguishes approved scope from implemented/verified features.
- Kept app `package.json` version at 15.5.7 because the code baseline was not fully reimplemented/retested as 1.0.0 in this packaging step.
- No claim that full production build, browser E2E, Windows EXE or Android APK passed.


---

## উৎস নথি: `RELEASE-VERIFICATION-REPORT-15.5.21-BN.md`

# Release verification report — 15.5.21

**Status: NOT PRODUCTION CERTIFIED.** This package preserves the 15.5.20 source candidate, updates release metadata, and adds the latest consolidated Bengali requirements/verification handoff. It does **not** claim that every requested feature or previously reported defect has been fixed.

## Tests run in this packaging session
- Version consistency audit on base 15.5.20 source: PASS 4/4 (package, metadata, appVersion, CURRENT-VERSION were consistent before version bump).
- Smart member form source regression: PASS 13/13.
- Navigation visibility regression: PASS 10/10.
- Social sharing regression: PASS 10 checks.
- ZIP integrity: to be verified after packaging.

## Important known gaps found in source inspection
- `FamilyHubView` creates local invitations with `expiresAt: null` by default and QR payloads containing the join code; no user-selected role or duration is wired into that flow.
- `syncClient.publishInvite` sends `familyId`, archive, `expiresAt`, and `maxUses`, but no assigned role or authenticated membership grant.
- `server/sync-server.mjs` stores invite/archive and validates expiry/use count, but the shown join endpoint returns an archive; it does not establish a per-user family membership/role record. Therefore the complete role-controlled sharing requirement is NOT IMPLEMENTED/NOT VERIFIED in this source state.
- QR join flow currently reads a code then uses Join; there is no universal URL/deep-link join flow confirmed.
- No full `npm run verify`, TypeScript check, production build, real multi-device join, authenticated role enforcement test, backup restore round-trip, OCR accuracy, or mobile/desktop end-to-end test was completed for this package.
- Previous unresolved relationship-engine/runtime issues remain subject to full verification; no claim is made that all historical defects are fixed.

## Next release gate
Do not call this production-ready until server-side invitation/membership/role schema and endpoints are implemented, authorization is enforced for every family API, UI exposes allowed roles and expiry, code/QR/link share one invitation, and tests verify expiry/revoke/Viewer-to-Viewer/role hierarchy across separate authenticated accounts and devices. Then run full verify, typecheck, build, restore round-trip and responsive UI tests.
