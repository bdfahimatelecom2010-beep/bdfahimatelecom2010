const { app, BrowserWindow } = require('electron');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
function createWindow(){
 const win=new BrowserWindow({width:1440,height:950,minWidth:360,minHeight:640,show:false,icon:path.join(__dirname,'..','assets','icon.png'),webPreferences:{contextIsolation:true,sandbox:true}});
 const index=path.join(__dirname,'..','dist','index.html');
 win.loadURL(pathToFileURL(index).toString());
 win.once('ready-to-show',()=>win.show());
}
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
