> **মাস্টার কনসোলিডেশন নোট (2026-10-12):** এই প্যাকেজের মধ্যে 1.0.0-এর জন্য অনুমোদিত 1–34 নম্বর সিদ্ধান্ত `docs/requirements/MASTER-DECISIONS-1-34-BN.md`-এ একত্র করা হয়েছে। অ্যাপ সোর্স বেসলাইন এখনো 15.5.7; সব সিদ্ধান্ত বাস্তবায়িত বা পূর্ণ end-to-end test-এ পাস করেছে বলে দাবি করা হচ্ছে না। বিস্তারিত handoff: `MASTER-HANDOFF-V1.0.0-BN.md`।

# BONGSHOKOTHA Professional 15.5.7

একই source থেকে Windows desktop এবং Android/mobile build করার জন্য পরিষ্কার, offline-first genealogy/family-history platform। এই release-এ পুরোনো Bongshokotha source/release-গুলোর প্রয়োজনীয় lineage, member-profile, marriage, archive, OCR, dashboard, role, backup/sync এবং recovery ধারণাগুলো একীভূত করা হয়েছে। অপ্রয়োজনীয় পুরোনো release ZIP/source clutter এই package-এ রাখা হয়নি।

## প্রধান বৈশিষ্ট্য
- Bengali-first responsive UI: Windows, mobile ও tablet.
- Permanent internal Person ID; UI-তে নয়।
- Birth-order + relationship-based canonical generation/branch ordering.
- Birth-origin, marriage-origin এবং adopted lineage আলাদা।
- Married-in member তার biological parents profile-এ রাখতে পারে; তারা স্বয়ংক্রিয়ভাবে spouse-family member হয় না।
- Spouse ঠিক তার birth-line spouse-এর পাশে canonical display order-এ থাকে; spouse-এর own birth order display order বদলায় না।
- Multiple marriages এবং union-specific children.
- Member card/profile: নাম, generation, parents, DOB, living/deceased, current age/age at death, photo, occupation, address, origin, spouse এবং marriage count.
- Structured education, career/profession এবং residence history.
- Family Archive: NID, Birth Registration, Passport, certificates, letters, photos, land records, memories, audio/story এবং other documents.
- OCR: Bengali + English, field review/apply, NID/BRN/passport/DOB/parent extraction, PDF first-page rendering এবং local OCR model support.
- Original document binary archive থেকে profile attachment সরালেও archive record অক্ষত থাকে।
- Dashboard-এ Family Statistics-এর প্রয়োজনীয় অংশ; আলাদা Family Statistics menu নেই। Dashboard-এর প্রতিটি widget Settings থেকে ON/OFF, order ও layout control করা যায়।
- Owner/Admin/RBAC, five-priority succession, recovery backup ও configurable server registry.
- JSON/CSV/GEDCOM import-export foundation এবং integrity/recovery tools.
- Regression, deep-integration, OCR runtime এবং build audits.

## প্রথমবার Windows PowerShell build
```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
Set-Location -LiteralPath "C:\Bongshokotha-Professional"
npm.cmd install
npm.cmd run prepare:ocr
npm.cmd run verify
```

`prepare:ocr` একবার Bengali/English Tesseract model local `public\tessdata`-এ প্রস্তুত করবে। এরপর production package OCR model-এর জন্য runtime network request-এর ওপর নির্ভর করবে না।

## Windows desktop
```powershell
npm.cmd run desktop:build
```

## Android/mobile
```powershell
npm.cmd run mobile:init
npm.cmd run mobile:build
```

## গুরুত্বপূর্ণ
- `npm.cmd audit` নামে কোনো script প্রয়োজন নেই; `npm.cmd run audit:version`, `npm.cmd run verify` এবং `npm.cmd run deep:audit` ব্যবহার করুন।
- NID/Passport/OCR তথ্য user confirmation ছাড়া verified profile field-এ silently overwrite হবে না।
- পুরোনো demo/sample data reset-এর মাধ্যমে ফেরত আসবে না।


## 15.5.5 Smart marriage and profile details

This release adds separate address and both-sides’ parent-name fields to each marriage record and displays them on the member profile. It also displays source/document context for alternative identity names. See `CHANGELOG-15.5.5-SMART-MARRIAGE-PROFILE.md` for scope and verification limitations.

## Consolidated build notes
This package is Bongshokotha Professional 15.5.7. For setup, see `SETUP-BANGLA.md` and `BUILD-COMMANDS-WINDOWS.md`. For the current changes and verification status, see `CHANGELOG-15.5.5-SMART-MARRIAGE-PROFILE.md`.

## 15.4.1 Universal OCR workflow

This release treats every uploaded document as evidence first. OCR shows all
recognized structured fields, additional labelled information and preserved raw
OCR text. The user chooses which fields can be applied to the member Profile.

### Windows PowerShell quick start

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
Set-Location -LiteralPath "C:\Bongshokotha-Professional"
npm.cmd install --no-audit --no-fund
npm.cmd run dev
```

Open `http://localhost:3000`.

### OCR verification commands

```powershell
npm.cmd run ocr:test
npm.cmd run universal:ocr:test
npm.cmd run nid:ocr:test
npm.cmd run ocr:runtime:test
npm.cmd run deep:audit
```

### Production/build commands

```powershell
npm.cmd run build
npm.cmd run desktop:build
npm.cmd run mobile:init      # first Android setup only
npm.cmd run mobile:build
```

Do not use `npm run` if PowerShell blocks `npm.ps1`; use `npm.cmd` as shown.


## 15.4.14 safety fix

If a legacy browser database contains only the demo family, startup now creates and selects a blank real-family workspace instead of opening demo records as the user's genealogy. The demo remains available through an explicit Demo Family action. Run `npm.cmd run demo:autoload:test` to verify this safeguard.


## 15.5.7 consolidated handoff

- `MASTER-REQUIREMENTS-ALL-IN-ONE-BN.md` is the canonical complete Bengali requirement register.
- `REQUIREMENTS-STATUS-15.5.7.md` separates source evidence from runtime-verified status and open gaps.
- `docs/releases/RELEASE-TEST-REPORT-15.5.7.md` records the checks actually run for this package.
- A checkbox in a requirements document is not proof that a feature passed production end-to-end testing.
