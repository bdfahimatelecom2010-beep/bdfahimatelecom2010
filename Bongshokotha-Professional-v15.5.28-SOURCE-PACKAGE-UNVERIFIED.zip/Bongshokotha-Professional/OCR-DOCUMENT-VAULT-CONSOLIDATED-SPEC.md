# OCR + QR + Member Document Vault — Consolidated Specification

## Scan once, extract many ways
একটি image/PDF থেকে একই workflow-এ বাংলা, English, mixed text, numbers/dates এবং QR/Barcode data সংগ্রহের architecture।

## Source priority
1. Original document — immutable evidence
2. QR/Barcode payload — machine-readable source
3. OCR raw text — extracted source
4. Structured extraction — interpreted source
5. Existing member data — comparison source
6. User approval — final application decision

## Mandatory rule
কোনো OCR/QR result user approval ছাড়া গুরুত্বপূর্ণ member field overwrite করবে না।

## Member storage
Profile upload-এর document immutable Member ID দিয়ে link হবে। Member name পরিবর্তনে document link ভাঙবে না।

## Suggested document states
Uploaded → Processing → OCR Complete → Needs Review → Partially Approved → Approved → Rejected → Archived

## Confidence
High / Medium / Low confidence; critical identity fields require review even when confidence is high.

## Duplicate/conflict
Name, DOB, parent names, phone, document number ইত্যাদি দিয়ে সম্ভাব্য duplicate এবং conflicting values শনাক্ত করতে হবে।

## Preservation
Original binary, enhanced copy, OCR text, extracted fields, QR payload, metadata, provenance এবং audit history আলাদা logical artefact হিসেবে রাখতে হবে।

## Security
Role-based view/upload/OCR/approve/download/print/share/delete/restore permissions; sensitive identity documents-এর জন্য restricted access support.

## Backup
Binary documents-সহ complete archive backup/restore; metadata-only backup গ্রহণযোগ্য নয়।
