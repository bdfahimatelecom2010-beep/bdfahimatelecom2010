# BONGSHOKOTHA Professional 15.1.1 — Requirements Alignment

This revision is based directly on the supplied `MASTER-REQUIREMENTS-CONSOLIDATED.md` and the 15.1.0 consolidated source.

## Changes in 15.1.1
- Member Profile is widened into a full genealogy workspace.
- Profile now presents a consolidated lineage overview near the top: parents, paternal grandparents, maternal grandparents, spouse count, children count, siblings count, and document/archive count.
- Person serial numbers are no longer rendered in the member profile UI; permanent internal Person ID remains the canonical identity.
- Children remain visible even when they have not yet been assigned to a specific marriage record; marriage-specific grouping is preserved where available.
- Children cards show photo, son/daughter classification, birth order and birth date where available.
- Legacy/partial member and marriage records are normalized at storage read time so missing optional collections do not crash the UI after upgrades.
- Release version is 15.1.1.

## Verification performed in the source package
- Master requirements audit: 47/47 PASS
- Quality contracts: 29 PASS
- Integrated release audit: 20/20 PASS
- Deep integration audit: 22/22 PASS
- Version consistency: PASS
- Profile regression: 20/20 PASS
- Profile + lineage regression: 12/12 PASS
- Profile document/archive regression: PASS
- Member data integrity: 8/8 PASS
- Dashboard regression: 11/11 PASS
- Relationship canonical regression: 10/10 PASS
- Family visibility regression: PASS

The package does not claim that external production services (Google credentials, a real remote server, device camera permissions, or OS packaging toolchains) are live without their required environment configuration.
