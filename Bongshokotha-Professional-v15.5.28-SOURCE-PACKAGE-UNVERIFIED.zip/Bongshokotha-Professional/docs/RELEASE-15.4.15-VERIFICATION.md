# 15.4.15 verification notes

This release includes fixes to invite-code consistency, local/remote join behavior, Settings/Admin separation, legacy origin labels, and separate adoptive-parent name storage.

Executed successfully: `scripts/profile-lineage-regression-test.mjs` (12/12), `scripts/account-role-regression-test.mjs` (17/17), `scripts/settings-save-regression-test.mjs`, `scripts/deep-integration-audit.mjs` (22/22), and `scripts/master-audit.mjs` (47/47).

`npm install --no-audit --no-fund` timed out in this environment. Consequently, `npm run typecheck`, `npm run build`, Windows installer packaging, Android packaging, and real browser/device validation are pending and must not be treated as passed.
