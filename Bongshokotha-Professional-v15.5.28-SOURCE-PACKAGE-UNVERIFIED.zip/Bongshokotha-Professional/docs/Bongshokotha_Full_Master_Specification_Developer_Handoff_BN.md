# বংশকথা (BONGSHOKOTHA) — পূর্ণ Master Specification ও Developer/AI Handoff

এই নথির সম্পূর্ণ, বিন্যাসযুক্ত সংস্করণ DOCX ফাইলে দেওয়া হয়েছে। এটি প্রকল্পের লক্ষ্য, মেনু মানচিত্র, সদস্য-প্রোফাইল, সম্পর্ক ও প্রজন্মের নিয়ম, বহু বিবাহ, OCR, ঠিকানা ডিকশনারি, লগইন/রোল, ড্যাশবোর্ড, থিম, শেয়ারিং, ব্যাকআপ, নিরাপত্তা এবং release acceptance tests-এর একক নির্দেশনাপত্র।

## অপরিবর্তনীয় নীতি
- স্থায়ী Person ID/Family ID কখনো নাম দিয়ে প্রতিস্থাপন নয়।
- পুরোনো data, relationships, files বা backup নীরবে মুছে ফেলা যাবে না।
- OCR/AI ফল preview, correction ও user confirmation ছাড়া profile update করবে না।
- Uncertain duplicate auto-merge নয়।
- Demo data কখনো real family data overwrite করবে না।
- Role restrictions UI এবং service/backend—দুই স্তরেই প্রয়োগ করতে হবে।
- Tests not run হলে PASS লেখা যাবে না।
- ZIP integrity পাস মানেই app correctness নয়।

## Release gate
Release READY হবে কেবল requirement traceability, typecheck, automated tests, production build, backup/migration validation, role/privacy tests এবং target Android/Windows smoke tests পাস হলে। অসম্পন্ন/ব্লক হওয়া পরীক্ষা স্পষ্টভাবে NOT RUN/ BLOCKED হিসেবে নথিভুক্ত করতে হবে.

বিস্তারিত field-by-field ও menu-by-menu নির্দেশনার জন্য DOCX সংস্করণ দেখুন।
