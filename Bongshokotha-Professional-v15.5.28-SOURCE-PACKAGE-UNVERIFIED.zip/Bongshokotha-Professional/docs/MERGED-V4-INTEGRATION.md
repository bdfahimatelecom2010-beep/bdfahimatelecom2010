# BONGSHOKOTHA Professional — v4.0.0 Integration Review

## Merge policy
`Bongshokotha-Professional-Ultimate-11.0.0` remains the canonical application source and version baseline. The `BONGSHOKOTHA-PROFESSIONAL-MASTER-v4.0.0` project was reviewed as a secondary source; its separate application shell and incompatible data model were **not** allowed to overwrite the Ultimate 11.0.0 genealogy model.

## Compatible concepts retained/reconciled
- Separate Person and Marriage concepts.
- Married-in members retain their biological/original lineage.
- Generation is derived from parent relationships and spouse generation is aligned.
- Safe deletion/reference cleanup and data-repair principles were checked against the Ultimate validation/relationship engines.
- Duplicate-detection, audit, archive, import/export and repair concepts were checked against the corresponding Ultimate modules rather than duplicated with a second incompatible storage engine.
- Missing/unknown facts remain unknown; the merge does not invent dates or relationships.

## Profile organization update
The member profile now presents information in a consistent order:
1. Identity and status
2. Birth/death and lifespan
3. Grandparents and biological parents
4. Personal, contact and identity summary
5. Current/permanent address
6. Education and career history
7. Marriage history, children and siblings
8. Life events, residence and evidence history
9. NID, birth registration, passport and linked archive records
10. Biography, important information, family-origin story, memorial story and notes

This change is presentation-only for existing fields and does not replace existing member IDs or genealogy relationships.

## Verification performed in the merge workspace
- Ultimate quality-contract check: PASS.
- All Ultimate TypeScript/TSX source files: transpile/syntax check PASS.
- Full dependency installation and Vite production build were not completed in the isolated environment because `npm install` exceeded the available execution time. Therefore this package is not labeled as native-build verified here.
