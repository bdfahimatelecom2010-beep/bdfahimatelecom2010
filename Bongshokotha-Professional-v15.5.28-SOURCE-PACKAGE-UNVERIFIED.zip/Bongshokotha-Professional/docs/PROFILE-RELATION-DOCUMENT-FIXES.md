# Profile, Relationship & Document Fixes

Implemented in the Ultimate 11.0.0 master base:

- Spouse/partner selector in the member form, filtered by gender.
- Selected spouse is displayed immediately after the member name in the profile header.
- Existing current spouse is preserved; changing a spouse closes the previous current marriage as separated and creates the new current marriage.
- New spouse, father, or mother can be created directly from the relationship section and linked immediately.
- Father and mother dropdowns are gender-specific and show the member's gender label.
- Grandparents remain derived from biological parent links: paternal grandfather/grandmother and maternal grandfather/grandmother.
- Marital status defaults to Unmarried for new members.
- Living status defaults to Living for new members.
- Direct member document attachments are supported for photos, birth certificate, NID, passport, marriage/death certificates, education documents, and other files.
- Member document attachments are stored with the member record and exposed from the member profile.
- NID and birth registration number fields remain separate.
- Existing archive/document features remain intact.

Validation performed:
- 19/19 required source contracts: PASS
- 49/49 TypeScript/TSX source files transpile check: PASS
