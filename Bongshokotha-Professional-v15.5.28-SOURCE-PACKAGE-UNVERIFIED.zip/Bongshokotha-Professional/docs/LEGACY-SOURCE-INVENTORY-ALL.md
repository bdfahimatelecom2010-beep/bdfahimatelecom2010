# Legacy Source Inventory — Consolidated 14.0.0

This build was consolidated from the available Bongshokotha ZIP releases in the working source set plus the supplied Windows EXE reference.

## ZIP sources reviewed
- `BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip` — 144 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip` — 150 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.7.4-MASTER-REPAIRED.zip` — 153 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.7.5-MASTER-REPAIRED.zip` — 155 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip` — 152 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.7.7-MARRIAGE-ORIGIN-PARENT-FIXED.zip` — 153 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.7.8-CLEAN.zip` — 110 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.7.8-MARRIAGE-ORIGIN-FULL-FIXED.zip` — 151 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.8.1-REPAIRED-FINAL.zip` — 105 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.8.2-FINAL-FIXED.zip` — 105 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.8.2-FULL-TESTED.zip` — 106 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip` — 122 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip` — 122 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-13.0.1-FINAL-MASTER.zip` — 123 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-13.1.0-FINAL-MASTER.zip` — 114 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-13.2.0-FINAL-MASTER.zip` — 114 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-14.0.0-FINAL-MASTER.zip` — 122 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-MASTER-v4.0.0.zip` — 24 files — ZIP test: PASS
- `BONGSHOKOTHA-PROFESSIONAL-ULTIMATE-11.0.0-V4-FINAL-FAMILY-FIXED.zip` — 70 files — ZIP test: PASS
- `Bongshokotha-Professional-2.1.1-Fixed.zip` — 61 files — ZIP test: PASS
- `Bongshokotha-Professional-2.3.1-Dependency-Fixed(1).zip` — 61 files — ZIP test: PASS
- `Bongshokotha-Professional-2.4.0-New-Final.zip` — 60 files — ZIP test: PASS
- `Bongshokotha-Professional-2.5.0-Integrated.zip` — 60 files — ZIP test: PASS
- `Bongshokotha-Professional-Ultimate-11.0.0.zip` — 67 files — ZIP test: PASS

## Consolidation rule
- The verified 14.0.0 source is the implementation base.
- Older releases were treated as historical evidence; fixes/features were retained only when represented in the consolidated source or still required by the master requirements.
- Obsolete repeated RELEASE/VERIFY notes were not copied into the final package.
- The supplied `Bongshokotha-1.0.0-32bit-Setup.exe` was treated as a reference for the professional member-card and user-facing behavior; its reference contracts are retained in `scripts/exe-reference-regression-test.mjs`.
- The separate family-data template remains represented by the current domain/archive schema; no demo person is required for a fresh family.

## Unique-content observation
- ZIP files reviewed: 24
- Unique SHA-256 content blobs across those ZIPs: 459

## Explicitly retained historical requirements
- spouse-adjacent married-in ordering
- married-in biological parents stored as profile data without becoming birth-line family nodes automatically
- birth order independent from save order
- generation recalculation after late parent assignment
- child list immediately visible after edit
- OCR per-field review/apply and archive independence
- NID/BRN/Passport separation
- admin-only Gmail recovery and server controls
- five-slot succession plan
- dashboard widgets controlled from Settings
- no separate Family Statistics menu
- age/current-age and age-at-death derivation
- GEDCOM/CSV/archive interoperability
- local-first/offline operation.
