# বংশকথা Professional — Version 1.0.0
## সদস্যদের ফরম অপরিবর্তিত রেখে পূর্ণ সফটওয়্যার সমন্বয়, সেবা ও বাগ-ফিক্স পরিকল্পনা

**পর্যালোচিত ভিত্তি:** `BONGSHOKOTHA-PROFESSIONAL-15.5.7-INLAW-ADDRESS-FIX.zip`  
**সীমা:** এই পরিকল্পনায় Member Form/সদস্য ফরমের UI ও ফিল্ড বিন্যাস পরিবর্তন করা হবে না। অন্য মডিউল এবং সদস্য-সম্পর্কিত ব্যাকএন্ড, সেভ/লোড ও প্রোফাইল-প্রদর্শন আচরণ প্রয়োজনমতো পরীক্ষা/সংশোধনের আওতায় থাকবে।  
**সততা নোট:** এটি বাস্তবায়ন-পরিকল্পনা ও বর্তমান ভিত্তি-ফাইলের স্থিতি-নথি; এতে উল্লিখিত নতুন সুবিধাগুলো এই নথি তৈরির মাধ্যমে সফটওয়্যারে যুক্ত হয়ে যায়নি। নতুন ZIP তৈরি করা হয়নি।

---

## 1. রিলিজ লক্ষ্য ও সংস্করণ

- ব্যবহারকারীর কাঙ্ক্ষিত প্রকাশ-সংস্করণ: **1.0.0**।
- বর্তমান পর্যালোচিত আর্কাইভের `package.json` সংস্করণ: **15.5.7**। এটিকে 1.0.0 হিসেবে প্রকাশ করার আগে package metadata, UI version labels, changelog, installer/PWA metadata ও release notes একইভাবে সমন্বয় করতে হবে।
- সদস্য ফরমের বর্তমান ডিজাইন অপরিবর্তিত থাকবে।
- প্রতিটি পরিবর্তনের আগে ব্যাকআপ, ডেটা মাইগ্রেশন যাচাই, রিগ্রেশন টেস্ট এবং ব্যর্থ হলে rollback পরিকল্পনা থাকতে হবে।

## 2. অগ্রাধিকারভিত্তিক কাজ

### P0 — ডেটা নিরাপত্তা ও মূল কার্যকারিতা
1. বাস্তব সদস্য-ডেটা/ব্যাকআপ দিয়ে Import → save → reload → export round-trip যাচাই।
2. ডেমো/নমুনা ডেটা কোনো অবস্থায় ব্যবহারকারীর আসল ডেটার উপর স্বয়ংক্রিয়ভাবে লোড বা overwrite করবে না।
3. সদস্য সম্পাদনা, সন্তান যোগ, বিবাহ সম্পাদনা, নথি সংযুক্তি—সব ক্ষেত্রে সেভ সফল/ব্যর্থতার নির্ভরযোগ্য অবস্থা।
4. পিতা-মাতা ↔ সন্তান canonical relationship, spouse ↔ marriage record এবং marriage ↔ children link একক source of truth থেকে গণনা/দেখানো।
5. duplicate member/child তৈরি, ভুল member ID, orphaned relationship, cyclic parent links ও stale profile cache প্রতিরোধ।
6. প্রতিটি mutation-এ permission checks; UI-তে বোতাম লুকানোকে একমাত্র নিরাপত্তা হিসেবে ধরা যাবে না।
7. বিদ্যমান ডেটা হারানো ছাড়া versioned migration এবং rollback।

### P1 — প্রোফাইল ও বিবাহ/সন্তান সম্পর্কের ব্যাকএন্ড
- Member Form UI পরিবর্তন না করে, বিদ্যমান ফর্ম থেকে প্রাপ্ত ডেটা সঠিকভাবে সংরক্ষণ ও প্রোফাইলে দেখানো।
- একজন ব্যক্তির একাধিক বিবাহ আলাদা marriage record হবে; প্রতিটি রেকর্ডে spouse ID, তারিখ/আনুমানিক তারিখ, বর্তমান অবস্থা, প্রাসঙ্গিক নোট/দলিল এবং spouse-এর পিতা-মাতার পরিচয়/ঠিকানার সংযোগ থাকবে।
- বিবাহের অবস্থা প্রতি marriage record-এ থাকবে: বিবাহিত, তালাকপ্রাপ্ত, বিচ্ছিন্ন, স্বামী/স্ত্রী মৃত, তথ্য যাচাই বাকি। ব্যক্তির জীবিত/মৃত অবস্থা আলাদা field।
- এক বিবাহের status পরিবর্তনে অন্য বিবাহের status বদলাবে না।
- প্রতিটি সন্তান নির্দিষ্ট বিবাহের সঙ্গে link করা যাবে; বিদ্যমান member record থাকলে নতুন duplicate না বানিয়ে সেটিই যুক্ত হবে।
- সন্তানের নামের পাশে gender একই সারিতে দেখানো হবে। Gender আগে child/member profile-এ থাকলে সেই মান দেখাতে হবে; না থাকলে “নির্ধারিত নয়” দেখাতে হবে—অনুমান নয়।
- প্রোফাইলে পরিবর্তনের তাৎক্ষণিক preview; Save-এ persist; Cancel-এ unsaved changes বাতিল। Save ব্যর্থ হলে সফল বার্তা নয় এবং আগের saved data অক্ষত থাকবে।
- স্বামী/স্ত্রী উভয়ের প্রোফাইলে একই marriage record-এর সামঞ্জস্যপূর্ণ তথ্য দেখা যাবে।
- শ্বশুর/শাশুড়ির নাম spouse-এর parent profile থেকে prefill করা যায়, কিন্তু বিদ্যমান ব্যক্তির তথ্য নিঃশব্দে overwrite করা যাবে না।

### P1 — সদস্যদের অবস্থান ম্যাপ
Sidebar-এ **“সদস্যদের অবস্থান ম্যাপ”** মেনু।
- ঠিকানাভিত্তিক বিভাগ, জেলা, উপজেলা/থানা, ইউনিয়ন/পৌরসভা/সিটি কর্পোরেশন, ওয়ার্ড ও locality filter।
- বর্তমান ঠিকানা ও স্থায়ী ঠিকানা আলাদা filter/layer।
- একই এলাকার সদস্য-সংখ্যা ও map markers; অনুমতি থাকলে member profile-এ যাওয়ার ব্যবস্থা।
- নির্ভুল GPS/coordinates না থাকলে গ্রাম/উপজেলা পর্যায়ের আনুমানিক পিন; বাড়ির সুনির্দিষ্ট অবস্থান বানিয়ে দেওয়া যাবে না।
- গোপনীয়তা: default-এ সাধারণ সদস্যের নির্ভুল বাড়ির অবস্থান প্রকাশ নয়; role/consent-ভিত্তিক visibility।
- ইন্টারনেট না থাকলে ঠিকানা তালিকা চলবে; map tiles-এর offline availability আলাদা করে স্পষ্ট করতে হবে।

### P1 — বংশকথার ব্যক্তিগত সামাজিক যোগাযোগ
Sidebar-এ **“বংশকথা কমিউনিটি”** মেনু; কেবল এই genealogy workspace-এর অনুমোদিত সদস্যরা ব্যবহার করবেন।
- কেবল লেখা, স্থির ছবি এবং ভয়েস/অডিও পোস্ট বা বার্তা।
- ভিডিও আপলোড/পোস্ট, reels, live, video call, video message থাকবে না। সার্ভারেও MIME/signature যাচাই করে ভিডিও আটকাতে হবে।
- নিউজফিড, পোস্ট, মন্তব্য, সদস্য পরিচিতি/ডিরেক্টরি, notification, নিজের পোস্ট সম্পাদনা/মুছে ফেলা, রিপোর্ট ও moderation।
- ব্যবহারকারীর জন্য পোস্ট/ছবি/ভয়েসের নির্দিষ্ট quota বা পোস্টসংখ্যার কৃত্রিম সীমা থাকবে না; তবে বাস্তব storage/hosting-এর ধারণক্ষমতা অসীম নয়। স্টোরেজ বাড়ানোর ও অপব্যবহার ঠেকানোর ব্যবস্থা, monitoring ও খরচের সতর্কতা দরকার।
- অনুমোদিত account ছাড়া প্রবেশ নয়; সদস্যের genealogy data ও social posts/media পৃথক entity/storage policy-তে থাকবে। Social account বন্ধ/পোস্ট মুছলে genealogy relationship মুছে যাবে না।
- private messaging প্রথম সংস্করণে যুক্ত করলে তা text/image/voice-এ সীমিত এবং report/block controls-সহ হবে।
- server/API, authentication, storage, access control, backup ও retention policy না থাকলে এ ফিচারকে “চালু” বলা যাবে না।

### P1 — Admin System Update
Admin Menu-তে **“সিস্টেম আপডেট”**।
- “আপডেট পরীক্ষা করুন”, “এখনই আপডেট করুন”, update history, source/version/status ও error report।
- আপডেটযোগ্য data packs: Bangladesh administrative address catalogue, OCR/historical-word dictionary, relationship/document dictionaries, language/theme/configuration packs।
- Software-code update আলাদা pipeline; data update-এর সঙ্গে এক করা যাবে না।
- নির্ভরযোগ্য, versioned manifest, source attribution, checksum/digital signature, compatibility validation, staged download, backup, atomic apply এবং rollback।
- জেলা/উপজেলা পরিবর্তন হলে পুরোনো address references নীরবে rewrite নয়; mapping/migration preview ও unresolved records report।
- শুধু বোতাম দিয়ে internet-wide scraping নয়; trusted sources/maintained update endpoint এবং license/source metadata দরকার।
- Internet না থাকলে last-known-good data ব্যবহার; sync ফিরলে retry।
- Co-Admin-কে server settings, Gmail backup এবং পুরো genealogy deletion-এর অধিকার দেওয়া যাবে না; এসব সীমা UI ও server/API—দুই স্তরে enforced হবে।

### P2 — System Dictionary ও OCR
- বর্তমান `BONGSHOKOTHA-SYSTEM-DICTIONARY-DRAFT.json` একটি schema/seed draft; পূর্ণ যাচাইকৃত ঠিকানা dataset নয়।
- বাংলা/ইংরেজি/ঐতিহাসিক বানান, aliases, transliteration, old-to-modern terms; মূল OCR text অক্ষত রেখে normalized candidate আলাদা field-এ।
- OCR-এ পাওয়া তথ্য preview; ব্যবহারকারী অনুমোদন না করা পর্যন্ত member record-এ লেখা যাবে না।
- জন্ম সনদ, মৃত্যু সনদ, NID, পাসপোর্ট, বিবাহের দলিল, খতিয়ান/দলিল, স্কুল রেকর্ড, চিঠি/ডায়েরি, পারিবারিক রেজিস্টার ইত্যাদি document types।
- multi-page PDF, ছবি ঘোরানো/ক্রপ, বাংলা ও ইংরেজি OCR, field confidence, correction, accept/apply workflow এবং archive-এ extraction results দৃশ্যমান।
- কোনো OCR result-কে নিশ্চিত তথ্য ধরে স্বয়ংক্রিয়ভাবে সম্পর্ক তৈরি করা যাবে না।

### P2 — Bangladesh address catalogue
- বিভাগ → জেলা → উপজেলা/থানা → ইউনিয়ন/পৌরসভা/সিটি কর্পোরেশন → ওয়ার্ড → গ্রাম/মহল্লা → রাস্তা/বাড়ি/হোল্ডিং → ডাকঘর/পোস্টকোড।
- বর্তমান/স্থায়ী ঠিকানা আলাদা এবং “বর্তমান ঠিকানা কপি” সুবিধা।
- offline-first local cache; version/source/license/last-verified metadata।
- 15.5.7 আর্কাইভে বিভাগ/জেলা/উপজেলা/ইউনিয়ন স্তরের cascading selector আছে বলে source report জানায়, কিন্তু সম্পূর্ণ সরকারি-যাচাইকৃত জাতীয় ওয়ার্ড/গ্রাম/ডাকঘর/পোস্টকোড তালিকা bundled আছে—এমন দাবি করা যাবে না।
- আপডেট প্যাকের আগে source/license এবং সরকারি রেফারেন্স যাচাই।

### P2 — Account, roles, settings, dashboard
- My Account: নিজের নাম, login mobile, Gmail/email, password পরিবর্তন; account fields genealogy member record থেকে পৃথক।
- Roles: user, tester, editor, admin, co-admin, super-admin—প্রতিটি role-এর permission matrix লিখিত ও পরীক্ষিত।
- Co-Admin: সাধারণ প্রশাসনিক কাজ করতে পারবে; Gmail backup, server configuration এবং entire genealogy delete করতে পারবে না।
- Dashboard widget on/off controls settings-এ; পছন্দ persist ও per-user হলে আলাদা রাখা।
- Password recovery-এর জন্য real email/SMS provider/configuration না থাকলে তা স্পষ্টভাবে unavailable দেখাতে হবে; fake-success নয়।
- settings save/reload এবং privilege escalation test।

### P2 — Import/Export, archive, backup, restore
- JSON/CSV/GEDCOM-এর field mapping ও lossless round-trip test; XLSX/DOCX সমর্থিত না হলে UI-তে দাবি নয়।
- Import preview, duplicate detection, ID conflict resolution, validation errors এবং rollback।
- Export permissions, data privacy, audit log।
- Family Archive-এ uploaded file, OCR output, accepted values, source document, linked member ও audit trail।
- Restore preview/diff, media included check, overwrite warning, rollback এবং backup integrity check।
- Google Drive/Gmail backup/provider credentials থাকলেই integration enabled; credential না থাকলে configured বলা যাবে না।

### P2 — 112 themes ও Theme Studio
- Theme IDs `bkp-theme-001` … `bkp-theme-112` তালিকা পরিকল্পিত ID inventory; এগুলো বাস্তবায়িত theme-এর প্রমাণ নয়।
- duplicate/near-duplicate audit; stable IDs; theme metadata/version।
- Theme Studio: user-uploaded background, colors, font, card style, opacity, layout; dashboard-only/full-app application scope।
- per-user theme preference; নিরাপদ image size/type validation; missing image fallback।

### P3 — ভাষা, ডিভাইস ও প্যাকেজিং
- International Settings Menu, Bengali/English UI এবং date/number preferences।
- Android/mobile browser/desktop responsive testing; keyboard navigation ও accessible labels।
- PWA offline caching policy; sensitive social messages/media ভুল করে public cache-এ যাবে না।
- Windows Electron packaging ও Android Capacitor build আলাদাভাবে বাস্তব device/OS-এ যাচাই।

---

## 3. বর্তমান ZIP-এ ইতিমধ্যে উপস্থিত বলে source/status report-এ উল্লেখ আছে—তবে runtime-এ যাচাই বাকি

- Member/profile components, alternate names, relationship/generation engines।
- Multiple-marriage records এবং marriage-specific child UI-এর ভিত্তি।
- In-law name fields এবং cascading administrative address selectors (15.5.7)।
- OCR assets/engine/parser, profile/archive document components।
- Dashboard settings, theme registry, account/RBAC screens, server registry, storage/backup/import-export foundations।
- Recycle/restore and desktop/mobile build scripts।

**সতর্কতা:** source code বা source-level regression test থাকা মানে feature production-ready—এমন নয়। 15.5.7 release report অনুযায়ী full TypeScript/build এবং browser end-to-end tests সম্পন্ন হয়নি।

## 4. বর্তমান জানা সীমাবদ্ধতা ও যাচাইযোগ্য সমস্যা

1. `npm install`/dependencies এবং full `npm run typecheck`, `npm run build` সফলভাবে শেষ করা হয়নি—Windows target environment-এ চালাতে হবে।
2. Real browser/mobile end-to-end run ও persistence across reload/restart দরকার।
3. Real user backup দিয়ে relationship, generation, spouse-specific children, married-in origin ও sibling ordering পরীক্ষা দরকার।
4. Demo/sample data safety: blank database ও populated database উভয় অবস্থায় demo data যেন overwrite/autoload না হয়।
5. Complete official national address dataset bundled/verified নয়; online source first-use dependency ও licensing check আছে।
6. OCR accuracy across real multi-page Bengali documents, extraction preview/apply, archive display and file persistence যাচাই বাকি।
7. Cloud sync, email/SMS recovery, Google Drive backup এবং server integrations-এর real credentials/configuration ছাড়া production availability নিশ্চিত নয়।
8. Security: every write endpoint/API, file upload validation, role escalation, CSRF/CORS/session policy, secrets, audit log এবং backup encryption পর্যালোচনা দরকার।
9. New map/social/update modules এই base ZIP-এ বর্তমান বাস্তবায়িত ফিচার বলে ধরে নেওয়া যাবে না; এগুলো যোগ করতে হবে।
10. 112 theme inventory planned; 112 fully implemented and visually distinct themes হিসেবে দাবি করা যাবে না।

## 5. বাধ্যতামূলক release acceptance checklist

### Data integrity
- [ ] Backup তৈরি; backup hash/restore test সফল।
- [ ] Import → save → close/reopen → export-এ member/relationship/document data অক্ষত।
- [ ] Demo data real data overwrite করে না।
- [ ] Duplicate child/member, orphan relationship, cyclic parent relation আটকানো।
- [ ] Multiple marriages and spouse-specific children-এর regression/E2E tests সফল।

### Profile behavior (Member Form UI unchanged)
- [ ] বিদ্যমান Member Form UI/field layout পরিবর্তন হয়নি।
- [ ] Save/cancel/reload state সঠিক।
- [ ] Marriage status record-specific।
- [ ] Child gender profile থেকে এসেছে; missing gender guessed নয়।
- [ ] Existing child link পুনর্ব্যবহার হয়, duplicate member তৈরি হয় না।

### Security & privacy
- [ ] Co-Admin forbidden actions UI/API উভয় স্তরে blocked।
- [ ] User cannot view unapproved community or private member data. 
- [ ] Uploaded images/audio MIME/signature/size and access control validated; video upload rejected.
- [ ] Audit log contains actor, action, timestamp, target and outcome without leaking passwords/secrets.

### New modules
- [ ] Map filters and approximate-vs-exact location privacy tested.
- [ ] Social post/text/image/audio flows tested; video rejected; storage monitoring/backup works.
- [ ] System update signature/checksum/compatibility, backup, apply and rollback tested offline/online.
- [ ] Address/OCR dictionary update cannot silently corrupt existing profile links.

### Release
- [ ] `npm.cmd install` completes on Windows.
- [ ] `npm.cmd run verify` completes successfully.
- [ ] `npm.cmd run build` completes successfully.
- [ ] Browser tests on desktop and Android/mobile browser; native Android/Windows package only if release targets require it.
- [ ] Version labels, release notes, license/source attribution and migration guide consistent with Version 1.0.0.

## 6. Suggested implementation order

1. Backup/migration strategy and data integrity baseline.
2. Relationship engine and save/load regressions (without changing Member Form UI).
3. Import/export, archive and OCR apply/persistence.
4. RBAC/security, account separation, dashboard/settings persistence.
5. Address catalogue versioning and update service.
6. Member location map with privacy controls.
7. Private text/image/voice community and media backend.
8. Theme inventory/Theme Studio and international settings.
9. Full test matrix, version normalization to 1.0.0, release candidate build and rollback test.

## 7. Explicit exclusions for this task

- Member Form UI redesign or field reorganization.
- Video, live video, reels and video calling in social module.
- Claiming complete verified national address coverage without a verified dataset.
- Claiming production-ready security, OCR, cloud sync or native builds before corresponding tests pass.
- Creating a new ZIP without the user's explicit request.
