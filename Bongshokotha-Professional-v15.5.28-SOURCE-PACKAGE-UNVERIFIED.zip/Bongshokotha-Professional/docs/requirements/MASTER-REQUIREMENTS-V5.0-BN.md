# বংশকথা Professional — একীভূত সম্পূর্ণ মাস্টার রিকোয়ারমেন্ট তালিকা
**সংস্করণ:** 4.0 — Unified Master Edition  
**ভিত্তি:** পূর্বের v3.0 + v3.1 তালিকা, ৫টি ZIP + ১টি Master Specification, অতিরিক্ত Complete Master Specification, Supplemental Gap List, ১১২-থিম ক্যাটালগ এবং ব্যবহারকারীর সর্বশেষ অগ্রাধিকার।

**লক্ষ্য:** বংশতালিকা হবে স্মার্ট, সুন্দর, আধুনিক, দ্রুত, ডিভাইসের ক্ষমতার সঙ্গে মানানসই, সহজে ব্যবহারযোগ্য এবং ছোট থেকে অত্যন্ত বড় পরিবার/বংশের ক্ষেত্রেও স্থিতিশীল। ব্যবহারকারীকে একই তথ্য অকারণে বারবার লিখতে হবে না; তথ্য একবার সঠিকভাবে সংরক্ষণ করে পরিচয়-আইডি ও সম্পর্কের মাধ্যমে পুনর্ব্যবহার করতে হবে।

**সত্যতা নীতি:** এটি নির্মাণ ও পরীক্ষার চাহিদাপত্র—বাস্তবায়ন-সম্পন্নতার প্রমাণ নয়। প্রতিটি requirement-এর implementation reference, test ID এবং evidence আলাদাভাবে দিতে হবে। পুরোনো তথ্য/ফিচার যাচাই না করে মুছবে না; অনুমানকে সত্য বানাবে না।

## এই সংস্করণে একীভূত করার নিয়ম
- v3.0 ও v3.1-এর সব বিষয়কে এক master specification হিসেবে ধরতে হবে; পরিপূরককে আলাদা দ্বিতীয় তালিকা হিসেবে ব্যবহার করার দরকার নেই।
- একই বিষয়ের পুনরাবৃত্তি থাকলে একবারের মূল নিয়ম হিসেবে প্রয়োগ হবে; ভিন্ন বা বিরোধপূর্ণ দাবি সিদ্ধান্ত-রেজিস্টারে থাকবে।
- সব চাহিদা “অবশ্যই”, “প্রস্তাবিত”, “ঐচ্ছিক/পরবর্তী পর্যায়” বা “সিদ্ধান্ত বাকি” হিসেবে চিহ্নিত করতে হবে।
- ফিচারের নাম, mock screen, source file বা ZIP-এর নাম থাকলেই feature সম্পন্ন বলা যাবে না।
- কোনো feature বাদ/সরল/পরিবর্তন করলে Change Log, কারণ, অনুমোদন, ডেটা-প্রভাব এবং migration/rollback পরিকল্পনা লাগবে।

## ০. সর্বোচ্চ অগ্রাধিকার: স্মার্ট, দ্রুত ও বড় বংশে নির্ভরযোগ্য অভিজ্ঞতা
### ০.১ একবার তথ্য দিন, সবখানে ব্যবহার করুন
- প্রতিটি ব্যক্তি, বিবাহ, ঠিকানা, দলিল, প্রতিষ্ঠান ও পারিবারিক ঘটনার canonical record/স্থায়ী ID থাকবে; অন্য স্ক্রিনে একই তথ্য কপি করে আলাদা আলাদা রাখা হবে না।
- বাবা/মা/স্বামী/স্ত্রী/সন্তান/আত্মীয় যুক্ত করার সময় আগে বিদ্যমান সদস্য খোঁজা, alias/ইংরেজি/বাংলা নাম দিয়ে খোঁজা এবং সঠিক সদস্যকে নির্বাচন করার ব্যবস্থা থাকবে। “নতুন সদস্য” শুধু সত্যিই নতুন ব্যক্তি হলে।
- একই ঠিকানা, শিক্ষা প্রতিষ্ঠান, পেশা, নথি বা archive item পুনরায় প্রয়োজন হলে অনুমতি ও প্রাসঙ্গিকতা অনুযায়ী saved record থেকে নির্বাচন/লিংক করা যাবে; duplicate তৈরির আগে সতর্কতা থাকবে।
- একই তথ্য profile, tree, dashboard, reports, calendar, archive ও family book-এ canonical data থেকে প্রদর্শিত হবে। এক জায়গায় অনুমোদিত পরিবর্তন হলে সব view সঠিকভাবে refresh হবে।
- OCR/Import থেকে আসা তথ্য field-by-field preview, conflict comparison ও user approval ছাড়া profile-এর পুরোনো তথ্য overwrite করবে না।
- Form-এ “আগের সদস্য থেকে নিন”, “একই ঠিকানা ব্যবহার করুন”, “বিদ্যমান প্রতিষ্ঠান বাছুন”, “সম্পর্কিত ব্যক্তি নির্বাচন করুন”, autocomplete ও reusable templates থাকবে—কিন্তু auto-fill স্পষ্টভাবে দেখাতে হবে এবং ভুল তথ্য নীরবে বসানো যাবে না।
- পুনরাবৃত্ত entry-তে form state আগের ব্যক্তির তথ্য অনিচ্ছাকৃতভাবে ধরে রাখবে না; নতুন record-এর জন্য stale values মুছে/পুনরায় যাচাই করতে হবে।
- Save retry, OCR retry, import retry ও sync retry duplicate-safe হবে; double-click বা network retry-তে duplicate person/marriage/child/file তৈরি হবে না।
- ব্যবহারকারীকে যে তথ্য ইতিমধ্যে নির্ভরযোগ্যভাবে জানা আছে তা আবার বাধ্যতামূলকভাবে চাইবে না। তবে একই নামের ব্যক্তি বা অস্পষ্ট তথ্য হলে confirm/resolve করতে বলবে।
- Optional/unknown তথ্যের জন্য বাধ্যতামূলক ভুয়া মান বসাতে হবে না; draft-এ অসম্পূর্ণ তথ্য নিরাপদে রাখা যাবে।

### ০.২ ডিভাইসের ক্ষমতা অনুযায়ী অভিযোজন
- UI responsive হবে এবং ফোন, ট্যাবলেট, ল্যাপটপ, ডেস্কটপ ও লক্ষ্যকৃত Android WebView/PWA/Windows package-এ উপযোগীভাবে কাজ করবে।
- ছোট স্ক্রিনে compact cards, collapsible sections, bottom navigation/appropriate navigation, readable Bangla fonts, touch-friendly controls ও keyboard-safe forms; বড় স্ক্রিনে অতিরিক্ত space কাজে লাগিয়ে split view/detail panel/table/tree view।
- ডিভাইস/ব্রাউজারের memory, CPU, screen size ও offline capability অনুযায়ী tree rendering, image preview, OCR batch size, pagination এবং animation কমানো/বাড়ানোর progressive enhancement থাকবে। Device capability detect করা সম্ভব না হলে নিরাপদ default ব্যবহার করবে।
- কম ক্ষমতার ডিভাইসে heavy animation, একসঙ্গে হাজার node render, বড় original image বা পুরো archive memory-তে তোলা এড়াতে হবে; ব্যবহারকারীকে অকারণে crash/blank screen/অতিরিক্ত loading-এ ফেলা যাবে না।
- UI-তে loading/progress, empty state, retry/cancel, recoverable error এবং offline/unsaved state পরিষ্কার থাকবে; background task-এ কাজ চললে ব্যবহারকারী অন্য অংশ ব্যবহার করতে পারবেন যেখানে নিরাপদ।
- network নেই বা server unavailable হলে local-only capability যা সমর্থিত তা চলবে; cloud/sync feature configured না থাকলে তা স্পষ্টভাবে disabled/not configured দেখাবে।

### ০.৩ যত বড় বংশই হোক—পরিমাপযোগ্য পারফরম্যান্স
- “অসীম সদস্য” প্রতিশ্রুতি নয়; বাস্তব target hardware-এ benchmark নির্ধারণ করে ১,০০০ / ১০,০০০ / ১,০০,০০০ member synthetic dataset এবং বড় সম্পর্ক/দলিল-যুক্ত dataset-এ পরীক্ষা করতে হবে।
- পুরো বংশবৃক্ষ একসঙ্গে render নয়: visible branch/viewport অনুযায়ী lazy loading, collapse/expand, virtualization/canvas/graph strategy এবং incremental layout ব্যবহার করতে হবে।
- Search database/index-backed হবে; pagination, filtering, sorting ও debounced search ব্যবহার করে প্রতিটি keystroke-এ পুরো dataset scan এড়াতে হবে।
- Database query ও relationship traversal-এ index, query plan, batching, caching এবং bounded graph traversal; N+1 queries ও বারবার full-tree recomputation এড়াতে হবে।
- Generation/branch/statistics cache invalidation সঠিক হতে হবে; relation change-এর পর শুধু প্রভাবিত অংশ recompute করা গেলে তাই করতে হবে, তবে correctness আগে।
- Image thumbnails, responsive sizes, lazy loading, compression এবং document preview streaming; বড় PDF/image একসঙ্গে decode করে memory exhaustion করা যাবে না।
- Large import/export/backup/OCR/background jobs chunked/streaming, progress, cancel, resume/retry ও error report সহ চলবে।
- Performance target হবে p95 measurement-ভিত্তিক: সাধারণ cached profile open ও সাধারণ indexed search লক্ষ্য ≤ 2 সেকেন্ড; সাধারণ save লক্ষ্য ≤ 2 সেকেন্ড; 10,000-member benchmark-এ সাধারণ search লক্ষ্য ≤ 1 সেকেন্ড—বাস্তব target device-এ যাচাই করতে হবে। যেসব operation বড়, সেগুলোতে progress দেখাতে হবে; benchmark ব্যর্থ হলে release gate বন্ধ থাকবে।
- 100,000-member benchmark একটি লক্ষ্য-স্কেল পরীক্ষা; ডিভাইস/ডেটাবেসের বাস্তব সীমা মেপে documented supported scale দিতে হবে। কোনো পরীক্ষা ছাড়া “যেকোনো বড় বংশে সমস্যা হবে না” দাবি করা যাবে না।
- Crash recovery, autosave/draft, transaction, migration rollback, storage quota warning এবং database integrity check থাকতে হবে।
- Offline/local-first ও multi-user/server mode-এর data consistency, conflict detection, sync order, retry ও merge rules আলাদা করে নির্দিষ্ট ও পরীক্ষা করতে হবে।

## ০.৪ সহজ, সুন্দর ও অ্যাক্সেসিবল UI
- বাংলা-first, consistent design system; spacing, typography, color tokens, form controls, modal, toast, error, focus/disabled state ও responsive breakpoints একরকম।
- Dashboard-এর Statistics আলাদা প্রধান menu নয়; dashboard card/widget হিসেবে থাকবে। কার্ড ক্লিক করলে প্রাসঙ্গিক list/detail খুলবে; widget on/off, order, size/visibility যেখানে প্রযোজ্য, ব্যবহারকারীর পছন্দ অনুযায়ী সংরক্ষণ হবে।
- theme preview/apply/reset এবং পছন্দ restart-এর পরও থাকবে; একই রকম theme অকারণে duplicate নয়। 80/112/116 সংখ্যার দ্বন্দ্ব code registry + 112-ID catalog + visual audit দিয়ে নিষ্পত্তি করতে হবে।
- Keyboard navigation, focus indicator, screen-reader labels, sufficient contrast, scalable font, Bengali glyph rendering, touch target, reduced-motion preference এবং form validation accessibility বজায় রাখতে হবে।
- কোনো animation/data visualization-ই ব্যবহারকারীর ডিভাইস ধীর করে বা গুরুত্বপূর্ণ তথ্য আড়াল করে না; reduced-motion/low-performance fallback থাকবে।



# পূর্ববর্তী মাস্টার তালিকার একীভূত মূল বিষয়বস্তু (v3.0 + v3.1)

বংশকথা Professional

সম্পূর্ণ মাস্টার রিকোয়ারমেন্ট তালিকা

সংস্করণ ৩.১ — অতিরিক্ত উৎস-পর্যালোচনা ও ঘাটতি সংযোজনসহ

ভিত্তি: পূর্বের ৫টি ZIP + ১টি Master Specification; পরিপূরক: v2.0 specification, GAP list v1.1, ১১২ থিম ক্যাটালগ ও পূর্ববর্তী স্পষ্ট চাহিদা

গুরুত্বপূর্ণ সীমা: এই নথি হলো প্রয়োজনীয়তার তালিকা; এটি সফটওয়্যারের সব ফিচার বাস্তবায়িত বা পরীক্ষিত হওয়ার সার্টিফিকেট নয়। প্রতিটি requirement-এর জন্য implementation reference, test result এবং evidence আলাদাভাবে দিতে হবে.

# বংশকথা Professional — ছয় উৎসের সমন্বিত সম্পূর্ণ মাস্টার তালিকা

সংস্করণ: 3.0

ভিত্তি: ব্যবহারকারীর দেওয়া ৫টি ZIP + ১টি পূর্ণ Master Specification

উদ্দেশ্য: নতুন নির্মাণ, বিদ্যমান প্রকল্প উন্নয়ন, ডেভেলপার/AI handoff, বাস্তবায়ন ও গ্রহণযোগ্যতা পরীক্ষা

প্রধান নীতি: পরিবারের তথ্য ও সম্পর্ক কোডের চেয়ে গুরুত্বপূর্ণ; প্রমাণ ছাড়া কোনো ফিচারকে সম্পন্ন বলা যাবে না।

## কীভাবে এই তালিকা ব্যবহার করতে হবে

এই নথি ছয়টি উৎসে পাওয়া চাহিদা, নিয়ম, প্রকল্প-নির্দেশনা, কোড/নথির ইঙ্গিত এবং যাচাই-সীমাবদ্ধতা একত্র করে। পুনরাবৃত্ত বিষয়গুলো এক জায়গায় সাজানো হয়েছে; পরস্পরবিরোধী বা অসম্পূর্ণ বিষয় মুছে ফেলা হয়নি—সিদ্ধান্ত/যাচাইয়ের জন্য আলাদা করে দেখানো হয়েছে। কোনো ZIP-এ কোড বা ফিচারের নাম থাকা মানেই সেটি পূর্ণ, নির্ভুল, নিরাপদ বা production-ready—এমন নয়।

প্রতিটি requirement বাস্তবায়নের সময় অবস্থা লিখতে হবে: সম্পন্ন—প্রমাণসহ / আংশিক / অসম্পন্ন / পরীক্ষা হয়নি / প্রযোজ্য নয়। প্রমাণ হতে পারে নির্দিষ্ট source file, automated test output, browser E2E, বাস্তব Android/Windows test, বা user-approved data round-trip report।

# ১. পণ্যের পরিচয়, উদ্দেশ্য ও নকশার নীতি

বংশকথা একটি দীর্ঘমেয়াদি genealogy/family-history preservation system—শুধু কে কার বাবা তা দেখানোর অ্যাপ নয়। এতে সদস্য, প্রজন্ম, সম্পর্ক, বিবাহের ইতিহাস, পরিবার-শাখা, স্মৃতি, জীবনী, ছবি, দলিল, পারিবারিক আর্কাইভ, ক্যালেন্ডার, রিপোর্ট, Family Book, sharing, import/export, backup/restore ও data validation থাকবে।

- বাংলা হবে প্রধান UI ভাষা; English নাম ও প্রয়োজনে English UI/দ্বিভাষিক রপ্তানি থাকবে।

- Android/mobile অগ্রাধিকার; responsive browser/PWA এবং Windows desktop লক্ষ্য/প্যাকেজিংয়ের প্রয়োজন অনুযায়ী সমর্থনযোগ্য।

- Offline/local-first কাজ ও persistent storage মৌলিক প্রয়োজন; cloud/server/sync আলাদা configured capability।

- বিদ্যমান কাজ করা ফিচার ও পুরোনো তথ্য যাচাই না করে অন্ধভাবে নতুন প্রকল্প বানানো বা ফর্মের field বাদ দেওয়া যাবে না।

- AI/OCR সহায়ক হবে; গুরুত্বপূর্ণ তথ্য পরিবর্তনে মানুষের নিশ্চিতকরণ লাগবে।

- অজানা তথ্য blank/unknown/approximate হিসেবে থাকবে; সত্য হিসেবে অনুমান করা যাবে না।

# ২. স্থায়ী পরিচয় ও মূল ডেটা মডেল

## ২.১ Person

প্রত্যেক ব্যক্তির স্থায়ী unique Person ID থাকবে। নাম বদল, বানান সংশোধন বা অন্য ফর্মে প্রদর্শন বদলালেও ID বদলাবে না। একই নামের দুই ব্যক্তির আলাদা ID হবে। সম্পর্কের key হবে ID—নাম নয়।

প্রোফাইলে প্রয়োজন অনুযায়ী:

- বাংলা পূর্ণ নাম; English name ঐচ্ছিক, আলাদা field; ডাকনাম/প্রচলিত নাম।

- বিকল্প নাম/বানান; নামের ধরন, উৎস-দলিল, তারিখ, নোট ও যাচাই-অবস্থা।

- লিঙ্গ; ছবি; সদস্যের ধরন: জন্মসূত্রে / বিবাহসূত্রে / দত্তকসূত্রে।

- জন্মতারিখ, তারিখের নির্ভুলতা, জন্মস্থান, নিজ জন্ম-ক্রমিক নম্বর (যদি ব্যবহারকারী/পুরোনো ডেটায় থাকে), প্রজন্ম/branch display।

- জীবিত/মৃত/অজানা; মৃত্যুর তারিখ/স্থান/কবরস্থান; বয়স গণনা; রক্তের গ্রুপ ঐচ্ছিক।

- যোগাযোগ, বর্তমান/স্থায়ী ঠিকানা, শিক্ষা, একাধিক শিক্ষা প্রতিষ্ঠান, পেশা/একাধিক পেশা, কর্মস্থল, দক্ষতা, অর্জন, জীবনী, নোট।

- একাধিক ছবি/দলিল/জীবনের ঘটনা; privacy setting ও data source/provenance।

## ২.২ পরিচয় ও নম্বরের পার্থক্য

Person ID, UI-তে দেখানো member number, জন্ম-ক্রমিক নম্বর, পরিবারের নিজস্ব serial—এক জিনিস ধরে নেওয়া যাবে না। পুরোনো নথিতে “নিজ ক্রমিক নং”/“member number” নিয়ে ভিন্নতা আছে। সিদ্ধান্ত ছাড়া এক field-এ মিশিয়ে ফেলা যাবে না; পুরোনো field থাকলে backward compatibility বজায় রাখতে হবে।

## ২.৩ তারিখের নির্ভুলতা

Exact day/month/year, month+year, year only, approximate, historical-source date, unknown—প্রয়োজন অনুযায়ী সংরক্ষণ। তারিখের সঙ্গে source/note থাকতে পারে। বর্তমান বয়স জন্মতারিখ ও বর্তমান তারিখ থেকে হিসাব হবে; historical/manual age আলাদা note/verified field হতে পারে।

## ২.৪ উৎস ও দ্বন্দ্ব

প্রতিটি গুরুত্বপূর্ণ fact-এর source, source type, file/document reference, confidence, entered/verified by, timestamp ও notes রাখার নকশা থাকবে। পরস্পরবিরোধী তথ্য নীরবে overwrite নয়; পুরোনো মান ও নতুন মান তুলনা করে user review করবে। মৌখিক ইতিহাস/স্মৃতিচারণও উৎসসহ সংরক্ষণযোগ্য।

# ৩. স্মার্ট সদস্য ফর্ম ও প্রোফাইল UX

- পুরোনো ফর্মের কোনো field, option বা function নীরবে বাদ দেওয়া যাবে না; redesign হলে আগে field-by-field inventory ও regression test।

- compact, responsive, section-ভিত্তিক form; প্রয়োজনমতো section collapse/expand, কিন্তু collapse করলে তথ্য মুছে যাবে না।

- বাংলা নাম প্রধান; English নাম ঐচ্ছিক—বাংলা নাম থেকে স্বয়ংক্রিয়ভাবে ইংরেজি বানান তৈরি/কপি করা যাবে না।

- সদস্যের ধরন শুধু জন্মসূত্রে/বিবাহসূত্রে/দত্তকসূত্রে; gender, life status, marital status ও children indicator আলাদা ধারণা।

- default life status “জীবিত”, default marital status “অবিবাহিত”—তবে পুরোনো imported value অকারণে বদলানো যাবে না।

- marital status অনুযায়ী প্রাসঙ্গিক spouse/marriage/children/in-law section দেখানো বা লুকানো যাবে; hide করা মানে data delete নয়। অবিবাহিত ব্যক্তির জন্য অপ্রয়োজনীয় spouse fields default-এ দেখানো হবে না।

- save, edit, cancel, validation, error/success state স্পষ্ট। Save ব্যর্থ হলে success দেখানো যাবে না; আগের saved data অক্ষত থাকবে।

- profile-এ relation, spouse/marriage history, children, address, aliases, documents, OCR result, education/profession, life events ও archive links দেখা যাবে।

- নাম পরিবর্তন করলে সম্পর্ক, search, tree, report, document links বা spouse/child records ভাঙা যাবে না।

- পেশা, শিক্ষা প্রতিষ্ঠান, achievements ইত্যাদিতে বিদ্যমান তালিকা থেকে বেছে নেওয়া এবং অনুমতি অনুযায়ী নতুন entry যোগ/স্থায়ী dictionary-তে সংরক্ষণ।

# ৪. সম্পর্ক ও Genealogy Engine

## ৪.১ Canonical links

- Father ↔ child এবং Mother ↔ child একই canonical relationship source থেকে সামঞ্জস্যপূর্ণভাবে নির্ণয়/দেখানো।

- Spouse সম্পর্ক reciprocal; marriage history আলাদা entity।

- দাদা/দাদি, নানা/নানি, ভাইবোন, চাচা/চাচি, ফুফু/ফুফা, মামা/মামি, খালা/খালু ইত্যাদি যাচাইকৃত parent links থেকে derive করা যাবে।

- step-parent, adoptive parent, guardian, foster/other relation, biological relation এবং marriage-based relation আলাদা type হিসেবে রাখার সুযোগ।

- অপ্রাসঙ্গিক নাম টাইপ করে duplicate person বানানোর বদলে বিদ্যমান Person ID নির্বাচন/সংযুক্ত করা।

- পিতৃবংশ ও মাতৃবংশ অনুসরণ, relationship source ও uncertainty প্রদর্শনের ব্যবস্থা।

## ৪.২ Validation

- নিজের পূর্বপুরুষ নিজেই হওয়া, circular parent chain, duplicate ID, duplicate child, orphaned link, broken reciprocal link, incompatible parent/child relation শনাক্ত/প্রতিরোধ।

- relation পরিবর্তনের পর সংশ্লিষ্ট profile, tree, sibling list, generation ও dashboard তাৎক্ষণিকভাবে সঠিকভাবে আপডেট।

- একই ব্যক্তির নাম/বানান একাধিক থাকলেও একই Person ID ব্যবহার।

- relationship merge/repair preview, backup, confirmation, audit trail ও rollback।

## ৪.৩ বিবাহসূত্রে আসা সদস্যের জন্মপরিবার

বিবাহসূত্রে যুক্ত ব্যক্তির নিজের biological father/mother তথ্য রাখা যাবে। তাঁদের স্বয়ংক্রিয়ভাবে নতুন primary family tree-র member বানানো যাবে না; family-entry rules অনুযায়ী দৃশ্যমানতা নির্ধারিত হবে। শিশুর দাদা-দাদি/নানা-নানি নির্ণয়ে parent links ও বিবাহের context ব্যবহার করতে হবে—শুধু display name দিয়ে নয়।

# ৫. বিবাহ, বহু বিবাহ, সন্তান ও বৈবাহিক অবস্থা

## ৫.১ Marriage entity

একটি spouseId field দিয়ে পুরো ইতিহাস চালানো যাবে না। প্রতিটি marriage-এর স্থায়ী Marriage ID ও আলাদা record থাকবে:

- দুই পক্ষের Person ID;

- বিবাহের তারিখ ও precision, স্থান, ঠিকানা;

- marriage status, বিচ্ছেদ/তালাকের তারিখ, end reason;

- spouse-side parent/in-law links, নোট, দলিল;

- ওই বিবাহের সন্তানদের links;

- source/provenance, audit history।

## ৫.২ Status আলাদা রাখতে হবে

Life status: জীবিত / মৃত / অজানা।

ব্যক্তির marital status: অবিবাহিত / বিবাহিত / বিধবা / বিপত্নীক / তালাকপ্রাপ্ত / বিচ্ছিন্ন / পুনর্বিবাহিত / অজানা।

প্রতিটি marriage-এর status আলাদা। spouse মারা গেলে নাম ও history থাকবে; divorce বা separation হলে পুরোনো spouse record মুছে যাবে না। এক বিবাহের status পরিবর্তনে অন্য marriage বদলাবে না।

## ৫.৩ Marriage-specific children

- প্রতিটি সন্তান সঠিক parent IDs এবং প্রযোজ্য marriage ID-র সঙ্গে যুক্ত।

- Marriage A-এর সন্তান Marriage B-এর সন্তান হিসেবে দেখানো যাবে না।

- শিশু/সন্তানের লিঙ্গ-লেবেল profile-এর তথ্য থেকে দেখাতে হবে; অজানা হলে অনুমান নয়।

- সন্তান যোগ/সম্পাদনার পর list ও profile-এ সঙ্গে সঙ্গে দেখা যাবে; আগের child data নতুন child form-এ অনিচ্ছাকৃতভাবে থেকে যাবে না।

- adopted child, step-child, guardian link ও biological parents-এর তথ্য আলাদা relationship type-এ।

- husband/wife profile-এ একই marriage record-এর সামঞ্জস্যপূর্ণ তথ্য।

## ৫.৪ In-laws

শ্বশুর/শাশুড়ি, জামাই, পুত্রবধূ ও অন্যান্য marriage-based relations marriage context থেকে derive/দেখাতে হবে। একই ব্যক্তির একাধিক বিবাহে in-law context মিশবে না। বিদ্যমান spouse-parent record থাকলে সেটি ব্যবহার; নীরবে overwrite নয়।

# ৬. প্রজন্ম, জন্মক্রম, পরিবার ও শাখা

- Parent আগের generation, child পরের generation, spouse সাধারণত একই generation।

- Generation verified parent-child links থেকে dynamically calculate; manual override থাকলে আলাদা metadata ও source।

- Backup-এর পুরোনো generation অন্ধভাবে গ্রহণ নয়; verified relationship অগ্রাধিকার।

- জন্ম-ক্রম (birth order) save order বা member ID থেকে অনুমান নয়; জন্মতথ্য/ব্যবহারকারী নিশ্চিত করা তথ্য অনুযায়ী; unknown হলে unknown।

- পরে parent assign করলে generation পুনর্গণনা ও UI refresh।

- family branches: পূর্বপুরুষ, geographic, historical বা user-defined branch; branch ID ও membership rules।

- tree-তে ancestors/descendants, immediate family, siblings, spouse, children, in-laws, branches, generation; expand/collapse, focus, zoom/pan, search, branch hide/show, print/export।

- বড় tree-তে performance, virtualization/lazy loading বা equivalent responsiveness।

- tree node click করলে member profile/detail; connection line ও labels স্পষ্ট।

# ৭. ঠিকানা ও International Settings

- বর্তমান ঠিকানা, স্থায়ী ঠিকানা, জন্মস্থান, বিবাহ-ঠিকানা ও অন্যান্য ঐতিহাসিক ঠিকানা আলাদা।

- country → division/state/province → district → upazila/thana → union/municipality/city corporation → ward/locality/village/mohalla → post office/postcode → road/house/holding; দেশ অনুযায়ী প্রযোজ্য স্তর।

- cascading lists সঠিক parent-child relationship-সহ; উপরের selection পাল্টালে invalid lower-level selection reset।

- সম্পূর্ণ ঠিকানা comma-separated preview; user চাইলে সম্পাদনা/override এবং source রাখবে।

- বাংলা/English address labels/values সমর্থন।

- পেশা, শিক্ষা প্রতিষ্ঠান, ঠিকানা, document type ইত্যাদি dictionary data persistent ও versioned।

- বাংলাদেশ প্রশাসনিক ও ডাক-ঠিকানার সম্পূর্ণ dataset দাবি করার আগে coverage, freshness, source, license ও missing-coverage report দিতে হবে। উৎসগুলোর একাধিক নথিতে সম্পূর্ণ সরকারি ইউনিয়ন/ডাকঘর/পোস্টকোড dataset bundled/verified নয় বলে সীমাবদ্ধতা আছে।

- আন্তর্জাতিক locale: দেশ, ভাষা, calendar/date/number/time formats; unknown/historical place গ্রহণযোগ্য।

# ৮. ছবি, দলিল, OCR, QR/Barcode ও Document Vault

## ৮.১ Supported workflow

Member Profile এবং Family Archive থেকে ছবি/PDF/সমর্থিত নথি upload; birth registration, NID, passport, driving licence, marriage/death certificates, education/land/historical documents ইত্যাদির জন্য document type-specific extraction map।

- Original file immutable evidence হিসেবে থাকবে।

- Original binary, enhanced image, raw OCR text, structured extracted fields, QR/barcode payload, metadata, provenance ও audit history আলাদা সংরক্ষণ।

- Document lifecycle: Uploaded → Processing → OCR Complete → Needs Review → Partially Approved → Approved/Rejected → Archived।

- OCR result field-by-field preview; user correct/edit/select/approve করার পর profile field-এ apply।

- OCR result মূল data-র ওপর নীরবে overwrite নয়; conflict compare ও duplicate suggestion।

- OCR source priority: original document; machine-readable QR/barcode payload; raw OCR text; interpreted structured extraction; existing member data comparison; user approval is final.

- Bengali, English, mixed script; front/back/combined images; multipage PDF; page-wise result; offline OCR model/asset support যেখানে package-এ থাকে।

- NID/BRN/passport/document numbers আলাদা type; document type mix করে ভুল identifier নয়।

- QR, PDF417/barcode parsing only when technically supported and tested; support আছে বলে দাবি করতে হলে real samples ও test evidence দিতে হবে।

- confidence high/medium/low; critical identity fields review বাধ্যতামূলক—even high confidence।

- NID/BRN/passport OCR-এর accuracy benchmark, known limitations ও regression samples সংরক্ষণ।

- Archive-এ OCR findings দৃশ্যমান; শুধু “সংরক্ষণ করুন” status নয়।

- Document access permission: view/upload/OCR/approve/download/print/share/delete/restore আলাদা নিয়ন্ত্রণযোগ্য।

- Complete backup/restore-এ original binary files-ও থাকতে হবে; metadata-only archive backup যথেষ্ট নয়।

# ৯. Family Archive, Family History ও Family Book

- ছবি, scan, PDF, historical records, চিঠি, জন্মনিবন্ধন/NID-সংক্রান্ত নথি, জমি/বাড়ির ইতিহাস, family stories, oral history/audio clips, captions, memories, important events।

- Archive item-কে Person ID, Marriage ID, branch, event বা family workspace-এর সঙ্গে link।

- file search, filters, tags, source/date/creator metadata, privacy, duplicate detection ও restore।

- Family History: family origin, ancestors, historical events, important people, timeline, memories ও contribution।

- Family Book: printable/exportable family history—intro, tree, generation, member biographies, marriage history, children, events, branch history, photos, historical notes।

- বাংলা-সমর্থিত print/PDF; layout preview; large tree/page-breaks; sensitive fields বাদ দেওয়ার control।

- Family crest/logo optional; profile photo থেকে আলাদা asset।

# ১০. Dashboard, Navigation, Search ও Calendar

## ১০.১ Navigation

প্রধান menu-র প্রস্তাবিত বিন্যাস: Dashboard; সব সদস্য; Family Tree; Family Book; Family Archive; Family Calendar; Import/Export/Print/Backup; Settings. Statistics আলাদা প্রধান menu নয়—Dashboard-এ থাকবে। Menu structure platform-এ মানানসই হতে পারে, তবে duplicate/conflicting navigation এড়াতে হবে।

## ১০.২ Dashboard widgets

- মোট সদস্য; জীবিত/মৃত/অজানা; gender distribution; generation/branch counts।

- oldest/youngest living/deceased, longest-lived—শুধু পর্যাপ্ত verified dates থাকলে।

- জন্মদিন, বিবাহবার্ষিকী, মৃত্যুবার্ষিকী, family events/reminders।

- recent activity, archive overview, backup status, data quality/relationship integrity, import/export status।

- age/gender/generation/branch charts; summary/detail drill-down।

- প্রতিটি widget Settings থেকে ON/OFF, reorder, reset; settings persistence।

- clickable card/widget সঠিক filtered list/detail-এ যাবে; “Static” বা duplicate Statistics menu তৈরি নয়।

## ১০.৩ Search/filter

নাম, alternate name, English/Bangla name, birth serial (যদি UI-তে থাকে), Person ID, generation, branch, gender, life/marital status, address, parents, spouse, child, relationship, document/alias/source। Sort/filter; quick edit; profile/relationship view; permission-aware search।

## ১০.৪ Calendar

Birthday, marriage anniversary, death anniversary, family events, reminders; approximate/unknown date-কে exact event হিসেবে দেখানো নয়।

# ১১. থিম, ভাষা, অ্যাপ আইকন ও ডিভাইস অভিযোজন

- Light/Dark/System এবং theme registry; catalog/IDs-কে runtime-এ থাকা বাস্তব theme-এর সঙ্গে reconcile করতে হবে।

- বিভিন্ন উৎসে 80-theme catalog এবং 112/116 unique theme inventory/test ফল আছে; সংখ্যাগুলো পরস্পর এক নয়। চূড়ান্ত সংখ্যা/নাম/ID runtime registry, CSV/XLSX, visual audit ও duplicate test দিয়ে স্থির করতে হবে।

- একই নাম/দেখতে প্রায় একই theme অকারণে duplicate নয়; প্রতিটি theme-এর color tokens, typography, surface, controls, focus/disabled states, contrast ও all-page consistency পরীক্ষা।

- theme preview, apply, save, restart persistence, reset; dashboard/profile/forms/archive/modals/print views-এ ধারাবাহিকতা।

- বাংলা/English UI; future locale-ready translation keys; missing translation test।

- user-selected app icon/logo support; Android camera/media/gallery permissions platform অনুযায়ী minimal permission, user explanation ও denial fallback।

- Android WebView safe area, status/navigation bar, keyboard, dynamic viewport, bottom navigation; unwanted white gap নেই।

- mobile/tablet/desktop responsive; keyboard accessibility, contrast, touch target, readable Bangla font।

# ১২. Account, Login, My Account ও ৮টি Role

## ১২.১ Account বনাম genealogy profile

প্রত্যেক account-এর name/login mobile/email/password/photo বদল genealogy Person record-কে বদলাবে না। My Account পৃথক screen/data entity; নিজের account edit access সব ব্যবহারকারীর জন্য role policy অনুযায়ী।

- username/mobile login; forgot password/recovery workflow; account lifecycle, lockout/rate limit, session/device management।

- email/SMS reset কেবল বাস্তব provider/configuration থাকলে “সক্রিয়” বলা যাবে।

- account profile photo ও genealogy member photo আলাদা, যদি না user explicitly link করে।

## ১২.২ Role set

Owner, Super Admin, Admin, Co-Admin, Tester, Editor, Contributor, Viewer—আটটি role-এর permission matrix, UI visibility এবং server/service-side enforcement।

- উচ্চ বা সমান ক্ষমতার role assign করা যাবে না; role escalation আটকাতে হবে।

- Viewer কেবল অনুমোদিত read এবং নিজের account edit করবে।

- Contributor: permitted additions/proposals; approval workflow configured থাকলে Pending → Review → Approve/Reject → Audit।

- Editor: permitted genealogy editing।

- Tester: explicit test permissions; real data destructive permission নয়, unless authorized.

- Admin/Super Admin/Owner permissions স্পষ্ট, least privilege ভিত্তিক।

- Co-Admin সব সাধারণ admin ক্ষমতা পাবে, কিন্তু Gmail backup, server settings/server list এবং সম্পূর্ণ genealogy delete করার ক্ষমতা পাবে না।

- permission UI hide করাই যথেষ্ট নয়; every mutation/API/storage operation-এ enforcement।

- password storage, session handling, audit log, secret management, file upload validation, access checks।

- recovery/change events audit; privileged changes require confirmation.

# ১৩. Import, Export, Backup, Restore, Sharing ও Migration

## ১৩.১ Import/export

- স্পষ্টভাবে ঘোষিত formats: JSON, CSV, GEDCOM; XLSX/DOCX/PDF বা অন্য format support থাকলে আলাদা tested claim।

- international structured export, bilingual export, family-only export, complete backup, printable Family Book আলাদা উদ্দেশ্য।

- Import flow: receive → preview → schema/version validate → duplicate detection → relationship validate → conflict review → user confirm → import → integrity check।

- imported file-এ missing field blank/unknown থাকবে; নিজে থেকে data বানানো যাবে না।

- stable IDs ও relationships preserve; unsupported fields/losses-এর report।

- GEDCOM/CSV round-trip loss report; media/document inclusion explicit।

## ১৩.২ Backup/restore

- manual/local/automatic backup; cloud/Gmail/Drive backup only when actual credentials, APIs, scopes, encryption and error recovery configured।

- portable versioned package; manifest/schema version, integrity/hash, timestamp, source, media/documents, settings and required metadata।

- restore preview, conflict handling, backup-before-restore, rollback/recovery।

- restore-এর পরে member count, IDs, parent/child/spouse/marriage, generations, branches, documents/media, settings মিলিয়ে report।

- existing data overwrite/merge policy user-selected; blind overwrite নয়।

- update/migration-এর আগে source/data backup; migration versioned, validated, recoverable।

## ১৩.৩ Demo/sample data safety

- demo data ও real family data আলাদা workspace/explicit demo mode।

- real data load/import হলে app startup demo data দিয়ে overwrite বা replace করবে না।

- blank database-এর demo behavior user-controlled; sample record যেন real family member হিসেবে merge না হয়।

## ১৩.৪ Sharing, server, sync

- share link/code/invitation, preview, request access, approval, field/category permission, expiry/revocation।

- received family data automatic merge নয়; preview/validate/duplicate/conflict review/approval।

- local-first/offline; future LAN/cloud multi-user sync হলে conflict detection/resolution, audit, access control।

- server registry/admin controls, Gmail backup, cloud sync ও social communication separate modules; integration configured/tested না হলে feature complete বলা যাবে না।

- user-approved scope অনুযায়ী optional text/image/audio family communication; privacy, report/moderation. Video/live call sources-এ in-scope নয় বলে একটি সিদ্ধান্তে উল্লেখ—আবার অনুমোদন ছাড়া যোগ নয়।

# ১৪. Data Integrity, Recycle Bin, Audit ও Repair

- missing name, duplicate ID, broken parent/child/spouse link, cyclic relationship, orphaned marriage, wrong child-marriage association, inconsistent living/marital status, malformed import, missing media link শনাক্ত।

- safe repair আগে preview/diff/backup/confirmation; repair log এবং rollback।

- soft delete → Recycle Bin → restore/permanent delete; permanent deletion confirmation, role restriction, audit।

- restore করলে original Person ID, marriage links, relationships ও relevant media ফিরে আসবে।

- audit: actor, timestamp, action, old value, new value, source/reason; sensitive data logs-এ অপ্রয়োজনীয়ভাবে প্রকাশ নয়।

- uncertain duplicate: compare/review/merge or keep separate; name-only auto-merge নিষিদ্ধ।

- merge reversible/traceable; IDs redirect/alias policy স্পষ্ট।

- sensitive field privacy: Public / Family Only / Private; NID, birth certificate, phone, private address/documents default protected; share permission field/category level-এ।

# ১৫. Performance, Reliability, Offline ও Security

- UI component সরাসরি বিভিন্ন স্থানে family data mutate করবে না; central genealogy/domain service, relationship engine, generation engine, persistence service।

- persistent storage single source of truth; React state একমাত্র database নয়।

- autosave হলে conflict/dirty state স্পষ্ট; failure handling, retry, recovery।

- large family tree/search/archive-এ responsive performance; memory/file size management।

- offline core workflow; network unavailable হলে local data কাজ করবে।

- sensitive local data secure storage/encryption where feasible; backup encryption/key recovery design।

- API keys mobile bundle-এ expose নয়; secure server-side proxy বা safe on-device method।

- production server-এ authentication, authorization on every mutation, session/cookie policy, CSRF/CORS, upload MIME/size checks, rate limits, logging/monitoring, secrets management।

- user data delete/export/access policy ও retention স্পষ্ট।

- app update এবং address dictionary update আলাদা; trusted update source, integrity/version checks, backup-before-update ও rollback।

- accessibility, keyboard, contrast, screen-reader labels, touch targets।

# ১৬. Architecture ও ডেভেলপমেন্ট পদ্ধতি

প্রস্তাবিত logical layers:

UI → Application/state → Genealogy service → Relationship/marriage service → Generation/order engine → Persistence/database → Media/archive service → Import/export/backup/migration.

- platform adapters: web/PWA, Capacitor Android, optional Electron Windows, optional server/sync.

- types/schema centrally defined; runtime validation at import/storage boundary.

- Person, Marriage, Family/Workspace, Branch, Address, Alias/NameVariant, LifeEvent, Document, ArchiveItem, Source/Evidence, Account, Role/Permission, AuditEntry, BackupManifest—প্রয়োজন অনুযায়ী আলাদা entity।

- schema version ও migration history; unknown fields safely preserve where possible।

- test fixtures, real-data sanitized fixture, regression tests, release notes, requirements traceability matrix।

- নতুন developer প্রথমে সব ZIP/source, package/version, components, services, schema, storage, OCR, theme, permissions, build scripts, known issues ও tests inspect করবে; তারপর পরিবর্তন।

- source change-এর আগে impact analysis, backup, migration plan, implementation, tests, regression, report।

- build green হওয়া runtime correctness-এর বিকল্প নয়।

# ১৭. Windows, Android ও release delivery

- Windows PowerShell-এ dependency install, typecheck, unit/regression tests, production build, run/launch, optional Electron package।

- Android: web build → Capacitor sync → Android Gradle build → install on real device/emulator → persistence and permission checks → APK/AAB as requested।

- exact build commands project package.json/scripts দেখে নিতে হবে; পুরোনো README থেকে blindly command কপি নয়।

- version metadata, package.json, UI labels, changelog, installer/APK metadata ও docs সামঞ্জস্যপূর্ণ।

- release package-এ source, requirements, setup instructions, build scripts, test reports, known limitations, schema/migration notes, backup/restore guide।

- no “zero bugs”/“fully complete” claim without evidence.

- source package verification, typecheck/build, browser E2E, Windows packaging, Android device testing, OCR real samples, address data coverage, backup restore and security review are distinct gates.

# ১৮. বাধ্যতামূলক গ্রহণযোগ্যতা/Regression Test

## Data & persistence

- [ ] Fresh empty workspace starts without unwanted demo member data.

- [ ] Add/edit/delete/restore member; close/reopen/refresh; data remains.

- [ ] Backup → restore → export round-trip preserves IDs, relations, marriages, docs/media and settings.

- [ ] Existing real data never overwritten by demo data.

- [ ] migration from every supported old schema/package is tested with preserved source backup.

## Relationship & marriage

- [ ] Father/mother ↔ child reciprocal consistency.

- [ ] rename preserves IDs, spouse, parents, children, tree, search, reports and document links.

- [ ] sibling ordering independent of save order.

- [ ] parent added later recalculates generation correctly.

- [ ] multiple marriages edit independently; spouse-specific children remain correctly associated.

- [ ] widow/widower/divorce/separation/remarriage preserve history.

- [ ] married-in person's biological parents retained without unintended primary-tree nodes.

- [ ] no duplicate/orphan/cyclic relations; safe repair preview works.

## Form, address & names

- [ ] Every legacy field accounted for; form save/edit/cancel/reload tested.

- [ ] Bangla/English/aliases with source type; no silent overwrite of main name.

- [ ] conditional sections hide/show without deleting data.

- [ ] cascading address lists reset invalid child selection; complete address preview/edit.

- [ ] address dataset coverage, source, license and missing areas documented.

## OCR & archive

- [ ] NID/BRN/passport types remain separate.

- [ ] front/back/multipage document workflow; OCR preview, correction and apply.

- [ ] OCR apply only changes approved fields; conflicting values preserved.

- [ ] original file, raw text, extracted fields, QR payload and archive links survive restart and backup/restore.

- [ ] benchmark includes difficult Bangla, English, mixed-script, blur/rotation, missing fields and known failures.

## Dashboard, themes & devices

- [ ] dashboard widget ON/OFF/order persists; each card opens correct detail.

- [ ] theme catalog IDs unique; no duplicate names/appearance without reason; theme persists after restart and applies across screens.

- [ ] responsive browser/mobile; Android safe-area/bottom white-space/keyboard/permissions tested.

- [ ] Bengali/English translations, date/number locale and accessibility checked.

## Accounts & security

- [ ] account-only edits never change genealogy member fields.

- [ ] all 8 roles tested against every mutation and privileged screen/API.

- [ ] Co-Admin cannot Gmail backup, server settings/list, or delete entire genealogy.

- [ ] role escalation blocked server-side; Viewer edits own account only.

- [ ] real recovery/provider/cloud integrations tested with authorized credentials or clearly marked not configured.

- [ ] audit, privacy, upload validation and secret exposure review.

## Release gates

- [ ] automated unit/domain/regression tests report.

- [ ] typecheck/build results captured.

- [ ] browser E2E result captured.

- [ ] Windows/Android package and actual device install results captured.

- [ ] actual backup restore and representative user data tests captured.

- [ ] known limitations and unverified areas documented.

# ১৯. উৎসগুলোর মধ্যে গুরুত্বপূর্ণ অমিল/সিদ্ধান্ত প্রয়োজন

1. Theme count: একটি catalog-এ 80 premium themes; অন্য নথিতে 112 unique IDs; 15.5.7 test report-এ 116 unique themes detected। চূড়ান্ত runtime registry + catalog + visual uniqueness audit ছাড়া সংখ্যা স্থির নয়।

1. Member serial: Person ID, readable member number, own birth serial এবং legacy serialNumber আলাদা রাখতে হবে। UI-তে কোনটি দেখানো/সম্পাদনা করা যাবে—সিদ্ধান্ত ও migration mapping দরকার।

1. Member form design: একটি implementation plan বলছে existing Member Form UI/field layout পরিবর্তন নয়; অন্য requirement smart/compact responsive form চায়। স্থির সিদ্ধান্ত: কোনো field/function বাদ নয়; UI redesign শুধু অনুমোদিত হলে, before/after field inventory ও regressionসহ।

1. Address completeness: ZIP-এ address form/source checks উল্লেখ থাকলেও সম্পূর্ণ সরকারি বাংলাদেশ ইউনিয়ন/ডাকঘর/postcode catalogue verified/bundled নয়—এই সীমাবদ্ধতা সংরক্ষণ করতে হবে।

1. OCR: local OCR assets/parser/source tests থাকা বাস্তব নথির accuracy, multi-page PDF, barcode parsing বা profile apply end-to-end সফল হওয়ার প্রমাণ নয়।

1. Cloud/Gmail/server/recovery: source/UI থাকলেও real credentials, API scopes, security, deployment ও provider tests ছাড়া live feature বলে দাবি নয়।

1. Theme catalogue vs runtime: catalog rows/IDs থাকলেই সব theme সব screen-এ আলাদা/সঠিকভাবে render করে—এমন নয়।

1. Release status: 15.5.7 report-এ source-level audits pass বলা হলেও full typecheck/build/browser E2E/Windows EXE/Android APK ও real-device checks সম্পন্ন হয়নি বলে স্পষ্ট সীমা আছে।

1. Data format: JSON/CSV/GEDCOM support ও XLSX/DOCX/PDF support একভাবে দাবি নয়; প্রতিটি format-এর tested scope ও loss report দরকার।

1. Optional social/map/cloud features: legacy/implementation plan-এ উল্লেখ থাকলেও current package-এ production-ready উপস্থিতি আলাদা করে যাচাই করতে হবে।

# ২০. ছয়টি উৎসের ভিত্তি ও কীভাবে মিলানো হয়েছে

এই তালিকা নিম্নের ঠিক ছয়টি user-provided source থেকে প্রস্তুত:

1. BONGSHOKOTHA-PROFESSIONAL-12.6.2-FINAL-INTEGRATED-MASTER.zip

1. BONGSHOKOTHA-PROFESSIONAL-15.1.1-REQUIREMENTS-ALIGNED.zip

1. BONGSHOKOTHA-PROFESSIONAL-15.5.7-MASTER-RELEASE-CANDIDATE.zip

1. BONGSHOKOTHA-PROFESSIONAL-ULTIMATE-11.0.0-V4-MERGED.zip

1. Bongshokotha-Professional-v1.3.0-runtime-safe.zip

1. বংশকথা (BONGSHOKOTHA) — পূর্ণ Master Specification ও ভবিষ্যৎ Handoff Document.md

প্রতিটি ZIP-এর archive inventory, README/master requirements/feature matrices/legacy inventory/release notes/known limitations, available theme catalog, OCR specification, smart form list, decisions/implementation plan এবং relevant source-tree structure দেখা হয়েছে। পূর্ণ সব source file-এর line-by-line functional audit বা বাস্তব ডিভাইসে প্রতিটি feature চালানো এই নথি তৈরির অংশ নয়; তাই feature status বিষয়ে অতিরঞ্জিত দাবি করা হয়নি।

# ২১. ভবিষ্যৎ Developer/AI-কে দেওয়ার কাজের নির্দেশ

প্রথমে inspect; তারপর preserve; তারপর implement; শেষে verify.

1. Source ZIP ও real family backup-এর আলাদা read-only copy/hash রাখুন।

1. এই মাস্টার তালিকা থেকে requirement IDs বানিয়ে traceability matrix তৈরি করুন।

1. current implementation-এর প্রতিটি requirement-কে file/test evidence দিয়ে map করুন।

1. field/data/relationship বাদ পড়েছে কি না compare করুন।

1. conflicts/decisions owner-এর অনুমোদন ছাড়া নিজে থেকে মীমাংসা করবেন না।

1. backup ও migration plan ছাড়া destructive change নয়।

1. unit/regression tests, typecheck/build, browser E2E, Android/Windows runtime ও real-data round-trip আলাদা পরীক্ষা করুন।

1. ব্যর্থতা, সীমাবদ্ধতা, untested areas এবং প্রমাণসহ final handoff দিন।

## চূড়ান্ত মূলনীতি

- NAME IS DISPLAY DATA; ID IS RELATIONSHIP DATA.

- UNKNOWN MUST REMAIN UNKNOWN.

- BACKUP DATA MUST SURVIVE UPDATES.

- MARRIAGE HISTORY AND MARRIAGE-SPECIFIC CHILDREN MUST NOT BE MIXED.

- OCR/AI SUGGESTS; USER CONFIRMS.

- EXISTING DATA MUST NEVER BE SILENTLY REPLACED BY DEMO DATA.

- SOURCE PRESENCE IS NOT THE SAME AS VERIFIED FUNCTIONALITY.

# ২২. পরবর্তী উৎস-পর্যালোচনায় যোগ করা অতিরিক্ত ও আরও স্পষ্ট বাধ্যতামূলক নিয়ম — v3.1

এই সংযোজনটি v3.0-এর বিকল্প নয়। আগের তালিকার সঙ্গে একত্রে পড়তে হবে। মূল ছয় উৎসের বাইরে Library-তে থাকা অতিরিক্ত মাস্টার স্পেসিফিকেশন v2.0, Supplemental Gap List v1.1, থিম ID তালিকা এবং আগের কথোপকথনের স্পষ্ট শর্তের সঙ্গে মিলিয়ে নিচের বিষয়গুলো আরও স্পষ্ট করা হয়েছে। এগুলো requirements; এগুলো বাস্তবায়িত বা পরীক্ষিত হওয়ার প্রমাণ নয়।

## ২২.১ পরিচয়, নাম, ব্যক্তিগত তথ্য ও প্রমাণের উৎস

- বাংলা নাম ও ইংরেজি নাম আলাদা ক্ষেত্র হবে; ইংরেজি নাম ঐচ্ছিক। বাংলা নাম থেকে ইংরেজি নাম স্বয়ংক্রিয়ভাবে কপি/অনুবাদ করে নীরবে সংরক্ষণ করা যাবে না। Transliteration প্রস্তাব হিসেবে দেখালে ব্যবহারকারীর অনুমোদন লাগবে।

- ব্যক্তি-পরিচয়ের নাম, দৈনন্দিন/পছন্দের নাম, ডাকনাম, বানানভেদ, নথিভিত্তিক নাম এবং পূর্বনাম/বিবাহ-পরবর্তী নাম আলাদা variant হিসেবে রাখা যাবে; প্রতিটির ভাষা, ধরন, উৎস নথি, যাচাই-অবস্থা ও নোট থাকবে।

- ব্যক্তি, নামের variant, সম্পর্ক, তারিখ ও ঐতিহাসিক দাবির সঙ্গে প্রমাণ/সূত্র যুক্ত করা যাবে: দলিল/ছবি/আর্কাইভ আইটেম, মৌখিক সূত্র, গবেষক/প্রদানকারী, তারিখ, নির্ভরযোগ্যতার স্তর ও মন্তব্য। অনিশ্চিত তথ্যকে নিশ্চিত তথ্য হিসেবে দেখানো যাবে না।

- সংশোধনের ইতিহাসে কে, কখন, কোন তথ্য কেন বদলেছেন এবং প্রযোজ্য ক্ষেত্রে আগের/পরের মান থাকবে; গোপন/সংবেদনশীল মান অপ্রয়োজনীয়ভাবে audit log-এ লেখা যাবে না।

- সম্ভাব্য একই ব্যক্তি শনাক্তকরণ কেবল প্রস্তাব/সতর্কতা; প্রমাণ ও ব্যবহারকারীর অনুমোদন ছাড়া merge, primary name বদল বা রেকর্ড delete করা যাবে না।

## ২২.২ বংশসম্পর্কের অতিরিক্ত নিরাপত্তা ও অস্পষ্ট সম্পর্ক

- জৈবিক পিতা-মাতা, দত্তক পিতা-মাতা, সৎ-সম্পর্ক, আইনি অভিভাবক/guardian এবং পরিচর্যাকারী/অন্যান্য সম্পর্ক আলাদা type-এ রাখতে হবে; এক ধরনের সম্পর্ক অন্যটিকে overwrite করবে না।

- কোনো সম্পর্ক যোগ/পরিবর্তনের আগে self-link, ancestor cycle, duplicate link, ভুল parentage, অস্বাভাবিক বয়স/তারিখ, marriage-child mismatch এবং সম্ভাব্য unintended family-tree node যাচাই করতে হবে।

- বিবাহসূত্রে যুক্ত ব্যক্তির জন্মপরিবার অক্ষুণ্ণ থাকবে; শ্বশুর-শাশুড়ি spouse-এর parent links থেকে resolve হবে। কেবল in-law field পূরণ করতে গিয়ে অপ্রমাণিত ব্যক্তি/parent তৈরি করা যাবে না।

- ভাইবোন ও প্রজন্ম যতদূর সম্ভব canonical parentage থেকে নির্ণয় হবে। কোনো manual override থাকলে তার কারণ/সূত্র সংরক্ষণ এবং স্বয়ংক্রিয় গণনার সঙ্গে পার্থক্য দেখাতে হবে।

- সম্পর্ক সম্পাদনা একটি transaction হিসেবে হবে; আংশিকভাবে parent বদল, child list, marriage links, tree, reports ও generation আপডেট হয়ে থেমে যাওয়া চলবে না।

- Generation গণনার নীতি—প্রতিষ্ঠাতা/মূল প্রজন্ম, বিবাহসূত্রে আসা সদস্য, দত্তক/সৎ-সম্পর্ক, অজানা পিতা-মাতা ও একাধিক শাখা—লিখিতভাবে নির্ধারণ ও পরীক্ষায় অনুমোদন করতে হবে; অস্পষ্ট নীতি নিজে থেকে ধরে নেওয়া যাবে না।

## ২২.৩ পূর্ণ ঠিকানা ও ঠিকানা-ডেটাসেট

- বর্তমান ঠিকানা, স্থায়ী ঠিকানা, জন্মস্থান, মৃত্যুর স্থান, বিবাহের স্থান এবং spouse-এর ঠিকানা আলাদা address record হবে। প্রয়োজনমতো দেশ, বিভাগ, জেলা, উপজেলা/থানা, ইউনিয়ন পরিষদ/পৌরসভা/সিটি কর্পোরেশন, ওয়ার্ড, গ্রাম/মহল্লা/এলাকা, ডাকঘর, পোস্টকোড, রাস্তা, বাড়ি/হোল্ডিং/ফ্ল্যাট নম্বর এবং প্রতিষ্ঠান/স্থানীয় landmark-এর পৃথক ক্ষেত্র থাকবে।

- প্রতিটি ঠিকানায় বাংলা ও ঐচ্ছিক ইংরেজি মান থাকবে; পূর্ণ ঠিকানার comma-separated preview, edit ও change থাকবে। composed text সংশোধন করলেও structured components হারাবে না।

- Dropdown hierarchy parent selection অনুযায়ী filter হবে; উপরের স্তর বদলালে অকার্যকর নিম্নস্তরের নির্বাচন clear হবে। গ্রাম/পোস্ট অফিস না থাকলে অনুমোদিত manual add-এ parent unit, উৎস, যোগকারী, তারিখ ও verification status লাগবে।

- Address catalog-এর উৎস, license, version, update date, administrative level অনুযায়ী coverage, missing-level/duplicate report এবং update process থাকতে হবে। পূর্ণ বাংলাদেশের সব গ্রাম/ডাকঘর আছে—এ দাবি কেবল যাচাইকৃত coverage evidence-সহ করা যাবে।

- Offline address lookup এবং catalog update-এর নীতি স্পষ্ট হবে; catalog update পুরোনো saved address নীরবে পরিবর্তন করতে পারবে না।

## ২২.৪ সদস্য ফর্ম, ড্রাফট ও সংরক্ষণ-নিরাপত্তা

- Smart form-এর section navigation/quick-jump, ধাপে ধাপে ফর্ম, review screen, draft save/recovery, cancel confirmation, validation, duplicate warning এবং relation inconsistency warning থাকবে।

- বৈবাহিক অবস্থা পরিবর্তন করলে কোন section দেখাবে তা নিয়ন্ত্রণ হবে; লুকানো section-এর আগের তথ্য মুছে যাবে না। মুছে ফেলা বা পরিবর্তনের আগে সম্ভাব্য প্রভাব দেখাতে হবে।

- একই তথ্য বারবার প্রবেশ করাতে বাধ্য করা যাবে না; existing member search/select থাকবে। Save ব্যর্থ হলে অর্ধেক member/relationship/marriage তৈরি হবে না; retry করলে duplicate record তৈরি হবে না।

- Occupation, education, institution, workplace, awards, biography এবং অন্যান্য repeatable data-তে একাধিক entry ও ব্যবহারকারীর দেওয়া multiline text সমর্থন করতে হবে।

- Member ID/UUID, ব্যবহারযোগ্য member number, নিজের জন্ম ক্রমিক নম্বর এবং legacy serialNumber পৃথক ধারণা হিসেবে থাকবে; migration mapping ও UI-তে কোনটি দেখানো/সম্পাদনা করা যাবে তা সিদ্ধান্ত-রেজিস্টারে অনুমোদন করতে হবে।

## ২২.৫ বংশবৃক্ষ, Family Book, গবেষণা ও প্রতিবেদন

- বংশবৃক্ষে ancestor/descendant, প্রজন্ম-সীমা, পিতা-মাতা, ভাইবোন, একাধিক spouse, marriage-specific children এবং adopted/step/guardian links-এর স্পষ্ট visual distinction থাকবে; mobile-এ zoom/pan/collapse/focus এবং click-to-profile পরীক্ষা করতে হবে।

- Family Book/বংশ ইতিহাস তৈরি করলে নির্বাচিত শাখা/প্রজন্ম, ব্যক্তি-প্রোফাইল, নামভেদ, সম্পর্ক, ছবি/দলিল, সূত্র/নোট, index/table of contents, privacy filtering, page layout এবং print/PDF output-এর scope আলাদা করে নির্ধারণ করতে হবে।

- Historical/approximate/unknown dates ও places গ্রহণযোগ্য হবে; আনুমানিক তারিখকে সঠিক দিন হিসেবে দেখানো যাবে না। Report-এ filter, generation rules, calculation date এবং data-source/limitations দৃশ্যমান থাকবে।

- একাধিক বিবাহে member count, spouse count ও child count double-count হবে না; report-এর counting rule লিখিত থাকবে।

- Birthday, death anniversary, wedding anniversary এবং custom family dates-এর reminders opt-in হবে; timezone/date locale ও privacy preferences মানতে হবে। Email/SMS notification বাস্তব provider integration না থাকলে configured বলে দাবি করা যাবে না।

## ২২.৬ অ্যাকাউন্ট, সেশন ও ভূমিকা

- Login-এ মোবাইল নম্বর, ইমেইল/Gmail এবং password ভিত্তিক প্রবেশের শর্ত বজায় রাখতে হবে; username-ও সমর্থিত হলে তার mapping ও uniqueness rule স্পষ্ট করতে হবে। Password reset/forgot password কেবল বাস্তবে সংযুক্ত নিরাপদ recovery flow থাকলে active বলে গণ্য হবে।

- Account profile (display name, login mobile, email, password, avatar, recovery) genealogy member profile থেকে আলাদা; account-only edit genealogy fields পরিবর্তন করতে পারবে না।

- আটটি role-এর প্রতিটির জন্য screen/action/API mutation অনুযায়ী allow/deny matrix এবং positive/negative test লাগবে। UI থেকে বোতাম লুকানো যথেষ্ট নয়; trusted service/API layer-এ permission check বাধ্যতামূলক।

- Role assignment-এ একই বা উচ্চতর role দেওয়া আটকাতে হবে; escalation, session expiry, logout, password change, recovery, account disable এবং privileged action audit করতে হবে।

- Co-Admin-এর অনুমোদিত ক্ষমতা বিস্তৃত হলেও Gmail backup, server settings/list এবং সম্পূর্ণ genealogy delete নিষিদ্ধ থাকবে; এ নিষেধ UI ও backend—দুই স্তরেই পরীক্ষা করতে হবে। Viewer কেবল নিজের account তথ্য সম্পাদনা করবে, genealogy data নয়।

- Local-only mode ও server/multi-user mode-এর ক্ষমতা, backup, sync, privacy boundary এবং security differences UI ও documentation-এ স্পষ্ট থাকবে।

## ২২.৭ Import/export, backup, restore ও migration

- Import-এর আগে preview, field mapping, unsupported fields, duplicate candidates, relation validation এবং added/updated/skipped/conflict summary দেখাতে হবে।

- Export/Import round-trip-এ person IDs, aliases, parentage, marriage participants, marriage-specific children, addresses, documents, archive links, settings এবং supported metadata অক্ষুণ্ণ আছে কি না loss report দিয়ে দেখাতে হবে।

- Backup-এ metadata ছাড়াও প্রয়োজনীয় original media/documents, archive files ও linkage থাকতে হবে। Restore-এর আগে current backup, dry-run/diff, conflict resolution, rollback এবং corrupted/incomplete backup handling পরীক্ষা করতে হবে।

- Migration প্রতিটি supported legacy package/schema-তে read-only source copy, pre/post validation, rollback plan ও loss report-সহ হবে; demo/seed data কখনো existing real data overwrite করবে না।

- JSON/CSV/GEDCOM/XLSX/PDF/DOCX—প্রতিটি format-এর support scope আলাদা করে উল্লেখ করতে হবে; কোনো format-কে সমর্থিত বলা যাবে কেবল বাস্তব import/export test evidence থাকলে।

- Gmail/cloud/server backup-এর জন্য বাস্তব OAuth/API scopes, token storage, revoke, provider failure handling এবং authorized integration test লাগবে।

## ২২.৮ নিরাপত্তা, গোপনীয়তা ও নির্ভরযোগ্যতা

- Password-এর জন্য আধুনিক password hashing, session expiry, rate limiting, secure cookie/session policy (web/server mode), input/output validation, upload type/size validation, safe filenames এবং authorization-checked download/share/print থাকতে হবে।

- Secret/API key/token source code, client bundle, exported diagnostics বা logs-এ থাকবে না। Error message বাংলায় করণীয় দেখাবে; raw stack trace কেবল diagnostic context-এ।

- Private fields, NID/BRN/passport numbers, documents, photos এবং exported reports-এর visibility/access rules স্পষ্ট হবে; default export-এ private identifiers mask/omit করার নীতি নির্ধারিত থাকবে।

- Concurrent edit conflict শনাক্ত করতে হবে; একজনের পরিবর্তন অন্যজনের পরিবর্তন নীরবে overwrite করতে পারবে না। Upload/OCR/import/export-এ progress, cancel, retry ও duplicate-safe retry থাকবে।

- বড় family tree ও হাজারো সদস্যের জন্য indexed search, pagination/virtualization, lazy loading এবং performance benchmarks থাকবে।

- Camera/media/file permissions প্রয়োজনের সময় ব্যাখ্যাসহ চাইবে; permission না দিলে manual entry/upload path সচল থাকবে।

## ২২.৯ পরীক্ষা, রিলিজ ও প্রমাণের বাধ্যতামূলক রেজিস্টার

প্রতিটি requirement-এর জন্য unique ID, priority, status, implementation reference, test ID, evidence link, owner এবং target release রাখতে হবে। Status vocabulary হবে: Planned / In Progress / Implemented / Tested / Blocked / Deferred / Not Applicable. ‘Implemented’ এবং ‘Tested’ এক নয়।

ন্যূনতম পৃথক release gates:

1. Source/package inventory, dependency/license and secret scan.

1. Unit/domain tests for identity, parentage, marriage, generation, address and permissions.

1. Typecheck, lint, production build and automated regression tests.

1. Browser end-to-end: create/edit/save/reload/restart and no-demo-overwrite.

1. Real backup → restore → export/import round-trip with files and relations.

1. Address dataset provenance, coverage and cascading-dropdown tests.

1. OCR representative real samples: Bangla, English, mixed script, blur/rotation, front/back/PDF, missing fields, QR/barcode where claimed; field-by-field approval and archive display.

1. All eight role positive/negative tests, including Co-Admin exclusions and Viewer restriction.

1. Responsive phone/tablet/desktop, keyboard/focus/screen reader, contrast, date/number locale and Android permissions/safe-area tests.

1. Clean Windows folder build/launch independent of developer cache; Windows launcher/EXE, PWA and Android APK are separate artifacts and require separate install tests.

1. Version, release date, changelog, checksum, user manual, run/stop/restart instructions, known limitations and test logs included.

## ২২.১০ সিদ্ধান্ত-রেজিস্টারে অবশ্যই খোলা রাখতে হবে

- Generation calculation semantics for marriage-in, adopted, step, guardian, unknown parent and merged branches.

- Family merge semantics and how conflicting identity/relationship evidence is resolved.

- Local-only versus server/multi-user and offline synchronization/conflict policy.

- Family Book content, layout, privacy and export scope.

- Exact identifiers exposed in UI: UUID, member number, own birth serial and legacy serial.

- Theme count/catalog authority: previous sources conflict between 80, 112 and 116; use the provided 112-ID catalog as a required input, but final runtime count and appearance must be reconciled against code and visual audit before claiming completion.

- Address catalog completeness and source/licensing; village/post-office coverage remains evidence-dependent.

- Which advanced integrations (Gmail/cloud/server/email/SMS/social/maps) are Required, Optional, Deferred or Not Applicable; no mock/UI-only item may be described as production-ready.

## ২২.১১ অতিরিক্ত উৎস ও সীমাবদ্ধতা

এই v3.1 update-এ আগের ছয় উৎসের v3.0 তালিকার সঙ্গে অতিরিক্তভাবে Library-তে থাকা Bongshokotha_Professional_Complete_Master_Specification_BN_v2.0.docx, Bongshokotha_Professional_Supplemental_Gap_List_BN_v1.1.docx, BONGSHOKOTHA-PROFESSIONAL-112-UNIQUE-THEME-IDS.xlsx/.csv, এবং পূর্ববর্তী কথোপকথনে স্পষ্ট করা ঠিকানা/লগইন/সম্পর্কের নিয়ম মিলিয়ে ঘাটতি ও acceptance criteria আরও স্পষ্ট করা হয়েছে। অতএব v3.1 এখন আর শুধু ছয় উৎসের সারাংশ নয়; এটি ছয় উৎসের সমন্বিত তালিকার একটি পরিপূরক-সমৃদ্ধ সংস্করণ।

এটি এখনও সম্পূর্ণ line-by-line audit of every source code file বা runtime/device verification নয়। কোনো ফিচার অ্যাপে আছে, নেই, কাজ করছে বা পরীক্ষিত—তা নিশ্চিত করতে সংশ্লিষ্ট source code, automated tests, browser E2E, real data, backup/restore, address coverage এবং device/package evidence আলাদাভাবে যাচাই করতে হবে।


## ২৩. একীভূত বাস্তবায়ন, অগ্রাধিকার ও গ্রহণযোগ্যতার চূড়ান্ত চুক্তি
### ২৩.১ Data-entry duplication prevention acceptance tests
- [ ] একই Person ID দিয়ে ব্যক্তি সব view-তে পুনর্ব্যবহৃত; relation add করলে নাম-ভিত্তিক duplicate record তৈরি হয় না।
- [ ] Alias/Bangla/English/ID search দিয়ে existing member পাওয়া যায়; ambiguous matches confirm হয়।
- [ ] Repeated address/institution/occupation/doc/archive linking reuse flow কাজ করে; duplicate warning-এর override reason log হয়।
- [ ] OCR/Import field preview দেখায়; conflict হলে old/new/source তুলনা হয়; user approval ছাড়া overwrite হয় না।
- [ ] Double-click, retry, refresh ও offline reconnect-এ duplicate-safe save/relationship/import নিশ্চিত।
- [ ] Hidden conditional form sections-এর saved data অক্ষত; নতুন সদস্য ফর্মে আগের সদস্যের stale values আসে না।
- [ ] One fact edit করলে profile, tree, dashboard, search, calendar, reports ও Family Book consistent update হয়।

### ২৩.২ Large genealogy/performance acceptance tests
- [ ] 1k/10k/100k-member benchmark datasets তৈরি; parent/child/marriage/alias/document distributions documented।
- [ ] p50/p95 profile open, search, save, tree initial render, branch expansion, report, import/export ও memory usage log হয়।
- [ ] 10k members-এ indexed search p95 ≤ 1 second target; ordinary profile open/save p95 ≤ 2 seconds target on defined reference device.
- [ ] Tree initial view শুধু visible/selected branch render করে; expand/collapse-এ app freeze/crash হয় না।
- [ ] Stress test-এ memory, CPU, database size, query count, UI blocking ও background job cancellation পরীক্ষা।
- [ ] Low-memory/slow CPU/mobile network/offline mode-এ graceful degradation; errors recoverable, no data loss।
- [ ] Performance target না মিললে known limitation ও supported scale প্রকাশ না করা পর্যন্ত release gate fail।

### ২৩.৩ Device adaptation acceptance tests
- [ ] Phone portrait/landscape, tablet, desktop and Windows clean-install environment tested.
- [ ] Android WebView/PWA safe-area, keyboard, viewport resize, permission denied, back navigation and file picker tested.
- [ ] Reduced-motion, large font, keyboard-only, screen-reader labels, contrast and Bangla text wrapping tested.
- [ ] Low capability device uses smaller batch/thumbnail/animation profile; no user data/feature correctness change.

### ২৩.৪ Requirement traceability and release gate
প্রতিটি requirement-এর unique ID, priority (P0/P1/P2), status (Planned/In Progress/Implemented/Tested/Blocked/Deferred/Not Applicable), source, code reference, test ID, evidence, owner ও release target থাকবে। “Implemented” এবং “Tested” আলাদা। P0 data integrity/security/relationship correctness fail হলে release হবে না।

**P0 — Release-blocking:** data persistence/no demo overwrite; canonical identity/relations; marriage-specific children; duplicate prevention; backup/restore/rollback; permissions/role enforcement; privacy; no silent overwrite; clean build and crash-free core flows.

**P1 — Core quality:** smart form, cascading address, OCR review/apply, dashboard settings, search, large tree performance, accessibility, import/export, themes and Family Book.

**P2 — Optional/phase-gated:** social/maps, email/SMS reminders, cloud providers and other external integrations unless user explicitly marks required. UI mock alone is not production integration.

## ২৪. একীভূত সিদ্ধান্ত-রেজিস্টার
- Theme count: 80 vs 112 vs 116 conflict; 112-ID catalog is required input, but runtime implementation and visual uniqueness audit decides final count.
- Identifiers: Person UUID, readable member number, own birth serial and legacy serial remain separate until migration/UI decision approved.
- Generation semantics for marriage-in, adopted/step/guardian, unknown parent and merged branches require explicit rule and tests.
- Family merge/conflicting evidence resolution requires preview, confirmation, audit and rollback.
- Address catalog: source/license/freshness/coverage must be evidenced; full village/post office coverage cannot be claimed without report.
- Local-only vs server/multi-user/offline sync behavior must be selected/documented; no false sync guarantees.
- Family Book content/privacy/export formats require scope approval.
- OCR/barcode support depends on representative real sample tests; no guaranteed extraction for unsupported/poor-quality documents.
- Gmail/cloud/server/email/SMS/social/maps are Required/Optional/Deferred only by explicit decision; credentials/API integration and security tests required.

## ২৫. একীভূত উৎস ও সীমাবদ্ধতা
এই একীভূত সংস্করণে v3.0-এর ছয় উৎস-ভিত্তিক মাস্টার তালিকা, v3.1-এর অতিরিক্ত ঘাটতি/acceptance criteria, Complete Master Specification v2.0, Supplemental Gap List v1.1, ১১২-থিম catalog এবং ব্যবহারকারীর সর্বশেষ smart/modern/performance/no-repeat-entry অগ্রাধিকার একত্র করা হয়েছে। পুনরাবৃত্ত বিষয়গুলো একক নীতিতে একীভূত; theme count, IDs, address coverage, external integrations এবং generation semantics-এর মতো অনিষ্পন্ন দ্বন্দ্ব মুছে না দিয়ে সিদ্ধান্ত-রেজিস্টারে রাখা হয়েছে।

এই নথি requirements-এর একক ভিত্তি। এটি source-code-এর পূর্ণ line-by-line audit, বাস্তব data restore, browser E2E বা Android/Windows device test-এর বিকল্প নয়। বাস্তবায়নের প্রতিটি দাবির পক্ষে code/test/evidence লাগবে।


---

# সংস্করণ 5.0 — বহুমাত্রিক গবেষণা, সর্বজনীন OCR ও বাস্তবায়ন-প্রমাণ সংযোজন
**তারিখ:** ১৩ অক্টোবর ২০২৬  
**সম্পর্ক:** v4.0-এর পূর্ণ তালিকা অক্ষত রেখে এই অংশটি নতুন বাধ্যতামূলক/প্রস্তাবিত চাহিদা, গবেষণা-সূত্র এবং যাচাইযোগ্য acceptance criteria যোগ করে। আগের অংশ মুছে বা সংক্ষিপ্ত করে প্রতিস্থাপন করা যাবে না।

## ২৬. গবেষণা থেকে প্রাপ্ত প্রযুক্তিগত নীতি

### ২৬.১ OCR-কে একটি ইঞ্জিন নয়, বহু-ধাপের Document Intelligence Pipeline হিসেবে বানাতে হবে
- প্রথমে ফাইলের ধরন, MIME, পৃষ্ঠা সংখ্যা, rotation, resolution, embedded text, language/script, document layout এবং file safety পরীক্ষা করতে হবে।
- ডিজিটাল PDF-এ আগে embedded text extraction চেষ্টা করতে হবে; স্ক্যান/ছবির PDF-এ প্রতিটি পৃষ্ঠা rasterize করে OCR করতে হবে। একই পৃষ্ঠায় text layer থাকলেও ভুল/অসম্পূর্ণ হলে user-approved redo OCR বিকল্প থাকবে।
- preprocessing: orientation correction, deskew, perspective correction, crop/edge detection, glare/shadow reduction, denoise, contrast enhancement, blur/low-resolution warning; মূল ফাইল কখনো পরিবর্তন করে মুছে ফেলা যাবে না।
- OCR ফলাফল শুধু plain text হবে না: text blocks, bounding boxes, page index, reading order, table/label-value structure, confidence, engine/model/version, language, processing settings এবং source-file hash সংরক্ষণ করতে হবে।
- document classification → OCR/layout parsing → field extraction → normalization → candidate matching → conflict review → user approval → save/link—প্রতিটি ধাপ আলাদা ও পুনরায় চালানোযোগ্য হবে।
- field extraction-এর schema document type অনুযায়ী হবে; যেমন NID, জন্মনিবন্ধন, পাসপোর্ট, ড্রাইভিং লাইসেন্স, শিক্ষাগত সনদ, বিবাহ/তালাক/মৃত্যু সনদ, জমির দলিল, পুরোনো খতিয়ান, চিঠি, ডায়েরি, সংবাদপত্রের কাটিং, বই/বংশলতিকা, হাতে লেখা নোট, ছবি/ক্যাপশন, PDF, TIFF, PNG, JPEG, WebP এবং বহু-পৃষ্ঠার স্ক্যান।
- “সব ধরনের ডকুমেন্ট পড়বে” লক্ষ্যটি **বিস্তৃত ফাইল-ইনটেক ও প্লাগইনযোগ্য পার্সার** হিসেবে বাস্তবায়ন করতে হবে; সব নথি থেকে শতভাগ সঠিক তথ্য পাওয়ার প্রতিশ্রুতি প্রযুক্তিগতভাবে গ্রহণযোগ্য নয়। অচেনা/ক্ষতিগ্রস্ত/পাসওয়ার্ড-সুরক্ষিত/অস্পষ্ট নথির জন্য graceful fallback, raw text, manual review ও unsupported reason দেখাতে হবে।

### ২৬.২ OCR ইঞ্জিন নির্বাচন ও fallback
- বিদ্যমান Tesseract বাংলা/ইংরেজি OCR offline baseline হিসেবে রাখা যেতে পারে; তবে বাস্তব NID/জন্মনিবন্ধন/পাসপোর্ট/পুরোনো নথির নিজস্ব labelled test set দিয়ে accuracy মাপতে হবে।
- PaddleOCR-এর document parsing pipeline (যেমন PP-StructureV3/PaddleOCR-VL) একটি পরীক্ষাযোগ্য বিকল্প/সহায়ক স্তর হিসেবে evaluate করতে হবে—বিশেষত layout, tables, skewed/warped documents ও structured JSON/Markdown output-এর জন্য। মডেল, সংস্করণ, hardware, license এবং Bengali script performance যাচাই না করে একে সরাসরি production default করা যাবে না।
- Engine router document type, language, confidence, available memory/CPU/GPU এবং offline/online preference দেখে প্রথম engine নির্বাচন করবে; low-confidence হলে second engine বা manual review প্রস্তাব করবে।
- OCR-এর জন্য internet/API বাধ্যতামূলক হবে না। Offline mode-এ bundled/locally installed supported models ব্যবহার হবে; optional cloud OCR আলাদা সম্মতি, privacy notice ও explicit opt-in ছাড়া চালু হবে না।
- বড় মডেল ডাউনলোড/লোড করার আগে storage/RAM check, download size, model version, checksum, license, cancellation ও progress দেখাতে হবে। low-memory device-এ ছোট model/low-resolution preview/queue ব্যবহার করতে হবে।
- Bengali Unicode normalization, যুক্তাক্ষর/কার/ফলা, বাংলা ও ইংরেজি মিশ্র লাইন, বাংলা/ইংরেজি/আরবি অঙ্ক, তারিখের একাধিক বিন্যাস, নামের transliteration এবং OCR-এ সাধারণ confusions-এর জন্য locale-aware normalization রাখতে হবে। মূল OCR text অক্ষত রাখতে হবে।
- OCR confidence-কে নিশ্চিত সত্য হিসেবে দেখানো যাবে না। প্রতিটি field-এ confidence/সতর্কতা ও source-page crop থাকবে; user মূল নথির সঙ্গে মিলিয়ে অনুমোদন করতে পারবেন।

### ২৬.৩ Document format support matrix
প্রতি release-এ পরীক্ষিত format matrix প্রকাশ করতে হবে:
- Raster: JPG/JPEG, PNG, WebP, TIFF (multi-page সহ), BMP; HEIC/HEIF support থাকলে platform dependency ও conversion স্পষ্ট করতে হবে।
- PDF: text-based, scanned, mixed, multi-page, rotated, skewed, encrypted/password-protected, malformed; supported/unsupported আচরণ নির্দিষ্ট।
- Office/text: DOCX, ODT, RTF, TXT, CSV, XLSX/ODS—যেখানে প্রযোজ্য text/table extraction; spreadsheet formula ও displayed value আলাদা হলে তা নথিভুক্ত করতে হবে।
- Archive/batch import: ZIP-এর ভিতরের supported file types, size/depth limits, zip-bomb defense, duplicate detection, partial failure report; executable/script কখনো চালানো যাবে না।
- Camera capture: front/back, multiple images, edge crop, glare/blur feedback, retake, page ordering; scanner app থেকে share/import।
- Audio/video বা handwriting-এর মতো জটিল উপাদান default OCR scope নয়; আলাদা transcription/handwriting model ও পৃথক acceptance tests ছাড়া সমর্থিত বলে দাবি করা যাবে না।
- barcode/QR/PDF417 extraction OCR থেকে আলাদা decoder path হবে; decoded payload-কে untrusted input ধরে sanitize করতে হবে। barcode data ও visual OCR-এর মধ্যে conflict থাকলে তুলনা দেখাতে হবে।

## ২৭. নথি-ভিত্তিক তথ্যের নির্ভরযোগ্যতা, প্রমাণ ও দ্বন্দ্ব নিষ্পত্তি
- প্রতিটি extracted field-এর provenance: document ID, page, crop/bounding box, extraction engine/version, confidence, extraction time, reviewer, approval status এবং original raw value।
- একই ব্যক্তির একাধিক নথিতে নাম/জন্মতারিখ/পিতা-মাতা/ঠিকানা/NID ভিন্ন হলে স্বয়ংক্রিয়ভাবে একটি মান বেছে নেওয়া যাবে না; side-by-side conflict queue-তে সব উৎস, তারিখ, document type এবং user decision রাখতে হবে।
- Document authenticity যাচাই করা না গেলে “নথিতে লেখা আছে” এবং “যাচাইকৃত তথ্য” আলাদা status হবে। OCR মানেই সরকারি/আইনি সত্যের প্রমাণ নয়।
- Field-level audit log: কে, কখন, কোন উৎস থেকে, কী পরিবর্তন করল; আগের মান; নতুন মান; revert/undo; merge/split person operation-এর log।
- Duplicate document শনাক্তকরণে hash + perceptual hash + metadata + OCR similarity; একই নথির সামনে/পেছন আলাদা page হিসেবে link করতে হবে, duplicate ব্যক্তি হিসেবে নয়।
- Sensitive document preview-এ masking, download/print permission, retention policy, access log এবং secure deletion policy থাকতে হবে। OCR provider-এ upload হলে আগে consent ও data-transfer disclosure আবশ্যক।
- OCR থেকে পাওয়া সম্ভাব্য ব্যক্তি/আত্মীয়কে স্বয়ংক্রিয়ভাবে family tree-তে link বা save করা যাবে না; candidate match + user approval আবশ্যক।

## ২৮. বংশতালিকার বড় ডেটা ও স্থাপত্য
- Person, relationship, union/marriage, event, address, name-variant, document, source/citation, institution, media এবং account-কে আলাদা normalized entities হিসেবে মডেল করতে হবে; প্রদর্শন-ভিত্তিক duplicate data নয়।
- Relationship edge-এ relation type, biological/adoptive/step/guardian distinction, validity dates, source/evidence, privacy, confidence and status রাখতে হবে।
- Recursive tree traversal-এ cycle detection, maximum depth, bounded query, indexes, pagination/virtualization, branch-only loading এবং cancellation আবশ্যক।
- 100k+ synthetic members-এ full-tree render নয়; selected ancestor/descendant path, immediate relatives, search result and focused branch lazily load করতে হবে।
- Search: normalized Bengali, English, alias, phonetic/transliteration, exact ID/document number (role-gated), partial name, date range, place and relation filters. Sensitive identifiers must not be exposed in general search.
- Offline/local and server mode-এ explicit sync state, conflict resolution, idempotent retry, optimistic UI rollback, version/revision checks, backup/restore and schema migration tests থাকতে হবে।
- performance budgets কেবল target; low-end phone, mid-range phone, laptop, desktop এবং representative large dataset-এ benchmark দিয়ে অনুমোদন করতে হবে। “কোনো সমস্যা হবে না” বাস্তবসম্মত গ্যারান্টি নয়—release blocker, monitoring, recovery ও test coverage দিয়ে ঝুঁকি কমাতে হবে।

## ২৯. UX ও প্রবেশগম্যতার অতিরিক্ত নিয়ম
- “দ্রুত সদস্য যোগ” flow: আগে existing-person search; একবারের সংক্ষিপ্ত form; advanced fields accordion; draft autosave; “তথ্য নেই/জানা নেই” আলাদা; একই তথ্য অন্য সদস্য থেকে reuse করলে source/link বজায় থাকবে।
- long form-এ section progress, unsaved-change warning, inline validation, keyboard navigation, mobile camera/upload, back navigation-safe draft এবং screen-reader labels।
- বাংলা তারিখ/অঙ্ক, Gregorian date, optional local calendar representation; stored canonical date unambiguous হবে।
- responsive design শুধু width নয়: touch target, orientation, memory pressure, reduced motion, network state, input method, font scale এবং platform file-picker differences বিবেচনা করবে।
- Dashboard widgets configurable, reorderable, hide/show; widget click opens relevant detail/list; expensive counts cached/indexed and refreshed safely.
- theme catalog-এর 80/112/116 সংখ্যার বিরোধ code registry ও theme spreadsheet audit দিয়ে সমাধান করতে হবে। একই ধরনের theme ID alias/duplicate বাদ দিয়ে final theme count, preview, contrast and screenshot test প্রকাশ করতে হবে।

## ৩০. Security, privacy, recovery ও governance
- Threat model: unauthorized account access, privilege escalation, malicious uploads, archive/ZIP bombs, XSS in imported text, SQL/NoSQL injection, path traversal, document leakage, backup theft and insecure logs।
- file upload-এ extension + MIME + magic bytes যাচাই, file size/page/pixel limits, decompression limits, malware scanning where available, isolated parser process, safe filenames and no execution।
- role checks server-side; UI hide করলেই authorization সম্পন্ন নয়। Co-Admin exclusions server-side tests দিয়ে নিশ্চিত করতে হবে।
- encryption in transit and at rest where supported, least privilege, session expiry, password hashing, account recovery abuse protection, export audit and revocation.
- backup restore rehearsal, interrupted import recovery, disk-full handling, corrupt database recovery, rollback migration, export checksum and disaster-recovery runbook release gate হবে।
- privacy-by-default: living persons’ sensitive data restricted; user-configurable consent/visibility; public tree export excludes sensitive identifiers and private documents by default.

## ৩১. বাস্তব OCR ও স্কেল বেঞ্চমার্ক—release gate
প্রতিটি release candidate-এ versioned test corpus থাকবে; বাস্তব ব্যক্তিগত নথি ব্যবহার করলে consent, masking ও secure test handling আবশ্যক।
- নথির ধরন অনুযায়ী অন্তত পরিষ্কার, low-resolution, rotated, skewed, glare, faded/old print, mixed Bengali-English, multi-page, front/back, barcode এবং handwriting/unsupported samples।
- OCR metrics: character error rate (CER), word error rate (WER), field-level exact match, field precision/recall, document classification accuracy, confidence calibration, latency, peak RAM, model size, offline success rate।
- আলাদা critical-field metric: নাম, জন্মতারিখ, পিতা/মাতা, document number, ঠিকানা; ভুল critical field কখনো নীরবে auto-save নয়।
- baseline-এর তুলনায় regression threshold, per-engine result, failure examples and known limitations প্রকাশ করতে হবে। aggregate accuracy দিয়ে কোনো বিশেষ document type-এর দুর্বলতা আড়াল করা যাবে না।
- Scalability corpus: 1k, 10k, 100k, এবং 1M synthetic member/relationship graph (শেষ স্তর feasible hardware-এ); profile/search/branch load/save/import/export/backup/restore এবং relationship traversal benchmark।
- Reliability tests: interrupted OCR, browser refresh, app crash, offline transition, sync conflict, duplicate retry, database migration, storage full, memory pressure, malformed files and permission denial।
- Acceptance: critical-field overwrite=0 without approval; duplicate creation on retry=0; saved draft loss=0 in tested crash/recovery scenarios; relation integrity errors=0 in approved fixtures; unsupported inputs show actionable errors rather than crash.
- Performance numbers from v4.0 remain provisional until measured on named reference devices; record device model, OS, RAM, browser, dataset size, cold/warm cache and p50/p95/p99 latency.

## ৩২. বহিরাগত গবেষণা-সূত্র ও কীভাবে ব্যবহার করতে হবে
নিচের উৎসগুলো প্রযুক্তি নির্বাচনের জন্য; এগুলো Bongshokotha-র নিজস্ব code, accuracy বা production readiness প্রমাণ করে না।

1. **PaddleOCR official documentation** — OCR, multilingual document parsing, layout-aware structured output, deployment options and version migration.  
   https://www.paddleocr.ai/main/en/index.html  
   ব্যবহার: OCR pipeline prototype, document-layout parsing, CPU/edge/server model comparison; Bengali language coverage ও offline packaging আলাদাভাবে যাচাই।
2. **PaddleOCR 3.0 technical report** — architecture, recognition/parsing, deployment and evaluation background.  
   https://arxiv.org/abs/2507.05595  
   ব্যবহার: design review ও reproducible benchmark planning; reported benchmark সরাসরি নিজের data-তে expected accuracy ধরে নেওয়া যাবে না।
3. **Tesseract OCR official repository/documentation** — baseline OCR engine, language data and local execution.  
   https://github.com/tesseract-ocr/tesseract  
   ব্যবহার: offline Bengali+English baseline, model licensing/version pinning, known-language support verification।
4. **OCRmyPDF language documentation** — language packs and multi-page PDF OCR workflow.  
   https://ocrmypdf.readthedocs.io/en/latest/languages.html  
   ব্যবহার: scanned PDF preprocessing/searchable text-layer option; structured genealogy field extraction-এর বিকল্প নয়।
5. **W3C WCAG 2.2** — accessibility guidance for contrast, keyboard access, focus, target size and robust interaction.  
   https://www.w3.org/TR/WCAG22/  
   ব্যবহার: UI acceptance checklist; WCAG compliance দাবি করতে actual audit দরকার।
6. **OWASP File Upload Cheat Sheet** — upload validation, limits, safe storage and malicious-file risks.  
   https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html  
   ব্যবহার: document/archive import threat model and security tests.
7. **OWASP Application Security Verification Standard (ASVS)** — verifiable application-security controls.  
   https://owasp.org/www-project-application-security-verification-standard/  
   ব্যবহার: role, authentication, input handling, logging and session-security release checklist.
8. **SQLite documentation: limits and query planning** — embedded/offline database limits and query/index analysis.  
   https://www.sqlite.org/limits.html  
   https://www.sqlite.org/queryplanner.html  
   ব্যবহার: offline/local data store sizing and indexed-query verification if SQLite is selected; database choice must follow workload tests.
9. **PostgreSQL documentation: indexes and recursive queries** — server database query/index design and recursive relationship traversal.  
   https://www.postgresql.org/docs/current/indexes.html  
   https://www.postgresql.org/docs/current/queries-with.html  
   ব্যবহার: server-scale architecture option; not a requirement to adopt PostgreSQL without benchmarking.
10. **Unicode Normalization, Unicode Standard Annex #15** — stable handling of equivalent Unicode sequences.  
    https://unicode.org/reports/tr15/  
    ব্যবহার: Bengali text normalization/search deduplication; normalization must not erase original OCR/source text.

## ৩৩. সিদ্ধান্ত-রেজিস্টার: অনুমানকে requirement হিসেবে চালু করা যাবে না
- **OCR model:** Tesseract baseline; PaddleOCR/other engine must pass Bengali-specific corpus, offline, licensing, RAM and latency gates before selection.
- **“সব document” support:** universal intake/format plugins are required; universal perfect extraction is not promised. Each format has explicit tested/partial/unsupported status.
- **Database:** choose after measuring local/offline requirements, server sync, graph queries, expected scale, backup and migration.
- **Theme count:** 80/112/116 discrepancy remains open until spreadsheet and code registry reconciliation.
- **Performance thresholds:** provisional until tested on named devices and datasets.
- **Legal identity data:** OCR output is transcription, not official validation; external government lookup is not required for offline operation.
- **Handwriting, audio/video, unusual scripts, encrypted documents:** opt-in/phase-specific scope, not silently represented as supported.

## ৩৪. Traceability and handoff requirements
প্রতিটি requirement-এর জন্য এক সারিতে রাখতে হবে: `REQ-ID`, priority, user story, UI screen, data model, API/service, implementation file/commit, automated test ID, manual test steps, device/dataset, evidence artifact, known limitation, release status।
- Status vocabulary: `Not started`, `In progress`, `Implemented—unverified`, `Tested—passed`, `Blocked`, `Deferred`.
- কোনো feature কেবল তখনই `Tested—passed` হবে যখন code reference, reproducible test result এবং প্রাসঙ্গিক screenshot/log/benchmark artifact আছে।
- Handoff package-এ architecture decision records, ER diagram, relationship rules, OCR engine/model manifest, supported-format matrix, privacy/security threat model, benchmark report, migration plan, backup restore evidence, known-bugs list and release checklist থাকতে হবে।
- এই specification নিজে বাস্তবায়ন, OCR accuracy, zero-crash, unlimited scale বা সব ডিভাইসে সমান performance প্রমাণ করে না; সেই প্রমাণ source code ও পরীক্ষার মাধ্যমে দিতে হবে।
