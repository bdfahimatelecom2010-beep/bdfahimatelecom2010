# বংশকথা প্রফেশনাল ১.০.০ — অনুমোদিত মাস্টার সিদ্ধান্ত ও কাজের তালিকা

**অবস্থা:** ব্যবহারকারীর অনুমোদিত চাহিদা/স্পেসিফিকেশন। এটি ফিচার সম্পন্ন হওয়ার প্রমাণ নয়।  
**কোড বেসলাইন:** অন্তর্ভুক্ত অ্যাপ সোর্সটি পূর্ববর্তী `15.5.7` প্যাকেজ থেকে নেওয়া।  
**লক্ষ্য:** সব অনুমোদিত শর্ত বাস্তবায়ন, পরীক্ষা ও প্রমাণসহ যাচাই করে তবেই 1.0.0 রিলিজ ঘোষণা।

## বাধ্যতামূলক নিয়ম
1. কোনো অনুমোদিত ফিল্ড, ডাটা, সম্পর্ক বা ফিচার নীরবে বাদ দেওয়া যাবে না।
2. নতুন করে বানানোর আগে বিদ্যমান ফিচার যাচাই করতে হবে।
3. OCR/AI-এর অনুমান মানুষের অনুমোদন ছাড়া মূল বংশতথ্য বদলাবে না।
4. অনিশ্চিত বা পরস্পরবিরোধী তথ্য মুছে না দিয়ে উৎস ও দ্বন্দ্ব সংরক্ষণ করতে হবে।
5. প্রত্যেক আইটেমের বাস্তব অবস্থা `সম্পন্ন`, `আংশিক`, `অসম্পন্ন`, `পরীক্ষা হয়নি`—এর একটি হবে; প্রমাণ ছাড়া `সম্পন্ন` নয়।
6. সোর্স-প্যাটার্ন টেস্ট, production build, browser E2E এবং বাস্তব ডিভাইস পরীক্ষা আলাদা করে রিপোর্ট করতে হবে।

## ১–২৩: ব্যবহারকারীর অনুমোদিত মূল তালিকা

1. **সদস্য ফর্ম ও সফটওয়্যার উন্নয়ন:** আগের সব ফিল্ড ও কার্যকারিতা বজায় রেখে আধুনিক, কমপ্যাক্ট UI; save/edit/reload স্থায়িত্ব; সম্পর্ক, OCR, ব্যাকআপ, role ও নিরাপত্তা উন্নয়ন।
2. **স্মার্ট সদস্য ফর্ম:** সব পুরোনো ফিল্ড অক্ষুণ্ণ; কেবল বিন্যাস ছোট, পরিষ্কার ও responsive। সদস্যের ধরন শুধু `জন্মসূত্রে`, `বিবাহসূত্রে`, `দত্তকসূত্রে`; জীবনাবস্থা/বৈবাহিক অবস্থা আলাদা ফিল্ড।
3. **মূল বংশতালিকা ও প্রজন্ম:** কমপ্যাক্ট সদস্য কার্ড, প্রজন্মভিত্তিক সাজানো, সম্পর্কের সংযোগরেখা, প্রোফাইলে যাওয়া, বড় গাছে কর্মক্ষমতা।
4. **ড্যাশবোর্ড ও মেনু:** সদস্য/প্রজন্ম/জীবনাবস্থা/সাম্প্রতিক কার্যক্রম/আর্কাইভ/ব্যাকআপ তথ্য; প্রতিটি উইজেট Settings থেকে ON/OFF এবং বিন্যাস নিয়ন্ত্রণ।
5. **অনুসন্ধান ও ফিল্টার:** নাম, ডাকনাম, জন্মক্রমিক নম্বর, প্রজন্ম, ঠিকানা, লিঙ্গ, জীবনাবস্থা, বৈবাহিক অবস্থা ও সম্পর্ক।
6. **সম্পর্ক নির্ভুলতা:** বাবা-মা/সন্তান, ভাইবোন, দাদা-দাদি/নানা-নানি, বহু বিবাহ, বিয়েভিত্তিক সন্তান, দত্তক, বিবাহসূত্রে আসা সদস্য, ইন-লিংক; চক্র/ডুপ্লিকেট/ভাঙা লিংক শনাক্ত।
7. **ডাটা সংরক্ষণ ও পুনরুদ্ধার:** স্থায়ী ডাটাবেস; refresh/restart-এ ডাটা অক্ষত; আসল ডাটার জায়গায় demo data auto-load নয়; restore পরীক্ষা।
8. **ইমপোর্ট/এক্সপোর্ট/ব্যাকআপ:** JSON/CSV/GEDCOM ও স্পষ্টভাবে ঘোষিত ফরম্যাট; ডুপ্লিকেট/ত্রুটিপূর্ণ ডাটা যাচাই; restore preview ও rollback।
9. **ডকুমেন্ট/OCR/Family Archive:** মূল নথি সংরক্ষণ; OCR ফলাফল দৃশ্যমান; ব্যবহারকারী review/edit/accept করার পরই প্রোফাইলে প্রয়োগ।
10. **অ্যাকাউন্ট/রোল/নিরাপত্তা:** নিজের অ্যাকাউন্ট বংশতথ্য থেকে পৃথক; Owner, Super Admin, Admin, Co-Admin, Tester, Editor, Contributor, Viewer অনুমতি পরীক্ষা; Co-Admin Gmail backup, server management ও সম্পূর্ণ বংশ মুছতে পারবে না।
11. **পূর্ণ ঠিকানা ডিকশনারি:** যাচাইকৃত দেশ/প্রশাসনিক স্তর, cascading selection, বাংলা/English, পুরোনো ঠিকানার সামঞ্জস্য; অসম্পূর্ণ ডেটাকে পূর্ণাঙ্গ বলে দাবি নয়।
12. **সার্ভার/সিঙ্ক/Gmail ব্যাকআপ:** অনুমোদিত server registry, নিরাপদ login/sync, conflict handling, provider credentials ও permission পরীক্ষা।
13. **থিম/ভাষা/আন্তর্জাতিক সেটিংস:** ১১২টি স্বতন্ত্র theme ID-এর পরিকল্পনা, বাংলা/English, তারিখ/সময়/সংখ্যা ফরম্যাট।
14. **সামাজিক যোগাযোগ:** অনুমোদিত সদস্যদের text/image/audio; ভিডিও/লাইভ কল নয়; privacy/report/moderation।
15. **আপডেট/rollback:** trusted source, version/integrity checks, backup-before-update, failure rollback; app update ও address-data update পৃথক।
16. **চূড়ান্ত পরীক্ষা:** Windows, Android, browser, persistence, relations, roles, OCR, backup, import/export, performance/security; PASS/FAIL/NOT RUN প্রমাণসহ।
17. **পুরোনো ডাটা/APK/ZIP স্থানান্তর:** মূল ফাইল অক্ষত রেখে পরীক্ষামূলক import; সদস্য/সম্পর্ক/নথি মিলিয়ে অনুমোদিত migration।
18. **বংশবই/প্রিন্ট:** বাংলা-সমর্থিত PDF, print preview, পুরো বংশ/নির্বাচিত শাখা বা প্রজন্মের রিপোর্ট।
19. **পরিবর্তনের ইতিহাস:** actor/time/field-level audit log, প্রয়োজনীয় Undo ও নিরাপদ recovery।
20. **গোপনীয়তা:** ব্যক্তিগত নথি, ছবি, যোগাযোগ ও পোস্টের role/permission-based access এবং লগ।
21. **গ্রহণযোগ্যতার মানদণ্ড:** বাস্তব end-to-end test ছাড়া complete ঘোষণা নয়।
22. **অফলাইন/অনলাইন:** কোন কাজ offline চলে, কোনটিতে server লাগে, pending save ও sync conflict স্পষ্ট।
23. **রিলিজ/সংস্করণ:** migration-safe updates, backup/restore, release checklist ও পরিচিত ত্রুটির নথি।

## ২৪–৩৪: ব্যবহারকারীর অনুমোদিত অতিরিক্ত যাচাই

24. **ব্যক্তি/পরিবার/পরিচয়ের কাঠামো:** স্থায়ী Person ID; ব্যক্তি একাধিক Family-তে যুক্ত হতে পারেন; cross-family link-এ সংশ্লিষ্ট দুই Owner-এর অনুমোদন; Root/branch governance ও history।
25. **প্রমাণ/অনিশ্চয়তা:** biological/adoptive/step/guardian/legal/unknown/disputed relation; অজানা তথ্য স্পষ্ট; conflicting evidence সংরক্ষণ; AI/OCR ফল মানব-যাচাই ছাড়া canonical নয়।
26. **উন্নত বংশগাছ ও আন্তর্জাতিক numbering:** ancestor/descendant/branch/fan/hourglass/compact/vertical/horizontal views; zoom/pan/expand; Ahnentafel ও d’Aboville derived numbering; PNG/PDF/print যাচাই।
27. **জন্মক্রম/প্রজন্ম/শাখা:** জন্মতারিখ/সময়, authorized manual rank ও stable tie-break; root/parent change-এ recalculation; circular ancestry প্রতিরোধ।
28. **জীবন ও পারিবারিক ইতিহাস:** একাধিক education/career/residence record, biography, events, achievements, oral/audio history, death information ও evidence; অজানা তথ্য অনুমান নয়।
29. **Household/মানচিত্র:** বসবাসের পরিবার-দৃশ্য genealogy relation থেকে পৃথক; birth/current/permanent/death place পৃথক; location privacy ও uncertainty support।
30. **Delete/Undo/Merge/Restore:** soft delete, recycle bin, preview, authorization, relationship/document preservation, transactional merge এবং recoverable failure।
31. **Offline/sync:** pending state, network failure, concurrent edit conflict, identity/link preservation, truthful sync status।
32. **Accessibility/usability:** Bengali font, contrast, keyboard navigation, responsive forms, clear validation/errors, large-tree performance measurement।
33. **Release evidence/licensing:** dependencies/fonts/OCR data licences, supported formats, update/migration instructions, known issues, test evidence and limitations।
34. **চূড়ান্ত প্রমাণভিত্তিক অডিট:** প্রতিটি requirement-এ status + test evidence; source tests, typecheck/build, browser E2E, Android/Windows device tests পৃথক রিপোর্ট; known bugs পুনরায় যাচাই।

## বিশেষ সম্পর্ক ও ডাটা নীতি
- Relationship records names নয়, stable Person IDs/UUIDs দিয়ে link হবে।
- Parent-child, spouse/marriage, siblings, grandparents, generations, branches, statistics and exports canonical graph থেকে derive হবে।
- একই ব্যক্তির একাধিক বিবাহের সন্তান ভুল করে অন্য বিবাহে দেখানো যাবে না।
- বিবাহসূত্রে যুক্ত ব্যক্তির জন্ম-পিতা-মাতা সংরক্ষণ করা যাবে, কিন্তু অনুমতি ছাড়া primary family-র birth-line member হয়ে যাবেন না।
- Root = Generation 1; spouse/marriage-origin ব্যক্তি সাধারণত birth-line spouse-এর একই generation-এ দেখাবেন, কিন্তু blood descendant হিসেবে গণনা হবেন না।
- জন্মক্রমে creation date প্রকৃত birth order-এর বিকল্প নয়।
- Same name alone duplicate বা merge করার যথেষ্ট প্রমাণ নয়।
- Gmail backup, server management, genealogy-wide deletion-এর মতো privileged actions backend-এ enforce করতে হবে; শুধু UI hide যথেষ্ট নয়।

## এই প্যাকেজে থাকা ডকুমেন্ট
- `MASTER-REQUIREMENTS-DETAILED-BN.md`: বিস্তারিত মাস্টার গ্রহণযোগ্যতা তালিকা।
- `LIST-2-SMART-MEMBER-FORM-BN.md`: অনুমোদিত স্মার্ট সদস্য ফর্মের নিয়ম।
- `IMPLEMENTATION-PLAN-V1.0.0-BN.md`: non-member-form implementation plan।
- `112-UNIQUE-THEME-IDS.csv/.xlsx`: থিম ID রেফারেন্স।
- `SYSTEM-DICTIONARY-DRAFT.json`: খসড়া ডিকশনারি schema/seed; পূর্ণ যাচাইকৃত বাংলাদেশ ঠিকানা ডেটাসেট নয়।

## বর্তমান অবস্থা সম্পর্কে সতর্কতা
এই ZIP-এর অ্যাপ সোর্স পূর্ববর্তী `15.5.7` baseline থেকে নেওয়া। 1.0.0-এর সব ১–৩৪ শর্ত বাস্তবায়িত বা runtime-এ পরীক্ষিত—এমন দাবি করা হচ্ছে না। পুরোনো রিপোর্টে full TypeScript/build ও browser E2E অনিষ্পন্ন বলা আছে। লক্ষ্য কম্পিউটারে dependency install, OCR preparation, verify, build এবং বাস্তব ডিভাইস পরীক্ষা চালিয়ে status update করতে হবে।
