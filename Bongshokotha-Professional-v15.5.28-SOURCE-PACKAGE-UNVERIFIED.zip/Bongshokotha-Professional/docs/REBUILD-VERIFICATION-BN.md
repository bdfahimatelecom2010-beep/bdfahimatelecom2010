# পুনর্গঠন ও যাচাই রিপোর্ট — v15.5.11

তারিখ: 2026-10-13

## প্যাকেজে রাখা হয়েছে
- v5.0 master requirements এবং requirement-to-source map
- smart member form, canonical relationships/generation, marriage details, alternate name provenance
- structured address fields, online administrative catalog cache, saved-family-address offline suggestions
- OCR/document archive modules and local Bangla/English Tesseract assets
- dashboard/theme/settings/account-role modules and Windows/Android build scripts

## এই পরিবেশে চালানো source-level checks
নিচের স্ক্রিপ্টগুলো সফল হয়েছে:
- `smart-member-form-regression-test.mjs`: 10/10
- `member-address-form-regression-test.mjs`: 16/16
- `relationship-canonical-regression-test.mjs`: canonical rules + safety extensions pass
- `profile-document-archive-regression-test.mjs`: pass
- `universal-ocr-regression-test.mjs`: 10/10
- `dashboard-regression-test.mjs`: 15/15
- `alternate-name-source-regression-test.mjs`: 5/5
- `marriage-details-regression-test.mjs`: 7/7
- `account-role-regression-test.mjs`: 17/17
- `account-recovery-regression-test.mjs`: 8/8
- `dashboard-regression-test.mjs`: 15/15
- `device-adaptation-regression-test.mjs`: 11/11
- `device-permissions-regression-test.mjs`: 12/12
- `theme-regression-test.mjs`: 116 unique themes
- `ui-theme-runtime-regression-test.mjs`: 12/12
- `relationship-ui-regression-test.mjs`: 18 contracts
- `profile-lineage-regression-test.mjs`: 12/12
- `final-requirements-regression-test.mjs`: 11/11
- `child-document-deep-regression-test.mjs`: 11/11
- `ocr-parser-regression-test.mjs`: 10/10
- `nid-ocr-runtime-regression-test.mjs`: 11/11
- `universal-ocr-runtime-regression-test.mjs`: 21/21
- `consistency-audit.mjs`: 8/8
- `version-consistency-audit.mjs`: PASS (`15.5.11`)
- `deep-integration-audit.mjs`: 22/22
- `master-audit.mjs`: 47/47
- `requirements-pack-audit.mjs`: 11 required artifacts found
- অন্যান্য চালানো source regression/audit স্ক্রিপ্টের অধিকাংশও পাস করেছে; সবকিছু পাস করেছে এমন দাবি করা হচ্ছে না।

## এখনও নিশ্চিত নয়
- Dependency install timeout হওয়ায় `tsc --noEmit` ও Vite production build চালানো যায়নি।
- পূর্ণ `npm run verify` chain চালানো হয়নি।
- Browser end-to-end, Windows EXE, Android APK, বাস্তব ডিভাইস এবং low-memory device পরীক্ষা হয়নি।
- OCR accuracy-র জন্য representative NID/জন্মনিবন্ধন/পাসপোর্ট corpus দিয়ে precision/recall মাপা হয়নি; 100% OCR দাবি করা যায় না।
- বাংলাদেশের প্রতিটি গ্রাম/ডাকঘর/পোস্টকোডের পূর্ণাঙ্গ offline address dictionary এই প্যাকেজে প্রমাণিত নয়। বর্তমানে structured selectors, fetched catalog cache এবং আগে-সংরক্ষিত ঠিকানার offline suggestions আছে।
- Social-media live publishing/login integrations provider credentials, API scopes ও security tests ছাড়া সম্পন্ন বলা যাবে না।
- Master v5.0-এ থাকা সব acceptance gate পাস হয়েছে বলা যাবে না; `docs/V5.0-INTEGRATION-STATUS-BN.md`-এর gaps প্রযোজ্য।

## পরবর্তী বাধ্যতামূলক release gate
1. Clean `npm.cmd install`
2. `npm.cmd run typecheck`
3. `npm.cmd run requirements:pack-audit`
4. `npm.cmd run verify`
5. Production build ও browser E2E
6. Windows/Android package + real-device tests
7. OCR sample matrix ও address catalog coverage/license audit
8. Backup/restore + real family dataset integrity test


## v15.5.11 অতিরিক্ত সংশোধন
- সামাজিক মাধ্যম ও শেয়ার পেজ যোগ হয়েছে: Facebook, X, WhatsApp, Telegram, Email, ডিভাইসের Web Share এবং Copy text।
- শেয়ার কনটেন্টে ব্যক্তিগত সদস্যের তথ্য স্বয়ংক্রিয়ভাবে যুক্ত হয় না; গোপনীয়তার সতর্কতা যোগ করা হয়েছে।
- `social-sharing-regression-test.mjs`-এ ১০টি সোর্স-লেভেল চেক পাস।
- পূর্ণ TypeScript/production build এখনও যাচাই করা যায়নি, কারণ dependency installation সময়সীমায় সম্পন্ন হয়নি।
