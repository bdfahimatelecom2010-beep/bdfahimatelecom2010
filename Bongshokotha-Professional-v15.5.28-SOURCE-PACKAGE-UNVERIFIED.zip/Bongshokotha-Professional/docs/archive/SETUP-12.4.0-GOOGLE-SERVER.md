# BONGSHOKOTHA Professional 12.5.0 — Google Account & Server Setup

## Google / Gmail account
- Settings → Synchronization-এ device/browser-এর Google account chooser ব্যবহার করা যায়।
- নির্দিষ্ট Gmail address দিলে সেটি OAuth `login_hint` হিসেবে ব্যবহার করা হয়।
- প্রথম OAuth consent-এর পর প্রথম family backup স্বয়ংক্রিয়ভাবে শুরু হয়।
- পরবর্তী Auto Backup চালু করলে ২৪ ঘণ্টা পরপর backup attempt হয়।
- Backup Google Drive-এর private `appDataFolder`-এ থাকে; Gmail password কখনো অ্যাপের কাছে দেওয়া হয় না।
- Google Web OAuth Client ID (`VITE_GOOGLE_CLIENT_ID`) অবশ্যই Google Cloud Console-এ configure করতে হবে।

## Server list
Settings → Synchronization-এ server list থেকে একটি server-এর URL দিন এবং Login / Connect চাপুন।
- This Computer — Local Server: default `http://localhost:8787`
- Local Network Server: PC/LAN server URL
- Cloud Server 1 / 2: নিজের cloud server URL
- Custom Server: যেকোনো compatible BONGSHOKOTHA sync server

একটি server connected হলে তার endpoint family `syncEndpoint` হিসেবে save হয় এবং Family Share / Join Code / Remote Sync সেটিই ব্যবহার করে।

### Optional server authentication
Self-hosted server-এ `BONGSHOKOTHA_SERVER_TOKEN` environment variable দিলে `/api/*` routes token ছাড়া access হবে না। একই token server profile-এ দিলে client automatic Authorization header পাঠাবে। `/health` monitoring endpoint public থাকে।
