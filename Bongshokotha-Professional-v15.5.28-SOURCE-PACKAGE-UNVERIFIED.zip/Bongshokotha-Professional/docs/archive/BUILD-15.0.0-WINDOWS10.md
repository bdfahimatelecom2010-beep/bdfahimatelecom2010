# Windows 10 PowerShell Build — Bongshokotha 15.1.0

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
Set-Location -LiteralPath "C:\Bongshokotha-Professional"
npm.cmd install
npm.cmd run prepare:ocr
npm.cmd run verify
npm.cmd run desktop:build
```

For Android:

```powershell
npm.cmd run mobile:init
npm.cmd run mobile:build
```

The same source is used for Windows desktop and Android/mobile. If `npm` is blocked by PowerShell execution policy, use `npm.cmd` exactly as above.
