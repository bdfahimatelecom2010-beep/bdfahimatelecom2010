# Windows 10 Build Guide — Bongshokotha Consolidated

Open Windows PowerShell:

```powershell
Set-Location -LiteralPath "C:\Bongshokotha-Professional"
Set-ExecutionPolicy -Scope Process Bypass -Force
npm.cmd install
npm.cmd run verify
npm.cmd run dev
```

For a Windows desktop package after dependencies are installed:

```powershell
npm.cmd run desktop:build
```

For Android debug APK:

```powershell
npm.cmd run mobile:build
```

## Important
- `npm.cmd` is used so Windows PowerShell ExecutionPolicy does not block `npm.ps1`.
- The Bengali and English OCR language models are already included in `public\tessdata`; `npm.cmd run prepare:ocr` validates them and only downloads if a model is genuinely absent.
- Do not run `npm audit fix --force` as a blind step; it can introduce breaking dependency changes. Review dependency advisories before changing versions.
- A successful `verify` source build does not replace camera/document manual smoke tests.
