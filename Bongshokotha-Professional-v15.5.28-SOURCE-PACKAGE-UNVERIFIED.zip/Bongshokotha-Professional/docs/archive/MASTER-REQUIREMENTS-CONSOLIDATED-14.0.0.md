# Consolidated 15.1.0 — Final Addendum

## Dashboard rule (final)
**Family Statistics is not a separate navigation menu.** All practical family-statistics functions are represented as Dashboard widgets. Every Dashboard widget is controlled from Settings and can be individually enabled/disabled, reordered, and displayed in a selected density. Clicking a result opens a compact result list and then the relevant member/tree/archive screen.

## Final profile/card fields
The compact member card and Family Tree card must show, where available: name, generation, father/mother, birth date, death date when deceased, living/deceased state, current age or age at death, photo, occupation, short address, birth/marriage/adoption origin, spouse name when married, and total marriage count. One spouse must never be rendered twice for one marriage record.

## Marriage-origin rule
A member joining through marriage is displayed immediately after the relevant birth-line spouse, with the same generation. The married-in member's own birth-order number remains stored as historical information about the person's birth family; it does not control the person's position in this family.

## Biological parents of a married-in member
The member's own father/mother can be stored and edited in the profile. Those parents are not automatically added as this family's birth-line nodes. If a parent later becomes independently connected to the family through a legitimate birth-line relationship, canonical family visibility may show that parent.

## Offline OCR requirement
English and Bengali Tesseract models are bundled under `public/tessdata/`. After installation, OCR must not require an internet connection to obtain language data. OCR extraction remains review-first: extracted values are shown individually and are applied only when the user selects them. Original documents remain in the Family Archive independently of profile pointers.

## Dashboard widget scope
The dashboard may include key metrics, alerts/data health, generations, demographics, upcoming dates, completeness, branches, age/life profile, recent members, quick tools, marriage status, documents/archive, research/verification health, family milestones, branch highlights and family overview. The registry is extensible, but each widget must have a Settings ON/OFF control.

## Data-quality and research
The final architecture may surface missing parents, missing dates, missing identity data, duplicate candidates, broken relationships, OCR review queues, source/evidence gaps and chronology conflicts without claiming that a completeness percentage equals historical truth.
