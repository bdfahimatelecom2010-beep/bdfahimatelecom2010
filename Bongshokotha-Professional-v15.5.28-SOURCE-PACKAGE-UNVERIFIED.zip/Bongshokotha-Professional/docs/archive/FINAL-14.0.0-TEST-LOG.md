# 14.0.0 Verification Plan / Test Log

This package was assembled after static comparison of the available historical releases. Run the following on Windows after `npm.cmd install` and OCR model preparation:

1. version consistency
2. consistency audit
3. master audit
4. quality contracts
5. theme regression
6. runtime theme regression
7. relationship UI regression
8. canonical relationship regression
9. generation + canonical ordering
10. member color regression
11. age regression
12. member data integrity
13. profile document/archive regression
14. profile lineage regression
15. dashboard regression + short result list
16. family visibility regression
17. OCR parser source regression
18. OCR field runtime regression
19. deep integration audit
20. TypeScript noEmit
21. production Vite build
22. Windows desktop packaging
23. Android debug build
24. fresh-profile manual smoke test
25. OCR NID/BRN/Passport/DOB manual test
26. married-in parent-data manual test
27. child-list edit/persistence manual test
28. dashboard Settings ON/OFF/order persistence manual test
29. archive unlink-without-delete manual test
30. backup/restore and role-permission manual test

A passing source build is not treated as proof that camera OCR, Windows packaging or Android packaging works until those platform-specific smoke tests are run.
