# Release verification — 15.5.7

## Changes in this correction
- Added separate stored fields for father-in-law and mother-in-law names, independent of whether those people have their own member profile.
- Existing spouse parent names are used as a prefill/fallback when available.
- Profile view renders saved external in-law names.
- Division, district, upazila and union/municipality/city-area fields are cascading dropdowns from a bilingual Bangladesh administrative catalogue, cached in local storage after a successful fetch.
- Village, ward, house/holding, road, post office and postal code remain separate details. Post office and postal-code controls are not claimed to be a complete official national list.

## Checks performed
- In-law/address source regression: 10/10 PASS.
- Existing in-law/OCR profile source regression: 13/13 PASS.
- Existing address form source regression: 16/16 PASS.
- Version consistency audit: 4/4 PASS.
- ZIP integrity: to be checked after packaging.

## Not verified
- Full TypeScript typecheck and production build could not be completed because dependencies are not installed in this environment (`vite/client` and React types are unavailable). The target Windows machine must run `npm.cmd install`, then `npm.cmd run verify` and `npm.cmd run build`.
- Browser end-to-end test was not run here.
- The administrative catalogue is fetched on first use and cached locally; initial internet access is required if no cache exists. The online dataset is community-maintained and should be checked against current official sources for critical/legal use.
