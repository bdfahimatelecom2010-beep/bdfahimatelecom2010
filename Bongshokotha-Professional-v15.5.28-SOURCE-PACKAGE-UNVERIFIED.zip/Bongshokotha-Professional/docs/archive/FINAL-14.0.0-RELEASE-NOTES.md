# BONGSHOKOTHA Professional 14.0.0

## Consolidation
- Rebuilt from the latest clean master source while reviewing all available historical Bongshokotha ZIPs and the supplied Windows EXE reference.
- Old release clutter is excluded from the final package.

## Critical fixes strengthened
- OCR field parser separated from OCR worker runtime.
- Label-bound NID/BRN extraction with Bengali/Arabic digit normalization.
- Passport label and MRZ extraction.
- English name and full DOB extraction.
- PDF first-page local rendering before OCR.
- Per-field OCR selection before profile apply.
- Local Tesseract Bengali/English model preparation for offline runtime.
- Canonical marriage-origin spouse ordering and family visibility.
- Member edit persistence and child/parent relationship synchronization.
- Current age and age-at-death presentation.
- Dashboard widget visibility/order/layout persisted through Settings.
- Family Statistics kept inside Dashboard; no separate Family Statistics menu.
- Family Archive keeps canonical documents even when profile attachments are removed.

## Build quality
The release includes source-level regression, runtime OCR field regression, deep integration audit, TypeScript check and production build commands. Windows-specific packaging still needs to be executed on Windows 10/11.
