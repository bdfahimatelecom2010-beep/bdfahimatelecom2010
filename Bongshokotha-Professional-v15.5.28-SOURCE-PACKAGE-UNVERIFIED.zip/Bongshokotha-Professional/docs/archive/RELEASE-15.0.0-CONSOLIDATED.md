# BONGSHOKOTHA Professional 15.1.0 — Consolidated Build

This release is the clean continuation of the 14.0.0 consolidated source. It is intended to be unpacked on Windows 10 and built from PowerShell into the same application for desktop and Android/mobile.

## Consolidation policy
- The newest consolidated source is the implementation base.
- Earlier ZIPs are historical evidence; older source is not blindly overlaid because doing so can reintroduce fixed defects.
- Items found only in historical releases are recorded in the legacy review rather than silently reactivated.
- No real family member/demo person is required in a fresh installation.

## Functional priorities preserved
- permanent internal Person ID, never used as a visible serial number
- birth order controls sibling ordering, not save time
- generation is relationship-derived with manual override where supported
- marriage-origin/in-law members are displayed after the birth-line spouse
- biological parents of an in-married person remain lineage information and are not automatically added to the spouse's birth-line
- multiple marriages and union-specific children
- two-way relationship persistence
- organized single-page member profile
- separate NID, birth registration and passport fields
- documents can be added later and are archived canonically
- Bengali + English OCR with review before applying extracted fields
- Family Archive remains independent of profile attachments
- Dashboard contains the statistics widgets; no separate Family Statistics menu
- Dashboard widgets are configurable from Settings
- theme system is centralized and responsive
- import/export validates before changing family data
- reset does not delete family data
- backup/restore, recycle-bin and integrity checks
- offline-first operation with optional server/cloud synchronization
- Windows desktop and Android build paths from the same source

## Verification note
Source-level consolidation audits and ZIP integrity are performed before handoff. A true Windows 10 Electron installer build and Android Gradle build require the user's Windows/Android toolchain and are therefore not claimed as executed inside this Linux packaging environment.
