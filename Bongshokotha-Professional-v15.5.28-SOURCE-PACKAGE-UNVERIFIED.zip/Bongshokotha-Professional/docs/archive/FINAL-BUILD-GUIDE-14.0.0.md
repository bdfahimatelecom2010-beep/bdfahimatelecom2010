# Windows 10 PowerShell Build Guide — BONGSHOKOTHA 14.0.0

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
Set-Location -LiteralPath "C:\Bongshokotha-Professional"
npm.cmd install
npm.cmd run prepare:ocr
npm.cmd run verify
```

## Development
```powershell
npm.cmd run dev
```

## Windows desktop
```powershell
npm.cmd run desktop:build
```

## Android/mobile
```powershell
npm.cmd run mobile:init
npm.cmd run mobile:build
```

## Individual verification
```powershell
npm.cmd run audit:version
npm.cmd run ocr:test
npm.cmd run ocr:runtime:test
npm.cmd run deep:audit
npm.cmd run typecheck
npm.cmd run build
```

If PowerShell blocks `npm.ps1`, use `npm.cmd` exactly as above.
