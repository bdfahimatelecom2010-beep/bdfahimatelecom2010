# BONGSHOKOTHA Professional 11.0.4 — Consolidated Feature Matrix

Reference inputs: APK reference build, prior Ultimate/V4 source, Admin/Role merge notes, generation fixes, and the requested member-profile specification.

## Admin & Roles (Owner-only)
- Admin Dashboard
- User & Collaborator
- Role Management
- Role Menu Management
- Permission Management
- Gmail/Cloud Backup & Share
- Server & Sync controls
- Contributor Proposals
- Data Integrity & Repair
- Audit & Activity Log

## Access
- Login/access gate
- Owner-only Admin sidebar
- Non-owner Role Menu filtering
- Six roles: Owner, Super Admin, Admin, Editor, Contributor, Viewer

## Member Profile canonical order
1. Photo
2. Name / Full Name / English Name / Nickname
3. Gender
4. Born-in-family / Joined-by-marriage origin
5. Birth date / birthplace
6. Death status / death date / burial information
7. Marital status
8. Generation
9. Birth Order
10. Family Branch
11. Father / Mother
12. Paternal Grandfather / Grandmother
13. Maternal Grandfather / Grandmother
14. Spouse(s) / marriage history
15. Children grouped by son / daughter / other and sorted by Birth Order
16. Profession / education
17. Mobile / email
18. Current / permanent location
19. NID / Birth Certificate / Passport / other identity records
20. Member photos / uploaded documents / scanned archive records
21. Biography / important information / family history / memorial memories

## Generation rules
- Parent generation + 1 = child generation.
- A spouse who joined by marriage shares the family member's generation even if their biological parents are stored.
- Explicit grandparents can recover an incomplete parent generation.
- Marriage-record child links participate in generation calculation and Profile child display.

## Sharing
- Family share package JSON export
- Web Share API when available
- Download fallback
- Import/export foundation retained

## Documents & OCR
- Profile photo upload
- Profile document upload
- NID and Birth Registration are distinct identity fields
- Document scanner/OCR retained
- Archive records can remain linked to member profiles
