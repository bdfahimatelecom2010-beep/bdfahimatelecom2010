# Final Verification Matrix

## Automated source checks
1. Version consistency
2. Consistency audit
3. Master requirements audit
4. Quality contracts
5. Theme regression/runtime theme regression
6. Relationship UI/canonical regression
7. Generation/canonical order regression
8. Member color regression
9. Age regression
10. Member data integrity
11. Profile document/archive regression
12. Profile lineage regression
13. Dashboard + short-result-list regression
14. Family visibility regression
15. OCR parser/runtime regression
16. EXE reference regression
17. Profile form regression
18. Integrated release audit
19. Deep integration audit
20. TypeScript noEmit
21. Vite production build

## Manual acceptance tests
- Fresh family creation and login by phone/email
- Owner/Admin/Editor/Contributor/Viewer menu visibility
- Owner-only Admin/Server controls
- Child added during member edit appears immediately
- Late parent assignment reorders the member with siblings by birth order
- Married-in member appears immediately after spouse, never before spouse
- Married-in parents remain profile-only unless independently connected
- Multiple marriages and union-specific children
- Current age and age-at-death
- Compact card shows the required fields and one spouse only
- NID/BRN/Passport OCR field-by-field review and apply
- Passport label + MRZ
- Bengali + English name and DOB extraction
- PDF OCR locally
- Original document remains in archive after profile unlink/delete
- Dashboard widget ON/OFF/order persistence from Settings
- Dashboard result click opens compact list
- Gmail recovery address and private backup workflow
- Server registry select/connect/health status
- Succession 1–5 and candidate-death warning
- Export/import and safe restore
- Windows desktop build
- Android debug build
- Small/medium/large phone layouts
- Offline OCR after installation with network disabled
