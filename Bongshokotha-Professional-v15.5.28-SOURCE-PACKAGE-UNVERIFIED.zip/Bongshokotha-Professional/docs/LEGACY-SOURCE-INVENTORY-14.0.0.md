# Legacy Source Inventory — 14.0.0

Analyzed ZIP archives: **34**

Legacy EXE reference: `Bongshokotha-1.0.0-32bit-Setup.exe` (SHA-256: `bf2c18462d847fdfe89a01cd3cc08b36de8d0f8eb69b697dcf0bca9a4a24a236`)

## Decision

The new package uses the latest 13.2 source as the clean implementation base, then restores/strengthens useful capabilities found in earlier releases. Old release ZIPs are **not** copied into the final source package.

## Archive inventory

- `BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip` — 144 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.2-SELF-BUILD-MASTER.zip` — 150 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip` — 150 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.4-MASTER-REPAIRED.zip` — 153 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.5-MASTER-REPAIRED.zip` — 155 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.6-MASTER-OCR-REPAIRED.zip` — 157 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip` — 152 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.7-MARRIAGE-ORIGIN-PARENT-FIXED.zip` — 153 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.8-CLEAN.zip` — 110 files
- `BONGSHOKOTHA-PROFESSIONAL-12.7.8-MARRIAGE-ORIGIN-FULL-FIXED.zip` — 151 files
- `BONGSHOKOTHA-PROFESSIONAL-12.8.0-FINAL-MASTER.zip` — 107 files
- `BONGSHOKOTHA-PROFESSIONAL-12.8.1-REPAIRED-FINAL.zip` — 105 files
- `BONGSHOKOTHA-PROFESSIONAL-12.8.2-FINAL-FIXED.zip` — 105 files
- `BONGSHOKOTHA-PROFESSIONAL-12.8.2-FULL-TESTED.zip` — 106 files
- `BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip` — 122 files
- `BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip` — 122 files
- `BONGSHOKOTHA-PROFESSIONAL-13.0.1-FINAL-MASTER.zip` — 123 files
- `BONGSHOKOTHA-PROFESSIONAL-13.1.0-FINAL-MASTER.zip` — 114 files
- `BONGSHOKOTHA-PROFESSIONAL-13.2.0-FINAL-MASTER.zip` — 114 files
- `BONGSHOKOTHA-PROFESSIONAL-ULTIMATE-11.0.0-V4-FINAL-FAMILY-FIXED.zip` — 70 files
- `Bongshokotha-Professional-2.1.1-Fixed.zip` — 61 files
- `Bongshokotha-Professional-2.2.0-Final.zip` — 61 files
- `Bongshokotha-Professional-2.2.1-Dependency-Fixed.zip` — 60 files
- `Bongshokotha-Professional-2.3.0-Final.zip` — 61 files
- `Bongshokotha-Professional-2.3.1-Dependency-Fixed(1).zip` — 61 files
- `Bongshokotha-Professional-2.3.2-Remediation-Draft(1).zip` — 63 files
- `Bongshokotha-Professional-2.3.2-Remediation-Draft.zip` — 63 files
- `Bongshokotha-Professional-2.4.0-New-Final.zip` — 60 files
- `Bongshokotha-Professional-2.5.0-Integrated.zip` — 60 files
- `Bongshokotha-Professional-Final-2026.zip` — 60 files
- `Bongshokotha-Professional-Ultimate-11.0.0.zip` — 67 files
- `bongshokotha---বংশকথা.zip` — 59 files
- `bongshokotha-professional(1).zip` — 58 files
- `bongshokotha-professional.zip` — 44 files

## Useful capabilities found outside the latest source tree

- `AUDIT-REPORT-12.7.2.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.8-CLEAN.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `AUDIT-REPORT-12.9.0.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip
- `BUILD-READINESS-11.5.9.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip
- `BUILD-VERIFICATION-12.7.3.txt` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.4-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MASTER-OCR-REPAIRED.zip
- `CHANGELOG-2026-09-26-FAMILY-RELATION-FIX.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.8.0-FINAL-MASTER.zip
- `EXE-REFERENCE-AUDIT-13.0.1.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-13.0.1-FINAL-MASTER.zip
- `FINAL-BUILD-GUIDE-13.0.0.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip
- `FINAL-BUILD-GUIDE-13.0.1.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-13.0.1-FINAL-MASTER.zip
- `FINAL-BUILD-GUIDE-13.1.0.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-13.1.0-FINAL-MASTER.zip
- `FULL-AUDIT-REPORT-11.5.3.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip
- `RELEASE-11.4.3-MEMBER-EDIT-PERSISTENCE.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.2-RELATIONSHIP-CANONICAL-FIX.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.3-FULL-AUDIT-FIXES.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.5-MEMBER-COLOR-RELATION-FIX.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.7-MEMBER-DATA-INTEGRITY-2026-09-29.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.8-BACKUP-INTEGRITY-2026-09-29.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.8-DASHBOARD-EXPANSION-2026-09-29.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.8-INLAW-FAMILY-VISIBILITY-FIX-2026-09-29.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.8-MEMBER-FORM-FIX-2026-09-29.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.9-DASHBOARD-2026-09-29.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-11.5.9-PROFILE-OCR-AND-RELEASE-HARDENING-2026-09-29.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-12.2.0-OCR-GMAIL-SERVER-GENERATION.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-12.3.0-PROFILE-DOCUMENT-OCR-ARCHIVE.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-12.4.0-HD-THEMES-SMART-RESTORE-GOOGLE-SERVER.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-12.6.0-PROFILE-LINEAGE-MERGED.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.1-FINAL-MERGED-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `RELEASE-12.7.4-ADMIN-ORDER-DOCUMENT-REPAIR.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.4-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MASTER-OCR-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.5-MASTER-REPAIRED.zip
- `RELEASE-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIX.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.7-MARRIAGE-ORIGIN-PARENT-FIXED.zip
- `RELEASE-12.7.6-OCR-PROFILE-DOCUMENT-FIX.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.6-MASTER-OCR-REPAIRED.zip
- `RELEASE-12.7.7-MARRIAGE-ORIGIN-PARENT-FIX.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.7-MARRIAGE-ORIGIN-PARENT-FIXED.zip
- `SELF-BUILD-MASTER-MANIFEST-12.7.2.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.8-CLEAN.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip
- `SELF-BUILD-MASTER-MANIFEST-12.8.0.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.8.0-FINAL-MASTER.zip
- `SELF-BUILD-MASTER-MANIFEST-12.8.1.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.8.1-REPAIRED-FINAL.zip
- `SELF-BUILD-MASTER-MANIFEST-12.8.2.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.8.2-FULL-TESTED.zip, BONGSHOKOTHA-PROFESSIONAL-12.8.2-FINAL-FIXED.zip
- `SELF-BUILD-MASTER-MANIFEST-12.9.0.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip
- `VERIFY-11.4.2.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip
- `VERIFY-11.5.10.txt` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip
- `VERIFY-12.8.0.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.8.0-FINAL-MASTER.zip
- `VERIFY-12.8.1.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.8.1-REPAIRED-FINAL.zip
- `VERIFY-12.8.2.md` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.8.2-FULL-TESTED.zip, BONGSHOKOTHA-PROFESSIONAL-12.8.2-FINAL-FIXED.zip
- `VERIFY-THIS-BUILD.txt` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.3-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-13.0.0-FINAL-MASTER.zip
- `WINDOWS-VERIFY-12.7.4.txt` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.4-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MASTER-OCR-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.5-MASTER-REPAIRED.zip
- `docs/INSTALL-WINDOWS.md` — seen in: Bongshokotha-Professional-2.1.1-Fixed.zip
- `docs/WINDOWS-INSTALL.md` — seen in: Bongshokotha-Professional-2.2.0-Final.zip
- `scripts/age-regression-test.mjs` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.8.2-FULL-TESTED.zip, BONGSHOKOTHA-PROFESSIONAL-12.8.1-REPAIRED-FINAL.zip, BONGSHOKOTHA-PROFESSIONAL-12.8.2-FINAL-FIXED.zip
- `scripts/deep-integration-audit.mjs` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip
- `scripts/document-ocr-flow-regression-test.mjs` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.6-MASTER-OCR-REPAIRED.zip
- `scripts/marriage-companion-order-regression-test.mjs` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.6-MASTER-OCR-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.5-MASTER-REPAIRED.zip
- `scripts/member-edit-regression-test.mjs` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.6-MEMBER-EDIT-FAMILY-TREE-FIXED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.7-MARRIAGE-ORIGIN-PARENT-FIXED.zip
- `scripts/member-marriage-origin-regression-test.mjs` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.8-CLEAN.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.8-MARRIAGE-ORIGIN-FULL-FIXED.zip
- `scripts/member-origin-order-regression-test.mjs` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.7.4-MASTER-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.6-MASTER-OCR-REPAIRED.zip, BONGSHOKOTHA-PROFESSIONAL-12.7.5-MASTER-REPAIRED.zip
- `server.ts` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `server/defaultData.ts` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `server/gedcom.ts` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/assets/images/adult_female_portrait_1789911342148.jpg` — seen in: bongshokotha-professional(1).zip
- `src/assets/images/adult_male_portrait_1789911328484.jpg` — seen in: bongshokotha-professional(1).zip
- `src/assets/images/matriarch_portrait_1789911308937.jpg` — seen in: bongshokotha-professional(1).zip
- `src/assets/images/patriarch_portrait_1789911283993.jpg` — seen in: bongshokotha-professional(1).zip
- `src/components/AddDocumentModal.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/AddRelationshipModal.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/AuditLogsView.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/BackupRestoreView.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/DocumentsView.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/FamilyStatisticsView.tsx` — seen in: bongshokotha-professional(1).zip
- `src/components/FanChart.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/GpsAuditModal.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/MissingInformationDashboardModal.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/NewFamilyModal.tsx` — seen in: bongshokotha-professional(1).zip
- `src/components/OCRView.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/PedigreeChart.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/components/TimelineView.tsx` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/engine/ageEngine.ts` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.8.2-FULL-TESTED.zip, BONGSHOKOTHA-PROFESSIONAL-12.8.1-REPAIRED-FINAL.zip, BONGSHOKOTHA-PROFESSIONAL-12.8.2-FINAL-FIXED.zip
- `src/engine/ocrFieldParser.ts` — seen in: BONGSHOKOTHA-PROFESSIONAL-12.9.0-FINAL-INTEGRATED.zip
- `src/lib/gedcomExporter.ts` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip
- `src/utils/safeStorage.ts` — seen in: bongshokotha-professional(1).zip, bongshokotha-professional.zip

## Specifically retained or strengthened

- PDF-to-image OCR pipeline from the 12.9 integration line.
- Separated OCR field parser with stronger label-bound NID/BRN extraction.
- Passport label extraction plus MRZ support.
- Per-field OCR review/apply instead of an all-or-nothing apply action.
- Local Tesseract model preparation for Bengali + English.
- Existing member edit persistence and lineage/generation fixes.
- Marriage-origin spouse canonical ordering and external in-law visibility.
- Dashboard widget registry and Settings-controlled visibility/order/layout.
- Family Archive canonical document linkage and non-destructive profile unlinking.
- Owner/Admin Gmail recovery and server registry architecture.
- Age, member-data, profile-document, lineage, dashboard and family-visibility regression coverage.

## Intentionally not copied

- old release ZIPs, node_modules, build output, duplicate release notes, and stale versioned source folders.
- standalone Family Statistics menu; statistics belong in Dashboard widgets.
- obsolete demo/sample data as the default family state.