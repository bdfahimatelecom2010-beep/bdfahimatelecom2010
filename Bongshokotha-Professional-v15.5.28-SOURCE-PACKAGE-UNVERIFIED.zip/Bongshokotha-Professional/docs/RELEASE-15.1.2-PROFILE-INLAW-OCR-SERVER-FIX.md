# BONGSHOKOTHA Professional 15.1.2 — Profile, In-Law, OCR & Server Fix

## Fixed
- Member profile now has a compact section navigator and a canonical lineage-first layout.
- Parents-in-law are derived per marriage from each spouse’s canonical father/mother.
- Historical/manual in-law fallback remains visible without overriding canonical spouse lineage.
- Member editor prioritizes the selected spouse’s canonical parents and can create missing spouse parents directly.
- Profile has a direct **স্ক্যান + তথ্য নিন** action.
- Direct profile file upload accepts image/PDF/document files; image/PDF files enter the OCR pipeline.
- Scanner supports review/apply OCR to the selected member. OCR remains evidence-assistance only.
- Admin server registry now lists Local, LAN, Neon PostgreSQL, Supabase, Firebase, Appwrite and Custom BONGSHOKOTHA Server. Cloudflare Pages/Workers/D1 is not included.

## Verification
- Added `npm run inlaw:ocr:test`.
- Full verification, typecheck and production build must pass before release packaging.
