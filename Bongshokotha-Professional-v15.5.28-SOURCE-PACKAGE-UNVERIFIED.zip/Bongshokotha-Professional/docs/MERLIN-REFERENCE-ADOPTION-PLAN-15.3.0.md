# Merlin Reference Adoption Plan — Bongshokotha Professional 15.3.1

This release uses the supplied Merlin HTML only as a design/logic reference. No Merlin HTML, CSS, demo data, function names, or UI markup is copied into the product.

## Adopted ideas, rebuilt for Bongshokotha

1. **Stable Person ID** — retain immutable IDs as the identity key; visible serial numbers remain presentation-only.
2. **Separate marriage/union context** — keep marriage records independent so children can be associated with the correct union without mixing children across multiple marriages.
3. **Derived family relationships** — derive grandparents and siblings from canonical parent links rather than storing duplicated relationship names.
4. **Deterministic child order** — use birth order, then date components, then immutable ID as a stable tie-breaker.
5. **Profile-first navigation** — after creating a child, the persisted canonical record can be opened directly; the profile is not a temporary form-only record.
6. **Backup as a complete dataset** — preserve canonical people, marriages, archive data, recycle data and integrity metadata rather than exporting a small demo-store object.
7. **Responsive presentation** — retain the useful mobile/dark-mode direction, but keep Bongshokotha's existing theme system and accessibility controls.

## Deliberately NOT copied

- Merlin's localStorage-only database pattern.
- Merlin demo seed data and automatic reseeding behavior.
- Merlin's simple father/mother-only sibling classification.
- Merlin's marriage-child link being treated as proof of both biological parents.
- Merlin's hard-delete approach.
- Merlin's limited navigation/settings/security model.
- Merlin's standalone HTML/CSS/JavaScript structure.

## Additional hardening in this release

- A marriage-specific child entry no longer creates a synthetic second biological parent in the relationship graph.
- Full/half sibling classification no longer uses shared marriage membership as biological evidence.
- Canonical child lists have deterministic ordering.
- Existing 15.2.x security, OCR, persistence, marriage-isolation and child/profile fixes remain the base.

## Source boundary

The Merlin file is treated as inspiration only. Bongshokotha remains governed by its own canonical data model, evidence/conflict rules, audit trail, RBAC, backup/restore model and relationship integrity engine.
