# Legacy Review — 15.0.0

The available Library inventory contains 24 Bongshokotha ZIP releases spanning the early builds through 14.0.0. The previous consolidated inventory recorded 459 unique ZIP content blobs across those archives.

## Review result
The 14.0.0 consolidated source already contains the current implementation families for genealogy ordering, generation, relationship handling, profile/document OCR, archive, dashboard, themes, storage, succession, server registry and build tooling. Historical-only material was reviewed as evidence instead of blindly replacing current code.

## Historical-only material explicitly collected
Examples include older release notes, verification manifests, the 11.5.x marriage-origin regression script, older build-readiness documents, and legacy lockfiles. These are historical evidence, not competing runtime implementations.

## Important carry-forward findings
1. Marriage-origin must be a first-class state.
2. A married-in member must be presented beside the corresponding birth-line spouse, after that spouse.
3. A married-in member's biological parents must not be promoted automatically into the spouse's family birth-line.
4. Birth order is local to siblings and is independent of save time.
5. Branch traversal must complete one sibling's descendant branch before the next sibling.
6. OCR output is proposed data until reviewed; existing verified fields must not be silently overwritten.
7. NID, birth-registration and passport identifiers remain separate.
8. Archive records must survive removal of a profile attachment.
9. Factory/settings reset must not delete family records.
10. Import must preview duplicates and relationship conflicts before commit.

## No legacy code overlay
Older source files were not copied over the consolidated implementation merely because they existed. This avoids regression of fixes already integrated into the current codebase.
