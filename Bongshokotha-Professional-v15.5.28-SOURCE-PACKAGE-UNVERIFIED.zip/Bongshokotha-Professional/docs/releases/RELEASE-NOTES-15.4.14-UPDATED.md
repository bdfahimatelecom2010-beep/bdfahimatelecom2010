# Bongshokotha Professional 15.4.14 — Updated Source Package

This package consolidates the latest source-folder changes and regression safeguards for the current 15.4.14 line. It is a source package, not a claim that Android APK or Windows EXE binaries have been built and tested.

## Included areas
- Responsive layouts and device adaptation checks for small phones, mobile, tablet, and large displays.
- Reduced-motion and forced-colors accessibility safeguards; low-resource visual effects reduction.
- Application error boundary and local-only session diagnostics.
- Dashboard metrics optimization and safe handling of incomplete dates/data.
- Family relationships, married-in members' external biological-parent facts, child creation/profile refresh, and OCR review/apply workflows.
- NID/duplicate-data safeguards, family data health checks, role-based access including Co-Admin restrictions, server-list checks, and demo-data auto-load safeguards.
- Theme registry and UI runtime safeguards.

## Regression checks run in this package
- Device adaptation: 11/11
- App resilience: 8 safeguards
- Source quality contracts: 31
- Dashboard: 14/14
- Themes: 112 themes and required tokens
- UI theme runtime: 12/12
- Profile/lineage: 12/12
- Member data integrity: 8 contracts
- Child profile + OCR apply: passed
- Child + document deep checks: 11/11
- NID parent profile: 10/10
- Security regression: passed
- Account/Co-Admin permissions: 17/17
- Demo auto-load safety: 4/4
- Server list: 10/10
- Marriage-origin: 8/8
- Married-in external parents: passed
- Data health: 7/7
- Settings save: passed
- Relationship UI: 18 contracts
- Canonical relationship rules: 10/10
- Relationship safety extensions: 3/3

## Build status / limitations
These regression scripts are source-level checks. A full dependency-backed TypeScript/Vite build, Windows installer/EXE, Android APK, and physical-device testing have not been verified in this packaging run. Run `npm install` first, then follow `SETUP-BANGLA.md` and `BUILD-COMMANDS-WINDOWS.md` on the target machine. OCR preparation currently uses a Windows PowerShell script as defined in `package.json`.

## Privacy
The ZIP intentionally excludes `node_modules`, build output, local `.env` secrets, and personal NID/passport image files from the parent workspace. Configure secrets locally from `.env.example` where required.
