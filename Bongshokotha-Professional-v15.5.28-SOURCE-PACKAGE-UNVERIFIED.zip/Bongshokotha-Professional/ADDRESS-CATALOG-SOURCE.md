# Bangladesh address catalogue source

The address form uses a bilingual administrative hierarchy from `https://iqbalhasandev.github.io/bangladesh-geo-json/bangladesh-geo.json`. It contains divisions, districts, upazilas, unions and pourashavas. The app caches the response in local storage as `bongshokotha:bd-location-catalog:v1` after first successful load.

If the catalogue is not already cached, the first use of these dropdowns requires an internet connection. Village, ward, house/holding, road, post office and postal code are retained as separate details; post-office/post-code options are suggestions from saved records, not a complete authoritative national list.
