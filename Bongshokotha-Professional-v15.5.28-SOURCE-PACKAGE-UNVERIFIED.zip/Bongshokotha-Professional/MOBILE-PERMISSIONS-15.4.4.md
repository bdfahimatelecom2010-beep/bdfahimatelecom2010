# Bongshokotha Professional 15.4.4 — Camera & Media Permission Update

This release adds device-permission handling for the mobile/Capacitor build.

- Camera capture now asks for camera permission before `getUserMedia()` is used.
- Settings → Camera & Scanner now shows Camera and Photos/Media permission states and buttons to request them.
- Photo/media access uses the Capacitor Camera permission API on native Android/iOS.
- PDF/DOC/DOCX and other document uploads continue through the system file picker. The app does not request broad permanent storage access merely to choose a file.
- The supplied `Nafsan Logo copy.jpg` artwork is used as the application/PWA/favicon icon source.

Android 13+ uses granular media permissions / the system photo picker rather than the old broad external-storage permission model.

Before building the native Android app from a fresh clone:

```powershell
npm.cmd install
npm.cmd run mobile:init
npm.cmd run mobile:sync
npm.cmd run mobile:build
```

After `android/` exists, icon resources can be generated with:

```powershell
npm.cmd run mobile:icons
```
