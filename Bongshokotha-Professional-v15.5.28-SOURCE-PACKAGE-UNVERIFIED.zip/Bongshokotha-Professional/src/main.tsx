import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { AppErrorBoundary } from './components/AppErrorBoundary';
import './index.css';

// Adapt visual effects to device capability without blocking app startup.
try {
  const nav = navigator as Navigator & { deviceMemory?: number };
  const cores = Number(nav.hardwareConcurrency || 4);
  const memory = Number(nav.deviceMemory || 4);
  const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
  const tier = cores <= 2 || memory <= 2 ? 'lite' : cores >= 8 && memory >= 8 ? 'high' : 'standard';
  document.documentElement.dataset.deviceTier = tier;
  if (reducedMotion) document.documentElement.dataset.reducedMotion = 'true';
} catch { /* Feature detection must never prevent the app from rendering. */ }

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppErrorBoundary>
      <App />
    </AppErrorBoundary>
  </StrictMode>,
);
