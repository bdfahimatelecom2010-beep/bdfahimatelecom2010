/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Internationalization Architecture & Comprehensive Localization Lexicon (Part 4)
 * 
 * Supported initial languages:
 * 1. Bengali (বাংলা - default)
 * 2. English (English)
 * 3. Hindi (हिन्दी)
 * 4. Arabic (العربية - with RTL direction support)
 * 
 * Future-ready registry architecture for Urdu, Persian, Turkish, Malay, etc.
 * STRICT RULE: Changing UI language NEVER alters stored user data, biographies,
 * historical names, original deeds, or OCR transcripts.
 */

export type SupportedLanguage = 'bn' | 'en' | 'hi' | 'ar';

export interface LanguageMeta {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  direction: 'ltr' | 'rtl';
  flag: string;
}

export const SUPPORTED_LANGUAGES: LanguageMeta[] = [
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', direction: 'ltr', flag: '🇧🇩' },
  { code: 'en', name: 'English', nativeName: 'English', direction: 'ltr', flag: '🇬🇧' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', direction: 'ltr', flag: '🇮🇳' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', direction: 'rtl', flag: '🇸🇦' }
];

export interface TranslationDictionary {
  // Application Branding
  appName: string;
  appTagline: string;
  appDescription: string;
  
  // Navigation
  navDashboard: string;
  navMembers: string;
  navTree: string;
  navRelationships: string;
  navBook: string;
  navArchive: string;
  navCalendar: string;
  navPrint: string;
  navSettings: string;
  
  // Member Fields
  fullName: string;
  banglaName: string;
  englishName: string;
  nickname: string;
  personId: string;
  serialNumber: string;
  generation: string;
  branch: string;
  gender: string;
  male: string;
  female: string;
  other: string;
  unknown: string;
  status: string;
  living: string;
  deceased: string;
  birthDate: string;
  birthPlace: string;
  deathDate: string;
  restingPlace: string;
  father: string;
  mother: string;
  spouse: string;
  children: string;
  siblings: string;
  biography: string;
  nidNumber: string;
  brnNumber: string;
  passportNumber: string;
  
  // Actions
  addMember: string;
  editMember: string;
  deleteMember: string;
  addMarriage: string;
  saveChanges: string;
  cancel: string;
  confirm: string;
  search: string;
  filter: string;
  exportData: string;
  importData: string;
  restoreData: string;
  printBook: string;
  
  // Kinship
  traceKinship: string;
  relationshipPath: string;
  directBloodLine: string;
  inLawLineage: string;
  
  // Archive
  archiveVault: string;
  scanDocument: string;
  recordAudio: string;
  bulkUpload: string;
  originalEvidence: string;
  enhancedCopy: string;
  verifiedStatus: string;
  unverifiedStatus: string;
  
  // Roles & Security (Part 4)
  roleOwner: string;
  roleSuperAdmin: string;
  roleAdmin: string;
  roleEditor: string;
  roleContributor: string;
  roleViewer: string;
  maskNumbers: string;
  revealNumbers: string;
  privacySetting: string;
  livingPrivacy: string;
  
  // Settings 25 Categories
  catAccount: string;
  catLanguage: string;
  catTheme: string;
  catDisplay: string;
  catDashboard: string;
  catFamily: string;
  catGenealogy: string;
  catArchive: string;
  catOcr: string;
  catCamera: string;
  catStorage: string;
  catPrivacy: string;
  catSecurity: string;
  catNotifications: string;
  catBackup: string;
  catRestore: string;
  catImport: string;
  catExport: string;
  catSync: string;
  catPermissions: string;
  catAccessibility: string;
  catValidation: string;
  catRepair: string;
  catAbout: string;
  catReset: string;

  // Diagnostics & Reset
  dataIntegrity: string;
  runIntegrityCheck: string;
  autoRepair: string;
  noErrorsFound: string;
  resetSettingsTitle: string;
  resetSettingsDesc: string;
  factoryResetTitle: string;
  factoryResetDesc: string;
}

export const TRANSLATIONS: Record<SupportedLanguage, TranslationDictionary> = {
  bn: {
    appName: 'বংশকথা',
    appTagline: 'পারিবারিক ঐতিহ্য ও বংশধারা সংরক্ষণাগার',
    appDescription: 'পূর্বপুরুষদের ইতিহাস, রক্তের সম্পর্ক, ঐতিহাসিক দলিল ও স্মৃতিকথা সংরক্ষণের বিশ্বস্ত উন্মুক্ত প্রযুক্তি।',
    
    navDashboard: 'ড্যাশবোর্ড',
    navMembers: 'সদস্য তালিকা',
    navTree: 'বংশলতিকা',
    navRelationships: 'সম্পর্ক নির্ণয়',
    navBook: 'বংশপুস্তক',
    navArchive: 'পারিবারিক আর্কাইভ',
    navCalendar: 'বর্ষপঞ্জি',
    navPrint: 'মুদ্রণ ও সনদ',
    navSettings: 'সেটিংস',
    
    fullName: 'পূর্ণ নাম',
    banglaName: 'বাংলা নাম',
    englishName: 'ইংরেজি নাম',
    nickname: 'ডাকনাম / উপাধি',
    personId: 'স্থায়ী ব্যক্তিসংখ্যা (ID)',
    serialNumber: 'বংশক্রমিক নম্বর',
    generation: 'প্রজন্ম',
    branch: 'শাখা / তরফ',
    gender: 'লিঙ্গ',
    male: 'পুরুষ',
    female: 'মহিলা',
    other: 'অন্যান্য',
    unknown: 'অজ্ঞাত',
    status: 'অবস্থা',
    living: 'জীবিত',
    deceased: 'প্রয়াত / মরহুম',
    birthDate: 'জন্ম তারিখ',
    birthPlace: 'জন্মস্থান',
    deathDate: 'মৃত্যু তারিখ',
    restingPlace: 'সমাধিস্থল / কবরস্থান',
    father: 'পিতা',
    mother: 'মাতা',
    spouse: 'জীবনসঙ্গী / স্ত্রী / স্বামী',
    children: 'সন্তানসন্ততি',
    siblings: 'সহোদর ভাইবোন',
    biography: 'জীবনী ও কীর্তিগাথা',
    nidNumber: 'জাতীয় পরিচয়পত্র নম্বর (NID)',
    brnNumber: 'জন্ম নিবন্ধন নম্বর (BRN)',
    passportNumber: 'পাসপোর্ট নম্বর',
    
    addMember: 'নতুন সদস্য যুক্ত করুন',
    editMember: 'সদস্য তথ্য সংশোধন',
    deleteMember: 'সদস্য অপসারণ',
    addMarriage: 'বৈবাহিক বন্ধন নথিভুক্ত',
    saveChanges: 'পরিবর্তন সংরক্ষণ',
    cancel: 'বাতিল',
    confirm: 'নিশ্চিত করুন',
    search: 'সদস্য, স্থান বা দলিল খুঁজুন...',
    filter: 'ফিল্টার',
    exportData: 'ডেটা এক্সপোর্ট',
    importData: 'ডেটা আমদানি',
    restoreData: 'নিরাপদ রিস্টোর',
    printBook: 'বংশপুস্তক মুদ্রণ',
    
    traceKinship: 'রক্তের সম্পর্ক নির্ণয়',
    relationshipPath: 'সম্পর্কের সংযোগসূত্র',
    directBloodLine: 'সরাসরি পিতৃ/মাতৃ রক্তের ধারা',
    inLawLineage: 'বৈবাহিক আত্মীয়তা ধারা',
    
    archiveVault: 'পারিবারিক আর্কাইভ ও নথিশালা',
    scanDocument: 'দলিল স্ক্যান ও ওসিআর',
    recordAudio: 'স্মৃতিচারণ অডিও ধারণ',
    bulkUpload: 'একত্রে বহু নথি আপলোড',
    originalEvidence: 'মূল অবিকৃত প্রমাণপত্র',
    enhancedCopy: 'উন্নত ডিজিটাল প্রতিলিপি',
    verifiedStatus: 'যাচাইকৃত প্রামাণ্য দলিল',
    unverifiedStatus: 'অযাচাইকৃত পাণ্ডুলিপি',
    
    roleOwner: 'বংশমালিক / প্রতিষ্ঠাতা (Owner)',
    roleSuperAdmin: 'বংশপ্রধান / অভিভাবক (Super Admin)',
    roleAdmin: 'প্রশাসক (Admin)',
    roleEditor: 'বংশ-লেখক / লিপিকার (Editor)',
    roleContributor: 'বংশধর / অবদানকারী (Contributor)',
    roleViewer: 'অতিথি / দর্শক (Viewer)',
    maskNumbers: 'আইডি নম্বর গোপন করুন',
    revealNumbers: 'আইডি নম্বর প্রদর্শন করুন',
    privacySetting: 'গোপনীয়তা ও নিরাপত্তা',
    livingPrivacy: 'জীবিত সদস্যদের ব্যক্তিগত তথ্য সুরক্ষা',
    
    catAccount: 'অ্যাকাউন্ট',
    catLanguage: 'ভাষা ও লিপ্যন্তর',
    catTheme: '১১৬টি HD প্রিমিয়াম থিম',
    catDisplay: 'প্রদর্শন ও বিন্যাস',
    catDashboard: 'ড্যাশবোর্ড নিয়ন্ত্রণ',
    catFamily: 'পারিবারিক পরিচয়',
    catGenealogy: 'বংশলতিকা নিয়ম',
    catArchive: 'পারিবারিক আর্কাইভ',
    catOcr: 'বাংলা ওসিআর',
    catCamera: 'ক্যামেরা ও স্ক্যানার',
    catStorage: 'ডিভাইস স্টোরেজ',
    catPrivacy: 'তথ্য গোপনীয়তা',
    catSecurity: 'নিরাপত্তা ও পিন',
    catNotifications: 'স্মরণবার্তা ও নোটিফিকেশন',
    catBackup: 'ব্যাকআপ সংরক্ষণ',
    catRestore: 'নিরাপদ রিস্টোর',
    catImport: 'আমদানি উইজার্ড',
    catExport: 'বহুভাষিক এক্সপোর্ট',
    catSync: 'সার্ভার সমন্বয়',
    catPermissions: 'ভূমিকা ও প্রবেশাধিকার',
    catAccessibility: 'সহজগম্যতা (Accessibility)',
    catValidation: 'শুদ্ধতা যাচাই নিয়ম',
    catRepair: '৮-পয়েন্ট ডেটা মেরামত',
    catAbout: 'বংশকথা পরিচিতি',
    catReset: 'রিসেট ও ফ্যাক্টরি মুছুন',

    dataIntegrity: '৮-পয়েন্ট ডেটা শুদ্ধতা ইঞ্জিন',
    runIntegrityCheck: 'শুদ্ধতা পরীক্ষা চালান',
    autoRepair: 'স্বয়ংক্রিয় ত্রুটি মেরামত',
    noErrorsFound: 'কোনো অসঙ্গতি পাওয়া যায়নি! ডেটাবেস সম্পূর্ণ ত্রুটিমুক্ত।',
    resetSettingsTitle: 'সেটিংস রিসেট (নিরাপদ)',
    resetSettingsDesc: 'পছন্দসমূহ ও থিম প্রাথমিক অবস্থায় ফিরবে; পারিবারিক কোনো তথ্য মুছবে না।',
    factoryResetTitle: 'ফ্যাক্টরি রিসেট (ধ্বংসাত্মক)',
    factoryResetDesc: 'স্থানীয় সকল তথ্য স্থায়ীভাবে মুছে প্রাথমিক অবস্থায় ফেরত যাবে।'
  },
  
  en: {
    appName: 'BONGSHOKOTHA',
    appTagline: 'Heritage Lineage & Family History Platform',
    appDescription: 'Preserving ancestral history, genetic kinship, legal deeds, and oral memoirs for generations to come.',
    
    navDashboard: 'Dashboard',
    navMembers: 'All Members',
    navTree: 'Family Tree',
    navRelationships: 'Relationships',
    navBook: 'Family Book',
    navArchive: 'Family Archive',
    navCalendar: 'Family Calendar',
    navPrint: 'Print & Export',
    navSettings: 'Settings',
    
    fullName: 'Full Name',
    banglaName: 'Bangla Name',
    englishName: 'English Name',
    nickname: 'Nickname / Title',
    personId: 'Permanent Person ID',
    serialNumber: 'Lineage Kromik',
    generation: 'Generation',
    branch: 'Branch / Torof',
    gender: 'Gender',
    male: 'Male',
    female: 'Female',
    other: 'Other',
    unknown: 'Unknown',
    status: 'Status',
    living: 'Living',
    deceased: 'Deceased',
    birthDate: 'Birth Date',
    birthPlace: 'Birth Place',
    deathDate: 'Death Date',
    restingPlace: 'Resting Place / Cemetery',
    father: 'Father',
    mother: 'Mother',
    spouse: 'Spouse',
    children: 'Children',
    siblings: 'Siblings',
    biography: 'Biography & Heritage',
    nidNumber: 'National ID (NID)',
    brnNumber: 'Birth Registration (BRN)',
    passportNumber: 'Passport No.',
    
    addMember: 'Add Member',
    editMember: 'Edit Member',
    deleteMember: 'Delete Member',
    addMarriage: 'Record Marriage',
    saveChanges: 'Save Changes',
    cancel: 'Cancel',
    confirm: 'Confirm',
    search: 'Search members, places, records...',
    filter: 'Filter',
    exportData: 'Export Data',
    importData: 'Import Data',
    restoreData: 'Non-Destructive Restore',
    printBook: 'Print Heritage Book',
    
    traceKinship: 'Trace Kinship',
    relationshipPath: 'Kinship Connection Path',
    directBloodLine: 'Direct Biological Lineage',
    inLawLineage: 'Affinal / In-Law Lineage',
    
    archiveVault: 'Digital Family Archive & Vault',
    scanDocument: 'Scan Document & OCR',
    recordAudio: 'Record Voice Memo',
    bulkUpload: 'Bulk Ingestion Studio',
    originalEvidence: 'Original Evidence',
    enhancedCopy: 'Enhanced Digital Copy',
    verifiedStatus: 'Verified Record',
    unverifiedStatus: 'Unverified Draft',
    
    roleOwner: 'Family Owner / Founder',
    roleSuperAdmin: 'Family Head / Super Admin',
    roleAdmin: 'Administrator',
    roleEditor: 'Family Chronicler / Editor',
    roleContributor: 'Family Member / Contributor',
    roleViewer: 'Guest / Public Viewer',
    maskNumbers: 'Mask Sensitive Numbers',
    revealNumbers: 'Reveal Numbers',
    privacySetting: 'Privacy & Security Shield',
    livingPrivacy: 'Living Persons Privacy Shield',
    
    catAccount: 'Account',
    catLanguage: 'Language & i18n',
    catTheme: '116 HD Premium Themes',
    catDisplay: 'Display & Layout',
    catDashboard: 'Dashboard Controls',
    catFamily: 'Family Identity',
    catGenealogy: 'Genealogy Rules',
    catArchive: 'Archive & Vault',
    catOcr: 'Bangla OCR Engine',
    catCamera: 'Camera & Scanner',
    catStorage: 'Device Storage',
    catPrivacy: 'Data Privacy',
    catSecurity: 'Security & PIN',
    catNotifications: 'Remembrances & Alerts',
    catBackup: 'Backup Preservation',
    catRestore: 'Safe Restore',
    catImport: 'Import Wizard',
    catExport: 'Multilingual Export',
    catSync: 'Server Synchronization',
    catPermissions: 'Roles & Permissions',
    catAccessibility: 'Accessibility',
    catValidation: 'Validation Rules',
    catRepair: '8-Point Data Repair',
    catAbout: 'About Bongshokotha',
    catReset: 'Reset & Destruction',

    dataIntegrity: '8-Point Data Integrity Engine',
    runIntegrityCheck: 'Run Diagnostic Check',
    autoRepair: 'Auto-Repair Anomalies',
    noErrorsFound: 'No anomalies detected! Database is in pristine condition.',
    resetSettingsTitle: 'Reset Settings (Safe)',
    resetSettingsDesc: 'Restores default preferences and themes. Family genealogy is completely untouched.',
    factoryResetTitle: 'Factory Reset (Destructive)',
    factoryResetDesc: 'Permanently erases all local lineage and vaults back to pristine clean state.'
  },

  hi: {
    appName: 'वंशकथा',
    appTagline: 'पारिवारिक विरासत और वंशावली संरक्षण',
    appDescription: 'पूर्वजों के इतिहास, रक्त संबंधों, ऐतिहासिक दस्तावेजों और संस्मरणों को सुरक्षित रखने का मंच।',
    
    navDashboard: 'डैशबोर्ड',
    navMembers: 'सभी सदस्य',
    navTree: 'वंश वृक्ष',
    navRelationships: 'संबंध निर्धारण',
    navBook: 'वंश पुस्तक',
    navArchive: 'पुरालेखागार',
    navCalendar: 'पंचांग',
    navPrint: 'प्रिंट और प्रमाणपत्र',
    navSettings: 'सेटिंग्स',
    
    fullName: 'पूरा नाम',
    banglaName: 'मूल नाम',
    englishName: 'अंग्रेजी नाम',
    nickname: 'उपनाम',
    personId: 'स्थायी व्यक्ति पहचान',
    serialNumber: 'वंश क्रमांक',
    generation: 'पीढ़ी',
    branch: 'शाखा',
    gender: 'लिंग',
    male: 'पुरुष',
    female: 'महिला',
    other: 'अन्य',
    unknown: 'अज्ञात',
    status: 'स्थिति',
    living: 'जीवित',
    deceased: 'दिवंगत',
    birthDate: 'जन्म तिथि',
    birthPlace: 'जन्म स्थान',
    deathDate: 'मृत्यु तिथि',
    restingPlace: 'समाधि स्थल',
    father: 'पिता',
    mother: 'माता',
    spouse: 'जीवनसाथी',
    children: 'संतान',
    siblings: 'भाई-बहन',
    biography: 'जीवनी और विरासत',
    nidNumber: 'राष्ट्रीय पहचान संख्या',
    brnNumber: 'जन्म पंजीकरण संख्या',
    passportNumber: 'पासपोर्ट संख्या',
    
    addMember: 'नया सदस्य जोड़ें',
    editMember: 'सदस्य संपादित करें',
    deleteMember: 'सदस्य हटाएं',
    addMarriage: 'विवाह दर्ज करें',
    saveChanges: 'परिवर्तन सहेजें',
    cancel: 'रद्द करें',
    confirm: 'पुष्टि करें',
    search: 'खोजें...',
    filter: 'फ़िल्टर',
    exportData: 'डेटा निर्यात',
    importData: 'डेटा आयात',
    restoreData: 'डेटा पुनर्स्थापित करें',
    printBook: 'वंश पुस्तक प्रिंट करें',
    
    traceKinship: 'रिश्ता खोजें',
    relationshipPath: 'संबंध मार्ग',
    directBloodLine: 'प्रत्यक्ष रक्त रेखा',
    inLawLineage: 'वैवाहिक संबंध',
    
    archiveVault: 'डिजिटल अभिलेखागार',
    scanDocument: 'दस्तावेज़ स्कैन',
    recordAudio: 'ऑडियो रिकॉर्डिंग',
    bulkUpload: 'सामूहिक अपलोड',
    originalEvidence: 'मूल प्रमाण',
    enhancedCopy: 'संवर्धित प्रति',
    verifiedStatus: 'सत्यापित रिकॉर्ड',
    unverifiedStatus: 'असत्यापित',
    
    roleOwner: 'वंश स्वामी (Owner)',
    roleSuperAdmin: 'वंश प्रमुख (Super Admin)',
    roleAdmin: 'प्रशासक (Admin)',
    roleEditor: 'संपादक (Editor)',
    roleContributor: 'योगदानकर्ता (Contributor)',
    roleViewer: 'दर्शक (Viewer)',
    maskNumbers: 'पहचान संख्या छुपाएं',
    revealNumbers: 'पहचान संख्या दिखाएं',
    privacySetting: 'गोपनीयता सुरक्षा',
    livingPrivacy: 'जीवित सदस्यों की गोपनीयता',
    
    catAccount: 'खाता',
    catLanguage: 'भाषा',
    catTheme: '५० प्रीमियम थीम्स',
    catDisplay: 'प्रदर्शन',
    catDashboard: 'डैशबोर्ड',
    catFamily: 'पारिवारिक पहचान',
    catGenealogy: 'वंशावली नियम',
    catArchive: 'पुरालेख',
    catOcr: 'ओसीआर इंजन',
    catCamera: 'कैमरा व स्कैनर',
    catStorage: 'भंडारण',
    catPrivacy: 'गोपनीयता',
    catSecurity: 'सुरक्षा व पिन',
    catNotifications: 'स्मरण व सूचनाएं',
    catBackup: 'बैकअप',
    catRestore: 'पुनर्प्राप्ति',
    catImport: 'आयात विज़ार्ड',
    catExport: 'निर्यात',
    catSync: 'सर्वर सिंक',
    catPermissions: 'भूमिकाएं',
    catAccessibility: 'सुलभता',
    catValidation: 'वैधता',
    catRepair: '८-बिंदु मरम्मत',
    catAbout: 'परिचय',
    catReset: 'रीसेट',

    dataIntegrity: '८-बिंदु डेटा अखंडता इंजन',
    runIntegrityCheck: 'जांच चलाएं',
    autoRepair: 'त्रुटि मरम्मत',
    noErrorsFound: 'डेटाबेस त्रुटिहीन है।',
    resetSettingsTitle: 'सेटिंग्स रीसेट (सुरक्षित)',
    resetSettingsDesc: 'पसंद रीसेट होगी; पारिवारिक डेटा सुरक्षित रहेगा।',
    factoryResetTitle: 'फ़ैक्टरी रीसेट (विनाशकारी)',
    factoryResetDesc: 'सभी डेटा स्थायी रूप से मिटा दिया जाएगा।'
  },

  ar: {
    appName: 'بونغشوكوثا (شجرة العائلة)',
    appTagline: 'منصة حفظ الأنساب والتراث العائلي',
    appDescription: 'حفظ تاريخ الأجداد، صلات القرابة، الوثائق التاريخية، والمذكرات الشفوية للأجيال القادمة.',
    
    navDashboard: 'لوحة التحكم',
    navMembers: 'الأعضاء',
    navTree: 'شجرة العائلة',
    navRelationships: 'صلة القرابة',
    navBook: 'كتاب العائلة',
    navArchive: 'الأرشيف التاريخي',
    navCalendar: 'التقويم',
    navPrint: 'طباعة وشهادات',
    navSettings: 'الإعدادات',
    
    fullName: 'الاسم الكامل',
    banglaName: 'الاسم الأصلي',
    englishName: 'الاسم الإنجليزي',
    nickname: 'اللقب / الكنية',
    personId: 'المعرف الثابت',
    serialNumber: 'الرقم التسلسلي للنسب',
    generation: 'الجيل',
    branch: 'الفرع / الفخذ',
    gender: 'الجنس',
    male: 'ذكر',
    female: 'أنثى',
    other: 'آخر',
    unknown: 'غير محدد',
    status: 'الحالة',
    living: 'على قيد الحياة',
    deceased: 'متوفى / مرحوم',
    birthDate: 'تاريخ الميلاد',
    birthPlace: 'مكان الميلاد',
    deathDate: 'تاريخ الوفاة',
    restingPlace: 'المدفن / المقبرة',
    father: 'الأب',
    mother: 'الأم',
    spouse: 'الزوج / الزوجة',
    children: 'الأبناء',
    siblings: 'الإخوة والأخوات',
    biography: 'السيرة والتاريخ',
    nidNumber: 'رقم الهوية الوطنية',
    brnNumber: 'رقم شهادة الميلاد',
    passportNumber: 'رقم جواز السفر',
    
    addMember: 'إضافة عضو',
    editMember: 'تعديل البيانات',
    deleteMember: 'حذف العضو',
    addMarriage: 'تسجيل زواج',
    saveChanges: 'حفظ التغييرات',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
    search: 'بحث...',
    filter: 'تصفية',
    exportData: 'تصدير البيانات',
    importData: 'استيراد البيانات',
    restoreData: 'استعادة آمنة',
    printBook: 'طباعة كتاب العائلة',
    
    traceKinship: 'تتبع النسب',
    relationshipPath: 'مسار القرابة',
    directBloodLine: 'خط النسب المباشر',
    inLawLineage: 'نسب المصاهرة',
    
    archiveVault: 'الخزينة والأرشيف الرقمي',
    scanDocument: 'مسح المستندات ضوئياً',
    recordAudio: 'تسجيل الذاكرة الصوتية',
    bulkUpload: 'رفع متعدد',
    originalEvidence: 'الوثيقة الأصلية',
    enhancedCopy: 'نسخة رقمية محسنة',
    verifiedStatus: 'وثيقة موثقة',
    unverifiedStatus: 'مسودة غير موثقة',
    
    roleOwner: 'مالك النسب (Owner)',
    roleSuperAdmin: 'عميد العائلة (Super Admin)',
    roleAdmin: 'مدير النظام (Admin)',
    roleEditor: 'مؤرخ العائلة (Editor)',
    roleContributor: 'مشارك (Contributor)',
    roleViewer: 'زائر (Viewer)',
    maskNumbers: 'إخفاء الأرقام الحساسة',
    revealNumbers: 'إظهار الأرقام',
    privacySetting: 'درع الخصوصية والأمان',
    livingPrivacy: 'حماية خصوصية الأحياء',
    
    catAccount: 'الحساب',
    catLanguage: 'اللغة',
    catTheme: '٥٠ قالباً مميزاً',
    catDisplay: 'العرض والمظهر',
    catDashboard: 'لوحة التحكم',
    catFamily: 'هوية العائلة',
    catGenealogy: 'قواعد الأنساب',
    catArchive: 'الأرشيف والخزينة',
    catOcr: 'التعرف الضوئي (OCR)',
    catCamera: 'الكاميرا والماسح',
    catStorage: 'مساحة الجهاز',
    catPrivacy: 'الخصوصية',
    catSecurity: 'الأمان ورقم PIN',
    catNotifications: 'التنبيهات والذكريات',
    catBackup: 'النسخ الاحتياطي',
    catRestore: 'الاستعادة الآمنة',
    catImport: 'معالج الاستيراد',
    catExport: 'تصدير متعدد اللغات',
    catSync: 'مزامنة الخادم',
    catPermissions: 'الأدوار والصلاحيات',
    catAccessibility: 'إمكانية الوصول',
    catValidation: 'قواعد التحقق',
    catRepair: 'إصلاح البيانات',
    catAbout: 'عن التطبيق',
    catReset: 'إعادة الضبط',

    dataIntegrity: 'محرك سلامة البيانات ذو ٨ نقاط',
    runIntegrityCheck: 'فحص الأخطاء',
    autoRepair: 'إصلاح تلقائي',
    noErrorsFound: 'لا توجد أخطاء! قاعدة البيانات سليمة تماماً.',
    resetSettingsTitle: 'إعادة ضبط الإعدادات (آمن)',
    resetSettingsDesc: 'يعيد التفضيلات دون مس أنساب العائلة.',
    factoryResetTitle: 'استعادة ضبط المصنع (حذف شامل)',
    factoryResetDesc: 'يمسح جميع بيانات العائلة والأرشيف نهائياً.'
  }
};

/**
 * Translation helper hook / getter
 */
export function getTranslations(lang: SupportedLanguage = 'bn'): TranslationDictionary {
  return TRANSLATIONS[lang] || TRANSLATIONS.bn;
}
