/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Bengali Calendar and Multi-Calendar Date Engine
 */

import { GenealogyDate, DatePrecision } from '../types/genealogy';

export const BANGLA_MONTHS = [
  'বৈশাখ',   // Boishakh (starts mid April)
  'জ্যৈষ্ঠ',   // Joishtho
  'আষাঢ়',    // Asharh
  'শ্রাবণ',    // Srabon
  'ভাদ্র',    // Bhadro
  'আশ্বিন',   // Ashwin
  'কার্তিক',  // Kartik
  'অগ্রহায়ণ', // Ogrohayon
  'পৌষ',     // Poush
  'মাঘ',     // Magh
  'ফাল্গুন',   // Falgun
  'চৈত্র'     // Choitro
];

export const BANGLA_DIGITS: { [key: string]: string } = {
  '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
  '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
};

export function toBanglaDigits(input: string | number | null | undefined): string {
  if (input === null || input === undefined) return '';
  return String(input).replace(/[0-9]/g, match => BANGLA_DIGITS[match] || match);
}

/**
 * Standard Revised Bengali Calendar Conversion (Bangladesh Standard)
 * Boishakh starts on April 14.
 * First 5 months (Boishakh - Bhadro) have 31 days.
 * Next 6 months have 30 days.
 * Falgun has 29 or 30 days depending on leap year.
 */
export function gregorianToBangla(year: number, month: number, day: number): { year: number; monthName: string; day: number } {
  // Approximate standard conversion
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  const monthDays = [31, isLeapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  let banglaYear = year - 593;
  // If date is before April 14, Bangla year is year - 594
  if (month < 4 || (month === 4 && day < 14)) {
    banglaYear = year - 594;
  }

  // Calculate day of year in Gregorian
  let dayOfYear = day;
  for (let i = 0; i < month - 1; i++) {
    dayOfYear += monthDays[i];
  }

  // April 14 is day 104 (or 105 in leap year)
  const boishakhStartDay = isLeapYear ? 105 : 104;

  let banglaMonthIndex = 0;
  let banglaDay = 1;

  if (dayOfYear >= boishakhStartDay) {
    let diff = dayOfYear - boishakhStartDay;
    // Bangladesh standard revised month lengths:
    // Boishakh to Ashwin (first 6 months): 31 days each
    // Kartik to Magh (next 4 months): 30 days each
    // Falgun: 29 or 30 (leap year)
    // Choitro: 30 days
    const banglaLengths = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, isLeapYear ? 30 : 29, 30];

    for (let i = 0; i < 12; i++) {
      if (diff < banglaLengths[i]) {
        banglaMonthIndex = i;
        banglaDay = diff + 1;
        break;
      }
      diff -= banglaLengths[i];
    }
  } else {
    // Before Pohela Boishakh: fall into Poush, Magh, Falgun, Choitro of previous Gregorian year
    let remaining = boishakhStartDay - dayOfYear;
    // Choitro is 30 days
    if (remaining <= 30) {
      banglaMonthIndex = 11; // Choitro
      banglaDay = 30 - remaining + 1;
    } else {
      remaining -= 30;
      const falgunDays = isLeapYear ? 30 : 29;
      if (remaining <= falgunDays) {
        banglaMonthIndex = 10; // Falgun
        banglaDay = falgunDays - remaining + 1;
      } else {
        remaining -= falgunDays;
        if (remaining <= 30) {
          banglaMonthIndex = 9; // Magh
          banglaDay = 30 - remaining + 1;
        } else {
          banglaMonthIndex = 8; // Poush
          banglaDay = Math.max(1, 30 - (remaining - 30));
        }
      }
    }
  }

  return {
    year: banglaYear,
    monthName: BANGLA_MONTHS[banglaMonthIndex] || BANGLA_MONTHS[0],
    day: Math.max(1, banglaDay)
  };
}

/**
 * Format date respecting precision and missing fields
 * Rule: Never invent missing facts.
 */
export function formatGenealogyDate(
  date?: GenealogyDate,
  lang: 'bn' | 'en' | 'hi' | 'ar' = 'en'
): string {
  if (!date || (!date.year && !date.isoString)) {
    return lang === 'bn' ? 'তারিখ অজানা' : 'Date unknown';
  }

  const precision = date.precision || 'exact';
  let dateText = '';

  if (date.year && date.month && date.day) {
    const monthNamesEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthNamesBn = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    
    if (lang === 'bn') {
      dateText = `${toBanglaDigits(date.day)} ${monthNamesBn[date.month - 1]} ${toBanglaDigits(date.year)}`;
    } else {
      dateText = `${date.day} ${monthNamesEn[date.month - 1]} ${date.year}`;
    }
  } else if (date.year && date.month) {
    const monthNamesEn = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthNamesBn = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    
    if (lang === 'bn') {
      dateText = `${monthNamesBn[date.month - 1]} ${toBanglaDigits(date.year)}`;
    } else {
      dateText = `${monthNamesEn[date.month - 1]} ${date.year}`;
    }
  } else if (date.year) {
    dateText = lang === 'bn' ? `${toBanglaDigits(date.year)} সাল` : `${date.year}`;
  } else {
    return lang === 'bn' ? 'তারিখ অজানা' : 'Date unknown';
  }

  // Precision qualifiers
  switch (precision) {
    case 'approximate':
      return lang === 'bn' ? `আনুমানিক ${dateText}` : `circa ${dateText}`;
    case 'estimated':
      return lang === 'bn' ? `অনুমিত ${dateText}` : `est. ${dateText}`;
    case 'before':
      return lang === 'bn' ? `${dateText}-এর পূর্বে` : `before ${dateText}`;
    case 'after':
      return lang === 'bn' ? `${dateText}-এর পরে` : `after ${dateText}`;
    case 'unknown':
      return lang === 'bn' ? 'তারিখ নিশ্চিত নয়' : 'Uncertain date';
    case 'exact':
    default:
      return dateText;
  }
}

/**
 * Format Bangla Calendar string if provided or calculated
 */
export function formatBanglaCalendarDate(date?: GenealogyDate): string | null {
  if (!date) return null;
  if (date.banglaDate?.year) {
    const day = date.banglaDate.day ? `${toBanglaDigits(date.banglaDate.day)} ` : '';
    const month = date.banglaDate.month ? `${date.banglaDate.month} ` : '';
    const year = `${toBanglaDigits(date.banglaDate.year)} বঙ্গাব্দ`;
    return `${day}${month}${year}`;
  }

  // If exact Gregorian is provided, auto compute Bangla calendar
  if (date.year && date.month && date.day) {
    const bg = gregorianToBangla(date.year, date.month, date.day);
    return `${toBanglaDigits(bg.day)} ${bg.monthName} ${toBanglaDigits(bg.year)} বঙ্গাব্দ`;
  }

  if (date.year) {
    return `${toBanglaDigits(date.year - 593)} বঙ্গাব্দ (আনুমানিক)`;
  }

  return null;
}

export const HIJRI_MONTHS = [
  'মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল আউয়াল', 'জমাদিউস সানি',
  'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ্জ'
];

/**
 * Format Hijri Date approximation from Gregorian
 */
export function formatHijriCalendarDate(date?: GenealogyDate): string | null {
  if (!date) return null;
  if (date.hijriDate?.year) {
    const day = date.hijriDate.day ? `${toBanglaDigits(date.hijriDate.day)} ` : '';
    const month = date.hijriDate.month ? `${date.hijriDate.month} ` : '';
    return `${day}${month}${toBanglaDigits(date.hijriDate.year)} হিজরী`;
  }
  if (date.year) {
    // Gregorian to Hijri approximation formula
    const hijriYear = Math.round((date.year - 622) * (33 / 32));
    return `${toBanglaDigits(hijriYear)} হিজরী (আনুমানিক)`;
  }
  return null;
}

/**
 * Format standard date with custom pattern and number system
 */
export function formatCustomDate(
  year?: number | null,
  month?: number | null,
  day?: number | null,
  format: 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'YYYY-MM-DD' = 'DD/MM/YYYY',
  numSystem: 'bengali' | 'english' = 'bengali'
): string {
  if (!year) return '';
  const yStr = String(year);
  const mStr = month ? String(month).padStart(2, '0') : '--';
  const dStr = day ? String(day).padStart(2, '0') : '--';

  let formatted = '';
  switch (format) {
    case 'MM/DD/YYYY':
      formatted = `${mStr}/${dStr}/${yStr}`;
      break;
    case 'YYYY-MM-DD':
      formatted = `${yStr}-${mStr}-${dStr}`;
      break;
    case 'DD/MM/YYYY':
    default:
      formatted = `${dStr}/${mStr}/${yStr}`;
      break;
  }

  if (numSystem === 'bengali') {
    return toBanglaDigits(formatted);
  }
  return formatted;
}

/**
 * Calculate age / lifespan safely without inventing exact figures
 */
export function calculateLifespan(
  birthDate?: GenealogyDate,
  deathDate?: GenealogyDate,
  isLiving: boolean = true,
  lang: 'bn' | 'en' | 'hi' | 'ar' = 'en'
): string | null {
  if (!birthDate?.year) return null;

  const currentYear = 2026;
  const endYear = (!isLiving && deathDate?.year) ? deathDate.year : (isLiving ? currentYear : null);

  if (!endYear) return null;

  const years = endYear - birthDate.year;
  if (years < 0) return null;

  const isApprox = birthDate.precision !== 'exact' || (deathDate && deathDate.precision !== 'exact');

  if (lang === 'bn') {
    const yrsText = toBanglaDigits(years);
    return isApprox ? `প্রায় ${yrsText} বছর` : `${yrsText} বছর`;
  }
  return isApprox ? `approx. ${years} yrs` : `${years} yrs`;
}
