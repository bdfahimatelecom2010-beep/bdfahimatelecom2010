/** Centralized, date-precise age calculations used by Card/Profile/Tree/Dashboard. */
export interface AgeResult { years: number; months: number; days: number }
function validDate(y?: number|null, m?: number|null, d?: number|null): Date | null {
  if (!y || y < 1) return null;
  const mm = m && m >= 1 && m <= 12 ? m : 1;
  const dd = d && d >= 1 && d <= 31 ? d : 1;
  const date = new Date(y, mm - 1, dd);
  if (date.getFullYear() !== y || date.getMonth() !== mm - 1 || date.getDate() !== dd) return null;
  return date;
}
export function calculateAge(birth?: { year?: number|null; month?: number|null; day?: number|null }, end: Date = new Date()): AgeResult | undefined {
  const start = validDate(birth?.year, birth?.month, birth?.day);
  if (!start || end < start) return undefined;
  let years = end.getFullYear() - start.getFullYear();
  let months = end.getMonth() - start.getMonth();
  let days = end.getDate() - start.getDate();
  if (days < 0) { months -= 1; days += new Date(end.getFullYear(), end.getMonth(), 0).getDate(); }
  if (months < 0) { years -= 1; months += 12; }
  return { years: Math.max(0, years), months: Math.max(0, months), days: Math.max(0, days) };
}
export function ageYears(birth?: { year?: number|null; month?: number|null; day?: number|null }, end?: Date): number | undefined { return calculateAge(birth, end)?.years; }
