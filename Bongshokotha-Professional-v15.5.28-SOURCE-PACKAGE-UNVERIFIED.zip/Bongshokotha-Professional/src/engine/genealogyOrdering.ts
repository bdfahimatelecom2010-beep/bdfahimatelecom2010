/**
 * Canonical genealogy ordering for BONGSHOKOTHA.
 *
 * IMPORTANT DOMAIN RULES
 * - birthOrder is LOCAL to siblings who share a parent/union.
 * - A married-in person's own birthOrder never controls their position in the
 *   spouse's birth-line. The spouse is displayed immediately after the
 *   birth-line member they are married to.
 * - Directory order is depth-first: a parent, then each child in sibling
 *   order, with the child's COMPLETE descendant branch before the next sibling.
 * - The same ordering engine can be reused by the directory, family tree,
 *   family book and exports that need genealogical presentation order.
 */

import { Member, MarriageRecord } from '../types/genealogy';
import { getValidatedMarriageChildIds } from './relationshipIntegrity';

const FALLBACK = 999999;

function compareBirthOrder(a: Member, b: Member): number {
  const ao = a.birthOrder ?? FALLBACK;
  const bo = b.birthOrder ?? FALLBACK;
  if (ao !== bo) return ao - bo;

  const ay = a.birth?.date?.year ?? 9999;
  const by = b.birth?.date?.year ?? 9999;
  if (ay !== by) return ay - by;

  const am = a.birth?.date?.month ?? 99;
  const bm = b.birth?.date?.month ?? 99;
  if (am !== bm) return am - bm;

  const ad = a.birth?.date?.day ?? 99;
  const bd = b.birth?.date?.day ?? 99;
  if (ad !== bd) return ad - bd;

  return a.id.localeCompare(b.id);
}

function compareMarriage(a: MarriageRecord, b: MarriageRecord): number {
  const status = (m: MarriageRecord) => m.status === 'current' ? 0 : 1;
  const statusDiff = status(a) - status(b);
  if (statusDiff) return statusDiff;

  const ay = a.marriageDate?.year ?? 9999;
  const by = b.marriageDate?.year ?? 9999;
  if (ay !== by) return ay - by;
  const am = a.marriageDate?.month ?? 99;
  const bm = b.marriageDate?.month ?? 99;
  if (am !== bm) return am - bm;
  const ad = a.marriageDate?.day ?? 99;
  const bd = b.marriageDate?.day ?? 99;
  if (ad !== bd) return ad - bd;
  return a.id.localeCompare(b.id);
}

/**
 * Returns a stable, recursive family-branch order for all visible members.
 * The returned array is the presentation order, not a database renumbering.
 */
export function getCanonicalGenealogyOrder(
  members: Member[],
  marriages: MarriageRecord[]
): string[] {
  if (!members.length) return [];

  const memberMap = new Map(members.map(m => [m.id, m]));
  const marriageByMember = new Map<string, MarriageRecord[]>();
  const childrenByParent = new Map<string, Set<string>>();

  const addChild = (parentId: string | undefined, childId: string) => {
    if (!parentId || !memberMap.has(parentId) || !memberMap.has(childId)) return;
    const set = childrenByParent.get(parentId) || new Set<string>();
    set.add(childId);
    childrenByParent.set(parentId, set);
  };

  for (const member of members) {
    addChild(member.fatherId, member.id);
    addChild(member.motherId, member.id);
  }

  for (const marriage of marriages) {
    if (!memberMap.has(marriage.husbandId) || !memberMap.has(marriage.wifeId)) continue;
    for (const id of [marriage.husbandId, marriage.wifeId]) {
      const list = marriageByMember.get(id) || [];
      list.push(marriage);
      marriageByMember.set(id, list);
    }
    for (const childId of getValidatedMarriageChildIds(marriage, members)) {
      addChild(marriage.husbandId, childId);
      addChild(marriage.wifeId, childId);
    }
  }

  for (const [id, list] of marriageByMember) {
    list.sort(compareMarriage);
    marriageByMember.set(id, list);
  }

  const birthLineChildren = (parentId: string): Member[] => {
    const ids = Array.from(childrenByParent.get(parentId) || []);
    return ids
      .map(id => memberMap.get(id))
      .filter((m): m is Member => Boolean(m))
      .filter(m => m.id !== parentId)
      .sort(compareBirthOrder);
  };

  const spouseList = (memberId: string): Member[] => {
    const ids: string[] = [];
    for (const marriage of marriageByMember.get(memberId) || []) {
      const spouseId = marriage.husbandId === memberId ? marriage.wifeId : marriage.husbandId;
      if (spouseId && memberMap.has(spouseId) && !ids.includes(spouseId)) ids.push(spouseId);
    }
    return ids.map(id => memberMap.get(id)!).filter(Boolean);
  };

  // A birth-line root has no known in-family biological parent and is not a
  // marriage-origin-only member. Independent roots are retained deterministically.
  const hasInFamilyParent = (m: Member) =>
    Boolean((m.fatherId && memberMap.has(m.fatherId)) || (m.motherId && memberMap.has(m.motherId)));

  const roots = members
    .filter(m => !hasInFamilyParent(m) && m.birthOrigin !== 'joined_by_marriage' && !m.marriageOrigin)
    .sort(compareBirthOrder);

  // If legacy/incomplete data has no obvious root, fall back to deterministic
  // members rather than dropping records from the directory.
  const fallbackRoots = roots.length ? roots : members.slice().sort(compareBirthOrder);

  const result: string[] = [];
  const visited = new Set<string>();

  const visit = (memberId: string, allowSpouse = true) => {
    if (visited.has(memberId) || !memberMap.has(memberId)) return;
    visited.add(memberId);
    result.push(memberId);

    // Spouses are presentation companions. Their own birth order is deliberately
    // ignored. They are placed immediately after the member they married.
    if (allowSpouse) {
      for (const spouse of spouseList(memberId)) {
        if (!visited.has(spouse.id)) {
          visited.add(spouse.id);
          result.push(spouse.id);
        }
      }
    }

    // CRITICAL: recurse through the entire first child's branch before moving
    // to the second child. This is the user's "বড় ভাইয়ের শাখা সম্পূর্ণ শেষ হবে,
    // তারপর ছোট ভাইয়ের শাখা শুরু হবে" rule.
    for (const child of birthLineChildren(memberId)) {
      visit(child.id, true);
    }
  };

  for (const root of fallbackRoots) visit(root.id, true);

  // Preserve disconnected/legacy records instead of hiding them.
  for (const member of members.slice().sort(compareBirthOrder)) {
    if (!visited.has(member.id)) visit(member.id, true);
  }

  return result;
}

export function sortMembersByCanonicalGenealogyOrder(
  members: Member[],
  marriages: MarriageRecord[]
): Member[] {
  const order = getCanonicalGenealogyOrder(members, marriages);
  const rank = new Map(order.map((id, index) => [id, index]));
  return members.slice().sort((a, b) => (rank.get(a.id) ?? FALLBACK) - (rank.get(b.id) ?? FALLBACK));
}
