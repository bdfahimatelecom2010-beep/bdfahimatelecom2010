import { Member, Gender, BirthOrigin } from '../types/genealogy';

export type MemberColorKey =
  | 'living-born-male' | 'deceased-born-male' | 'living-married-male' | 'deceased-married-male'
  | 'living-born-female' | 'deceased-born-female' | 'living-married-female' | 'deceased-married-female'
  | 'living-other' | 'deceased-other';

export interface MemberColorSpec {
  key: MemberColorKey;
  accent: string;
  soft: string;
  border: string;
  text: string;
  bn: string;
  en: string;
}

const COLORS: Record<MemberColorKey, MemberColorSpec> = {
  'living-born-male': { key:'living-born-male', accent:'#2563eb', soft:'#eff6ff', border:'#93c5fd', text:'#1e40af', bn:'জীবিত • জন্মসূত্রে • পুরুষ', en:'Living • Birth-line • Male' },
  'deceased-born-male': { key:'deceased-born-male', accent:'#475569', soft:'#f1f5f9', border:'#94a3b8', text:'#334155', bn:'মৃত • জন্মসূত্রে • পুরুষ', en:'Deceased • Birth-line • Male' },
  'living-married-male': { key:'living-married-male', accent:'#059669', soft:'#ecfdf5', border:'#6ee7b7', text:'#047857', bn:'জীবিত • বিবাহসূত্রে • পুরুষ', en:'Living • Married-in • Male' },
  'deceased-married-male': { key:'deceased-married-male', accent:'#065f46', soft:'#ecfdf5', border:'#34d399', text:'#064e3b', bn:'মৃত • বিবাহসূত্রে • পুরুষ', en:'Deceased • Married-in • Male' },
  'living-born-female': { key:'living-born-female', accent:'#db2777', soft:'#fdf2f8', border:'#f9a8d4', text:'#be185d', bn:'জীবিত • জন্মসূত্রে • নারী', en:'Living • Birth-line • Female' },
  'deceased-born-female': { key:'deceased-born-female', accent:'#9f1239', soft:'#fff1f2', border:'#fda4af', text:'#881337', bn:'মৃত • জন্মসূত্রে • নারী', en:'Deceased • Birth-line • Female' },
  'living-married-female': { key:'living-married-female', accent:'#d97706', soft:'#fffbeb', border:'#fcd34d', text:'#b45309', bn:'জীবিত • বিবাহসূত্রে • নারী', en:'Living • Married-in • Female' },
  'deceased-married-female': { key:'deceased-married-female', accent:'#92400e', soft:'#fff7ed', border:'#fdba74', text:'#7c2d12', bn:'মৃত • বিবাহসূত্রে • নারী', en:'Deceased • Married-in • Female' },
  'living-other': { key:'living-other', accent:'#7c3aed', soft:'#f5f3ff', border:'#c4b5fd', text:'#6d28d9', bn:'জীবিত • অন্যান্য', en:'Living • Other' },
  'deceased-other': { key:'deceased-other', accent:'#4b5563', soft:'#f9fafb', border:'#9ca3af', text:'#374151', bn:'মৃত • অন্যান্য', en:'Deceased • Other' },
};

export function getMemberColor(member: Pick<Member, 'gender'|'isLiving'|'birthOrigin'|'marriageOrigin'>): MemberColorSpec {
  const marriedIn = member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin;
  const life = member.isLiving ? 'living' : 'deceased';
  if (member.gender === 'male') return COLORS[`${life}-${marriedIn ? 'married' : 'born'}-male` as MemberColorKey];
  if (member.gender === 'female') return COLORS[`${life}-${marriedIn ? 'married' : 'born'}-female` as MemberColorKey];
  return COLORS[`${life}-other` as MemberColorKey];
}

export const MEMBER_COLOR_LEGEND = Object.values(COLORS);
