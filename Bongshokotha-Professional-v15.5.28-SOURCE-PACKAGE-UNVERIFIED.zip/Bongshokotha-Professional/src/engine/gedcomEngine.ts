/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * GEDCOM 5.5.1 Universal Genealogical Interoperability Engine (Part 4)
 * 
 * Features:
 * - GEDCOM 5.5.1 standard export with UTF-8 encoding
 * - Non-destructive parser with preview and conflict protection
 * - Lineage preserves Bengali names, Kromik numbers, and NID in custom tags
 */

import { Member, MarriageRecord, Family, Gender } from '../types/genealogy';

export function exportToGedcom(
  family: Family,
  members: Member[],
  marriages: MarriageRecord[]
): string {
  const lines: string[] = [];
  const today = new Date();
  const dateStr = today.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase();

  // Header
  lines.push('0 HEAD');
  lines.push('1 SOUR BONGSHOKOTHA');
  lines.push('2 VERS 1.0.0');
  lines.push('2 NAME BONGSHOKOTHA / বংশকথা');
  lines.push('1 DEST ANY');
  lines.push(`1 DATE ${dateStr}`);
  lines.push('1 GEDC');
  lines.push('2 VERS 5.5.1');
  lines.push('2 FORM LINEAGE-LINKED');
  lines.push('1 CHAR UTF-8');
  lines.push('1 LANG Bengali');

  // Submitters
  lines.push('0 @SUBM1@ SUBM');
  lines.push(`1 NAME ${family.name} Chronicler`);

  // Build maps for fast lookups
  const memberChildFamilies = new Map<string, string>();
  const memberSpouseFamilies = new Map<string, string[]>();

  // Assign FAM IDs
  marriages.forEach((mar, idx) => {
    const famId = `@F${idx + 1}@`;
    if (mar.husbandId) {
      const list = memberSpouseFamilies.get(mar.husbandId) || [];
      list.push(famId);
      memberSpouseFamilies.set(mar.husbandId, list);
    }
    if (mar.wifeId) {
      const list = memberSpouseFamilies.get(mar.wifeId) || [];
      list.push(famId);
      memberSpouseFamilies.set(mar.wifeId, list);
    }
  });

  // Map children to parent marriage FAM
  members.forEach(m => {
    if (m.fatherId || m.motherId) {
      const parentMarriageIndex = marriages.findIndex(mar =>
        (m.fatherId && (mar.husbandId === m.fatherId || mar.wifeId === m.fatherId)) ||
        (m.motherId && (mar.wifeId === m.motherId || mar.husbandId === m.motherId))
      );
      if (parentMarriageIndex !== -1) {
        memberChildFamilies.set(m.id, `@F${parentMarriageIndex + 1}@`);
      }
    }
  });

  // Export Individuals (INDI)
  members.forEach((m, idx) => {
    const indiId = `@I${idx + 1}@`;
    lines.push(`0 ${indiId} INDI`);
    lines.push(`1 NAME ${m.fullName || m.banglaName || 'Unknown'}`);
    if (m.banglaName) {
      lines.push(`2 _BNAME ${m.banglaName}`);
    }
    if (m.nickname) {
      lines.push(`2 NICK ${m.nickname}`);
    }

    // Gender
    const sexChar = m.gender === 'male' ? 'M' : m.gender === 'female' ? 'F' : 'U';
    lines.push(`1 SEX ${sexChar}`);

    // Birth
    if (m.birth) {
      lines.push('1 BIRT');
      if (m.birth.date?.year) {
        const d = m.birth.date;
        const bDateStr = [d.day, d.month, d.year].filter(Boolean).join(' ');
        lines.push(`2 DATE ${bDateStr}`);
      }
      if (m.birth.place?.village || m.birth.place?.district) {
        const placeStr = [m.birth.place.village, m.birth.place.upazila, m.birth.place.district]
          .filter(Boolean)
          .join(', ');
        lines.push(`2 PLAC ${placeStr}`);
      }
    }

    // Death
    if (m.death?.isDeceased) {
      lines.push('1 DEAT Y');
      if (m.death.date?.year) {
        const d = m.death.date;
        const dDateStr = [d.day, d.month, d.year].filter(Boolean).join(' ');
        lines.push(`2 DATE ${dDateStr}`);
      }
      if (m.death.place?.village || m.death.place?.district) {
        const placeStr = [m.death.place.village, m.death.place.district].filter(Boolean).join(', ');
        lines.push(`2 PLAC ${placeStr}`);
      }
      if (m.death.burialPlace) {
        lines.push(`2 NOTE Resting place: ${m.death.burialPlace}`);
      }
    }

    // Permanent Kromik & Custom identifiers
    lines.push(`1 _BONGSHO_ID ${m.id}`);
    lines.push(`1 _KROMIK ${m.serialNumber}`);
    if (m.birthOrder != null) lines.push(`1 _BIRTH_ORDER ${m.birthOrder}`);
    lines.push(`1 _ORIGIN ${m.birthOrigin || 'unknown'}`);
    if (m.marriageOrigin != null) lines.push(`1 _MARRIAGE_ORIGIN ${m.marriageOrigin ? 'Y' : 'N'}`);
    if (m.generationMode) lines.push(`1 _GEN_MODE ${m.generationMode}`);
    if (m.computedGeneration != null) lines.push(`1 _GENERATION ${m.computedGeneration}`);
    if (m.originalLineageNote) lines.push(`1 _LINEAGE_NOTE ${m.originalLineageNote.replace(/\n/g, ' ')}`);
    if (m.branchId) lines.push(`1 _BRANCH ${m.branchId}`);
    if (m.identityDocs?.nidNumber) lines.push(`1 _NID ${m.identityDocs.nidNumber}`);
    if (m.identityDocs?.birthRegistrationNumber) lines.push(`1 _BRN ${m.identityDocs.birthRegistrationNumber}`);

    // Biography
    if (m.biography) {
      lines.push(`1 NOTE ${m.biography.replace(/\n/g, ' ')}`);
    }

    // Family child link
    const famc = memberChildFamilies.get(m.id);
    if (famc) {
      lines.push(`1 FAMC ${famc}`);
    }

    // Family spouse link
    const famsList = memberSpouseFamilies.get(m.id) || [];
    famsList.forEach(fams => {
      lines.push(`1 FAMS ${fams}`);
    });
  });

  // Export Families (FAM)
  marriages.forEach((mar, idx) => {
    const famId = `@F${idx + 1}@`;
    lines.push(`0 ${famId} FAM`);

    const husbandIndex = members.findIndex(m => m.id === mar.husbandId);
    if (husbandIndex !== -1) {
      lines.push(`1 HUSB @I${husbandIndex + 1}@`);
    }

    const wifeIndex = members.findIndex(m => m.id === mar.wifeId);
    if (wifeIndex !== -1) {
      lines.push(`1 WIFE @I${wifeIndex + 1}@`);
    }

    // Marriage Details
    lines.push('1 MARR');
    if (mar.marriageDate?.year) {
      const d = mar.marriageDate;
      const mDateStr = [d.day, d.month, d.year].filter(Boolean).join(' ');
      lines.push(`2 DATE ${mDateStr}`);
    }
    if (mar.status === 'divorced') {
      lines.push('1 DIV');
    }

    // Children of this marriage
    const children = members.filter(m =>
      (m.fatherId === mar.husbandId && m.motherId === mar.wifeId) ||
      (m.fatherId === mar.husbandId && !m.motherId) ||
      (m.motherId === mar.wifeId && !m.fatherId)
    );

    children.forEach(child => {
      const childIndex = members.findIndex(m => m.id === child.id);
      if (childIndex !== -1) {
        lines.push(`1 CHIL @I${childIndex + 1}@`);
      }
    });
  });

  lines.push('0 TRLR');
  return lines.join('\n');
}

export interface GedcomParseResult {
  members: Partial<Member>[];
  marriages: Partial<MarriageRecord>[];
  stats: {
    totalIndividuals: number;
    totalFamilies: number;
  };
}

export function parseGedcom(gedcomText: string): GedcomParseResult {
  const lines = gedcomText.split(/\r?\n/);
  const rawIndis = new Map<string, any>();
  const rawFams = new Map<string, any>();

  let currentEntity: any = null;
  let currentTag = '';
  let entityType: 'INDI' | 'FAM' | null = null;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    const parts = trimmed.split(' ');
    const level = parts[0];

    if (level === '0') {
      if (currentEntity && entityType === 'INDI') {
        rawIndis.set(currentEntity.id, currentEntity);
      } else if (currentEntity && entityType === 'FAM') {
        rawFams.set(currentEntity.id, currentEntity);
      }

      if (parts[2] === 'INDI') {
        entityType = 'INDI';
        currentEntity = { id: parts[1], names: [], notes: [] };
      } else if (parts[2] === 'FAM') {
        entityType = 'FAM';
        currentEntity = { id: parts[1], children: [] };
      } else {
        entityType = null;
        currentEntity = null;
      }
      continue;
    }

    if (!currentEntity) continue;

    if (level === '1') {
      currentTag = parts[1];
      const val = parts.slice(2).join(' ');

      if (entityType === 'INDI') {
        if (currentTag === 'NAME') currentEntity.name = val.replace(/\//g, '').trim();
        else if (currentTag === '_BNAME') currentEntity.banglaName = val;
        else if (currentTag === 'SEX') currentEntity.sex = val;
        else if (currentTag === '_KROMIK') currentEntity.kromik = val;
        else if (currentTag === '_BIRTH_ORDER') currentEntity.birthOrder = val;
        else if (currentTag === '_ORIGIN') currentEntity.birthOrigin = val;
        else if (currentTag === '_MARRIAGE_ORIGIN') currentEntity.marriageOrigin = val === 'Y';
        else if (currentTag === '_GEN_MODE') currentEntity.generationMode = val;
        else if (currentTag === '_GENERATION') currentEntity.computedGeneration = val;
        else if (currentTag === '_LINEAGE_NOTE') currentEntity.originalLineageNote = val;
        else if (currentTag === '_BONGSHO_ID') currentEntity.personId = val;
        else if (currentTag === '_NID') currentEntity.nid = val;
        else if (currentTag === '_BRN') currentEntity.brn = val;
        else if (currentTag === 'NOTE') currentEntity.notes.push(val);
      } else if (entityType === 'FAM') {
        if (currentTag === 'HUSB') currentEntity.husband = val;
        else if (currentTag === 'WIFE') currentEntity.wife = val;
        else if (currentTag === 'CHIL') currentEntity.children.push(val);
      }
    } else if (level === '2') {
      const subTag = parts[1];
      const val = parts.slice(2).join(' ');

      if (entityType === 'INDI') {
        if (currentTag === 'BIRT' && subTag === 'DATE') currentEntity.birthDate = val;
        if (currentTag === 'BIRT' && subTag === 'PLAC') currentEntity.birthPlace = val;
        if (currentTag === 'DEAT' && subTag === 'DATE') currentEntity.deathDate = val;
        if (currentTag === 'DEAT' && subTag === 'PLAC') currentEntity.deathPlace = val;
      } else if (entityType === 'FAM') {
        if (currentTag === 'MARR' && subTag === 'DATE') currentEntity.marrDate = val;
      }
    }
  }

  // Push final entity
  if (currentEntity && entityType === 'INDI') {
    rawIndis.set(currentEntity.id, currentEntity);
  } else if (currentEntity && entityType === 'FAM') {
    rawFams.set(currentEntity.id, currentEntity);
  }

  // Assemble into Members
  const members: Partial<Member>[] = [];
  const indiIdToUuid = new Map<string, string>();

  rawIndis.forEach((ind, indiKey) => {
    const uuid = ind.personId || `indi-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    indiIdToUuid.set(indiKey, uuid);

    const gender: Gender = ind.sex === 'M' ? 'male' : ind.sex === 'F' ? 'female' : 'other';
    const birthYear = ind.birthDate ? parseInt(ind.birthDate.match(/\d{4}/)?.[0] || '0', 10) : null;
    const deathYear = ind.deathDate ? parseInt(ind.deathDate.match(/\d{4}/)?.[0] || '0', 10) : null;

    const isDeceased = Boolean(ind.deathDate || ind.deathPlace);

    members.push({
      id: uuid,
      fullName: ind.name || 'Unknown Relative',
      banglaName: ind.banglaName || ind.name || 'অজ্ঞাত আত্মীয়',
      englishName: ind.name || 'Unknown Relative',
      serialNumber: ind.kromik || 'GEN-01',
      birthOrder: ind.birthOrder != null && ind.birthOrder !== '' ? Number(ind.birthOrder) : undefined,
      gender,
      isLiving: !isDeceased,
      birth: {
        date: { year: birthYear, precision: birthYear ? 'exact' : 'unknown' },
        place: { village: ind.birthPlace }
      },
      death: {
        isDeceased,
        date: { year: deathYear, precision: deathYear ? 'exact' : 'unknown' },
        place: { village: ind.deathPlace }
      },
      birthOrigin: ind.birthOrigin || (ind.marriageOrigin ? 'joined_by_marriage' : 'unknown'),
      marriageOrigin: Boolean(ind.marriageOrigin),
      generationMode: ind.generationMode === 'manual' ? 'manual' : 'automatic',
      computedGeneration: ind.computedGeneration ? Number(ind.computedGeneration) : undefined,
      originalLineageNote: ind.originalLineageNote,
      identityDocs: {
        nidNumber: ind.nid,
        birthRegistrationNumber: ind.brn,
        verificationStatus: 'unverified'
      },
      biography: ind.notes.join('\n')
    });
  });

  // Assemble Marriages & Parent Links
  const marriages: Partial<MarriageRecord>[] = [];
  rawFams.forEach((fam) => {
    const husbUuid = indiIdToUuid.get(fam.husband);
    const wifeUuid = indiIdToUuid.get(fam.wife);

    if (husbUuid || wifeUuid) {
      marriages.push({
        id: `mar-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        serialNumber: `MR-${marriages.length + 1}`,
        husbandId: husbUuid || '',
        wifeId: wifeUuid || '',
        marriageDate: { precision: 'unknown' },
        marriagePlace: {},
        status: 'current',
        childrenIds: []
      });
    }

    // Set parent links for children
    (fam.children || []).forEach((cKey: string) => {
      const childUuid = indiIdToUuid.get(cKey);
      if (childUuid) {
        const childMember = members.find(m => m.id === childUuid);
        if (childMember) {
          if (husbUuid) childMember.fatherId = husbUuid;
          if (wifeUuid) childMember.motherId = wifeUuid;
        }
      }
    });
  });

  return {
    members,
    marriages,
    stats: {
      totalIndividuals: members.length,
      totalFamilies: marriages.length
    }
  };
}
