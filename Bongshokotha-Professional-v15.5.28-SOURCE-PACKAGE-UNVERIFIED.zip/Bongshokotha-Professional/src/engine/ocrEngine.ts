/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Offline Document OCR, Image Enhancement & Genealogical Intelligence Engine
 * 
 * Capabilities:
 * 1. Image Enhancement (Grayscale, Adaptive Binarization, Contrast, Sharpen)
 * 2. Offline-First OCR with English & Bengali language workers
 * 3. Bengali Land & Family Document Dictionary (পিতা, পিং, জং, খতিয়ান, দাগ, মৌজা, ইত্যাদি)
 * 4. Structured Field Detection (NID, Birth Cert, Land Deed, Khatian)
 * 5. Duplicate Detection with Match Confidence
 * 6. Conflict Detection (Existing vs Extracted) for Non-Destructive Resolution
 */

import { createWorker, Worker } from 'tesseract.js';
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.mjs';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
(pdfjsLib as any).GlobalWorkerOptions.workerSrc = pdfWorkerUrl;
import {
  Member,
  ExtractedDocumentFields,
  FieldConflict,
  DuplicateCandidate
} from '../types/genealogy';
import { toBanglaDigits } from './banglaCalendar';
export { parseDocumentFields, parseDocumentDate, mergeExtractedDocumentFields, buildExtractedFieldCandidates } from './ocrFieldParser';
import { parseDocumentFields, mergeExtractedDocumentFields } from './ocrFieldParser';

/**
 * 1. EXTENSIBLE BENGALI FAMILY & LAND DOCUMENT DICTIONARY
 */
export const BENGALI_DOCUMENT_DICTIONARY = {
  parents: [
    { key: 'father', terms: ['পিতা', 'পিং', 'পিং-', 'পিতাঃ', 'পিতার নাম', 'Father', "Father's Name"] },
    { key: 'mother', terms: ['মাতা', 'মাতাঃ', 'মাতার নাম', 'Mother', "Mother's Name"] }
  ],
  spouses: [
    { key: 'husband', terms: ['জং', 'জং-', 'জওজে', 'জজে', 'স্বামী', 'স্বামীর নাম', 'Husband'] },
    { key: 'wife', terms: ['স্ত্রী', 'স্ত্রীর নাম', 'Wife'] }
  ],
  identity: [
    { key: 'nid', terms: ['জাতীয় পরিচয়পত্র', 'জাতীয় পরিচয়পত্র', 'এনআইডি', 'NID', 'NID No', 'National ID Card', 'Identity Card'] },
    { key: 'passport', terms: ['Passport', 'PASSPORT', 'Passport No', 'Passport Number', 'পাসপোর্ট'] },
    { key: 'brn', terms: ['জন্ম নিবন্ধন', 'জন্ম ও মৃত্যু নিবন্ধন', 'BRN', 'Birth Registration', 'Birth Certificate', 'ব্যক্তিগত পরিচিতি'] },
    { key: 'dob', terms: ['জন্ম তারিখ', 'Date of Birth', 'DOB', 'জন্ম সন'] }
  ],
  landTerms: [
    { key: 'khatian', terms: ['খতিয়ান', 'খতিয়ান', 'খতিয়ান নং', 'খতিয়ান নং', 'সি.এস', 'এস.এ', 'আর.এস', 'বি.এস', 'সিটি জরিপ'] },
    { key: 'dag', terms: ['দাগ', 'দাগ নং', 'দাগ নম্বর', 'প্লট নং'] },
    { key: 'mouza', terms: ['মৌজা', 'মৌজাঃ', 'জে.এল নং', 'জে এল নম্বর', 'পরগনা'] },
    { key: 'deed', terms: ['দলিল', 'দলিল নং', 'দলিল নম্বর', 'রেজিস্ট্রি', 'সাব-রেজিস্ট্রি', 'সাব রেজিস্ট্রি অফিস'] },
    { key: 'parties', terms: ['দাতা', 'গ্রহীতা', 'খরিদদার', 'মালিক', 'দখলকার', 'অংশীদার', 'ওয়ারিশ'] },
    { key: 'area', terms: ['জমির পরিমাণ', 'শতাংশ', 'একর', 'কাঠা', 'বিঘা', 'ছটাক'] }
  ],
  demise: [
    { key: 'death', terms: ['মৃত্যু তারিখ', 'ইন্তেকাল', 'মরহুম', 'মরহুমা', 'স্বর্গীয়', 'প্রয়াত', 'মৃত্যু স্থান', 'কবরস্থান', 'সমাধিস্থল'] }
  ]
};

/**
 * 2. IMAGE ENHANCEMENT SUITE (Canvas-Based Offline Operations)
 */
export interface ImageEnhancementOptions {
  contrast?: number; // -100 to 100
  brightness?: number; // -100 to 100
  binarize?: boolean; // Thresholding for yellowed old paper / deeds
  thresholdLevel?: number; // 0 - 255 (default 128)
  grayscale?: boolean;
  sharpen?: boolean;
  rotation?: number; // 0, 90, 180, 270
}

export async function enhanceDocumentImage(
  imageSource: string | HTMLImageElement,
  options: ImageEnhancementOptions = {}
): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = typeof imageSource === 'string' ? new Image() : imageSource;
    if (typeof imageSource === 'string') {
      img.crossOrigin = 'anonymous';
      img.src = imageSource;
    }

    const process = () => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(typeof imageSource === 'string' ? imageSource : img.src);
          return;
        }

        const rotation = options.rotation || 0;
        if (rotation === 90 || rotation === 270) {
          canvas.width = img.naturalHeight || img.height;
          canvas.height = img.naturalWidth || img.width;
        } else {
          canvas.width = img.naturalWidth || img.width;
          canvas.height = img.naturalHeight || img.height;
        }

        // Apply rotation
        ctx.save();
        if (rotation === 90) {
          ctx.translate(canvas.width, 0);
          ctx.rotate((90 * Math.PI) / 180);
        } else if (rotation === 180) {
          ctx.translate(canvas.width, canvas.height);
          ctx.rotate((180 * Math.PI) / 180);
        } else if (rotation === 270) {
          ctx.translate(0, canvas.height);
          ctx.rotate((270 * Math.PI) / 180);
        }

        ctx.drawImage(img, 0, 0);
        ctx.restore();

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;

        const contrast = options.contrast !== undefined ? options.contrast : 25; // mild default boost
        const brightness = options.brightness !== undefined ? options.brightness : 10;
        const factor = (259 * (contrast + 255)) / (255 * (259 - contrast));
        const threshold = options.thresholdLevel ?? 135;

        for (let i = 0; i < data.length; i += 4) {
          let r = data[i];
          let g = data[i + 1];
          let b = data[i + 2];

          // Brightness
          r += brightness;
          g += brightness;
          b += brightness;

          // Contrast
          r = factor * (r - 128) + 128;
          g = factor * (g - 128) + 128;
          b = factor * (b - 128) + 128;

          // Grayscale / Luminance
          const gray = 0.299 * r + 0.587 * g + 0.114 * b;

          if (options.binarize) {
            // Adaptive Binarization for aged historical manuscripts
            const v = gray > threshold ? 255 : 0;
            data[i] = v;
            data[i + 1] = v;
            data[i + 2] = v;
          } else if (options.grayscale) {
            data[i] = Math.min(255, Math.max(0, gray));
            data[i + 1] = Math.min(255, Math.max(0, gray));
            data[i + 2] = Math.min(255, Math.max(0, gray));
          } else {
            data[i] = Math.min(255, Math.max(0, r));
            data[i + 1] = Math.min(255, Math.max(0, g));
            data[i + 2] = Math.min(255, Math.max(0, b));
          }
        }

        ctx.putImageData(imageData, 0, 0);
        resolve(canvas.toDataURL('image/jpeg', 0.92));
      } catch (err) {
        console.error('Image enhancement error:', err);
        resolve(typeof imageSource === 'string' ? imageSource : img.src);
      }
    };

    if (img.complete) {
      process();
    } else {
      img.onload = () => process();
      img.onerror = () => resolve(typeof imageSource === 'string' ? imageSource : '');
    }
  });
}

/**
 * 3. OCR EXECUTION CONTROLLER (Worker-backed with cancellation and explicit failure handling)
 */
/** Create a focused crop using normalized coordinates. This is used only for
 * document-specific second-pass OCR; the original source is never modified. */
async function cropOcrRegion(source: string, x: number, y: number, width: number, height: number): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const sx = Math.max(0, Math.floor(img.naturalWidth * x));
        const sy = Math.max(0, Math.floor(img.naturalHeight * y));
        const sw = Math.max(1, Math.min(img.naturalWidth - sx, Math.floor(img.naturalWidth * width)));
        const sh = Math.max(1, Math.min(img.naturalHeight - sy, Math.floor(img.naturalHeight * height)));
        const scale = 2;
        const canvas = document.createElement('canvas');
        canvas.width = sw * scale;
        canvas.height = sh * scale;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(source);
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/png'));
      } catch {
        resolve(source);
      }
    };
    img.onerror = () => resolve(source);
    img.src = source;
  });
}

async function prepareNidFocusedSources(source: string): Promise<string[]> {
  // Bangladesh NID layouts place the identity block near the upper-middle area
  // and the address block on the lower reverse side. These are supplemental
  // passes only; full-document OCR remains authoritative for document detection.
  const identity = await cropOcrRegion(source, 0.24, 0.12, 0.56, 0.40);
  const address = await cropOcrRegion(source, 0.05, 0.52, 0.90, 0.31);
  return [identity, address];
}

export interface OcrProgressCallback {
  (status: string, progressPercent: number): void;
}

export interface OcrResult {
  text: string;
  confidence: number;
  extractedFields: ExtractedDocumentFields;
}

let activeTesseractWorker: Worker | null = null;

/** Render every PDF page locally so multipage documents are fully OCR-processed. */
async function pdfDataUrlToImages(dataUrl: string): Promise<string[]> {
  const base64 = dataUrl.split(',')[1] || dataUrl;
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const pdf = await (pdfjsLib as any).getDocument({ data: bytes }).promise;
  if (!pdf.numPages) throw new Error('PDF has no readable pages.');
  const images: string[] = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
    const page = await pdf.getPage(pageNumber);
    const viewport = page.getViewport({ scale: 2.2 });
    const canvas = document.createElement('canvas');
    canvas.width = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error(`PDF page ${pageNumber} canvas is unavailable.`);
    await page.render({ canvasContext: ctx, viewport }).promise;
    images.push(canvas.toDataURL('image/png'));
  }
  return images;
}

/** Backward-compatible single-source helper. For PDF this returns page 1. */
export async function prepareOcrSource(source: string, mimeType?: string): Promise<string> {
  const sources = await prepareOcrSources(source, mimeType);
  return sources[0];
}

/** Prepare one or many OCR images. Images remain one source; PDFs become all pages. */
export async function prepareOcrSources(source: string, mimeType?: string): Promise<string[]> {
  const isPdf = mimeType === 'application/pdf' || /^data:application\/pdf/i.test(source);
  return isPdf ? pdfDataUrlToImages(source) : [source];
}

export async function runDocumentOcr(
  imageSource: string,
  language: 'ben' | 'eng' | 'ben+eng' = 'ben+eng',
  onProgress?: OcrProgressCallback,
  abortSignal?: AbortSignal,
  mimeType?: string
): Promise<OcrResult> {
  onProgress?.('প্রস্তুতি ও প্রাক-প্রক্রিয়াকরণ...', 10);

  // PDFs are rendered locally; no server is needed for document conversion.
  const ocrSources = await prepareOcrSources(imageSource, mimeType);
  const enhancedImages: string[] = [];
  for (const source of ocrSources) {
    enhancedImages.push(await enhanceDocumentImage(source, { contrast: 30, brightness: 10, grayscale: true }));
  }

  if (abortSignal?.aborted) {
    throw new Error('OCR operation cancelled by user');
  }

  onProgress?.('অপটিক্যাল ক্যারেক্টার রিকগনিশন (OCR) লোড হচ্ছে...', 25);

  let rawText = '';
  let avgConfidence = 85;

  try {
    // Tesseract.js client worker
    const worker = await createWorker(language === 'ben' ? 'ben' : language === 'eng' ? 'eng' : 'ben+eng', 1, {
      langPath: '/tessdata',
      gzip: true,
      logger: m => {
        if (m.status === 'recognizing text' && m.progress !== undefined) {
          onProgress?.(
            `হরফ বিশ্লেষণ ও বর্ণ শনাক্তকরণ (${Math.round(m.progress * 100)}%)...`,
            Math.round(25 + m.progress * 55)
          );
        }
      }
    });

    activeTesseractWorker = worker;

    // Sparse/label-heavy identity cards are substantially better read with PSM 11.
    // This also preserves separate Bengali labels such as নাম, পিতা and মাতা.
    try {
      await worker.setParameters({ tessedit_pageseg_mode: '11', preserve_interword_spaces: '1' } as any);
    } catch {
      // Older/alternate Tesseract builds may not expose these parameters; default mode is safe.
    }

    if (abortSignal?.aborted) {
      await worker.terminate();
      throw new Error('OCR operation cancelled');
    }

    const pageTexts: string[] = [];
    const pageConfidences: number[] = [];
    for (let i = 0; i < enhancedImages.length; i++) {
      if (abortSignal?.aborted) throw new Error('OCR operation cancelled');
      onProgress?.(`পৃষ্ঠা ${i + 1}/${enhancedImages.length} পড়া হচ্ছে...`, Math.round(25 + ((i + 1) / enhancedImages.length) * 55));
      const { data } = await worker.recognize(enhancedImages[i]);
      pageTexts.push(data.text || '');
      pageConfidences.push(Number(data.confidence || 80));
    }

    rawText = pageTexts.join('\n\n===== PAGE BREAK =====\n\n');
    avgConfidence = Math.round(pageConfidences.reduce((a, b) => a + b, 0) / Math.max(1, pageConfidences.length));

    // NID-specific second pass: when the first pass identifies an NID but misses
    // core fields, read focused identity/address regions as well. This fixes the
    // common case where the Bengali labels are tiny while the MRZ dominates OCR.
    const firstPassFields = parseDocumentFields(rawText, avgConfidence);
    // OCR may miss the Bengali/English title on a small or combined front/back image.
    // The Bangladesh NID MRZ starts with I<BGD, so treat that as a strong NID hint
    // and allow focused crops even when the first parser pass returned `general`.
    const hasNidSignal = firstPassFields.documentKind === 'nid' ||
      /I\s*<\s*BGD|জাত[ীি]য়\s*পরিচয়পত্র|জাত[ীি]য়\s*পরিচয়পত্র|national\s+id|\bnid\b|identity\s+card/i.test(rawText);
    const needsNidFocus = hasNidSignal &&
      (!firstPassFields.fullNameBn || !firstPassFields.fatherName || !firstPassFields.motherName || !firstPassFields.address || !firstPassFields.dateOfBirth);
    if (needsNidFocus) {
      const focusedTexts: string[] = [];
      for (let i = 0; i < enhancedImages.length; i++) {
        const focused = await prepareNidFocusedSources(enhancedImages[i]);
        for (let j = 0; j < focused.length; j++) {
          if (abortSignal?.aborted) throw new Error('OCR operation cancelled');
          onProgress?.(`জাতীয় পরিচয়পত্রের নির্দিষ্ট অংশ পড়া হচ্ছে (${i + 1}/${enhancedImages.length}, ${j + 1}/2)...`, 82);
          const { data } = await worker.recognize(focused[j]);
          if (data.text) focusedTexts.push(data.text);
        }
      }
      if (focusedTexts.length) rawText += '\n\n===== NID FOCUSED OCR =====\n\n' + focusedTexts.join('\n\n===== NID REGION =====\n\n');
    }

    await worker.terminate();
    activeTesseractWorker = null;
  } catch (err: any) {
    console.warn('Tesseract worker error or offline worker fallback:', err);
    // If browser blocks worker script or was cancelled
    if (abortSignal?.aborted) throw err;

    throw new Error(`OCR engine could not complete: ${err instanceof Error ? err.message : String(err)}`);
  }

  onProgress?.('পারিবারিক তথ্য ও দলিল কাঠামো বিশ্লেষণ...', 90);

  // Field detection on extracted text
  const extractedFields = parseDocumentFields(rawText, avgConfidence);

  onProgress?.('সম্পন্ন হয়েছে!', 100);

  return {
    text: rawText,
    confidence: avgConfidence,
    extractedFields
  };
}

/**
 * OCR several files as one document session. This is intentionally sequential so
 * mobile devices do not create multiple Tesseract workers at once. NID front/back
 * can therefore be selected together and merged into one reviewable record.
 */
export async function runDocumentOcrBatch(
  sources: Array<{ source: string; mimeType?: string; name?: string }>,
  language: 'ben' | 'eng' | 'ben+eng' = 'ben+eng',
  onProgress?: OcrProgressCallback,
  abortSignal?: AbortSignal
): Promise<OcrResult> {
  if (!sources.length) throw new Error('No OCR sources supplied.');
  const results: OcrResult[] = [];
  for (let i = 0; i < sources.length; i++) {
    if (abortSignal?.aborted) throw new Error('OCR operation cancelled');
    const source = sources[i];
    const result = await runDocumentOcr(
      source.source,
      language,
      (status, pct) => onProgress?.(`ডকুমেন্ট ${i + 1}/${sources.length}: ${status}`, Math.round(((i + pct / 100) / sources.length) * 100)),
      abortSignal,
      source.mimeType
    );
    results.push(result);
  }
  const merged = mergeExtractedDocumentFields(results.map(r => r.extractedFields));
  return {
    text: results.map((r, i) => `===== DOCUMENT ${i + 1}${sources[i].name ? `: ${sources[i].name}` : ''} =====\n${r.text}`).join('\n\n'),
    confidence: merged.confidence,
    extractedFields: merged
  };
}

export function cancelActiveOcr() {
  if (activeTesseractWorker) {
    try {
      activeTesseractWorker.terminate();
    } catch (e) {
      console.error(e);
    }
    activeTesseractWorker = null;
  }
}

/**
 * 5. DUPLICATE DETECTION ALGORITHM
 * Compares extracted record against existing family members
 */
export function findDuplicateCandidates(
  extracted: ExtractedDocumentFields,
  members: Member[]
): DuplicateCandidate[] {
  const candidates: DuplicateCandidate[] = [];

  members.forEach(member => {
    let score = 0;
    const reasons: string[] = [];

    // NID Match (Decisive)
    if (
      extracted.nidNumber &&
      member.identityDocs?.nidNumber &&
      normalizeBanglaDigits(extracted.nidNumber) === normalizeBanglaDigits(member.identityDocs.nidNumber)
    ) {
      score += 85;
      reasons.push('জাতীয় পরিচয়পত্র (NID) নম্বর হুবহু মিলেছে');
    }

    // BRN Match (Decisive)
    if (
      extracted.brnNumber &&
      member.identityDocs?.birthRegistrationNumber &&
      normalizeBanglaDigits(extracted.brnNumber) === normalizeBanglaDigits(member.identityDocs.birthRegistrationNumber)
    ) {
      score += 85;
      reasons.push('জন্ম নিবন্ধন নম্বর (BRN) হুবহু মিলেছে');
    }

    // Name Match
    const extractedName = (extracted.fullNameBn || extracted.fullNameEn || '').trim().toLowerCase();
    const memberBn = (member.banglaName || '').toLowerCase();
    const memberEn = (member.englishName || member.fullName || '').toLowerCase();

    if (extractedName) {
      if (memberBn.includes(extractedName) || extractedName.includes(memberBn)) {
        score += 45;
        reasons.push('বাংলা নামে গভীর মিল পাওয়া গেছে');
      } else if (memberEn.includes(extractedName) || extractedName.includes(memberEn)) {
        score += 40;
        reasons.push('ইংরেজি নামে মিল পাওয়া গেছে');
      }
    }

    // Father Name Match
    if (extracted.fatherName && member.fatherId) {
      const fatherMember = members.find(m => m.id === member.fatherId);
      if (fatherMember) {
        const fatherBn = (fatherMember.banglaName || fatherMember.fullName).toLowerCase();
        if (fatherBn.includes(extracted.fatherName.toLowerCase()) || extracted.fatherName.toLowerCase().includes(fatherBn)) {
          score += 25;
          reasons.push(`পিতার নাম (${fatherMember.banglaName || fatherMember.fullName}) সামঞ্জস্যপূর্ণ`);
        }
      }
    }

    // Birth Year Match
    if (extracted.dateOfBirth && member.birth?.date?.year) {
      const extractedYear = extractYearFromString(extracted.dateOfBirth);
      if (extractedYear && Math.abs(extractedYear - member.birth.date.year) <= 1) {
        score += 20;
        reasons.push(`জন্ম সন প্রায় অভিন্ন (${member.birth.date.year})`);
      }
    }

    if (score >= 35) {
      candidates.push({
        member,
        matchScore: Math.min(score, 100),
        matchedReasons: reasons
      });
    }
  });

  return candidates.sort((a, b) => b.matchScore - a.matchScore);
}

/**
 * 6. INFORMATION CONFLICT DETECTOR
 * Finds differences between existing verified profile and newly extracted document facts
 */
export function detectConflicts(
  extracted: ExtractedDocumentFields,
  member: Member,
  members: Member[],
  sourceDocTitle: string
): FieldConflict[] {
  const conflicts: FieldConflict[] = [];

  // Name check
  if (extracted.fullNameBn && member.banglaName && extracted.fullNameBn.trim() !== member.banglaName.trim()) {
    conflicts.push({
      fieldKey: 'banglaName',
      fieldLabelEn: 'Bangla Name',
      fieldLabelBn: 'বাংলা নাম',
      existingValue: member.banglaName,
      extractedValue: extracted.fullNameBn,
      confidence: extracted.confidence,
      sourceDocumentTitle: sourceDocTitle,
      decision: 'pending'
    });
  }

  // NID check
  if (extracted.nidNumber && member.identityDocs?.nidNumber && extracted.nidNumber !== member.identityDocs.nidNumber) {
    conflicts.push({
      fieldKey: 'nidNumber',
      fieldLabelEn: 'NID Number',
      fieldLabelBn: 'জাতীয় পরিচয়পত্র নম্বর',
      existingValue: member.identityDocs.nidNumber,
      extractedValue: extracted.nidNumber,
      confidence: extracted.confidence,
      sourceDocumentTitle: sourceDocTitle,
      decision: 'pending'
    });
  }

  // BRN check
  if (extracted.brnNumber && member.identityDocs?.birthRegistrationNumber && extracted.brnNumber !== member.identityDocs.birthRegistrationNumber) {
    conflicts.push({
      fieldKey: 'birthRegistrationNumber',
      fieldLabelEn: 'Birth Registration (BRN)',
      fieldLabelBn: 'জন্ম নিবন্ধন নম্বর',
      existingValue: member.identityDocs.birthRegistrationNumber,
      extractedValue: extracted.brnNumber,
      confidence: extracted.confidence,
      sourceDocumentTitle: sourceDocTitle,
      decision: 'pending'
    });
  }

  // Date of Birth check
  if (extracted.dateOfBirth && member.birth?.date?.year) {
    const existingDobStr = `${member.birth.date.day || ''}/${member.birth.date.month || ''}/${member.birth.date.year}`;
    if (!extracted.dateOfBirth.includes(String(member.birth.date.year))) {
      conflicts.push({
        fieldKey: 'dateOfBirth',
        fieldLabelEn: 'Date of Birth',
        fieldLabelBn: 'জন্ম তারিখ',
        existingValue: existingDobStr,
        extractedValue: extracted.dateOfBirth,
        confidence: extracted.confidence,
        sourceDocumentTitle: sourceDocTitle,
        decision: 'pending'
      });
    }
  }

  // Father check
  if (extracted.fatherName && member.fatherId) {
    const father = members.find(m => m.id === member.fatherId);
    if (father && !father.banglaName.includes(extracted.fatherName) && !extracted.fatherName.includes(father.banglaName)) {
      conflicts.push({
        fieldKey: 'fatherName',
        fieldLabelEn: "Father's Name (পিং)",
        fieldLabelBn: 'পিতার নাম (পিং)',
        existingValue: father.banglaName || father.fullName,
        extractedValue: extracted.fatherName,
        confidence: extracted.confidence,
        sourceDocumentTitle: sourceDocTitle,
        decision: 'pending'
      });
    }
  }

  return conflicts;
}

// Helpers
function normalizeBanglaDigits(str: string): string {
  const bnToEn: Record<string, string> = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
  };
  return str.replace(/[০-৯]/g, d => bnToEn[d] || d);
}

function extractYearFromString(str: string): number | null {
  const normalized = normalizeBanglaDigits(str);
  const match = normalized.match(/\b(18|19|20)\d{2}\b/);
  return match ? parseInt(match[0], 10) : null;
}

