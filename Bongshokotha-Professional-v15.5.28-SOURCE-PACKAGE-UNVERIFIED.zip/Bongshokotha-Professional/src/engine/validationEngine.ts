/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Relationship Integrity Validator & Safe Link Repair Engine
 * 
 * Master Rule: "Existing verified information must never be silently replaced.
 * Missing information must remain missing until supplied or verified."
 */

import { Member, MarriageRecord, ValidationIssue, ValidationReport } from '../types/genealogy';
import { marriageMatchesParents, getValidatedMarriageChildIds } from './relationshipIntegrity';

export function validateGenealogyData(
  members: Member[],
  marriages: MarriageRecord[]
): ValidationReport {
  const issues: ValidationIssue[] = [];
  const memberMap = new Map<string, Member>(members.map(m => [m.id, m]));
  const marriageMap = new Map<string, MarriageRecord>(marriages.map(m => [m.id, m]));

  // 1. Check for Invalid Member IDs & Dangling Parent References
  for (const m of members) {
    if (m.fatherId && !memberMap.has(m.fatherId)) {
      issues.push({
        id: `invalid-father-${m.id}`,
        type: 'invalid_id',
        severity: 'error',
        title: `Invalid Father ID for ${m.englishName || m.fullName}`,
        banglaTitle: `${m.banglaName || m.fullName}-এর পিতার আইডি অনুপস্থিত বা ভুল`,
        description: `Member references non-existent father ID: ${m.fatherId}`,
        affectedMemberIds: [m.id],
        affectedMarriageIds: [],
        canAutoRepair: true
      });
    }

    if (m.motherId && !memberMap.has(m.motherId)) {
      issues.push({
        id: `invalid-mother-${m.id}`,
        type: 'invalid_id',
        severity: 'error',
        title: `Invalid Mother ID for ${m.englishName || m.fullName}`,
        banglaTitle: `${m.banglaName || m.fullName}-এর মাতার আইডি অনুপস্থিত বা ভুল`,
        description: `Member references non-existent mother ID: ${m.motherId}`,
        affectedMemberIds: [m.id],
        affectedMarriageIds: [],
        canAutoRepair: true
      });
    }

    // Check broken marriage references inside member
    for (const mid of m.marriageIds || []) {
      if (!marriageMap.has(mid)) {
        issues.push({
          id: `broken-mar-ref-${m.id}-${mid}`,
          type: 'broken_marriage',
          severity: 'warning',
          title: `Broken Marriage Reference in ${m.englishName || m.fullName}`,
          banglaTitle: `${m.banglaName || m.fullName}-এর তালিকায় অবলুপ্ত বৈবাহিক রেকর্ড রেফারেন্স`,
          description: `Member lists marriage ID ${mid} which is not found in marriage registry.`,
          affectedMemberIds: [m.id],
          affectedMarriageIds: [mid],
          canAutoRepair: true
        });
      }
    }
  }

  // Parent-role, chronology, and relationship integrity checks. Existing links are never silently removed.
  for (const m of members) {
    const father = m.fatherId ? memberMap.get(m.fatherId) : undefined;
    const mother = m.motherId ? memberMap.get(m.motherId) : undefined;
    if (father && father.id === m.id) issues.push({ id:`self-father-${m.id}`, type:'invalid_id', severity:'error', title:'Self-parent relationship', banglaTitle:'নিজেকেই পিতা হিসেবে নির্ধারণ করা হয়েছে', description:'A member cannot be their own father.', affectedMemberIds:[m.id], affectedMarriageIds:[], canAutoRepair:false });
    if (mother && mother.id === m.id) issues.push({ id:`self-mother-${m.id}`, type:'invalid_id', severity:'error', title:'Self-parent relationship', banglaTitle:'নিজেকেই মাতা হিসেবে নির্ধারণ করা হয়েছে', description:'A member cannot be their own mother.', affectedMemberIds:[m.id], affectedMarriageIds:[], canAutoRepair:false });
    if (father && !['male','unknown','other'].includes(father.gender)) issues.push({ id:`father-gender-${m.id}`, type:'invalid_id', severity:'error', title:'Father gender conflict', banglaTitle:'পিতার লিঙ্গের তথ্য অসামঞ্জস্যপূর্ণ', description:'The selected father is not recorded as male.', affectedMemberIds:[m.id,father.id], affectedMarriageIds:[], canAutoRepair:false });
    if (mother && !['female','unknown','other'].includes(mother.gender)) issues.push({ id:`mother-gender-${m.id}`, type:'invalid_id', severity:'error', title:'Mother gender conflict', banglaTitle:'মাতার লিঙ্গের তথ্য অসামঞ্জস্যপূর্ণ', description:'The selected mother is not recorded as female.', affectedMemberIds:[m.id,mother.id], affectedMarriageIds:[], canAutoRepair:false });
    const birthY=m.birth?.date?.year;
    const deathY=m.death?.date?.year;
    if (birthY && deathY && deathY < birthY) issues.push({ id:`date-order-${m.id}`, type:'invalid_id', severity:'error', title:'Birth/death chronology conflict', banglaTitle:'জন্ম ও মৃত্যুর তারিখের অসামঞ্জস্য', description:'Death cannot precede birth.', affectedMemberIds:[m.id], affectedMarriageIds:[], canAutoRepair:false });
    if (m.ageAtDeath != null && birthY && deathY) { const implied=deathY-birthY; if (Math.abs(implied-m.ageAtDeath)>1) issues.push({ id:`age-conflict-${m.id}`, type:'invalid_id', severity:'warning', title:'Age-at-death conflict', banglaTitle:'মৃত্যুকালের বয়স ও তারিখে অসামঞ্জস্য', description:`Stored age ${m.ageAtDeath} conflicts with year difference ${implied}.`, affectedMemberIds:[m.id], affectedMarriageIds:[], canAutoRepair:false }); }
  }

  // 2. Check for Circular Parent Relationships (Cycle Detection via DFS)
  const visited = new Set<string>();
  const recursionStack = new Set<string>();

  function detectCycle(currentId: string, path: string[]): boolean {
    visited.add(currentId);
    recursionStack.add(currentId);

    const current = memberMap.get(currentId);
    if (current) {
      const parents = [current.fatherId, current.motherId].filter(Boolean) as string[];
      for (const pId of parents) {
        if (!visited.has(pId)) {
          if (detectCycle(pId, [...path, pId])) return true;
        } else if (recursionStack.has(pId)) {
          // Cycle found!
          issues.push({
            id: `cycle-${currentId}-${pId}`,
            type: 'circular_parent',
            severity: 'error',
            title: `Circular Ancestry Loop Detected`,
            banglaTitle: `চক্রাকার বংশতালিকা ত্রুটি (Circular Loop)`,
            description: `A member is recorded as their own ancestor along the path: ${[...path, pId].join(' → ')}`,
            affectedMemberIds: [...path, pId],
            affectedMarriageIds: [],
            canAutoRepair: false // Requires manual user intervention
          });
          return true;
        }
      }
    }

    recursionStack.delete(currentId);
    return false;
  }

  for (const m of members) {
    if (!visited.has(m.id)) {
      detectCycle(m.id, [m.id]);
    }
  }

  // 3. Check Marriages for Invalid Spouses, Reciprocal Links, and Orphan Records
  for (const mar of marriages) {
    const hasHusband = memberMap.has(mar.husbandId);
    const hasWife = memberMap.has(mar.wifeId);

    if (!hasHusband || !hasWife) {
      issues.push({
        id: `invalid-spouse-${mar.id}`,
        type: 'invalid_spouse',
        severity: 'error',
        title: `Marriage ${mar.serialNumber || mar.id} References Missing Spouse`,
        banglaTitle: `বৈবাহিক রেকর্ড ${mar.serialNumber || mar.id}-এ অস্তিত্বহীন স্বামী/স্ত্রী রেফারেন্স`,
        description: `Marriage references non-existent husband (${mar.husbandId}) or wife (${mar.wifeId}).`,
        affectedMemberIds: [mar.husbandId, mar.wifeId].filter(id => memberMap.has(id)),
        affectedMarriageIds: [mar.id],
        canAutoRepair: false
      });
    }

    // Reciprocal check: husband has mar.id in marriageIds?
    if (hasHusband) {
      const husband = memberMap.get(mar.husbandId)!;
      if (!husband.marriageIds?.includes(mar.id)) {
        issues.push({
          id: `missing-recip-mar-h-${mar.id}`,
          type: 'missing_reciprocal_parent',
          severity: 'warning',
          title: `Husband ${husband.englishName || husband.fullName} Missing Link to Marriage ${mar.serialNumber || mar.id}`,
          banglaTitle: `স্বামীর প্রোফাইলে বৈবাহিক রেকর্ড ${mar.serialNumber || mar.id}-এর লিঙ্ক অনুপস্থিত`,
          description: `Marriage record exists, but husband's profile is not linked to it.`,
          affectedMemberIds: [husband.id],
          affectedMarriageIds: [mar.id],
          canAutoRepair: true
        });
      }
    }

    // Reciprocal check: wife has mar.id in marriageIds?
    if (hasWife) {
      const wife = memberMap.get(mar.wifeId)!;
      if (!wife.marriageIds?.includes(mar.id)) {
        issues.push({
          id: `missing-recip-mar-w-${mar.id}`,
          type: 'missing_reciprocal_parent',
          severity: 'warning',
          title: `Wife ${wife.englishName || wife.fullName} Missing Link to Marriage ${mar.serialNumber || mar.id}`,
          banglaTitle: `স্ত্রীর প্রোফাইলে বৈবাহিক রেকর্ড ${mar.serialNumber || mar.id}-এর লিঙ্ক অনুপস্থিত`,
          description: `Marriage record exists, but wife's profile is not linked to it.`,
          affectedMemberIds: [wife.id],
          affectedMarriageIds: [mar.id],
          canAutoRepair: true
        });
      }
    }

    // Duplicate children in marriage record
    if (mar.childrenIds) {
      const seenChildren = new Set<string>();
      for (const cid of mar.childrenIds) {
        if (seenChildren.has(cid)) {
          issues.push({
            id: `dup-child-${mar.id}-${cid}`,
            type: 'duplicate_child',
            severity: 'warning',
            title: `Duplicate Child in Marriage ${mar.serialNumber || mar.id}`,
            banglaTitle: `বিবাহ রেকর্ডে একই সন্তানের দ্বৈত اندراج`,
            description: `Child ID ${cid} appears multiple times in the marriage children list.`,
            affectedMemberIds: [cid],
            affectedMarriageIds: [mar.id],
            canAutoRepair: true
          });
        }
        seenChildren.add(cid);

        if (!memberMap.has(cid)) {
          issues.push({
            id: `invalid-child-id-${mar.id}-${cid}`,
            type: 'invalid_id',
            severity: 'error',
            title: `Non-Existent Child in Marriage ${mar.serialNumber || mar.id}`,
            banglaTitle: `বিবাহ রেকর্ডে অস্তিত্বহীন সন্তানের রেফারেন্স`,
            description: `Child ID ${cid} does not exist in member registry.`,
            affectedMemberIds: [],
            affectedMarriageIds: [mar.id],
            canAutoRepair: true
          });
        } else {
          const child = memberMap.get(cid)!;
          if (!marriageMatchesParents(child, mar)) {
            issues.push({
              id: `marriage-child-parent-conflict-${mar.id}-${cid}`,
              type: 'chronology_conflict',
              severity: 'error',
              title: `Marriage child conflicts with recorded parent`,
              banglaTitle: `বিবাহের সন্তান ও সংরক্ষিত পিতা-মাতার তথ্যের সংঘাত`,
              description: `Child ${child.fullName} is listed in marriage ${mar.serialNumber || mar.id}, but the known parent link points to a different parent.`,
              affectedMemberIds: [cid, mar.husbandId, mar.wifeId],
              affectedMarriageIds: [mar.id],
              canAutoRepair: false
            });
          }
        }
      }
    }
  }

  // 4. Missing Reciprocal Child-Marriage Links
  for (const m of members) {
    if (m.fatherId && m.motherId) {
      // Find marriage between father and mother
      const marriage = marriages.find(
        mar =>
          (mar.husbandId === m.fatherId && mar.wifeId === m.motherId) ||
          (mar.husbandId === m.motherId && mar.wifeId === m.fatherId)
      );

      if (marriage && (!marriage.childrenIds || !marriage.childrenIds.includes(m.id))) {
        issues.push({
          id: `missing-recip-child-${m.id}-${marriage.id}`,
          type: 'missing_reciprocal_child',
          severity: 'info',
          title: `Child ${m.englishName || m.fullName} Not Listed in Parents' Marriage Record`,
          banglaTitle: `সন্তান ${m.banglaName || m.fullName} পিতা-মাতার বিবাহ নথিতে তালিকাভুক্ত নয়`,
          description: `Child links both parents, but parents' marriage record doesn't include child in childrenIds list.`,
          affectedMemberIds: [m.id, m.fatherId, m.motherId],
          affectedMarriageIds: [marriage.id],
          canAutoRepair: true
        });
      }
    }
  }

  // 5. Chronology Conflicts (e.g. parent born after child)
  for (const m of members) {
    const childYear = m.birth?.date?.year;
    if (childYear) {
      if (m.fatherId) {
        const father = memberMap.get(m.fatherId);
        const fatherYear = father?.birth?.date?.year;
        if (fatherYear && fatherYear >= childYear) {
          issues.push({
            id: `chronology-father-${m.id}`,
            type: 'chronology_conflict',
            severity: 'error',
            title: `Chronological Conflict: Father Born After Child`,
            banglaTitle: `কালানুক্রমিক ত্রুটি: পিতা সন্তানের পরে বা একই বছরে জন্ম নিয়েছেন`,
            description: `Father ${father?.englishName} (${fatherYear}) is recorded as being born in or after child ${m.englishName} (${childYear}).`,
            affectedMemberIds: [father?.id || '', m.id],
            affectedMarriageIds: [],
            canAutoRepair: false
          });
        }
      }

      if (m.motherId) {
        const mother = memberMap.get(m.motherId);
        const motherYear = mother?.birth?.date?.year;
        if (motherYear && motherYear >= childYear) {
          issues.push({
            id: `chronology-mother-${m.id}`,
            type: 'chronology_conflict',
            severity: 'error',
            title: `Chronological Conflict: Mother Born After Child`,
            banglaTitle: `কালানুক্রমিক ত্রুটি: মাতা সন্তানের পরে বা একই বছরে জন্ম নিয়েছেন`,
            description: `Mother ${mother?.englishName} (${motherYear}) is recorded as being born in or after child ${m.englishName} (${childYear}).`,
            affectedMemberIds: [mother?.id || '', m.id],
            affectedMarriageIds: [],
            canAutoRepair: false
          });
        }
      }
    }

    // Death before birth
    if (m.birth?.date?.year && m.death?.date?.year && m.death.date.year < m.birth.date.year) {
      issues.push({
        id: `chronology-death-${m.id}`,
        type: 'chronology_conflict',
        severity: 'error',
        title: `Chronological Conflict: Death Precedes Birth`,
        banglaTitle: `কালানুক্রমিক ত্রুটি: মৃত্যু জন্মের পূর্বে রেকর্ড করা হয়েছে`,
        description: `Member ${m.englishName || m.fullName} has death year (${m.death.date.year}) earlier than birth year (${m.birth.date.year}).`,
        affectedMemberIds: [m.id],
        affectedMarriageIds: [],
        canAutoRepair: false
      });
    }
  }

  // Marriage spouse-role and multi-current-marriage checks.
  for (const m of marriages) {
    const husband=memberMap.get(m.husbandId), wife=memberMap.get(m.wifeId);
    if (husband && husband.gender === 'female') issues.push({id:`husband-role-${m.id}`,type:'invalid_spouse',severity:'error',title:'Marriage husband role conflicts with gender',banglaTitle:'বিবাহের স্বামীর তথ্য লিঙ্গের সঙ্গে অসামঞ্জস্যপূর্ণ',description:'The husband is recorded as female.',affectedMemberIds:[husband.id],affectedMarriageIds:[m.id],canAutoRepair:false});
    if (wife && wife.gender === 'male') issues.push({id:`wife-role-${m.id}`,type:'invalid_spouse',severity:'error',title:'Marriage wife role conflicts with gender',banglaTitle:'বিবাহের স্ত্রীর তথ্য লিঙ্গের সঙ্গে অসামঞ্জস্যপূর্ণ',description:'The wife is recorded as male.',affectedMemberIds:[wife.id],affectedMarriageIds:[m.id],canAutoRepair:false});
  }
  for (const member of members) {
    const currentCount=marriages.filter(m=>m.status==='current' && (m.husbandId===member.id || m.wifeId===member.id)).length;
    if (currentCount>1) issues.push({id:`multiple-current-marriages-${member.id}`,type:'invalid_spouse',severity:'warning',title:'Multiple current marriages',banglaTitle:'একাধিক বর্তমান বিবাহের রেকর্ড',description:`${member.fullName} has ${currentCount} current marriage records.`,affectedMemberIds:[member.id],affectedMarriageIds:marriages.filter(m=>m.status==='current' && (m.husbandId===member.id || m.wifeId===member.id)).map(m=>m.id),canAutoRepair:false});
  }
  const errors = issues.filter(i => i.severity === 'error').length;
  const warnings = issues.filter(i => i.severity === 'warning').length;
  return {
    scannedAt: new Date().toISOString(),
    isValid: errors === 0,
    errorCount: errors,
    warningCount: warnings,
    issues
  };
}

export interface RepairResult {
  repairedCount: number;
  updatedMembers: Member[];
  updatedMarriages: MarriageRecord[];
  repairLog: string[];
}

/**
 * Safely repairs reciprocal relationships, cleans broken IDs, and syncs marriage children.
 * 
 * Master Principle:
 * "Never invent missing facts. Never silently overwrite verified information."
 */
export function repairAllLinks(
  members: Member[],
  marriages: MarriageRecord[]
): RepairResult {
  const repairLog: string[] = [];
  let repairedCount = 0;

  const memberMap = new Map<string, Member>(
    members.map(m => [m.id, JSON.parse(JSON.stringify(m))])
  );
  const marriageMap = new Map<string, MarriageRecord>(
    marriages.map(m => [m.id, JSON.parse(JSON.stringify(m))])
  );

  // Step 1: Clean invalid dangling fatherId & motherId
  for (const m of memberMap.values()) {
    if (m.fatherId && !memberMap.has(m.fatherId)) {
      repairLog.push(`Removed invalid father ID ${m.fatherId} from ${m.fullName}`);
      m.fatherId = undefined;
      repairedCount++;
    }
    if (m.motherId && !memberMap.has(m.motherId)) {
      repairLog.push(`Removed invalid mother ID ${m.motherId} from ${m.fullName}`);
      m.motherId = undefined;
      repairedCount++;
    }
    // Clean deleted marriage IDs in member.marriageIds
    if (m.marriageIds && m.marriageIds.length > 0) {
      const validMids = m.marriageIds.filter(mid => marriageMap.has(mid));
      if (validMids.length !== m.marriageIds.length) {
        repairLog.push(`Cleaned broken marriage reference from ${m.fullName}`);
        m.marriageIds = validMids;
        repairedCount++;
      }
    }
  }

  // Step 2: Ensure reciprocal marriage IDs on spouses
  for (const mar of marriageMap.values()) {
    const husband = memberMap.get(mar.husbandId);
    if (husband) {
      if (!husband.marriageIds) husband.marriageIds = [];
      if (!husband.marriageIds.includes(mar.id)) {
        husband.marriageIds.push(mar.id);
        husband.isUnmarried = false;
        repairLog.push(`Linked marriage ${mar.serialNumber || mar.id} to husband ${husband.fullName}`);
        repairedCount++;
      }
    }

    const wife = memberMap.get(mar.wifeId);
    if (wife) {
      if (!wife.marriageIds) wife.marriageIds = [];
      if (!wife.marriageIds.includes(mar.id)) {
        wife.marriageIds.push(mar.id);
        wife.isUnmarried = false;
        repairLog.push(`Linked marriage ${mar.serialNumber || mar.id} to wife ${wife.fullName}`);
        repairedCount++;
      }
    }

    // Remove duplicate children & non-existent child IDs in marriage
    if (mar.childrenIds) {
      const uniqueValidChildren: string[] = [];
      for (const cid of mar.childrenIds) {
        if (memberMap.has(cid) && !uniqueValidChildren.includes(cid)) {
          uniqueValidChildren.push(cid);
        } else {
          repairedCount++;
          repairLog.push(`Removed invalid or duplicate child ID ${cid} from marriage ${mar.serialNumber || mar.id}`);
        }
      }
      mar.childrenIds = uniqueValidChildren;
    }
  }

  // Step 3: A child with both known biological parents belongs to the unique
  // marriage of those two parents. Never attach it to every marriage of either parent.
  for (const m of memberMap.values()) {
    if (!m.fatherId || !m.motherId) continue;
    const matches = Array.from(marriageMap.values()).filter(mar =>
      (mar.husbandId === m.fatherId && mar.wifeId === m.motherId) ||
      (mar.husbandId === m.motherId && mar.wifeId === m.fatherId)
    );
    if (matches.length === 1 && !matches[0].childrenIds.includes(m.id)) {
      matches[0].childrenIds.push(m.id);
      repairLog.push(`Added child ${m.fullName} only to the unique marriage of both recorded parents.`);
      repairedCount++;
    } else if (matches.length > 1) {
      repairLog.push(`Conflict retained: child ${m.fullName} matches multiple marriage records for the same parent pair.`);
    }
  }

  // Step 4: If marriage has children, ensure children have appropriate fatherId and motherId
  for (const mar of marriageMap.values()) {
    const husband = memberMap.get(mar.husbandId);
    const wife = memberMap.get(mar.wifeId);

    if (mar.childrenIds) {
      for (const cid of mar.childrenIds) {
        const child = memberMap.get(cid);
        if (child) {
          let updated = false;
          if (child.birthOrigin !== 'adopted' && husband && husband.gender === 'male' && !child.fatherId) {
            child.fatherId = husband.id;
            updated = true;
          }
          if (child.birthOrigin !== 'adopted' && wife && wife.gender === 'female' && !child.motherId) {
            child.motherId = wife.id;
            updated = true;
          }
          if (updated) {
            repairLog.push(`Linked biological parent(s) from marriage record to child ${child.fullName}`);
            repairedCount++;
          }
        }
      }
    }
  }



  return {
    repairedCount,
    updatedMembers: Array.from(memberMap.values()),
    updatedMarriages: Array.from(marriageMap.values()),
    repairLog
  };
}
