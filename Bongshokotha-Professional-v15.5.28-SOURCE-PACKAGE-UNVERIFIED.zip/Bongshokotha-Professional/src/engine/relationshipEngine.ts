/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Bidirectional Relationship Calculator & Kinship Path Finder
 * 
 * Rule: "Relationship Finder must show the actual relationship path."
 * Example: Person A -> Father -> Father's Brother -> His Daughter
 */

import { Member, MarriageRecord, RelationshipResult, KinshipPathStep } from '../types/genealogy';

interface GraphEdge {
  targetId: string;
  relation: 'father' | 'mother' | 'child' | 'spouse' | 'brother' | 'sister';
  labelEn: string;
  labelBn: string;
}

export function buildGenealogyGraph(members: Member[], marriages: MarriageRecord[]): Map<string, GraphEdge[]> {
  const graph = new Map<string, GraphEdge[]>();
  const memberMap = new Map<string, Member>(members.map(m => [m.id, m]));

  const addEdge = (from: string, to: string, rel: GraphEdge['relation'], labelEn: string, labelBn: string) => {
    if (!graph.has(from)) graph.set(from, []);
    // Prevent duplicate edges
    if (!graph.get(from)!.some(e => e.targetId === to && e.relation === rel)) {
      graph.get(from)!.push({ targetId: to, relation: rel, labelEn, labelBn });
    }
  };

  // 1. Biological parent-child edges
  for (const m of members) {
    if (m.fatherId && memberMap.has(m.fatherId)) {
      addEdge(m.id, m.fatherId, 'father', 'Father', 'বাবা');
      addEdge(m.fatherId, m.id, 'child', m.gender === 'female' ? 'Daughter' : 'Son', m.gender === 'female' ? 'মেয়ে' : 'ছেলে');
    }
    if (m.motherId && memberMap.has(m.motherId)) {
      addEdge(m.id, m.motherId, 'mother', 'Mother', 'মা');
      addEdge(m.motherId, m.id, 'child', m.gender === 'female' ? 'Daughter' : 'Son', m.gender === 'female' ? 'মেয়ে' : 'ছেলে');
    }
  }

  // 2. Spouse edges from marriages
  for (const mar of marriages) {
    if (memberMap.has(mar.husbandId) && memberMap.has(mar.wifeId)) {
      addEdge(mar.husbandId, mar.wifeId, 'spouse', 'Wife', 'স্ত্রী');
      addEdge(mar.wifeId, mar.husbandId, 'spouse', 'Husband', 'স্বামী');

      // Marriage-specific child grouping is contextual data, not proof of two
      // biological parent links. Parent/child graph edges are created only from
      // the child's canonical fatherId/motherId above. This prevents a child
      // linked to one known parent (or an adopted child) from gaining a false
      // second parent merely because the child is listed on a marriage record.
    }
  }

  return graph;
}

/**
 * Calculates relationship between Person A and Person B
 * Output includes the step-by-step path and authentic Bengali/English kinship terms.
 */
export function findRelationship(
  personAId: string,
  personBId: string,
  members: Member[],
  marriages: MarriageRecord[],
  genMap?: Map<string, number>
): RelationshipResult | null {
  if (personAId === personBId) {
    return {
      personAId,
      personBId,
      relationshipNameEn: 'Self',
      relationshipNameBn: 'নিজ',
      category: 'direct',
      generationDifference: 0,
      path: [],
      pathDescriptionEn: 'Same person',
      pathDescriptionBn: 'একই ব্যক্তি'
    };
  }

  const memberMap = new Map<string, Member>(members.map(m => [m.id, m]));
  const personA = memberMap.get(personAId);
  const personB = memberMap.get(personBId);
  if (!personA || !personB) return null;

  const graph = buildGenealogyGraph(members, marriages);

  // Shortest path via BFS
  interface QueueNode {
    id: string;
    path: KinshipPathStep[];
  }

  const visited = new Set<string>([personAId]);
  const queue: QueueNode[] = [{ id: personAId, path: [] }];
  let shortestPath: KinshipPathStep[] | null = null;

  while (queue.length > 0) {
    const current = queue.shift()!;
    if (current.id === personBId) {
      shortestPath = current.path;
      break;
    }

    const neighbors = graph.get(current.id) || [];
    for (const edge of neighbors) {
      if (!visited.has(edge.targetId)) {
        visited.add(edge.targetId);
        queue.push({
          id: edge.targetId,
          path: [
            ...current.path,
            {
              fromId: current.id,
              toId: edge.targetId,
              relationType: edge.relation,
              englishLabel: edge.labelEn,
              banglaLabel: edge.labelBn
            }
          ]
        });
      }
    }
  }

  if (!shortestPath) {
    return {
      personAId,
      personBId,
      relationshipNameEn: 'No Direct Link Recorded',
      relationshipNameBn: 'সরাসরি সম্পর্ক যুক্ত নয়',
      category: 'unrelated',
      generationDifference: 0,
      path: [],
      pathDescriptionEn: 'No connecting genealogy path found in active family records.',
      pathDescriptionBn: 'বর্তমান পারিবারিক তথ্যে কোনো সংযোগ পথ পাওয়া যায়নি।'
    };
  }

  // Determine generation difference
  const genA = genMap?.get(personAId) || 1;
  const genB = genMap?.get(personBId) || 1;
  const genDiff = genB - genA;

  // Derive precise kinship terminology from path pattern
  const { titleEn, titleBn, category } = classifyKinship(personA, personB, shortestPath, memberMap);

  // Construct visual path descriptions
  const stepDescsEn = shortestPath.map(step => {
    const target = memberMap.get(step.toId);
    return `${step.englishLabel} (${target?.englishName || target?.fullName || 'Member'})`;
  });
  const pathDescriptionEn = `${personA.englishName || personA.fullName} → ` + stepDescsEn.join(' → ');

  const stepDescsBn = shortestPath.map(step => {
    const target = memberMap.get(step.toId);
    return `${step.banglaLabel} (${target?.banglaName || target?.fullName || 'সদস্য'})`;
  });
  const pathDescriptionBn = `${personA.banglaName || personA.fullName} → ` + stepDescsBn.join(' → ');

  return {
    personAId,
    personBId,
    relationshipNameEn: titleEn,
    relationshipNameBn: titleBn,
    category,
    generationDifference: genDiff,
    path: shortestPath,
    pathDescriptionEn,
    pathDescriptionBn
  };
}

/**
 * Classifies exact Bengali & English kinship terms based on graph edge pattern
 */
function classifyKinship(
  personA: Member,
  personB: Member,
  path: KinshipPathStep[],
  memberMap: Map<string, Member>
): { titleEn: string; titleBn: string; category: RelationshipResult['category'] } {
  const steps = path.map(p => p.relationType);
  const isFemale = personB.gender === 'female';

  // 1 Step
  if (steps.length === 1) {
    const rel = steps[0];
    if (rel === 'father') return { titleEn: 'Father', titleBn: 'বাবা / পিতা', category: 'ancestor' };
    if (rel === 'mother') return { titleEn: 'Mother', titleBn: 'মা / মাতা', category: 'ancestor' };
    if (rel === 'child') {
      return {
        titleEn: isFemale ? 'Daughter' : 'Son',
        titleBn: isFemale ? 'মেয়ে / কন্যা' : 'ছেলে / পুত্র',
        category: 'descendant'
      };
    }
    if (rel === 'spouse') {
      return {
        titleEn: isFemale ? 'Wife' : 'Husband',
        titleBn: isFemale ? 'স্ত্রী' : 'স্বামী',
        category: 'direct'
      };
    }
  }

  // 2 Steps
  // Parent -> Child = Sibling
  if (steps.length === 2 && (steps[0] === 'father' || steps[0] === 'mother') && steps[1] === 'child') {
    // Sibling
    const aYear = personA.birth?.date?.year || 0;
    const bYear = personB.birth?.date?.year || 0;
    const isElder = bYear < aYear && aYear > 0 && bYear > 0;

    if (isFemale) {
      return {
        titleEn: isElder ? 'Elder Sister' : 'Younger Sister',
        titleBn: isElder ? 'বড় বোন / আপা' : 'ছোট বোন',
        category: 'sibling'
      };
    } else {
      return {
        titleEn: isElder ? 'Elder Brother' : 'Younger Brother',
        titleBn: isElder ? 'বড় ভাই' : 'ছোট ভাই',
        category: 'sibling'
      };
    }
  }

  // Parent -> Parent = Grandparents
  if (steps.length === 2 && (steps[0] === 'father' || steps[0] === 'mother') && (steps[1] === 'father' || steps[1] === 'mother')) {
    const isPaternal = steps[0] === 'father';
    if (isPaternal) {
      return {
        titleEn: isFemale ? 'Paternal Grandmother' : 'Paternal Grandfather',
        titleBn: isFemale ? 'দাদী' : 'দাদা',
        category: 'ancestor'
      };
    } else {
      return {
        titleEn: isFemale ? 'Maternal Grandmother' : 'Maternal Grandfather',
        titleBn: isFemale ? 'নানী' : 'নানা',
        category: 'ancestor'
      };
    }
  }

  // Child -> Child = Grandchild
  if (steps.length === 2 && steps[0] === 'child' && steps[1] === 'child') {
    const intermediateChild = memberMap.get(path[0].toId);
    const isSonChild = intermediateChild?.gender === 'male';
    if (isSonChild) {
      return {
        titleEn: isFemale ? 'Granddaughter (Son\'s daughter)' : 'Grandson (Son\'s son)',
        titleBn: isFemale ? 'নাতনি (পুত্রী)' : 'নাতি (পৌত্র)',
        category: 'descendant'
      };
    } else {
      return {
        titleEn: isFemale ? 'Granddaughter (Daughter\'s daughter)' : 'Grandson (Daughter\'s son)',
        titleBn: isFemale ? 'নাতনি (দৌহিত্রী)' : 'নাতি (দৌহিত্র)',
        category: 'descendant'
      };
    }
  }

  // Spouse -> Parent = In-laws (Father/Mother in law)
  if (steps.length === 2 && steps[0] === 'spouse' && (steps[1] === 'father' || steps[1] === 'mother')) {
    return {
      titleEn: steps[1] === 'mother' ? 'Mother-in-law' : 'Father-in-law',
      titleBn: steps[1] === 'mother' ? 'শাশুড়ি' : 'শ্বশুর',
      category: 'inlaw'
    };
  }

  // Child -> Spouse = Son-in-law / Daughter-in-law
  if (steps.length === 2 && steps[0] === 'child' && steps[1] === 'spouse') {
    return {
      titleEn: isFemale ? 'Daughter-in-law' : 'Son-in-law',
      titleBn: isFemale ? 'পুত্রবধূ / বৌমা' : 'জামাতা / জামাই',
      category: 'inlaw'
    };
  }

  // 3 Steps
  // Parent -> Parent -> Child = Uncle or Aunt
  if (steps.length === 3 && (steps[0] === 'father' || steps[0] === 'mother') && (steps[1] === 'father' || steps[1] === 'mother') && steps[2] === 'child') {
    const isPaternal = steps[0] === 'father';
    if (isPaternal) {
      if (isFemale) {
        return { titleEn: 'Paternal Aunt (Father\'s sister)', titleBn: 'ফুফু / পিসি', category: 'extended' };
      } else {
        return { titleEn: 'Paternal Uncle (Father\'s brother)', titleBn: 'চাচা / কাকা', category: 'extended' };
      }
    } else {
      if (isFemale) {
        return { titleEn: 'Maternal Aunt (Mother\'s sister)', titleBn: 'খালা / মাসি', category: 'extended' };
      } else {
        return { titleEn: 'Maternal Uncle (Mother\'s brother)', titleBn: 'মামা', category: 'extended' };
      }
    }
  }

  // Sibling's child: (Father/Mother -> Child -> Child) = Nephew / Niece
  if (steps.length === 3 && (steps[0] === 'father' || steps[0] === 'mother') && steps[1] === 'child' && steps[2] === 'child') {
    const intermediateSibling = memberMap.get(path[1].toId);
    const isBrotherChild = intermediateSibling?.gender === 'male';
    if (isBrotherChild) {
      return {
        titleEn: isFemale ? 'Niece (Brother\'s daughter)' : 'Nephew (Brother\'s son)',
        titleBn: isFemale ? 'ভাতিজি' : 'ভাতিজা',
        category: 'extended'
      };
    } else {
      return {
        titleEn: isFemale ? 'Niece (Sister\'s daughter)' : 'Nephew (Sister\'s son)',
        titleBn: isFemale ? 'ভাগ্নি' : 'ভাগ্নে',
        category: 'extended'
      };
    }
  }

  // 4 Steps: First Cousins (Parent -> Parent -> Child -> Child)
  if (steps.length === 4 && (steps[0] === 'father' || steps[0] === 'mother') && (steps[1] === 'father' || steps[1] === 'mother') && steps[2] === 'child' && steps[3] === 'child') {
    const uncleAunt = memberMap.get(path[2].toId);
    const isPaternal = steps[0] === 'father';

    if (isPaternal) {
      if (uncleAunt?.gender === 'male') {
        // Chachato
        return {
          titleEn: isFemale ? 'First Cousin (Paternal Uncle\'s daughter)' : 'First Cousin (Paternal Uncle\'s son)',
          titleBn: isFemale ? 'চাচাতো বোন' : 'চাচাতো ভাই',
          category: 'cousin'
        };
      } else {
        // Fufato
        return {
          titleEn: isFemale ? 'First Cousin (Paternal Aunt\'s daughter)' : 'First Cousin (Paternal Aunt\'s son)',
          titleBn: isFemale ? 'ফুফাতো বোন' : 'ফুফাতো ভাই',
          category: 'cousin'
        };
      }
    } else {
      if (uncleAunt?.gender === 'male') {
        // Mamato
        return {
          titleEn: isFemale ? 'First Cousin (Maternal Uncle\'s daughter)' : 'First Cousin (Maternal Uncle\'s son)',
          titleBn: isFemale ? 'মামাতো বোন' : 'মামাতো ভাই',
          category: 'cousin'
        };
      } else {
        // Khalato
        return {
          titleEn: isFemale ? 'First Cousin (Maternal Aunt\'s daughter)' : 'First Cousin (Maternal Aunt\'s son)',
          titleBn: isFemale ? 'খালাতো বোন' : 'খালাতো ভাই',
          category: 'cousin'
        };
      }
    }
  }

  // In-law spouse relationships (e.g. Uncle's Wife: Chachi, Mami; Aunt's Husband: Fufa, Khalu)
  if (steps.length === 4 && (steps[0] === 'father' || steps[0] === 'mother') && (steps[1] === 'father' || steps[1] === 'mother') && steps[2] === 'child' && steps[3] === 'spouse') {
    const isPaternal = steps[0] === 'father';
    const uncleAunt = memberMap.get(path[2].toId);
    if (isPaternal) {
      if (uncleAunt?.gender === 'male') {
        return { titleEn: 'Aunt (Paternal Uncle\'s Wife)', titleBn: 'চাচী', category: 'inlaw' };
      } else {
        return { titleEn: 'Uncle (Paternal Aunt\'s Husband)', titleBn: 'ফুফা', category: 'inlaw' };
      }
    } else {
      if (uncleAunt?.gender === 'male') {
        return { titleEn: 'Aunt (Maternal Uncle\'s Wife)', titleBn: 'মামী', category: 'inlaw' };
      } else {
        return { titleEn: 'Uncle (Maternal Aunt\'s Husband)', titleBn: 'খালু', category: 'inlaw' };
      }
    }
  }

  // Spouse's sibling (Brother-in-law, Sister-in-law)
  // Spouse -> Parent -> Child
  if (steps.length === 3 && steps[0] === 'spouse' && (steps[1] === 'father' || steps[1] === 'mother') && steps[2] === 'child') {
    const isPersonAFemale = personA.gender === 'female';
    if (isPersonAFemale) {
      // For woman: Husband's elder brother = Bhashur, younger brother = Dewor, sister = Nanad
      if (isFemale) {
        return { titleEn: 'Sister-in-law (Husband\'s Sister)', titleBn: 'ননদ', category: 'inlaw' };
      } else {
        const bYear = personB.birth?.date?.year || 0;
        const spouseYear = memberMap.get(path[0].toId)?.birth?.date?.year || 0;
        const isElderThanHusband = bYear < spouseYear && bYear > 0 && spouseYear > 0;
        return {
          titleEn: isElderThanHusband ? 'Brother-in-law (Husband\'s Elder Brother)' : 'Brother-in-law (Husband\'s Younger Brother)',
          titleBn: isElderThanHusband ? 'ভাসুর' : 'দেওর',
          category: 'inlaw'
        };
      }
    } else {
      // For man: Wife's brother = Shala, sister = Shalika
      return {
        titleEn: isFemale ? 'Sister-in-law (Wife\'s Sister)' : 'Brother-in-law (Wife\'s Brother)',
        titleBn: isFemale ? 'শালিকা' : 'শালা',
        category: 'inlaw'
      };
    }
  }

  // Deep ancestors / descendants
  if (steps.every(s => s === 'father' || s === 'mother')) {
    const depth = steps.length;
    if (depth === 3) return { titleEn: isFemale ? 'Great-Grandmother' : 'Great-Grandfather', titleBn: isFemale ? 'পরদাদী / পরনানী' : 'পরদাদা / পরনানা', category: 'ancestor' };
    return { titleEn: `${depth - 2}x Great-Grandparent`, titleBn: `উর্ধ্বতন পূর্বপুরুষ (${depth} প্রজন্ম)`, category: 'ancestor' };
  }

  if (steps.every(s => s === 'child')) {
    const depth = steps.length;
    if (depth === 3) return { titleEn: isFemale ? 'Great-Granddaughter' : 'Great-Grandson', titleBn: isFemale ? 'পুঁতি (মেয়ে)' : 'পুঁতি (ছেলে)', category: 'descendant' };
    return { titleEn: `${depth - 2}x Great-Grandchild`, titleBn: `অধস্তন উত্তরসূরী (${depth} প্রজন্ম)`, category: 'descendant' };
  }

  return {
    titleEn: `Relative (${path.length} degrees)`,
    titleBn: `আত্মীয় (${path.length} ধাপের সংযোগ)`,
    category: 'extended'
  };
}
