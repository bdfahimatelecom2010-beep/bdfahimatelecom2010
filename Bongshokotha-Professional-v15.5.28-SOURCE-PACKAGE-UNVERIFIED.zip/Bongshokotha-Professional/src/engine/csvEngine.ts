/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Advanced CSV, Excel, Text Dossier & Standalone Offline HTML Engine
 * 
 * Features:
 * - UTF-8 BOM (\uFEFF) prefixed CSV exports for seamless Microsoft Excel rendering of Bangla script
 * - Robust CSV parser handling quotes, linebreaks, commas, and bilingual column headers
 * - Members, Marriages, and Branches spreadsheet exporters
 * - Blank downloadable templates for community data collection
 * - Formatted hierarchical text dossier generator
 * - Self-contained single-file portable offline HTML archive exporter
 */

import { Member, MarriageRecord, Branch, Family, Gender, BirthInfo, DeathInfo, IdentityDocuments } from '../types/genealogy';
import { parseGedcom } from './gedcomEngine';
import { BongshokothaArchive } from '../services/storage';

// Helper to escape CSV cell content
function escapeCsv(value: string | number | boolean | null | undefined): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Export Members to CSV with UTF-8 BOM for Microsoft Excel & Google Sheets compatibility
 */
export function exportMembersToCSV(
  members: Member[],
  branches: Branch[],
  generations: Map<string, number>,
  memberMap: Map<string, Member>
): string {
  const branchMap = new Map(branches.map(b => [b.id, b]));

  const headers = [
    'Serial Number (ক্রমিক)',
    'Bangla Name (বাংলা নাম)',
    'English Name (ইংরেজি নাম)',
    'Nickname (ডাকনাম)',
    'Gender (লিঙ্গ)',
    'Generation (প্রজন্ম)',
    'Birth Order (জন্মক্রম)',
    'Birth Year (জন্ম সাল)',
    'Birth District (জন্মের জেলা)',
    'Living Status (জীবিত কি না)',
    'Death Year (মৃত্যু সাল)',
    'Father ID (পিতার আইডি)',
    'Father Name (পিতার নাম)',
    'Mother ID (মাতার আইডি)',
    'Mother Name (মাতার নাম)',
    'Branch Name (শাখা)',
    'NID Number (জাতীয় পরিচয়পত্র)',
    'Birth Registration (জন্ম নিবন্ধন)',
    'Important Info (গুরুত্বপূর্ণ তথ্য)',
    'Biography (জীবনী ও সংক্ষিপ্ত ইতিহাস)'
  ];

  const rows: string[][] = members.map(m => {
    const gen = generations.get(m.id) || 1;
    const branch = m.branchId ? branchMap.get(m.branchId) : null;
    const father = m.fatherId ? memberMap.get(m.fatherId) : null;
    const mother = m.motherId ? memberMap.get(m.motherId) : null;

    return [
      m.serialNumber || '',
      m.banglaName || m.fullName || '',
      m.englishName || '',
      m.nickname || '',
      m.gender === 'male' ? 'পুরুষ / Male' : m.gender === 'female' ? 'মহিলা / Female' : 'অন্যান্য / Other',
      String(gen),
      m.birthOrder !== undefined ? String(m.birthOrder) : '',
      m.birth?.date?.year ? String(m.birth.date.year) : '',
      m.birth?.place?.district || m.birth?.place?.village || '',
      m.isLiving ? 'জীবিত / Yes' : 'প্রয়াত / Deceased',
      m.death?.isDeceased && m.death?.date?.year ? String(m.death.date.year) : '',
      m.fatherId || '',
      father ? (father.banglaName || father.fullName) : '',
      m.motherId || '',
      mother ? (mother.banglaName || mother.fullName) : '',
      branch ? (branch.banglaName || branch.name) : '',
      m.identityDocs?.nidNumber || '',
      m.identityDocs?.birthRegistrationNumber || '',
      m.importantInformation || '',
      m.biography || ''
    ];
  });

  // UTF-8 Byte Order Mark for Excel
  const csvContent = '\uFEFF' + [headers.map(escapeCsv).join(','), ...rows.map(r => r.map(escapeCsv).join(','))].join('\r\n');
  return csvContent;
}

/**
 * Export Marriages to CSV
 */
export function exportMarriagesToCSV(
  marriages: MarriageRecord[],
  memberMap: Map<string, Member>
): string {
  const headers = [
    'Marriage ID (বন্ধন আইডি)',
    'Husband ID (স্বামীর আইডি)',
    'Husband Name (স্বামীর নাম)',
    'Wife ID (স্ত্রীর আইডি)',
    'Wife Name (স্ত্রীর নাম)',
    'Marriage Year (বিবাহের সাল)',
    'Marriage Place (বিবাহের স্থান)',
    'Status (বৈবাহিক অবস্থা)',
    'Total Children (সন্তান সংখ্যা)',
    'Children Names (সন্তানদের নাম)',
    'Notes (টিকা)'
  ];

  const rows = marriages.map(mar => {
    const husband = mar.husbandId ? memberMap.get(mar.husbandId) : null;
    const wife = mar.wifeId ? memberMap.get(mar.wifeId) : null;
    const childrenNames = (mar.childrenIds || [])
      .map(id => {
        const child = memberMap.get(id);
        return child ? (child.banglaName || child.fullName) : id;
      })
      .join('; ');

    return [
      mar.id,
      mar.husbandId || '',
      husband ? (husband.banglaName || husband.fullName) : '',
      mar.wifeId || '',
      wife ? (wife.banglaName || wife.fullName) : '',
      mar.marriageDate?.year ? String(mar.marriageDate.year) : '',
      mar.marriagePlace?.district || mar.marriagePlace?.village || '',
      mar.status || 'current',
      String((mar.childrenIds || []).length),
      childrenNames,
      mar.marriageNotes || ''
    ];
  });

  return '\uFEFF' + [headers.map(escapeCsv).join(','), ...rows.map(r => r.map(escapeCsv).join(','))].join('\r\n');
}

/**
 * Generate Blank Member CSV Template for Offline Entry
 */
export function generateMembersCsvTemplate(): string {
  const headers = [
    'Bangla Name (বাংলা নাম)*',
    'English Name (ইংরেজি নাম)',
    'Nickname (ডাকনাম)',
    'Gender (লিঙ্গ: male/female)*',
    'Birth Order (জন্মক্রম: 1, 2, 3...)',
    'Birth Year (জন্ম সাল: e.g. 1975)',
    'Birth District (জন্মের জেলা)',
    'Is Living (জীবিত কি না: yes/no)',
    'Death Year (মৃত্যু সাল)',
    'NID Number (জাতীয় পরিচয়পত্র)',
    'Birth Reg Number (জন্ম নিবন্ধন নম্বর)',
    'Important Info (পেশা বা গুরুত্বপূর্ণ তথ্য)',
    'Biography (সংক্ষিপ্ত তথ্য ও জীবনী)'
  ];

  const sampleRows = [
    [
      'মো. আব্দুল করিম চৌধুরী',
      'Md. Abdul Karim Chowdhury',
      'করিম সাহেব',
      'male',
      '1',
      '1952',
      'সিলেট',
      'yes',
      '',
      '1952911234567890',
      '19529112345678901',
      'অবসরপ্রাপ্ত শিক্ষক ও শিক্ষাবিদ',
      'পরিবারের জ্যেষ্ঠ অভিভাবক।'
    ],
    [
      'রাবেয়া সুলতানা চৌধুরী',
      'Rabeya Sultana Chowdhury',
      'রুবি',
      'female',
      '2',
      '1956',
      'সিলেট',
      'yes',
      '',
      '1956911234567891',
      '19569112345678912',
      'সমাজকর্মী',
      'পরিবারের দ্বিতীয় কন্যা।'
    ]
  ];

  return '\uFEFF' + [headers.map(escapeCsv).join(','), ...sampleRows.map(r => r.map(escapeCsv).join(','))].join('\r\n');
}

/**
 * Parse CSV text into raw table data
 */
export function parseCSVToRows(csvText: string): string[][] {
  const clean = csvText.replace(/^\uFEFF/, '');
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentCell = '';
  let insideQuote = false;

  for (let i = 0; i < clean.length; i++) {
    const char = clean[i];
    const nextChar = clean[i + 1];

    if (char === '"') {
      if (insideQuote && nextChar === '"') {
        currentCell += '"';
        i++; // skip escaped quote
      } else {
        insideQuote = !insideQuote;
      }
    } else if (char === ',' && !insideQuote) {
      currentRow.push(currentCell.trim());
      currentCell = '';
    } else if ((char === '\r' || char === '\n') && !insideQuote) {
      if (char === '\r' && nextChar === '\n') {
        i++;
      }
      currentRow.push(currentCell.trim());
      if (currentRow.some(c => c.length > 0)) {
        rows.push(currentRow);
      }
      currentRow = [];
      currentCell = '';
    } else {
      currentCell += char;
    }
  }

  if (currentCell.length > 0 || currentRow.length > 0) {
    currentRow.push(currentCell.trim());
    if (currentRow.some(c => c.length > 0)) {
      rows.push(currentRow);
    }
  }

  return rows;
}

export interface ParsedCsvMemberResult {
  members: Partial<Member>[];
  marriages?: MarriageRecord[];
  errors: string[];
  totalRows: number;
}

export interface UniversalImportResult {
  format: 'gedcom' | 'bkf_archive' | 'csv' | 'unknown';
  formatLabel: string;
  family?: Partial<Family>;
  members: Member[];
  marriages: MarriageRecord[];
  branches: Branch[];
  summary: {
    totalMembers: number;
    totalMarriages: number;
    estimatedGenerations: number;
    livingCount: number;
    deceasedCount: number;
    description: string;
  };
  errors: string[];
}

/**
 * Parse Members from CSV with automatic relationship resolution
 */
export function parseMembersFromCSV(
  csvText: string,
  familyId: string,
  defaultBranchId: string
): ParsedCsvMemberResult {
  const rows = parseCSVToRows(csvText);
  if (rows.length < 2) {
    return { members: [], errors: ['ফাইলে কোনো সদস্যের তথ্য খুঁজে পাওয়া যায়নি।'], totalRows: 0 };
  }

  const headerRow = rows[0].map(h => h.toLowerCase());
  const errors: string[] = [];
  const rawEntries: {
    data: Partial<Member>;
    rawFatherRef?: string;
    rawMotherRef?: string;
    rawSpouseRef?: string;
  }[] = [];

  // Helper to find column index by matching aliases
  const findCol = (aliases: string[]): number => {
    return headerRow.findIndex(h => aliases.some(alias => h.includes(alias.toLowerCase())));
  };

  const nameIdx = findCol(['bangla name', 'বাংলা নাম', 'name', 'নাম', 'full name', 'পূর্ণ নাম']);
  const engNameIdx = findCol(['english name', 'ইংরেজি নাম', 'english']);
  const nickIdx = findCol(['nickname', 'ডাকনাম']);
  const genderIdx = findCol(['gender', 'লিঙ্গ', 'sex']);
  const birthOrderIdx = findCol(['birth order', 'জন্মক্রম', 'ক্রম']);
  const birthYearIdx = findCol(['birth year', 'জন্ম সাল', 'birth date', 'জন্ম']);
  const districtIdx = findCol(['district', 'জেলা', 'birth place', 'জন্মস্থান']);
  const livingIdx = findCol(['living', 'জীবিত', 'alive']);
  const deathYearIdx = findCol(['death year', 'মৃত্যু সাল', 'death']);
  const nidIdx = findCol(['nid', 'জাতীয় পরিচয়পত্র', 'জাতীয় পরিচয়পত্র']);
  const birthRegIdx = findCol(['birth reg', 'জন্ম নিবন্ধন']);
  const infoIdx = findCol(['info', 'পেশা', 'information', 'গুরুত্বপূর্ণ']);
  const bioIdx = findCol(['bio', 'জীবনী', 'ইতিহাস', 'notes']);
  const fatherIdx = findCol(['father id', 'father name', 'father', 'পিতা', 'বাবার নাম', 'পিতার নাম', 'পিতার আইডি']);
  const motherIdx = findCol(['mother id', 'mother name', 'mother', 'মাতা', 'মায়ের নাম', 'মাতার নাম', 'মাতার আইডি']);
  const spouseIdx = findCol(['spouse', 'দাম্পত্য সঙ্গী', 'স্ত্রী', 'স্বামী', 'wife', 'husband']);
  const serialIdx = findCol(['serial number', 'serial', 'ক্রমিক', 'আইডি']);

  if (nameIdx === -1) {
    return {
      members: [],
      errors: ['কলামে "বাংলা নাম" বা "Name" শীর্ষক কোনো কলাম পাওয়া যায়নি।'],
      totalRows: rows.length - 1
    };
  }

  const now = new Date().toISOString();

  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    const rawName = row[nameIdx]?.trim();
    if (!rawName) continue; // skip blank rows

    let gender: Gender = 'male';
    if (genderIdx !== -1) {
      const gStr = row[genderIdx]?.toLowerCase() || '';
      if (gStr.includes('female') || gStr.includes('মহিলা') || gStr.includes('নারী') || gStr === 'f') {
        gender = 'female';
      } else if (gStr.includes('other') || gStr.includes('অন্যান্য')) {
        gender = 'other';
      }
    }

    let birthYear: number | undefined;
    if (birthYearIdx !== -1) {
      const parsedY = parseInt(row[birthYearIdx]?.replace(/\D/g, ''), 10);
      if (!isNaN(parsedY) && parsedY > 1000 && parsedY < 2100) {
        birthYear = parsedY;
      }
    }

    let deathYear: number | undefined;
    if (deathYearIdx !== -1) {
      const parsedDY = parseInt(row[deathYearIdx]?.replace(/\D/g, ''), 10);
      if (!isNaN(parsedDY) && parsedDY > 1000 && parsedDY < 2100) {
        deathYear = parsedDY;
      }
    }

    let birthOrder: number | undefined;
    if (birthOrderIdx !== -1) {
      const bo = parseInt(row[birthOrderIdx]?.replace(/\D/g, ''), 10);
      if (!isNaN(bo) && bo > 0) {
        birthOrder = bo;
      }
    }

    let isLiving = true;
    if (livingIdx !== -1) {
      const lStr = row[livingIdx]?.toLowerCase() || '';
      if (lStr.includes('no') || lStr.includes('না') || lStr.includes('মৃত') || lStr.includes('প্রয়াত') || lStr.includes('deceased')) {
        isLiving = false;
      }
    } else if (deathYear) {
      isLiving = false;
    }

    const birthInfo: BirthInfo = {
      date: {
        year: birthYear || null,
        month: null,
        day: null,
        precision: birthYear ? 'exact' : 'unknown'
      },
      place: {
        district: districtIdx !== -1 ? row[districtIdx]?.trim() : undefined
      }
    };

    const deathInfo: DeathInfo = {
      isDeceased: !isLiving,
      date: deathYear
        ? {
            year: deathYear,
            month: null,
            day: null,
            precision: 'exact'
          }
        : undefined
    };

    const identityDocs: IdentityDocuments = {
      nidNumber: nidIdx !== -1 && row[nidIdx]?.trim() ? row[nidIdx].trim() : undefined,
      birthRegistrationNumber: birthRegIdx !== -1 && row[birthRegIdx]?.trim() ? row[birthRegIdx].trim() : undefined,
      verificationStatus: 'unverified'
    };

    const memberId = `mem-${familyId}-${r}-${Date.now().toString(36).substring(3, 7)}`;
    const serialNum = serialIdx !== -1 && row[serialIdx]?.trim()
      ? row[serialIdx].trim()
      : `M-${String(r).padStart(3, '0')}`;

    const memberData: Partial<Member> = {
      id: memberId,
      serialNumber: serialNum,
      fullName: rawName,
      banglaName: rawName,
      englishName: engNameIdx !== -1 ? row[engNameIdx]?.trim() || rawName : rawName,
      nickname: nickIdx !== -1 ? row[nickIdx]?.trim() || undefined : undefined,
      gender,
      birthOrder,
      isLiving,
      birthOrigin: 'born_in_family',
      marriageOrigin: false,
      isUnmarried: false,
      branchId: defaultBranchId,
      marriageIds: [],
      birth: birthInfo,
      death: deathInfo,
      identityDocs,
      importantInformation: infoIdx !== -1 ? row[infoIdx]?.trim() || undefined : undefined,
      biography: bioIdx !== -1 ? row[bioIdx]?.trim() || undefined : undefined,
      createdAt: now,
      updatedAt: now
    };

    rawEntries.push({
      data: memberData,
      rawFatherRef: fatherIdx !== -1 ? row[fatherIdx]?.trim() : undefined,
      rawMotherRef: motherIdx !== -1 ? row[motherIdx]?.trim() : undefined,
      rawSpouseRef: spouseIdx !== -1 ? row[spouseIdx]?.trim() : undefined
    });
  }

  // Auto-connect parents and marriages across the dataset
  const parsedMembers = rawEntries.map(e => e.data);
  const nameToMemberMap = new Map<string, Partial<Member>>();
  parsedMembers.forEach(m => {
    if (m.banglaName) nameToMemberMap.set(m.banglaName.toLowerCase().trim(), m);
    if (m.englishName) nameToMemberMap.set(m.englishName.toLowerCase().trim(), m);
    if (m.serialNumber) nameToMemberMap.set(m.serialNumber.toLowerCase().trim(), m);
  });

  const generatedMarriages: MarriageRecord[] = [];
  const marriageKeySet = new Set<string>();

  rawEntries.forEach(({ data, rawFatherRef, rawMotherRef, rawSpouseRef }) => {
    if (rawFatherRef) {
      const match = nameToMemberMap.get(rawFatherRef.toLowerCase().trim());
      if (match && match.id) data.fatherId = match.id;
    }
    if (rawMotherRef) {
      const match = nameToMemberMap.get(rawMotherRef.toLowerCase().trim());
      if (match && match.id) data.motherId = match.id;
    }
    if (rawSpouseRef && data.id) {
      const spouseMatch = nameToMemberMap.get(rawSpouseRef.toLowerCase().trim());
      if (spouseMatch && spouseMatch.id) {
        const husbandId = data.gender === 'male' ? data.id : spouseMatch.id;
        const wifeId = data.gender === 'female' ? data.id : spouseMatch.id;
        const key = `${husbandId}-${wifeId}`;

        if (!marriageKeySet.has(key)) {
          marriageKeySet.add(key);
          const marId = `mar-${Date.now().toString(36)}-${generatedMarriages.length + 1}`;
          const marriageRecord: MarriageRecord = {
            id: marId,
            serialNumber: `MR-${String(generatedMarriages.length + 1).padStart(3, '0')}`,
            husbandId,
            wifeId,
            marriageDate: { precision: 'unknown' },
            marriagePlace: {},
            status: 'current',
            childrenIds: [],
            createdAt: now,
            updatedAt: now
          };
          generatedMarriages.push(marriageRecord);
          if (!data.marriageIds) data.marriageIds = [];
          data.marriageIds.push(marId);
          if (!spouseMatch.marriageIds) spouseMatch.marriageIds = [];
          spouseMatch.marriageIds.push(marId);
        }
      }
    }
  });

  // Link children to generated marriages
  generatedMarriages.forEach(mar => {
    const children = parsedMembers.filter(m =>
      (m.fatherId === mar.husbandId && m.motherId === mar.wifeId) ||
      (m.fatherId === mar.husbandId && !m.motherId) ||
      (m.motherId === mar.wifeId && !m.fatherId)
    );
    mar.childrenIds = children.map(c => c.id!).filter(Boolean);
  });

  return {
    members: parsedMembers,
    marriages: generatedMarriages,
    errors,
    totalRows: rows.length - 1
  };
}

/**
 * Universal Intelligent Auto-Detector and Importer
 * Automatically detects whether data is GEDCOM, Bongshokotha Backup, or CSV/Spreadsheet
 */
export function autoDetectAndParseUniversalImport(
  rawText: string,
  familyId: string,
  defaultBranchId: string
): UniversalImportResult {
  const clean = rawText.trim();
  const errors: string[] = [];
  const now = new Date().toISOString();

  // 1. Detect Bongshokotha Backup JSON (.bkf / .json)
  if (clean.startsWith('{') && (clean.includes('"format"') || clean.includes('"members"') || clean.includes('"family"'))) {
    try {
      const parsed = JSON.parse(clean);
      if (parsed.members && Array.isArray(parsed.members)) {
        const members: Member[] = parsed.members.map((m: any, i: number) => ({
          ...m,
          id: m.id || `mem-${familyId}-${i + 1}-${Date.now().toString(36)}`,
          serialNumber: m.serialNumber || `M-${String(i + 1).padStart(3, '0')}`,
          branchId: m.branchId || defaultBranchId,
          marriageIds: m.marriageIds || [],
          birth: m.birth || { date: { precision: 'unknown' }, place: {} },
          death: m.death || { isDeceased: !m.isLiving },
          identityDocs: m.identityDocs || { verificationStatus: 'unverified' },
          createdAt: m.createdAt || now,
          updatedAt: m.updatedAt || now
        }));

        const marriages: MarriageRecord[] = Array.isArray(parsed.marriages)
          ? parsed.marriages.map((mar: any, i: number) => ({
              ...mar,
              id: mar.id || `mar-${Date.now().toString(36)}-${i + 1}`,
              serialNumber: mar.serialNumber || `MR-${String(i + 1).padStart(3, '0')}`,
              createdAt: mar.createdAt || now,
              updatedAt: mar.updatedAt || now
            }))
          : [];

        const branches: Branch[] = Array.isArray(parsed.branches) ? parsed.branches : [];
        const livingCount = members.filter(m => m.isLiving !== false).length;

        return {
          format: 'bkf_archive',
          formatLabel: 'বংশকথা পূর্ণাঙ্গ সিস্টেম ব্যাকআপ (.bkf / .json)',
          family: parsed.family,
          members,
          marriages,
          branches,
          summary: {
            totalMembers: members.length,
            totalMarriages: marriages.length,
            estimatedGenerations: Math.max(1, Math.ceil(Math.log2(members.length + 1))),
            livingCount,
            deceasedCount: members.length - livingCount,
            description: `বংশকথা ব্যাকআপ ফাইল থেকে ${members.length} জন সদস্য ও ${marriages.length} টি সম্পর্ক সনাক্ত হয়েছে।`
          },
          errors
        };
      }
    } catch (err: unknown) {
      errors.push(`JSON পার্স ত্রুটি: ${err instanceof Error ? err.message : 'অকার্যকর ফরম্যাট'}`);
    }
  }

  // 2. Detect GEDCOM 5.5.1 (.ged)
  if (clean.includes('0 HEAD') || clean.includes('0 @I') || clean.includes('INDI') || clean.includes('0 @F')) {
    try {
      const gedResult = parseGedcom(clean);
      const members: Member[] = gedResult.members.map((m, i) => ({
        id: m.id || `ged-m-${Date.now().toString(36)}-${i + 1}`,
        serialNumber: m.serialNumber || `GD-${String(i + 1).padStart(3, '0')}`,
        fullName: m.fullName || `সদস্য ${i + 1}`,
        banglaName: m.banglaName || m.fullName || `সদস্য ${i + 1}`,
        englishName: m.englishName || m.fullName || `Member ${i + 1}`,
        gender: m.gender || 'male',
        isLiving: m.isLiving ?? true,
        birthOrigin: 'born_in_family',
        marriageOrigin: false,
        isUnmarried: false,
        branchId: defaultBranchId,
        marriageIds: m.marriageIds || [],
        fatherId: m.fatherId,
        motherId: m.motherId,
        birth: m.birth || { date: { precision: 'unknown' }, place: {} },
        death: m.death || { isDeceased: !m.isLiving },
        identityDocs: m.identityDocs || { verificationStatus: 'unverified' },
        createdAt: now,
        updatedAt: now
      }));

      const marriages: MarriageRecord[] = gedResult.marriages.map((mar, i) => ({
        id: mar.id || `ged-mar-${Date.now().toString(36)}-${i + 1}`,
        serialNumber: mar.serialNumber || `GMR-${String(i + 1).padStart(3, '0')}`,
        husbandId: mar.husbandId || '',
        wifeId: mar.wifeId || '',
        marriageDate: mar.marriageDate || { precision: 'unknown' },
        marriagePlace: mar.marriagePlace || {},
        status: mar.status || 'current',
        childrenIds: mar.childrenIds || [],
        createdAt: now,
        updatedAt: now
      }));

      const livingCount = members.filter(m => m.isLiving !== false).length;

      return {
        format: 'gedcom',
        formatLabel: 'আন্তর্জাতিক GEDCOM 5.5.1 বংশতালিকা ফাইল (.ged)',
        members,
        marriages,
        branches: [],
        summary: {
          totalMembers: members.length,
          totalMarriages: marriages.length,
          estimatedGenerations: gedResult.stats.totalFamilies > 0 ? Math.max(2, gedResult.stats.totalFamilies) : 1,
          livingCount,
          deceasedCount: members.length - livingCount,
          description: `GEDCOM ফাইল থেকে ${members.length} জন পূর্বপুরুষ ও ${marriages.length} টি পারিবারিক বন্ধন সনাক্ত হয়েছে।`
        },
        errors
      };
    } catch (err: unknown) {
      errors.push(`GEDCOM পার্স ত্রুটি: ${err instanceof Error ? err.message : 'অকার্যকর ফাইল'}`);
    }
  }

  // 3. Fallback: Parse as Excel / CSV / Delimited Spreadsheet
  const csvParsed = parseMembersFromCSV(clean, familyId, defaultBranchId);
  const members: Member[] = csvParsed.members.map((m, i) => ({
    id: m.id || `csv-m-${familyId}-${i + 1}-${Date.now().toString(36)}`,
    serialNumber: m.serialNumber || `M-${String(i + 1).padStart(3, '0')}`,
    fullName: m.fullName || `সদস্য ${i + 1}`,
    banglaName: m.banglaName || m.fullName || `সদস্য ${i + 1}`,
    englishName: m.englishName || m.fullName || `Member ${i + 1}`,
    nickname: m.nickname,
    gender: m.gender || 'male',
    birthOrder: m.birthOrder,
    isLiving: m.isLiving ?? true,
    birthOrigin: 'born_in_family',
    marriageOrigin: false,
    isUnmarried: false,
    branchId: defaultBranchId,
    marriageIds: m.marriageIds || [],
    fatherId: m.fatherId,
    motherId: m.motherId,
    birth: m.birth || { date: { precision: 'unknown' }, place: {} },
    death: m.death || { isDeceased: !m.isLiving },
    identityDocs: m.identityDocs || { verificationStatus: 'unverified' },
    importantInformation: m.importantInformation,
    biography: m.biography,
    createdAt: now,
    updatedAt: now
  }));

  const marriages = csvParsed.marriages || [];
  const livingCount = members.filter(m => m.isLiving !== false).length;

  return {
    format: 'csv',
    formatLabel: 'Microsoft Excel / CSV স্প্রেডশিট (.csv / .tsv)',
    members,
    marriages,
    branches: [],
    summary: {
      totalMembers: members.length,
      totalMarriages: marriages.length,
      estimatedGenerations: Math.max(1, Math.ceil(Math.log2(members.length + 1))),
      livingCount,
      deceasedCount: members.length - livingCount,
      description: `স্প্রেডশিট থেকে ${members.length} জন সদস্য ও ${marriages.length} টি বৈবাহিক সংযোগ স্বয়ংক্রিয়ভাবে সনাক্ত হয়েছে।`
    },
    errors: [...errors, ...csvParsed.errors]
  };
}

/**
 * Export Formatted Lineage Text Dossier (.txt / Markdown)
 */
export function exportLineageToText(
  family: Family,
  members: Member[],
  marriages: MarriageRecord[],
  generations: Map<string, number>
): string {
  const dateStr = new Date().toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' });
  const lines: string[] = [];

  lines.push('================================================================================');
  lines.push(`               বংশকথা • ${family.banglaName || family.name}                `);
  lines.push('                   ঐতিহাসিক বংশবৃক্ষ ও পারিবারিক নথিপত্র                    ');
  lines.push('================================================================================');
  lines.push(`মুদ্রণ / রপ্তানি তারিখ: ${dateStr}`);
  lines.push(`পরিবার: ${family.banglaName || family.name}`);
  lines.push(`মোট সদস্য সংখ্যা: ${members.length} জন`);
  lines.push(`মোট বৈবাহিক রেকর্ড: ${marriages.length} টি`);
  lines.push(`মোট প্রজন্ম গভীরতা: ${Math.max(...Array.from(generations.values()), 1)} স্তর`);
  lines.push('--------------------------------------------------------------------------------');
  lines.push('');

  // Group by generation
  const maxGen = Math.max(...Array.from(generations.values()), 1);
  for (let g = 1; g <= maxGen; g++) {
    const genMembers = members.filter(m => (generations.get(m.id) || 1) === g);
    if (genMembers.length === 0) continue;

    lines.push(`\n▶ [প্রজন্ম ${g}] ----------------------------------------------------`);
    genMembers.forEach((m, idx) => {
      const birthStr = m.birth?.date?.year ? ` (জন্ম: ${m.birth.date.year})` : '';
      const deathStr = !m.isLiving && m.death?.date?.year ? ` [মৃত্যু: ${m.death.date.year}]` : (!m.isLiving ? ' [প্রয়াত]' : '');
      const orderStr = m.birthOrder ? ` [জন্মক্রম #${m.birthOrder}]` : '';
      const nickStr = m.nickname ? ` (ডাকনাম: ${m.nickname})` : '';
      const nidStr = m.identityDocs?.nidNumber ? ` | NID: ${m.identityDocs.nidNumber}` : '';
      const livingStatus = m.isLiving ? 'জীবিত' : 'প্রয়াত';

      lines.push(`  ${idx + 1}. [${m.serialNumber}] ${m.banglaName || m.fullName}${nickStr}${orderStr}${birthStr}${deathStr} - ${livingStatus}${nidStr}`);
      if (m.importantInformation) lines.push(`     • তথ্য: ${m.importantInformation}`);
      if (m.biography) lines.push(`     • পরিচিতি: ${m.biography}`);

      // Spouses
      const memberMarriages = marriages.filter(mar => mar.husbandId === m.id || mar.wifeId === m.id);
      if (memberMarriages.length > 0) {
        memberMarriages.forEach(mar => {
          const spouseId = mar.husbandId === m.id ? mar.wifeId : mar.husbandId;
          const spouse = members.find(s => s.id === spouseId);
          const spouseName = spouse ? (spouse.banglaName || spouse.fullName) : 'দাম্পত্য সঙ্গী';
          const childrenCount = (mar.childrenIds || []).length;
          lines.push(`     ♥ দাম্পত্য সঙ্গী: ${spouseName} (সন্তান সংখ্যা: ${childrenCount} জন)`);
        });
      }
    });
  }

  lines.push('\n================================================================================');
  lines.push('               বংশকথা অ্যাপ দ্বারা স্বয়ংক্রিয়ভাবে সংকলিত ও সংরক্ষিত              ');
  lines.push('================================================================================');

  return lines.join('\n');
}

/**
 * Generate Standalone Single-File Interactive Offline HTML Archive
 */
export function exportStandaloneHTMLArchive(
  family: Family,
  members: Member[],
  marriages: MarriageRecord[],
  branches: Branch[],
  generations: Map<string, number>
): string {
  const safeTitle = family.banglaName || family.name;
  const membersJson = JSON.stringify(members);
  const marriagesJson = JSON.stringify(marriages);
  const branchesJson = JSON.stringify(branches);
  const dateStr = new Date().toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' });

  return `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>বংশকথা • ${safeTitle} (অফলাইন সংরক্ষণাগার)</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Noto Sans Bengali', sans-serif;
      background: #fafaf9;
      color: #1c1917;
      margin: 0;
      padding: 20px;
    }
    .header {
      background: linear-gradient(135deg, #78350f, #92400e);
      color: white;
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      margin-bottom: 30px;
      text-align: center;
    }
    .header h1 { margin: 0 0 10px 0; font-size: 28px; }
    .header p { margin: 5px 0; opacity: 0.9; font-size: 14px; }
    .stats {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-top: 15px;
      flex-wrap: wrap;
    }
    .stat-badge {
      background: rgba(255,255,255,0.18);
      padding: 6px 14px;
      border-radius: 99px;
      font-weight: bold;
      font-size: 13px;
    }
    .container { max-width: 1100px; margin: 0 auto; }
    .search-box {
      width: 100%;
      padding: 12px 18px;
      border-radius: 12px;
      border: 1px solid #d6d3d1;
      font-size: 15px;
      margin-bottom: 25px;
      box-sizing: border-box;
      outline: none;
    }
    .gen-section {
      background: white;
      border-radius: 16px;
      padding: 20px;
      margin-bottom: 25px;
      border: 1px solid #e7e5e4;
      box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    }
    .gen-title {
      font-size: 18px;
      font-weight: bold;
      color: #78350f;
      border-bottom: 2px solid #fef3c7;
      padding-bottom: 8px;
      margin-bottom: 15px;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 15px;
    }
    .card {
      border: 1px solid #e7e5e4;
      border-radius: 12px;
      padding: 15px;
      background: #fafaf9;
      transition: transform 0.2s;
    }
    .card:hover { transform: translateY(-2px); border-color: #92400e; }
    .card-top { display: flex; justify-content: space-between; margin-bottom: 8px; }
    .serial { font-family: monospace; font-size: 11px; font-weight: bold; background: #fef3c7; color: #92400e; padding: 2px 6px; border-radius: 6px; }
    .status { font-size: 10px; font-weight: bold; padding: 2px 8px; border-radius: 99px; }
    .living { background: #dcfce7; color: #166534; }
    .deceased { background: #f5f5f4; color: #57534e; }
    .name { font-size: 16px; font-weight: bold; color: #292524; margin-bottom: 4px; }
    .meta { font-size: 12px; color: #78716c; margin-bottom: 2px; }
    .footer { text-align: center; font-size: 12px; color: #a8a29e; margin-top: 40px; padding: 20px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${safeTitle}</h1>
      <p>বংশকথা অফলাইন পারিবারিক সংরক্ষণাগার ও বংশতালিকা</p>
      <div class="stats">
        <div class="stat-badge">মোট সদস্য: ${members.length} জন</div>
        <div class="stat-badge">বৈবাহিক বন্ধন: ${marriages.length} টি</div>
        <div class="stat-badge">শাখা: ${branches.length} টি</div>
        <div class="stat-badge">রপ্তানি তারিখ: ${dateStr}</div>
      </div>
    </div>

    <input type="text" id="searchInput" class="search-box" placeholder="নাম, ক্রমিক বা জন্ম সাল লিখে খুঁজুন..." oninput="filterMembers()">

    <div id="treeContainer"></div>

    <div class="footer">
      বংশকথা • অফলাইন-ফার্স্ট পারিবারিক ঐতিহ্য প্ল্যাটফর্ম • কোনো ইন্টারনেট সংযোগ ছাড়াই কাজ করে।
    </div>
  </div>

  <script>
    const members = ${membersJson};
    const marriages = ${marriagesJson};
    const branches = ${branchesJson};

    function renderTree(filter = '') {
      const container = document.getElementById('treeContainer');
      container.innerHTML = '';

      const query = filter.toLowerCase().trim();
      const filtered = query
        ? members.filter(m => 
            (m.banglaName && m.banglaName.toLowerCase().includes(query)) ||
            (m.englishName && m.englishName.toLowerCase().includes(query)) ||
            (m.serialNumber && m.serialNumber.toLowerCase().includes(query)) ||
            (m.birth?.date?.year && String(m.birth.date.year).includes(query))
          )
        : members;

      if (filtered.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:40px; color:#78716c;">কোনো সদস্যের তথ্য খুঁজে পাওয়া যায়নি।</div>';
        return;
      }

      // Group into generations
      const genGroups = {};
      filtered.forEach(m => {
        const g = m.generation || 1;
        if (!genGroups[g]) genGroups[g] = [];
        genGroups[g].push(m);
      });

      Object.keys(genGroups).sort((a, b) => Number(a) - Number(b)).forEach(gen => {
        const section = document.createElement('div');
        section.className = 'gen-section';
        section.innerHTML = '<div class="gen-title">প্রজন্ম ' + gen + ' (' + genGroups[gen].length + ' জন সদস্য)</div>';

        const grid = document.createElement('div');
        grid.className = 'grid';

        genGroups[gen].forEach(m => {
          const card = document.createElement('div');
          card.className = 'card';
          const isLiv = m.isLiving !== false;
          const statusClass = isLiv ? 'living' : 'deceased';
          const statusText = isLiv ? 'জীবিত' : 'প্রয়াত';

          card.innerHTML = 
            '<div class="card-top">' +
              '<span class="serial">' + (m.serialNumber || 'M') + '</span>' +
              '<span class="status ' + statusClass + '">' + statusText + '</span>' +
            '</div>' +
            '<div class="name">' + (m.banglaName || m.fullName) + '</div>' +
            (m.englishName ? '<div class="meta">' + m.englishName + '</div>' : '') +
            (m.birth?.date?.year ? '<div class="meta">জন্ম: ' + m.birth.date.year + '</div>' : '') +
            (!isLiv && m.death?.date?.year ? '<div class="meta">মৃত্যু: ' + m.death.date.year + '</div>' : '') +
            (m.importantInformation ? '<div class="meta">তথ্য: ' + m.importantInformation + '</div>' : '');

          grid.appendChild(card);
        });

        section.appendChild(grid);
        container.appendChild(section);
      });
    }

    function filterMembers() {
      const q = document.getElementById('searchInput').value;
      renderTree(q);
    }

    renderTree();
  </script>
</body>
</html>`;
}
