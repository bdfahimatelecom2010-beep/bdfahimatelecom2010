import { Member, MarriageRecord } from '../types/genealogy';

export interface RelationshipIntegrityResult {
  members: Member[];
  marriages: MarriageRecord[];
  conflicts: string[];
  repaired: number;
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value));
}

export function marriageMatchesParents(child: Member, marriage: MarriageRecord): boolean {
  const fatherMatches = child.fatherId === marriage.husbandId;
  const motherMatches = child.motherId === marriage.wifeId;
  const fatherConflicts = Boolean(child.fatherId && child.fatherId !== marriage.husbandId);
  const motherConflicts = Boolean(child.motherId && child.motherId !== marriage.wifeId);
  if (fatherConflicts || motherConflicts) return false;
  return fatherMatches || motherMatches || (!child.fatherId && !child.motherId);
}

/**
 * Marriage children are union-specific. A child explicitly recorded on a marriage
 * is accepted only when it does not contradict an already-known biological parent.
 * Missing parent sides may be completed from the husband/wife roles during repair.
 */
export function getValidatedMarriageChildIds(
  marriage: MarriageRecord,
  members: Member[]
): string[] {
  const memberMap = new Map(members.map(m => [m.id, m]));
  return [...new Set(marriage.childrenIds || [])].filter(id => {
    const child = memberMap.get(id);
    return Boolean(child && marriageMatchesParents(child, marriage));
  });
}

/**
 * Canonical children for one person. Direct fatherId/motherId links are always
 * included. Marriage children are included only when the marriage does not
 * contradict the child's known parent links. This prevents a child of marriage-1
 * from leaking into marriage-2 merely because the same parent has multiple spouses.
 */
function compareCanonicalChildren(a: Member, b: Member): number {
  const ao = a.birthOrder ?? Number.MAX_SAFE_INTEGER;
  const bo = b.birthOrder ?? Number.MAX_SAFE_INTEGER;
  if (ao !== bo) return ao - bo;
  const ad = a.birth?.date;
  const bd = b.birth?.date;
  const ay = ad?.year ?? Number.MAX_SAFE_INTEGER;
  const by = bd?.year ?? Number.MAX_SAFE_INTEGER;
  if (ay !== by) return ay - by;
  const am = ad?.month ?? Number.MAX_SAFE_INTEGER;
  const bm = bd?.month ?? Number.MAX_SAFE_INTEGER;
  if (am !== bm) return am - bm;
  const aday = ad?.day ?? Number.MAX_SAFE_INTEGER;
  const bday = bd?.day ?? Number.MAX_SAFE_INTEGER;
  if (aday !== bday) return aday - bday;
  return a.id.localeCompare(b.id);
}

export function getCanonicalChildren(
  memberId: string,
  members: Member[],
  marriages: MarriageRecord[]
): Member[] {
  const memberMap = new Map(members.map(m => [m.id, m]));
  const ids = new Set<string>();

  for (const child of members) {
    if (child.fatherId === memberId || child.motherId === memberId) ids.add(child.id);
  }

  for (const marriage of marriages) {
    if (marriage.husbandId !== memberId && marriage.wifeId !== memberId) continue;
    for (const childId of getValidatedMarriageChildIds(marriage, members)) ids.add(childId);
  }

  return [...ids]
    .map(id => memberMap.get(id))
    .filter((m): m is Member => Boolean(m))
    .sort(compareCanonicalChildren);
}

export function getCanonicalChildrenForMarriage(
  marriage: MarriageRecord,
  members: Member[]
): Member[] {
  const memberMap = new Map(members.map(m => [m.id, m]));
  return getValidatedMarriageChildIds(marriage, members)
    .map(id => memberMap.get(id))
    .filter((m): m is Member => Boolean(m))
    .sort(compareCanonicalChildren);
}

export interface SiblingSets {
  fullSiblings: Member[];
  halfSiblings: Member[];
}

/**
 * Siblings are derived from canonical parent links plus an explicit marriage
 * union when a parent side is missing. No same-name or generation-only matching
 * is ever used.
 */
export function getCanonicalSiblings(
  memberId: string,
  members: Member[],
  marriages: MarriageRecord[] = []
): SiblingSets {
  const target = members.find(m => m.id === memberId);
  if (!target) return { fullSiblings: [], halfSiblings: [] };

  const targetParentIds = new Set([target.fatherId, target.motherId].filter(Boolean));
  const full: Member[] = [];
  const half: Member[] = [];

  for (const candidate of members) {
    if (candidate.id === memberId) continue;
    const sharedFather = Boolean(target.fatherId && candidate.fatherId === target.fatherId);
    const sharedMother = Boolean(target.motherId && candidate.motherId === target.motherId);
    // A shared marriage/union alone is not proof of biological siblinghood.
    // This is especially important for adopted, step, guardian and legal children.
    // Full/half sibling classification therefore relies only on canonical biological
    // parent IDs here; marriage-specific child grouping remains available elsewhere.
    if (sharedFather && sharedMother) full.push(candidate);
    else if (sharedFather || sharedMother) half.push(candidate);
  }

  const sort = (a: Member, b: Member) =>
    (a.birthOrder ?? 999999) - (b.birthOrder ?? 999999) ||
    (a.birth?.date?.year ?? 9999) - (b.birth?.date?.year ?? 9999) ||
    (a.birth?.date?.month ?? 99) - (b.birth?.date?.month ?? 99) ||
    (a.birth?.date?.day ?? 99) - (b.birth?.date?.day ?? 99) ||
    a.id.localeCompare(b.id);

  full.sort(sort);
  half.sort(sort);
  return { fullSiblings: full, halfSiblings: half };
}

/**
 * Safe canonical reconciliation. It only repairs facts that are unambiguous:
 * - removes dangling/duplicate marriage child IDs
 * - restores spouse -> marriageIds reciprocity
 * - links a child to both parents when both parents are already explicit in the
 *   marriage and the child is listed there
 * - adds a child to the unique marriage matching both known parents
 *
 * It NEVER overwrites an existing conflicting father/mother and records a conflict
 * instead. This is critical for multiple marriages and historical families.
 */
export function reconcileCanonicalRelationships(
  inputMembers: Member[],
  inputMarriages: MarriageRecord[]
): RelationshipIntegrityResult {
  const members = clone(inputMembers) as Member[];
  const marriages = clone(inputMarriages) as MarriageRecord[];
  const memberMap = new Map(members.map(m => [m.id, m]));
  const conflicts: string[] = [];
  let repaired = 0;

  for (const member of members) {
    member.marriageIds = [...new Set((member.marriageIds || []).filter(id => marriages.some(m => m.id === id)))];
  }

  for (const marriage of marriages) {
    marriage.childrenIds = [...new Set((marriage.childrenIds || []).filter(id => memberMap.has(id)))];
    const husband = memberMap.get(marriage.husbandId);
    const wife = memberMap.get(marriage.wifeId);
    if (!husband || !wife) continue;

    for (const spouse of [husband, wife]) {
      if (!spouse.marriageIds.includes(marriage.id)) {
        spouse.marriageIds.push(marriage.id);
        spouse.isUnmarried = false;
        repaired++;
      }
    }

    for (const childId of [...marriage.childrenIds]) {
      const child = memberMap.get(childId);
      if (!child) continue;
      if ((child.fatherId && child.fatherId !== marriage.husbandId) || (child.motherId && child.motherId !== marriage.wifeId)) {
        conflicts.push(`Marriage ${marriage.id} child ${child.id} conflicts with both recorded parents.`);
        continue;
      }
      if (!child.fatherId && husband.gender === 'male' && child.birthOrigin !== 'adopted') {
        child.fatherId = husband.id;
        repaired++;
      }
      if (!child.motherId && wife.gender === 'female' && child.birthOrigin !== 'adopted') {
        child.motherId = wife.id;
        repaired++;
      }
    }
  }

  // If both biological parents are explicitly known, the child belongs to the
  // unique matching marriage only. Never attach it to every marriage of a parent.
  for (const child of members) {
    if (!child.fatherId || !child.motherId) continue;
    const matches = marriages.filter(m =>
      (m.husbandId === child.fatherId && m.wifeId === child.motherId) ||
      (m.husbandId === child.motherId && m.wifeId === child.fatherId)
    );
    if (matches.length === 1 && !matches[0].childrenIds.includes(child.id)) {
      matches[0].childrenIds.push(child.id);
      repaired++;
    } else if (matches.length > 1) {
      conflicts.push(`Child ${child.id} matches multiple marriage records for the same parent pair.`);
    }
  }

  return { members, marriages, conflicts, repaired };
}
