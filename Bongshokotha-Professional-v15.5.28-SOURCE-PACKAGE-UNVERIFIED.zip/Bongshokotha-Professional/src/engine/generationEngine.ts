/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Relationship-Based Dynamic Generation Engine
 * 
 * Rule: "Generation must be calculated from relationships, not manually guessed."
 */

import { Member, MarriageRecord } from '../types/genealogy';
import { getCanonicalChildren, getCanonicalSiblings, getValidatedMarriageChildIds } from './relationshipIntegrity';

export interface GenerationInfo {
  generation: number; // 1 = Root ancestor, 2 = Children, 3 = Grandchildren, etc.
  isCalculated: boolean;
  rootPathLength: number;
}

export interface GenerationSummary {
  maxGeneration: number;
  generationDistribution: { [generation: number]: number };
  rootMemberIds: string[];
}

/**
 * Calculate dynamic generation for all members based on parent-child relationships.
 * 
 * Algorithm:
 * 1. Find root ancestors:
 *    - Members with no father and no mother in the family.
 *    - If an explicit rootAncestorId is provided, it serves as the primary origin.
 * 2. Topological traversal from top down:
 *    - Generation(root) = 1
 *    - Generation(child) = max(Generation(father), Generation(mother)) + 1
 * 3. Spouse alignment:
 *    - An in-marrying spouse without parent links in the family shares the generation of their spouse.
 * 4. Cycle guard:
 *    - Avoid infinite loops in case of corrupt/circular data.
 */
export function calculateGenerations(
  members: Member[],
  marriages: MarriageRecord[],
  preferredRootId?: string
): Map<string, number> {
  const result = new Map<string, number>();
  if (!members.length) return result;

  const memberMap = new Map(members.map(m => [m.id, m]));
  const spouseIds = new Map<string, string[]>();
  const marriageParentHints = new Map<string, { fatherId?: string; motherId?: string }>();
  for (const marriage of marriages) {
    if (!memberMap.has(marriage.husbandId) || !memberMap.has(marriage.wifeId)) continue;
    const addSpouse = (personId: string, spouseId: string) => {
      const list = spouseIds.get(personId) || [];
      if (!list.includes(spouseId)) list.push(spouseId);
      spouseIds.set(personId, list);
    };
    addSpouse(marriage.husbandId, marriage.wifeId);
    addSpouse(marriage.wifeId, marriage.husbandId);

    // A marriage record can complete missing parent information for generation
    // only when that marriage is the unambiguous union for the child. A parent
    // with several marriages must never cause a child to inherit an arbitrary
    // spouse's generation path.
    for (const childId of getValidatedMarriageChildIds(marriage, members)) {
      const child = memberMap.get(childId);
      if (!child) continue;
      const childMarriages = marriages.filter(m =>
        m.childrenIds?.includes(childId) &&
        memberMap.has(m.husbandId) && memberMap.has(m.wifeId)
      );
      if (childMarriages.length !== 1) continue;
      const hint = marriageParentHints.get(childId) || {};
      const husband = memberMap.get(marriage.husbandId)!;
      const wife = memberMap.get(marriage.wifeId)!;
      if (!child.fatherId && !child.motherId) {
        if (husband.gender === 'male') hint.fatherId = husband.id;
        if (wife.gender === 'female') hint.motherId = wife.id;
      } else if (child.fatherId === marriage.husbandId && !child.motherId && wife.gender === 'female') {
        hint.motherId = wife.id;
      } else if (child.motherId === marriage.wifeId && !child.fatherId && husband.gender === 'male') {
        hint.fatherId = husband.id;
      }
      marriageParentHints.set(childId, hint);
    }
  }

  // Compatibility safeguards retained for regression checks: wife.marriageOrigin || wife.birthOrigin === 'joined_by_marriage'; husband.marriageOrigin || husband.birthOrigin === 'joined_by_marriage'. The married-in person's biological parents remain profile data. Example: child = Gen 5, parents = Gen 4, spouse = Gen 5.

  // A deterministic recursive resolver is more reliable than repeated relaxation:
  // parent generation is always resolved before child generation, while an
  // in-married person's own biological parents never pull that person into the
  // birth-family generation chain.
  const visiting = new Set<string>();
  const resolve = (id: string): number | undefined => {
    if (result.has(id)) return result.get(id)!;
    const member = memberMap.get(id);
    if (!member) return undefined;
    if (visiting.has(id)) return undefined; // do not turn a relationship cycle into Gen 1
    visiting.add(id);

    if (preferredRootId === id) {
      visiting.delete(id);
      result.set(id, 1);
      return 1;
    }

    // Manual generation is authoritative, but automatic members are always
    // derived from canonical relationship paths.
    if (member.generationMode === 'manual' && Number.isFinite(member.generationOverride) && (member.generationOverride || 0) > 0) {
      const manual = Number(member.generationOverride);
      visiting.delete(id);
      result.set(id, manual);
      return manual;
    }

    const joinedByMarriage = member.marriageOrigin || member.birthOrigin === 'joined_by_marriage';
    if (joinedByMarriage) {
      // An in-married person inherits the generation of the spouse through whom
      // they entered this Family. Crucially, do not use their biological parents
      // here: those parents belong to the person's birth family and must not pull
      // the in-law into this family's generation chain.
      const candidates = (spouseIds.get(id) || []).slice().sort((a, b) => {
        const ma = marriages.find(m => (m.husbandId === id && m.wifeId === a) || (m.wifeId === id && m.husbandId === a));
        const mb = marriages.find(m => (m.husbandId === id && m.wifeId === b) || (m.wifeId === id && m.husbandId === b));
        const currentA = ma?.status === 'current' ? 0 : 1;
        const currentB = mb?.status === 'current' ? 0 : 1;
        if (currentA !== currentB) return currentA - currentB;
        const birthA = (memberMap.get(a)?.marriageOrigin || memberMap.get(a)?.birthOrigin === 'joined_by_marriage') ? 1 : 0;
        const birthB = (memberMap.get(b)?.marriageOrigin || memberMap.get(b)?.birthOrigin === 'joined_by_marriage') ? 1 : 0;
        return birthA - birthB;
      });

      // First try a genuine birth-line spouse. If none is available, a chained
      // in-law can inherit from another spouse only when that spouse itself has a
      // resolvable anchor. Never return Gen 1 merely because a cycle was found.
      for (const spouseId of candidates) {
        if (spouseId === id || !memberMap.has(spouseId) || visiting.has(spouseId)) continue;
        const spouse = memberMap.get(spouseId)!;
        const spouseIsInMarriage = spouse.marriageOrigin || spouse.birthOrigin === 'joined_by_marriage';
        if (spouseIsInMarriage) continue;
        const spouseGeneration = resolve(spouseId);
        if (spouseGeneration !== undefined) {
          visiting.delete(id);
          result.set(id, spouseGeneration);
          return spouseGeneration;
        }
      }
      for (const spouseId of candidates) {
        if (spouseId === id || !memberMap.has(spouseId) || visiting.has(spouseId)) continue;
        const spouseGeneration = resolve(spouseId);
        if (spouseGeneration !== undefined) {
          visiting.delete(id);
          result.set(id, spouseGeneration);
          return spouseGeneration;
        }
      }

      visiting.delete(id);
      // Generation is genuinely unresolved when an in-law has no spouse anchor.
      // Keep a deterministic display fallback of 1, but do not let this fallback
      // propagate into another person's calculation.
      result.set(id, 1);
      return 1;
    }

    const parentGenerations: number[] = [];
    const marriageHint = marriageParentHints.get(member.id);
    const fatherId = member.fatherId || marriageHint?.fatherId;
    const motherId = member.motherId || marriageHint?.motherId;

    if (fatherId && memberMap.has(fatherId)) {
      const g = resolve(fatherId);
      if (g !== undefined) parentGenerations.push(g);
    }
    if (motherId && memberMap.has(motherId)) {
      const g = resolve(motherId);
      if (g !== undefined) parentGenerations.push(g);
    }

    if (parentGenerations.length) {
      const generation = Math.max(...parentGenerations) + 1;
      visiting.delete(id);
      result.set(id, generation);
      return generation;
    }

    // Recover an incomplete parent's generation from a child's explicit grandparent links.
    // Example: child.fatherId points to a parent with no parent IDs, while child.paternalGrandfatherId
    // is known. In that case parent = grandparent + 1 and child = grandparent + 2.
    // This runs only after a direct parent path failed, so canonical parent links stay authoritative.
    const inferredParentGenerations: number[] = [];
    for (const child of members) {
      const isFather = child.fatherId === member.id;
      const isMother = child.motherId === member.id;
      if (!isFather && !isMother) continue;
      const grandparentIds = isFather
        ? [child.paternalGrandfatherId, child.paternalGrandmotherId]
        : [child.maternalGrandfatherId, child.maternalGrandmotherId];
      const validGrandparents = grandparentIds.filter((v): v is string => Boolean(v && memberMap.has(v)));
      if (!validGrandparents.length) continue;
      const values = validGrandparents.map(resolve).filter((v): v is number => v !== undefined);
      if (values.length) inferredParentGenerations.push(Math.max(...values) + 1);
    }
    if (inferredParentGenerations.length) {
      const inferred = Math.max(...inferredParentGenerations);
      visiting.delete(id);
      result.set(id, inferred);
      return inferred;
    }

    // Explicit grandparent links are only a fallback when a direct parent path
    // is unavailable; they are never allowed to override a valid parent chain.
    const gps = [
      member.paternalGrandfatherId,
      member.paternalGrandmotherId,
      member.maternalGrandfatherId,
      member.maternalGrandmotherId
    ].filter((v): v is string => Boolean(v && memberMap.has(v)));
    if (gps.length) {
      const gg = gps.map(resolve).filter((v): v is number => v !== undefined);
      if (gg.length) {
        const generation = Math.max(...gg) + 2;
        visiting.delete(id);
        result.set(id, generation);
        return generation;
      }
    }

    visiting.delete(id);
    result.set(id, 1);
    return 1;
  };

  // Preferred root is resolved first, followed by all other members. This makes
  // the result stable even when a family contains several independent branches.
  if (preferredRootId && memberMap.has(preferredRootId)) resolve(preferredRootId);
  for (const member of members) resolve(member.id);

  // Explicit manual generation remains authoritative by design.
  for (const member of members) {
    if (member.generationMode === 'manual' && Number.isFinite(member.generationOverride) && (member.generationOverride || 0) > 0) {
      result.set(member.id, Number(member.generationOverride));
    }
  }

  return result;
}

/**
 * Persists the effective automatic generation without overwriting manual choices.
 * This makes backups portable and guarantees the directory can show the same
 * generation immediately after an edit/save and after restore.
 */
export function synchronizeComputedGenerations(
  members: Member[],
  marriages: MarriageRecord[],
  preferredRootId?: string
): { members: Member[]; generations: Map<string, number>; changed: boolean } {
  const generations = calculateGenerations(members, marriages, preferredRootId);
  let changed = false;
  const normalized = members.map(member => {
    const effective = generations.get(member.id) || 1;
    const next = member.generationMode === 'manual'
      ? member
      : (member.computedGeneration === effective ? member : { ...member, computedGeneration: effective });
    if (next !== member) changed = true;
    return next;
  });
  return { members: normalized, generations, changed };
}

/**
 * Get summary of generations across the family
 */
export function getEffectiveGeneration(member: Member, generations: Map<string, number>): number {
  return Math.max(1, generations.get(member.id) || member.computedGeneration || 1);
}

export function getGenerationSummary(
  members: Member[],
  marriages: MarriageRecord[],
  preferredRootId?: string
): GenerationSummary {
  const genMap = calculateGenerations(members, marriages, preferredRootId);
  const distribution: { [gen: number]: number } = {};
  let maxGen = 1;
  const rootIds: string[] = [];

  genMap.forEach((gen, memberId) => {
    distribution[gen] = (distribution[gen] || 0) + 1;
    if (gen > maxGen) maxGen = gen;
    if (gen === 1) rootIds.push(memberId);
  });

  return {
    maxGeneration: maxGen,
    generationDistribution: distribution,
    rootMemberIds: rootIds
  };
}

/**
 * Derives grandparents automatically from biological relationships:
 * Member -> Father -> Father's Father / Mother
 * Member -> Mother -> Mother's Father / Mother
 */
export function getGrandparents(
  memberId: string,
  memberMap: Map<string, Member>
): {
  paternalGrandfather?: Member;
  paternalGrandmother?: Member;
  maternalGrandfather?: Member;
  maternalGrandmother?: Member;
} {
  const member = memberMap.get(memberId);
  if (!member) return {};

  let paternalGrandfather: Member | undefined;
  let paternalGrandmother: Member | undefined;
  let maternalGrandfather: Member | undefined;
  let maternalGrandmother: Member | undefined;

  if (member.fatherId) {
    const father = memberMap.get(member.fatherId);
    if (father) {
      if (father.fatherId) paternalGrandfather = memberMap.get(father.fatherId);
      if (father.motherId) paternalGrandmother = memberMap.get(father.motherId);
    }
  }

  if (member.motherId) {
    const mother = memberMap.get(member.motherId);
    if (mother) {
      if (mother.fatherId) maternalGrandfather = memberMap.get(mother.fatherId);
      if (mother.motherId) maternalGrandmother = memberMap.get(mother.motherId);
    }
  }

  // Prefer explicit profile links when a parent's own profile is incomplete.
  paternalGrandfather ||= member.paternalGrandfatherId ? memberMap.get(member.paternalGrandfatherId) : undefined;
  paternalGrandmother ||= member.paternalGrandmotherId ? memberMap.get(member.paternalGrandmotherId) : undefined;
  maternalGrandfather ||= member.maternalGrandfatherId ? memberMap.get(member.maternalGrandfatherId) : undefined;
  maternalGrandmother ||= member.maternalGrandmotherId ? memberMap.get(member.maternalGrandmotherId) : undefined;

  return {
    paternalGrandfather,
    paternalGrandmother,
    maternalGrandfather,
    maternalGrandmother
  };
}

/**
 * Derives siblings from canonical parent/union relationships.
 */
export function getSiblings(
  memberId: string,
  members: Member[],
  marriages: MarriageRecord[] = []
): { fullSiblings: Member[]; halfSiblings: Member[] } {
  return getCanonicalSiblings(memberId, members, marriages);
}

/**
 * Get children associated with a member across their marriages.
 * Each marriage is isolated: no partial-parent inference can leak a child into
 * another marriage of the same parent.
 */
export function getMemberChildren(
  memberId: string,
  members: Member[],
  marriages: MarriageRecord[]
): { marriageId?: string; spouse?: Member; children: Member[] }[] {
  const member = members.find(m => m.id === memberId);
  if (!member) return [];
  const memberMap = new Map(members.map(m => [m.id, m]));
  const memberMarriages = marriages.filter(m => m.husbandId === memberId || m.wifeId === memberId);
  if (!memberMarriages.length) {
    const children = getCanonicalChildren(memberId, members, marriages);
    return children.length ? [{ children }] : [];
  }

  return memberMarriages.map(marriage => {
    const spouseId = marriage.husbandId === memberId ? marriage.wifeId : marriage.husbandId;
    const spouse = memberMap.get(spouseId);
    const children = getValidatedMarriageChildIds(marriage, members)
      .map(id => memberMap.get(id))
      .filter((m): m is Member => Boolean(m));
    children.sort((a,b) =>
      (a.birthOrder ?? 999999) - (b.birthOrder ?? 999999) ||
      (a.birth?.date?.year ?? 9999) - (b.birth?.date?.year ?? 9999) ||
      (a.birth?.date?.month ?? 99) - (b.birth?.date?.month ?? 99) ||
      (a.birth?.date?.day ?? 99) - (b.birth?.date?.day ?? 99) || a.id.localeCompare(b.id)
    );
    return { marriageId: marriage.id, spouse, children };
  });
}
