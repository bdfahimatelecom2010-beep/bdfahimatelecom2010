import type { ExtractedDocumentFields, ExtractedFieldCandidate, LocationInfo, DocumentSide } from '../types/genealogy';

const BN_DIGITS = '০১২৩৪৫৬৭৮৯';
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const normalizeDigits = (value: string) => value
  .replace(/[০-৯]/g, d => String(BN_DIGITS.indexOf(d)))
  .replace(/[٠-٩]/g, d => String(AR_DIGITS.indexOf(d)));
const compactDigits = (value: string) => normalizeDigits(value).replace(/[^0-9]/g, '');
const normalizeSpace = (value: string) => value.replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').trim();
const cleanValue = (value: string) => normalizeSpace(value).replace(/^[\s:：.\-–—]+|[\s,;|]+$/g, '').trim();

function valueAfterLabel(lines: string[], index: number, label: RegExp, lookAhead = 3): string | undefined {
  const rawSame = normalizeSpace(lines[index].replace(label, ''));
  if (/^(?:--|—|-)$/u.test(rawSame)) return '--';
  const same = cleanValue(rawSame);
  if (same && same.length > 1) return same;
  for (let j = index + 1; j < Math.min(lines.length, index + 1 + lookAhead); j++) {
    const candidate = cleanValue(lines[j]);
    if (!candidate) continue;
    if (/^(?:নাম|name|পিতা|পিতাঃ|মাতা|মাতাঃ|father|mother|date|dob|n\.i\.d|nid|passport|number|no\.?|ঠিকানা|address)\s*[:：.\-–—]?$/i.test(candidate)) continue;
    return candidate;
  }
  return undefined;
}

function digitCandidates(text: string): string[] {
  const normalized = normalizeDigits(text);
  const out = new Set<string>();
  for (const run of normalized.match(/\d[\d\s-]{2,24}/g) || []) {
    const compact = compactDigits(run);
    if ([9, 10, 13, 17].includes(compact.length)) out.add(compact);
  }
  for (const direct of normalized.match(/\d{9}|\d{10}|\d{13}|\d{17}/g) || []) out.add(direct);
  return [...out];
}

function validPassport(value: string): boolean {
  const v = value.replace(/[<\s-]/g, '').toUpperCase();
  return /^[A-Z][A-Z0-9]{6,11}$/.test(v);
}

function datePatternMatch(text: string): string | undefined {
  const pattern = /(?:\b\d{1,2}[\/.\-]\d{1,2}[\/.\-]\d{2,4}\b|\b\d{4}[\/.\-]\d{1,2}[\/.\-]\d{1,2}\b|\b\d{1,2}\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{4}\b|[০-৯]{1,2}[\/.\-][০-৯]{1,2}[\/.\-][০-৯]{2,4})/i;
  return text.match(pattern)?.[0]?.trim();
}

/** Shared OCR date parser for Profile and Edit workflows. */
export function parseDocumentDate(value?: string): { day:number; month:number; year:number; precision:'exact' } | undefined {
  if (!value) return undefined;
  const v = normalizeDigits(String(value)).trim();
  const months: Record<string,number> = { jan:1,january:1,feb:2,february:2,mar:3,march:3,apr:4,april:4,may:5,jun:6,june:6,jul:7,july:7,aug:8,august:8,sep:9,sept:9,september:9,oct:10,october:10,nov:11,november:11,dec:12,december:12 };
  let m=v.match(/\b(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})\b/i);
  if(m){const month=months[m[2].toLowerCase()]; if(month)return {day:+m[1],month,year:+m[3],precision:'exact'};}
  m=v.match(/\b(\d{4})[\/.\-](\d{1,2})[\/.\-](\d{1,2})\b/);
  if(m)return {day:+m[3],month:+m[2],year:+m[1],precision:'exact'};
  m=v.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})\b/);
  if(m)return {day:+m[1],month:+m[2],year:+m[3],precision:'exact'};
  m=v.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2})\b/);
  if(m)return {day:+m[1],month:+m[2],year:+m[3]+(+m[3]>30?1900:2000),precision:'exact'};
  return undefined;
}

function parseMrzDate(raw: string | undefined, kind: 'birth' | 'expiry'): string | undefined {
  if (!raw || !/^\d{6}$/.test(raw)) return undefined;
  const yy = Number(raw.slice(0, 2));
  const mm = Number(raw.slice(2, 4));
  const dd = Number(raw.slice(4, 6));
  if (mm < 1 || mm > 12 || dd < 1 || dd > 31) return undefined;
  const year = kind === 'expiry' ? 2000 + yy : (yy > 30 ? 1900 + yy : 2000 + yy);
  return `${String(dd).padStart(2, '0')}/${String(mm).padStart(2, '0')}/${year}`;
}

function locationFromParts(parts: Partial<LocationInfo>): LocationInfo | undefined {
  const clean: LocationInfo = {};
  (Object.keys(parts) as (keyof LocationInfo)[]).forEach(k => {
    const v = parts[k];
    if (typeof v === 'string' && v.trim() && !/^(?:--|—|-)$/u.test(v.trim())) (clean as any)[k] = v.trim();
  });
  return Object.keys(clean).length ? clean : undefined;
}

function detectSide(documentKind: ExtractedDocumentFields['documentKind'], lines: string[]): DocumentSide {
  const text = lines.join(' ');
  if (documentKind !== 'nid') return 'unknown';
  const frontScore = [
    /\bname\b|\bনাম\b/i.test(text),
    /date\s+of\s+birth|জন্ম\s*তারিখ/i.test(text),
    /father|পিতা|পিং/i.test(text),
    /mother|মাতা/i.test(text),
    /national\s+id|জাত[ীি]য়\s*পরিচয়/i.test(text)
  ].filter(Boolean).length;
  const backScore = [
    /বাসা\s*\/\s*হোল্ডিং|holding|house/i.test(text),
    /গ্রাম\s*\/\s*রাস্তা|village|road/i.test(text),
    /ডাকঘর|post\s*office/i.test(text),
    /উপজেলা|থানা|upazila|thana/i.test(text),
    /জেলা|district/i.test(text),
    /I<BGD|<BGD/i.test(text)
  ].filter(Boolean).length;
  if (frontScore >= 2 && backScore < 2) return 'front';
  if (backScore >= 2 && frontScore < 2) return 'back';
  return 'unknown';
}

const knownFieldLabels: Record<string, { bn: string; en: string; category: ExtractedFieldCandidate['category']; writable?: boolean }> = {
  fullNameBn: { bn: 'বাংলা নাম', en: 'Bangla Name', category: 'identity', writable: true },
  fullNameEn: { bn: 'ইংরেজি নাম', en: 'English Name', category: 'identity', writable: true },
  nidNumber: { bn: 'NID নম্বর', en: 'NID Number', category: 'identity', writable: true },
  brnNumber: { bn: 'জন্ম নিবন্ধন নম্বর', en: 'Birth Registration Number', category: 'identity', writable: true },
  passportNumber: { bn: 'পাসপোর্ট নম্বর', en: 'Passport Number', category: 'identity', writable: true },
  passportPersonalNumber: { bn: 'Passport Personal No.', en: 'Passport Personal Number', category: 'identity', writable: true },
  passportIssueDate: { bn: 'পাসপোর্ট ইস্যু তারিখ', en: 'Passport Issue Date', category: 'document', writable: true },
  passportExpiryDate: { bn: 'পাসপোর্ট মেয়াদ শেষ', en: 'Passport Expiry Date', category: 'document', writable: true },
  passportIssuingAuthority: { bn: 'পাসপোর্ট ইস্যুকারী কর্তৃপক্ষ', en: 'Passport Issuing Authority', category: 'document', writable: true },
  previousPassportNumber: { bn: 'পূর্বের পাসপোর্ট নম্বর', en: 'Previous Passport Number', category: 'identity', writable: true },
  documentNumber: { bn: 'দলিল নম্বর', en: 'Document Number', category: 'document', writable: true },
  documentIssueDate: { bn: 'দলিল ইস্যু তারিখ', en: 'Document Issue Date', category: 'document', writable: false },
  documentDate: { bn: 'দলিলের তারিখ', en: 'Document Date', category: 'document', writable: false },
  dateOfBirth: { bn: 'জন্ম তারিখ', en: 'Date of Birth', category: 'life', writable: true },
  placeOfBirth: { bn: 'জন্মস্থান', en: 'Place of Birth', category: 'life', writable: true },
  fatherName: { bn: 'পিতার নাম', en: 'Father Name', category: 'relationship', writable: true },
  motherName: { bn: 'মাতার নাম', en: 'Mother Name', category: 'relationship', writable: true },
  spouseName: { bn: 'স্বামী/স্ত্রীর নাম', en: 'Spouse Name', category: 'relationship', writable: false },
  childrenNames: { bn: 'সন্তানের নাম', en: 'Children Names', category: 'relationship', writable: false },
  occupation: { bn: 'পেশা', en: 'Occupation', category: 'life', writable: true },
  mobileNumber: { bn: 'মোবাইল নম্বর', en: 'Mobile Number', category: 'contact', writable: true },
  email: { bn: 'ই-মেইল', en: 'Email', category: 'contact', writable: true },
  religion: { bn: 'ধর্ম', en: 'Religion', category: 'life', writable: true },
  nationality: { bn: 'জাতীয়তা', en: 'Nationality', category: 'identity', writable: true },
  gender: { bn: 'লিঙ্গ', en: 'Gender', category: 'identity', writable: true },
  bloodGroup: { bn: 'রক্তের গ্রুপ', en: 'Blood Group', category: 'life', writable: true },
  address: { bn: 'ঠিকানা', en: 'Address', category: 'address', writable: true },
  presentAddress: { bn: 'বর্তমান ঠিকানা', en: 'Present Address', category: 'address', writable: true },
  permanentAddress: { bn: 'স্থায়ী ঠিকানা', en: 'Permanent Address', category: 'address', writable: true },
  holding: { bn: 'বাসা/হোল্ডিং', en: 'House/Holding', category: 'address', writable: true },
  road: { bn: 'গ্রাম/রাস্তা', en: 'Village/Road', category: 'address', writable: true },
  village: { bn: 'গ্রাম', en: 'Village', category: 'address', writable: true },
  union: { bn: 'ইউনিয়ন/পৌরসভা', en: 'Union/Municipality', category: 'address', writable: true },
  ward: { bn: 'ওয়ার্ড', en: 'Ward', category: 'address', writable: true },
  postOffice: { bn: 'ডাকঘর', en: 'Post Office', category: 'address', writable: true },
  postalCode: { bn: 'পোস্ট কোড', en: 'Postal Code', category: 'address', writable: true },
  upazila: { bn: 'উপজেলা/থানা', en: 'Upazila/Thana', category: 'address', writable: true },
  district: { bn: 'জেলা', en: 'District', category: 'address', writable: true },
  division: { bn: 'বিভাগ', en: 'Division', category: 'address', writable: true },
  country: { bn: 'দেশ', en: 'Country', category: 'address', writable: true },
  mouza: { bn: 'মৌজা', en: 'Mouza', category: 'land', writable: false },
  khatianNumber: { bn: 'খতিয়ান নম্বর', en: 'Khatian Number', category: 'land', writable: false },
  dagNumber: { bn: 'দাগ নম্বর', en: 'Dag Number', category: 'land', writable: false },
  deedNumber: { bn: 'দলিল নম্বর', en: 'Deed Number', category: 'land', writable: false },
  deedYear: { bn: 'দলিল সাল', en: 'Deed Year', category: 'land', writable: false },
  landAmount: { bn: 'জমির পরিমাণ', en: 'Land Amount', category: 'land', writable: false },
  restingPlace: { bn: 'কবর/শেষ ঠিকানা', en: 'Resting Place', category: 'life', writable: true },
  dateOfDeath: { bn: 'মৃত্যু তারিখ', en: 'Date of Death', category: 'life', writable: true },
  issuingAuthority: { bn: 'ইস্যুকারী কর্তৃপক্ষ', en: 'Issuing Authority', category: 'document', writable: false }
};

export function buildExtractedFieldCandidates(fields: ExtractedDocumentFields): ExtractedFieldCandidate[] {
  const out: ExtractedFieldCandidate[] = [];
  for (const [key, meta] of Object.entries(knownFieldLabels)) {
    const value = (fields as any)[key];
    if (value == null || value === '' || (Array.isArray(value) && !value.length)) continue;
    const text = Array.isArray(value) ? value.join(', ') : typeof value === 'object' ? JSON.stringify(value) : String(value);
    out.push({ key, labelBn: meta.bn, labelEn: meta.en, value: text, confidence: fields.confidence, category: meta.category, profileWritable: meta.writable });
  }
  return out.concat(fields.additionalFields || []);
}

export function parseDocumentFields(rawText: string, defaultConfidence = 80): ExtractedDocumentFields {
  const clean = rawText.replace(/\r/g, '').replace(/\u00a0/g, ' ');
  const lines = clean.split('\n').map(normalizeSpace).filter(Boolean);
  const text = lines.join(' ');

  let documentKind: ExtractedDocumentFields['documentKind'] = 'general';
  const hasPassport = /passport|পাসপোর্ট/i.test(text);
  const hasPassportMrz = lines.some((line, i) => /^P<\s*[A-Z0-9<]{20,}/i.test(line.replace(/\s/g, '')) && /^[A-Z0-9<]{30,}/i.test((lines[i + 1] || '').replace(/\s/g, '')));
  const hasNid = /জাত[ীি]য়\s*পরিচয়পত্র|জাত[ীি]য়\s*পরিচয়পত্র|national\s+id|\bnid\b|identity\s+card/i.test(text);
  const hasBrn = /জন্ম\s*(ও\s*মৃত্যু\s*)?নিবন্ধন|birth\s+(registration|certificate)|\bbrn\b/i.test(text);
  const hasDriving = /driving\s*licen[cs]e|driver'?s\s*licen[cs]e|ড্রাইভিং\s*লাইসেন্স|ড্রাইভিং\s*লাইসেন্স/i.test(text);
  const hasLand = /খতিয়ান|খতিয়ান|দাগ\s*(নং|নম্বর)?|মৌজা|দলিল|সাব[- ]?রেজিস্ট্রি/i.test(text);
  const hasMarriage = /নিকাহনামা|কাবিননামা|দেনমোহর|marriage\s+certificate/i.test(text);
  const hasDeath = /মৃত্যু\s*সনদ|কবরস্থান|demise|death\s+certificate/i.test(text);
  if (hasPassport || hasPassportMrz) documentKind = 'passport';
  else if (hasNid) documentKind = 'nid';
  else if (hasBrn) documentKind = 'birth_registration';
  else if (hasDriving) documentKind = 'driving_licence';
  else if (hasLand) documentKind = 'land_deed';
  else if (hasMarriage) documentKind = 'marriage_doc';
  else if (hasDeath) documentKind = 'death_doc';

  const documentSide = detectSide(documentKind, lines);
  let fullNameBn: string | undefined;
  let fullNameEn: string | undefined;
  let nidNumber: string | undefined;
  let passportNumber: string | undefined;
  let passportPersonalNumber: string | undefined;
  let passportIssueDate: string | undefined;
  let passportExpiryDate: string | undefined;
  let passportIssuingAuthority: string | undefined;
  let previousPassportNumber: string | undefined;
  let brnNumber: string | undefined;
  let documentNumber: string | undefined;
  let documentIssueDate: string | undefined;
  let documentDate: string | undefined;
  let dateOfBirth: string | undefined;
  let placeOfBirth: string | undefined;
  let fatherName: string | undefined;
  let motherName: string | undefined;
  let spouseName: string | undefined;
  const childrenNames: string[] = [];
  let occupation: string | undefined;
  let mobileNumber: string | undefined;
  let email: string | undefined;
  let religion: string | undefined;
  let nationality: string | undefined;
  let gender: ExtractedDocumentFields['gender'];
  let bloodGroup: ExtractedDocumentFields['bloodGroup'];
  let address: string | undefined;
  let presentAddress: LocationInfo | undefined;
  let permanentAddress: LocationInfo | undefined;
  let holding: string | undefined;
  let road: string | undefined;
  let village: string | undefined;
  let union: string | undefined;
  let ward: string | undefined;
  let postOffice: string | undefined;
  let postalCode: string | undefined;
  let upazila: string | undefined;
  let district: string | undefined;
  let division: string | undefined;
  let country: string | undefined;
  let mouza: string | undefined;
  let khatianNumber: string | undefined;
  let dagNumber: string | undefined;
  let deedNumber: string | undefined;
  let deedYear: string | undefined;
  let landAmount: string | undefined;
  let restingPlace: string | undefined;
  let dateOfDeath: string | undefined;
  let issuingAuthority: string | undefined;

  const passportMrzIndexes: number[] = [];
  lines.forEach((line, i) => {
    const compact = line.replace(/\s/g, '').toUpperCase();
    if (/^P</.test(compact) && compact.length >= 30) passportMrzIndexes.push(i);
  });

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const context = `${line} ${lines[i + 1] || ''} ${lines[i + 2] || ''}`;
    const lower = line.toLowerCase();

    if (!nidNumber && documentKind === 'nid' && /জাত[ীি]য়\s*পরিচয়পত্র|জাত[ীি]য়\s*পরিচয়পত্র|\bnid\b|national\s+id/i.test(line)) {
      nidNumber = [...digitCandidates(line), ...digitCandidates(context)].find(v => [10, 13, 17].includes(v.length));
    }
    if (!brnNumber && documentKind === 'birth_registration' && /জন্ম.*নিবন্ধন|birth\s+registration|\bbrn\b/i.test(line)) {
      brnNumber = [...digitCandidates(line), ...digitCandidates(context)].find(v => v.length === 17);
    }
    if (!passportNumber && documentKind === 'passport' && /passport|পাসপোর্ট/i.test(line)) {
      const raw = line.replace(/[^A-Za-z0-9<\s-]/g, ' ');
      const tokens = raw.split(/\s+/).map(v => v.replace(/[<\s-]/g, '')).filter(Boolean);
      passportNumber = tokens.find(v => !/^(passport|no|number|passportnumber|পাসপোর্ট)$/i.test(v) && validPassport(v));
      if (!passportNumber) {
        const nextTokens = (lines[i + 1] || '').replace(/[^A-Za-z0-9<\s-]/g, ' ').split(/\s+/).map(v => v.replace(/[<\s-]/g, '')).filter(Boolean);
        passportNumber = nextTokens.find(v => !/(?:passport|no|number|passportnumber|পাসপোর্ট)$/i.test(v) && validPassport(v));
      }
    }

    if (!fullNameBn && /^(?:নাম|নামঃ|বাংলা\s*নাম)\s*[:：.\-]?$/i.test(line)) {
      const v = valueAfterLabel(lines, i, /^(?:নাম|নামঃ|বাংলা\s*নাম)\s*/i); if (v && /[\u0980-\u09FF]/.test(v)) fullNameBn = v;
    }
    if (!fullNameEn && /^(?:name\s*in\s*english|english\s*name|name)\s*[:：.\-]?$/i.test(line)) {
      const v = valueAfterLabel(lines, i, /^(?:name\s*in\s*english|english\s*name|name)\s*/i); if (v && /[A-Za-z]/.test(v)) fullNameEn = v;
    }
    if (!fullNameBn && /^(?:নাম|নামঃ|বাংলা\s*নাম)\s*[:：.\-]/i.test(line)) fullNameBn = valueAfterLabel(lines, i, /^(?:নাম|নামঃ|বাংলা\s*নাম)\s*/i);
    if (!fullNameEn && /^(?:name\s*in\s*english|english\s*name|name)\s*[:：.\-]/i.test(line)) fullNameEn = valueAfterLabel(lines, i, /^(?:name\s*in\s*english|english\s*name|name)\s*/i);

    // NID OCR frequently puts the parent label and value on the same line, or
    // mangles the Bengali label (for example পিতাঃ/পিতা / পিং and মাতাঃ/মাতা).
    // Support both label-only and inline forms; this is intentionally independent
    // of marital status because a married-in woman's NID still describes her
    // biological parents, not her spouse.
    const fatherLabel = /^(?:পিতা|পিতাঃ|পিতার\s*নাম|পিং|পিং-|পিতা\s*নাম|father(?:'s)?\s*name|father)\s*/i;
    const motherLabel = /^(?:মাতা|মাতাঃ|মাতার\s*নাম|মাতার\s*নাম|মাতা\s*নাম|mother(?:'s)?\s*name|mother)\s*/i;
    if (!fatherName && fatherLabel.test(line)) fatherName = valueAfterLabel(lines, i, fatherLabel);
    if (!motherName && motherLabel.test(line)) motherName = valueAfterLabel(lines, i, motherLabel);
    if (!spouseName && /^(?:স্বামী|স্বামীর\s*নাম|স্ত্রী|স্ত্রীর\s*নাম|জং|জং-|জওজে|husband|wife|spouse)(?:\s*[:：.\-].*)?$/i.test(line)) spouseName = valueAfterLabel(lines, i, /^(?:স্বামী|স্বামীর\s*নাম|স্ত্রী|স্ত্রীর\s*নাম|জং|জং-|জওজে|husband|wife|spouse)\s*/i);
    if (/^(?:সন্তান(?:দের)?(?:\s*নাম)?|পুত্র(?:-কন্যা)?|children|child(?:ren)?(?:\s*name)?|sons?|daughters?)\s*[:：.\-]/i.test(line)) {
      const v = valueAfterLabel(lines, i, /^(?:সন্তান(?:দের)?(?:\s*নাম)?|পুত্র(?:-কন্যা)?|children|child(?:ren)?(?:\s*name)?|sons?|daughters?)\s*/i);
      if (v) v.split(/[,;|/]+/).map(cleanValue).filter(x => x.length >= 2).forEach(x => { if (!childrenNames.includes(x)) childrenNames.push(x); });
    }

    if (!occupation && /^(?:পেশা|পেশা\s*ও\s*কর্মস্থল|occupation|profession|job)\s*[:：.\-]/i.test(line)) occupation = valueAfterLabel(lines, i, /^(?:পেশা|পেশা\s*ও\s*কর্মস্থল|occupation|profession|job)\s*/i);
    if (!mobileNumber && /^(?:মোবাইল|মোবাইল\s*নম্বর|ফোন|ফোন\s*নম্বর|mobile|phone|mobile\s*number)\s*[:：.\-]/i.test(line)) mobileNumber = (valueAfterLabel(lines, i, /^(?:মোবাইল|মোবাইল\s*নম্বর|ফোন|ফোন\s*নম্বর|mobile|phone|mobile\s*number)\s*/i) || '').replace(/[^0-9+]/g, '') || undefined;
    if (!email && /^(?:ই-মেইল|ইমেইল|email|e-mail)\s*[:：.\-]/i.test(line)) email = valueAfterLabel(lines, i, /^(?:ই-মেইল|ইমেইল|email|e-mail)\s*/i);
    if (!religion && /^(?:ধর্ম|religion)\s*[:：.\-]/i.test(line)) religion = valueAfterLabel(lines, i, /^(?:ধর্ম|religion)\s*/i);
    if (!nationality && /^(?:জাতীয়তা|জাতীয়তা|nationality)\b/i.test(line)) nationality = valueAfterLabel(lines, i, /^(?:জাতীয়তা|জাতীয়তা|nationality)\s*/i);
    if (!gender && /^(?:লিঙ্গ|gender|sex)\s*[:：.\-]/i.test(line)) { const g = (valueAfterLabel(lines, i, /^(?:লিঙ্গ|gender|sex)\s*/i) || '').toLowerCase(); if (/নারী|মহিলা|female|woman|^f$/.test(g)) gender = 'female'; else if (/পুরুষ|male|man|^m$/.test(g)) gender = 'male'; else if (g) gender = 'unknown'; }
    if (!bloodGroup && /^(?:রক্তের\s*গ্রুপ|রক্ত\s*গ্রুপ|blood\s*group)\s*[:：.\-]/i.test(line)) { const g = (valueAfterLabel(lines, i, /^(?:রক্তের\s*গ্রুপ|রক্ত\s*গ্রুপ|blood\s*group)\s*/i) || '').toUpperCase().replace(/\s+/g, ''); if (/^(A|B|AB|O)[+-]$/.test(g)) bloodGroup = g as any; }
    if (!dateOfBirth && /জন্ম\s*তারিখ|date\s+of\s+birth|\bdob\b|birth\s*date/i.test(line)) dateOfBirth = datePatternMatch(context);
    if (!dateOfDeath && /মৃত্যু\s*তারিখ|date\s+of\s+death|death\s*date/i.test(line)) dateOfDeath = datePatternMatch(context);
    if (!placeOfBirth && /^(?:জন্মস্থান|place\s+of\s+birth|birth\s+place)\b/i.test(line)) placeOfBirth = valueAfterLabel(lines, i, /^(?:জন্মস্থান|place\s+of\s+birth|birth\s+place)\s*/i);

    const addressLabel = /^(?:ঠিকানা|address)\s*[:：.\-]?/i;
    const presentLabel = /^(?:বর্তমান\s*ঠিকানা|বর্তমান\s*ঠিকানা\s*এবং\s*ঠিকানা|present\s*address|current\s*address)\s*[:：.\-]?/i;
    const permanentLabel = /^(?:স্থায়ী\s*ঠিকানা|স্থায়ী\s*ঠিকানা|permanent\s*address)\s*[:：.\-]?/i;
    if (!address && addressLabel.test(line)) address = valueAfterLabel(lines, i, addressLabel, 6);
    if (!presentAddress && presentLabel.test(line)) presentAddress = { fullAddress: valueAfterLabel(lines, i, presentLabel, 6) };
    if (!permanentAddress && permanentLabel.test(line)) permanentAddress = { fullAddress: valueAfterLabel(lines, i, permanentLabel, 6) };

    const assign = (re: RegExp, setter: (v: string) => void) => { if (re.test(line)) { const v = valueAfterLabel(lines, i, re); if (v) setter(v); } };
    assign(/^(?:বাসা\s*\/\s*হোল্ডিং|বাসা|হোল্ডিং|house|holding)\s*[:：.\-]/i, v => { if (!holding || holding === '--') holding = v; });
    assign(/^(?:গ্রাম\s*\/\s*রাস্তা|গ্রাম|রাস্তা|village|road)\s*[:：.\-]/i, v => { road ||= v; if (!village && /গ্রাম|village/i.test(line)) village = v; });
    assign(/^(?:ইউনিয়ন|ইউনিয়ন|পৌরসভা|union|municipality)\s*[:：.\-]/i, v => union ||= v);
    assign(/^(?:ওয়ার্ড|ওয়ার্ড|ward)\s*[:：.\-]/i, v => ward ||= v);
    assign(/^(?:ডাকঘর|post\s*office)\s*[:：.\-]/i, v => postOffice ||= v);
    assign(/^(?:পোস্ট\s*কোড|postal\s*code|zip)\s*[:：.\-]/i, v => postalCode ||= compactDigits(v) || v);
    assign(/^(?:উপজেলা\s*\/\s*থানা|উপজেলা|থানা|upazila|thana)\s*[:：.\-]/i, v => upazila ||= v);
    assign(/^(?:জেলা|district)\s*[:：.\-]/i, v => district ||= v);
    assign(/^(?:বিভাগ|division)\s*[:：.\-]/i, v => division ||= v);
    assign(/^(?:দেশ|country)\s*[:：.\-]/i, v => country ||= v);

    if (!documentNumber && /^(?:দলিল\s*(?:নং|নম্বর)?|document\s*(?:no|number)|certificate\s*(?:no|number))\s*[:：.\-]/i.test(line)) documentNumber = valueAfterLabel(lines, i, /^(?:দলিল\s*(?:নং|নম্বর)?|document\s*(?:no|number)|certificate\s*(?:no|number))\s*/i);
    if (!documentIssueDate && /(?:issue\s*date|ইস্যু\s*তারিখ|প্রদান\s*তারিখ)/i.test(line)) documentIssueDate = datePatternMatch(context);
    if (!documentDate && /^(?:তারিখ|date)\s*[:：.\-]/i.test(line)) documentDate = datePatternMatch(context);

    if (!passportPersonalNumber && documentKind === 'passport' && /personal\s*(?:no|number)|personal\s*#|ব্যক্তিগত\s*নং/i.test(line)) passportPersonalNumber = valueAfterLabel(lines, i, /^(?:.*?)(?:personal\s*(?:no|number)|personal\s*#|ব্যক্তিগত\s*নং)\s*[:：.\-]?/i);
    if (!passportIssueDate && documentKind === 'passport' && /issue|ইস্যু/i.test(line)) passportIssueDate = datePatternMatch(context) || valueAfterLabel(lines, i, /^(?:.*?)(?:issue|ইস্যু).*?[:：.\-]?/i);
    if (!passportExpiryDate && documentKind === 'passport' && /expiry|expire|মেয়াদ|মেয়াদ/i.test(line)) passportExpiryDate = datePatternMatch(context) || valueAfterLabel(lines, i, /^(?:.*?)(?:expiry|expire|মেয়াদ|মেয়াদ).*?[:：.\-]?/i);
    if (!passportIssuingAuthority && documentKind === 'passport' && /issuing\s*authority|authority|প্রদানকারী\s*কর্তৃপক্ষ/i.test(line)) passportIssuingAuthority = valueAfterLabel(lines, i, /^(?:.*?)(?:issuing\s*authority|authority|প্রদানকারী\s*কর্তৃপক্ষ)\s*[:：.\-]?/i);
    if (!previousPassportNumber && /previous\s*passport|পুরাতন\s*পাসপোর্ট|পূর্বের\s*পাসপোর্ট/i.test(line)) previousPassportNumber = (valueAfterLabel(lines, i, /^(?:.*?)(?:previous\s*passport|পুরাতন\s*পাসপোর্ট|পূর্বের\s*পাসপোর্ট)\s*[:：.\-]?/i) || '').replace(/^(?:no\.?|নং)\s*/i, '') || undefined;

    if (!mouza && /(?:মৌজা|মৌজাঃ|\bmouza\b)/i.test(line)) mouza = valueAfterLabel(lines, i, /^(?:.*?)(?:মৌজা|মৌজাঃ|\bmouza\b)\s*[:：.\-]?/i);
    if (!khatianNumber && /(?:খতিয়ান|খতিয়ান|\bkhatian\b)/i.test(line)) khatianNumber = [...digitCandidates(context), ...context.match(/[A-Za-z0-9০-৯-]{1,20}/g) || []].map(normalizeDigits).find(v => /\d/.test(v));
    if (!dagNumber && /(?:দাগ|দাগ\s*নং|দাগ\s*নম্বর|\bdag\s*no\b)/i.test(line)) dagNumber = [...digitCandidates(context)].find(Boolean);
    if (!deedNumber && /(?:দলিল\s*(?:নং|নম্বর)?|\bdeed\s*no\b)/i.test(line)) deedNumber = [...digitCandidates(context)].find(Boolean);
    if (!deedYear && /(?:দলিল\s*সাল|deed\s*year)/i.test(line)) deedYear = normalizeDigits(valueAfterLabel(lines, i, /^(?:.*?)(?:দলিল\s*সাল|deed\s*year)\s*[:：.\-]?/i) || '');
    if (!landAmount && /(?:জমির\s*পরিমাণ|land\s*area|পরিমাণ)/i.test(line)) landAmount = valueAfterLabel(lines, i, /^(?:.*?)(?:জমির\s*পরিমাণ|land\s*area|পরিমাণ)\s*[:：.\-]?/i);
    if (!restingPlace && /(?:কবরস্থান|সমাধিস্থল|grave|cemetery|resting\s*place)/i.test(line)) restingPlace = valueAfterLabel(lines, i, /^(?:.*?)(?:কবরস্থান|সমাধিস্থল|grave|cemetery|resting\s*place)\s*[:：.\-]?/i);
  }

  // NID number fallback: many Bangladeshi NID scans place the 10/13/17 digit
  // number on a separate line without the NID label. Prefer candidates adjacent
  // to an identity-number label; only use a unique plausible candidate as a
  // last resort so address/postal digits are not casually mistaken for the NID.
  if (documentKind === 'nid' && !nidNumber) {
    const labelled = lines.flatMap((line, i) => {
      if (!/(?:জাত[ীি]য়\s*পরিচয়পত্র|জাত[ীি]য়\s*পরিচয়পত্র|\bnid\b|national\s+id|identity\s*(?:card|no|number)|পরিচয়পত্র\s*(?:নং|নম্বর)|নং|নম্বর)/i.test(line)) return [];
      return digitCandidates(`${line} ${lines[i + 1] || ''} ${lines[i + 2] || ''}`);
    });
    const uniqueLabelled = [...new Set(labelled)].filter(v => [10, 13, 17].includes(v.length));
    if (uniqueLabelled.length === 1) nidNumber = uniqueLabelled[0];
    if (!nidNumber) {
      const allCandidates = [...new Set(lines.flatMap(digitCandidates))].filter(v => [10, 13, 17].includes(v.length));
      if (allCandidates.length === 1) nidNumber = allCandidates[0];
    }
  }

  // If the OCR has an address heading but split the address into separate lines,
  // retain the consecutive address lines as a readable full-address fallback.
  if (documentKind === 'nid' && !address && !presentAddress?.fullAddress) {
    const addressIndex = lines.findIndex(line => /^(?:ঠিকানা|address|present\s+address|বর্তমান\s*ঠিকানা)\s*[:：.\-]?/i.test(line));
    if (addressIndex >= 0) {
      const addressLines: string[] = [];
      const stopAddress = /^(?:name|নাম|পিতা|পিতাঃ|মাতা|মাতাঃ|father|mother|date\s+of\s+birth|জন্ম\s*তারিখ|nid\s*(?:no|number)?|জাত[ীি]য়\s*পরিচয়পত্র)\s*[:：.\-]?/i;
      for (let j = addressIndex; j < Math.min(lines.length, addressIndex + 8); j++) {
        const raw = cleanValue(lines[j].replace(/^(?:ঠিকানা|address|present\s+address|বর্তমান\s*ঠিকানা)\s*[:：.\-]?/i, ''));
        if (j > addressIndex && stopAddress.test(lines[j])) break;
        if (raw && !/^(?:--|—|-)$/u.test(raw)) addressLines.push(raw);
      }
      const recovered = addressLines.join(', ').replace(/\s*,\s*,+/g, ', ').trim();
      if (recovered.length > 5) address = recovered;
    }
  }

  // Bangladesh NID machine-readable zone fallback. Layouts vary, so scan the I<BGD zone and nearby lines for YYMMDD.
  if (documentKind === 'nid') {
    const idxs=lines.map((line,i)=>({line:line.replace(/\s/g,'').toUpperCase(),i})).filter(x=>/^I<BGD/.test(x.line)).map(x=>x.i);
    for(const i of idxs){
      const zone=`${lines[i]||''} ${(lines[i+1]||'')} ${(lines[i+2]||'')}`.replace(/\s/g,'').toUpperCase();
      for(const raw of zone.match(/\d{6}/g)||[]){ const d=parseMrzDate(raw,'birth'); if(d){ dateOfBirth ||= d; break; } }
    }
  }

  // Passport MRZ:
  if (documentKind === 'passport' && passportMrzIndexes.length) {
    const i = passportMrzIndexes[0];
    const mrz1 = lines[i].replace(/\s/g, '').toUpperCase();
    const mrz2 = (lines[i + 1] || '').replace(/\s/g, '').toUpperCase();
    if (/^[A-Z0-9<]{40,46}$/.test(mrz2)) {
      const candidate = mrz2.slice(0, 9).replace(/<+$/g, '');
      if (!passportNumber && /^[A-Z0-9]{7,9}$/.test(candidate)) passportNumber = candidate;
      if (!dateOfBirth) dateOfBirth = parseMrzDate(mrz2.slice(13, 19), 'birth');
      if (!passportExpiryDate) passportExpiryDate = parseMrzDate(mrz2.slice(21, 27), 'expiry');
      if (!nationality && /^[A-Z]{3}$/.test(mrz2.slice(10, 13))) nationality = mrz2.slice(10, 13);
    }
    if (!fullNameEn) {
      const namePart = mrz1.slice(5).replace(/<+/g, ' ').replace(/<+/g, ' ').trim();
      if (namePart) fullNameEn = namePart.replace(/\s+/g, ' ');
    }
  }

  // NID fallback: labels can disappear completely in low-quality OCR. In that
  // case use the stable front-side reading order: name -> English name -> father
  // -> mother -> date of birth. This is only a fallback and never replaces an
  // explicitly labelled value.
  if (documentKind === 'nid') {
    const nameIndex = lines.findIndex(x => /^(?:name|নাম)\s*$/i.test(x) || /^(?:name|নাম)\s*[:：.\-]/i.test(x));
    const dobIndex = lines.findIndex(x => /date\s+of\s+birth|জন্ম\s*তারিখ/i.test(x));
    if (nameIndex >= 0) {
      const end = dobIndex > nameIndex ? dobIndex : Math.min(lines.length, nameIndex + 8);
      const window = lines.slice(nameIndex + 1, end);
      const isHeading = (x: string) => /^(?:name|নাম|national|জাতীয়|জাতীয়|পরিচয়|পরিচয়|national id|nid|identity card)$/i.test(x.trim());
      const candidates = window.filter(x => x.length > 2 && !isHeading(x) && !/^(?:date\s+of\s+birth|জন্ম\s*তারিখ|nid\s*(?:no|number)?|id\s*(?:no|number)?)\b/i.test(x));
      if (!fullNameBn) fullNameBn = candidates.find(x => /[\u0980-\u09FF]/.test(x) && !/\d{4}/.test(x));
      if (!fullNameEn) fullNameEn = candidates.find(x => /[A-Za-z]{3,}/.test(x) && !/[\u0980-\u09FF]/.test(x));
      const parentCandidates = candidates.filter(x => x !== fullNameBn && x !== fullNameEn && !/address|ঠিকানা|বাসা|গ্রাম|রাস্তা|ডাকঘর|উপজেলা|থানা|জেলা|division|district|upazila/i.test(x));
      if (!fatherName) fatherName = parentCandidates[0];
      if (!motherName) motherName = parentCandidates[1];
    }

    // Last-resort inline label recovery. Tesseract may emit several labelled
    // fields on one physical line; the anchored loop above cannot see them.
    const parentInline = (label: RegExp, stop: RegExp) => {
      const pattern = `${label.source}\\s*[:：.\\-]?\\s*(.+?)(?=\\s+${stop.source}|$)`;
      const m = text.match(new RegExp(pattern, 'i'));
      return cleanValue(m?.[1] || '') || undefined;
    };
    fatherName ||= parentInline(/(?:পিতা|পিতাঃ|পিতার\s*নাম|পিং|father(?:'s)?\s*name|father)/i, /(?:মাতা|মাতাঃ|মাতার\s*নাম|mother(?:'s)?\s*name|mother|date\s+of\s+birth|জন্ম\s*তারিখ)/i);
    motherName ||= parentInline(/(?:মাতা|মাতাঃ|মাতার\s*নাম|mother(?:'s)?\s*name|mother)/i, /(?:date\s+of\s+birth|জন্ম\s*তারিখ|ঠিকানা|address|nid|national\s+id)/i);
  }

  // Many NID OCR engines return the entire address row on one line. Extract
  // each labelled component from that row before building the final address.
  const addressBlob = lines.filter(line => /ঠিকানা|বাসা\s*\/\s*হোল্ডিং|গ্রাম\s*\/\s*রাস্তা|ডাকঘর|পৌরসভা|ইউনিয়ন|ইউনিয়ন|ওয়ার্ড|ওয়ার্ড|উপজেলা|থানা|জেলা|বিভাগ/i.test(line)).join(' , ');
  const embedded = (labels: string[]): string | undefined => {
    const labelPattern = labels.join('|');
    const next = '(?=\\s*,\\s*(?:' + [
      'বাসা\\s*\\/\\s*হোল্ডিং','গ্রাম\\s*\\/\\s*রাস্তা','ডাকঘর','পৌরসভা','ইউনিয়ন','ইউনিয়ন','ওয়ার্ড','ওয়ার্ড','উপজেলা','থানা','জেলা','বিভাগ','ঠিকানা'
    ].join('|') + ')\\s*[:：.\\-]|$)';
    const m = addressBlob.match(new RegExp('(?:' + labelPattern + ')\\s*[:：.\\-]?\\s*([^,]+?)' + next, 'i'));
    const value = cleanValue(m?.[1] || '');
    return value && !/^(?:--|—|-)$/u.test(value) ? value : undefined;
  };
  holding ||= embedded(['বাসা\\s*\\/\\s*হোল্ডিং','বাসা','হোল্ডিং','house','holding']);
  road ||= embedded(['গ্রাম\\s*\\/\\s*রাস্তা','গ্রাম','রাস্তা','village','road']);
  union ||= embedded(['ইউনিয়ন','ইউনিয়ন','পৌরসভা','union','municipality']);
  ward ||= embedded(['ওয়ার্ড','ওয়ার্ড','ward']);
  postOffice ||= embedded(['ডাকঘর','post\\s*office']);
  postalCode ||= embedded(['পোস্ট\\s*কোড','postal\\s*code','zip']);
  upazila ||= embedded(['উপজেলা\\s*\\/\\s*থানা','উপজেলা','থানা','upazila','thana']);
  district ||= embedded(['জেলা','district']);
  division ||= embedded(['বিভাগ','division']);

  if (holding && /^(?:--|—|-)$/u.test(holding)) holding = undefined;
  // Address headings on NID backs can cause the first child label to be mistaken
  // for the full address. Prefer the structured address components when that happens.
  if (address && /^(?:বাসা\s*\/\s*হোল্ডিং|গ্রাম\s*\/\s*রাস্তা|ডাকঘর|উপজেলা|জেলা)\s*[:：]/i.test(address)) address = undefined;
  const structuredAddressText = [holding, road || village, union, ward, postOffice, postalCode, upazila, district, division, country].filter(v => Boolean(v) && !/^(?:--|—|-)$/u.test(String(v))).join(', ');
  if (!address && structuredAddressText) address = structuredAddressText;
  if (presentAddress && structuredAddressText) presentAddress = { ...presentAddress, fullAddress: structuredAddressText };
  const structuredAddress = locationFromParts({ holding, road, village, union, ward, postOffice, postalCode, upazila, district, division, country, fullAddress: address });
  if (structuredAddress) {
    if (!presentAddress && documentSide === 'back') presentAddress = structuredAddress;
    address ||= [holding, road || village, union, ward, postOffice, postalCode, upazila, district, division, country].filter(Boolean).join(', ');
  }
  if (presentAddress?.fullAddress) presentAddress = { ...presentAddress, ...structuredAddress };
  if (permanentAddress?.fullAddress) permanentAddress = { ...permanentAddress, ...structuredAddress };

  const extractedKnownKeys = new Set(Object.keys(knownFieldLabels));
  const additionalFields: ExtractedFieldCandidate[] = [];
  const rawUnmappedLines: string[] = [];
  const labelLine = /^([^:：]{1,60})\s*[:：]\s*(.+)$/;
  for (const line of lines) {
    const match = line.match(labelLine);
    if (!match) { if (line.length >= 3 && !/^(?:PAGE BREAK|NID FOCUSED OCR|NID REGION)$/i.test(line)) rawUnmappedLines.push(line); continue; }
    const label = cleanValue(match[1]);
    const value = cleanValue(match[2]);
    if (!value || value === '--') continue;
    const alreadyKnown = Object.values(knownFieldLabels).some(meta => meta.bn === label || meta.en.toLowerCase() === label.toLowerCase());
    if (alreadyKnown) continue;
    additionalFields.push({
      key: `additional:${label}:${additionalFields.length}`,
      labelBn: /[\u0980-\u09FF]/.test(label) ? label : '',
      labelEn: /[A-Za-z]/.test(label) ? label : '',
      value,
      confidence: defaultConfidence,
      category: 'other',
      profileWritable: false
    });
  }

  // De-duplicate arbitrary fields and keep a small raw-text tail for complete review.
  const uniqueAdditional = Array.from(new Map(additionalFields.map(x => [`${x.labelBn}|${x.labelEn}|${x.value}`, x])).values()).slice(0, 120);
  const uniqueRaw = [...new Set(rawUnmappedLines)].slice(0, 160);

  return {
    documentKind,
    documentSide,
    fullNameBn,
    fullNameEn,
    nidNumber,
    passportNumber,
    passportPersonalNumber,
    passportIssueDate,
    passportExpiryDate,
    passportIssuingAuthority,
    previousPassportNumber,
    brnNumber,
    documentNumber,
    documentIssueDate,
    documentDate,
    dateOfBirth,
    placeOfBirth,
    fatherName,
    motherName,
    spouseName,
    childrenNames: childrenNames.length ? childrenNames : undefined,
    occupation,
    mobileNumber,
    email,
    religion,
    nationality,
    gender,
    bloodGroup,
    address,
    presentAddress,
    permanentAddress,
    holding,
    road,
    village,
    union,
    ward,
    postOffice,
    postalCode,
    upazila,
    district,
    division,
    country,
    mouza,
    khatianNumber,
    dagNumber,
    deedNumber,
    deedYear,
    landAmount,
    restingPlace,
    dateOfDeath,
    issuingAuthority,
    additionalFields: uniqueAdditional,
    rawUnmappedLines: uniqueRaw,
    confidence: defaultConfidence
  };
}

/** Merge multiple scans (for example NID front + NID back) without silently
 * choosing a conflicting value. The selected value is the first/highest-confidence
 * value, while every disagreement remains visible in `conflicts`. */
export function mergeExtractedDocumentFields(parts: ExtractedDocumentFields[]): ExtractedDocumentFields {
  const usable = parts.filter(Boolean);
  if (!usable.length) return { documentKind: 'general', confidence: 0 };
  const result: ExtractedDocumentFields = { ...usable[0], confidence: Math.round(usable.reduce((s, p) => s + (p.confidence || 0), 0) / usable.length) };
  const conflicts = [...(usable[0].conflicts || [])];

  const scalarKeys: (keyof ExtractedDocumentFields)[] = [
    'fullNameBn','fullNameEn','nidNumber','passportNumber','passportPersonalNumber','passportIssueDate','passportExpiryDate',
    'passportIssuingAuthority','previousPassportNumber','brnNumber','documentNumber','documentIssueDate','documentDate',
    'dateOfBirth','placeOfBirth','fatherName','motherName','spouseName','occupation','mobileNumber','email','religion',
    'nationality','gender','bloodGroup','address','holding','road','village','union','ward','postOffice','postalCode',
    'upazila','district','division','country','mouza','khatianNumber','dagNumber','deedNumber','deedYear','landAmount',
    'restingPlace','dateOfDeath','issuingAuthority'
  ];

  for (const key of scalarKeys) {
    const values = usable.map(p => (p as any)[key]).filter(v => v !== undefined && v !== null && String(v).trim() !== '').map(String);
    const unique = [...new Set(values)];
    if (!unique.length) continue;
    if (unique.length > 1) {
      const meta = knownFieldLabels[String(key)] || { bn: String(key), en: String(key) };
      conflicts.push({ fieldKey: String(key), labelBn: meta.bn, labelEn: meta.en, values: unique, confidenceByValue: Object.fromEntries(unique.map(v => [v, Math.max(...usable.filter(p => String((p as any)[key] ?? '') === v).map(p => p.confidence || 0), 0)])) });
    }
    const winner = usable
      .filter(p => (p as any)[key] !== undefined && (p as any)[key] !== null && String((p as any)[key]).trim() !== '')
      .sort((a, b) => (b.confidence || 0) - (a.confidence || 0))[0];
    if (winner) (result as any)[key] = (winner as any)[key];
  }

  const mergeLocation = (key: 'presentAddress'|'permanentAddress') => {
    const locations = usable.map(p => p[key]).filter(Boolean) as LocationInfo[];
    if (!locations.length) return;
    const merged: LocationInfo = {};
    for (const location of locations) Object.assign(merged, Object.fromEntries(Object.entries(location).filter(([, v]) => v !== undefined && String(v).trim() !== '')));
    result[key] = merged;
  };
  mergeLocation('presentAddress');
  mergeLocation('permanentAddress');

  const children = [...new Set(usable.flatMap(p => p.childrenNames || []))];
  if (children.length) result.childrenNames = children;
  const additional = [...usable.flatMap(p => p.additionalFields || [])];
  result.additionalFields = Array.from(new Map(additional.map(f => [`${f.labelBn}|${f.labelEn}|${f.value}`, f])).values());
  result.rawUnmappedLines = [...new Set(usable.flatMap(p => p.rawUnmappedLines || []))].slice(0, 200);
  result.conflicts = conflicts.length ? Array.from(new Map(conflicts.map(c => [c.fieldKey, c])).values()) : undefined;
  // If multiple NID sides were merged, side is intentionally "unknown" because the
  // resulting record represents the complete document pair rather than one side.
  const sides = [...new Set(usable.map(p => p.documentSide).filter(Boolean))];
  result.documentSide = sides.length === 1 ? sides[0] : 'unknown';
  result.documentKind = usable.find(p => p.documentKind !== 'general')?.documentKind || 'general';
  return result;
}
