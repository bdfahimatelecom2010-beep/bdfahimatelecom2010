import { Member, MarriageRecord } from '../types/genealogy';

/**
 * A married-in member keeps their biological parents as relationship data,
 * but those parents are not automatically members of this family's birth line.
 * They become visible in the family directory/tree only when they have an
 * independent birth-line connection to this family.
 */
export function isMarriedInMember(member: Member): boolean {
  return member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin === true;
}

export function isVisibleFamilyMember(
  member: Member,
  members: Member[],
  marriages: MarriageRecord[]
): boolean {
  // Married-in spouses remain visible members of this family directory/tree.
  if (isMarriedInMember(member)) return true;
  if (member.birthOrigin === 'adopted' || member.birthOrigin === 'unknown') {
    // These can still be displayed when independently connected below.
  }

  // A parent of a married-in member is external to this birth line unless
  // that same person is independently connected through a birth-line child
  // or a marriage to a birth-line member.
  const joinedIds = new Set(members.filter(isMarriedInMember).map(m => m.id));
  const isParentOfJoinedMember = members.some(child =>
    joinedIds.has(child.id) && (child.fatherId === member.id || child.motherId === member.id)
  );

  if (isParentOfJoinedMember) {
    const hasBirthLineChild = members.some(child =>
      !joinedIds.has(child.id) &&
      (child.fatherId === member.id || child.motherId === member.id)
    );
    const hasBirthLineMarriage = marriages.some(m => {
      const otherId = m.husbandId === member.id
        ? m.wifeId
        : m.wifeId === member.id
          ? m.husbandId
          : undefined;
      return Boolean(otherId && members.some(x => x.id === otherId && !isMarriedInMember(x)));
    });
    if (!hasBirthLineChild && !hasBirthLineMarriage) return false;
  }

  return true;
}

export function getVisibleFamilyMembers(members: Member[], marriages: MarriageRecord[]): Member[] {
  return members.filter(member => isVisibleFamilyMember(member, members, marriages));
}
