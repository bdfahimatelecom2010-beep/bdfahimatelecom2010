/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Core Genealogy Domain Models and Strict Types
 */

export type Gender = 'male' | 'female' | 'other' | 'unknown';

export type DatePrecision = 'exact' | 'approximate' | 'estimated' | 'before' | 'after' | 'unknown';

export type VerificationStatus = 'unverified' | 'verified' | 'disputed' | 'probable' | 'oral';

export type MarriageStatus = 'current' | 'separated' | 'divorce_pending' | 'divorced' | 'talaq' | 'widowed' | 'annulled';

export type BirthOrigin = 'born_in_family' | 'joined_by_marriage' | 'adopted' | 'unknown';
export type GenerationMode = 'automatic' | 'manual';
export type EvidenceStatus = 'unverified' | 'oral' | 'documented' | 'verified' | 'disputed' | 'approximate' | 'unknown';
export type LifeEventType = 'education' | 'employment' | 'residence' | 'migration' | 'award' | 'community' | 'milestone' | 'military' | 'immigration' | 'religious' | 'other';
export type ResearchStatus = 'verified' | 'probable' | 'family_reported' | 'unverified' | 'disputed' | 'needs_research';
export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-' | 'unknown';

export interface BanglaDate {
  day?: number;
  month?: string; // e.g., 'বৈশাখ', 'জ্যৈষ্ঠ', 'আষাঢ়'
  year?: number;  // e.g., 1430 BS
}

export interface HijriDate {
  day?: number;
  month?: string;
  year?: number; // AH
}

export interface GenealogyDate {
  year?: number | null;
  month?: number | null; // 1 - 12
  day?: number | null;   // 1 - 31
  isoString?: string;    // YYYY-MM-DD when known
  precision: DatePrecision;
  banglaDate?: BanglaDate;
  hijriDate?: HijriDate;
  notes?: string;
}

export interface LocationInfo {
  holding?: string;
  road?: string;
  village?: string;
  union?: string;
  ward?: string;
  postOffice?: string;
  postalCode?: string;
  upazila?: string;
  district?: string;
  division?: string;
  country?: string;
  fullAddress?: string;
}

/**
 * Identity documents: NID and Birth Registration MUST be separate fields.
 */
export interface EvidenceReference {
  id: string;
  sourceType: 'birth_certificate' | 'nid' | 'passport' | 'marriage_certificate' | 'death_certificate' | 'photo' | 'oral_history' | 'archive' | 'other';
  archiveRecordId?: string;
  note?: string;
  status: EvidenceStatus;
  verifiedAt?: string;
}

export interface LifeEvent {
  id: string;
  type: LifeEventType;
  title: string;
  date?: GenealogyDate;
  location?: LocationInfo;
  description?: string;
  evidenceReferenceIds?: string[];
}

export interface EducationRecord {
  id: string;
  institution?: string;
  qualification?: string;
  subject?: string;
  year?: number;
  result?: string;
  location?: LocationInfo;
  notes?: string;
}

export interface ProfessionRecord {
  id: string;
  profession?: string;
  organization?: string;
  designation?: string;
  startDate?: GenealogyDate;
  endDate?: GenealogyDate;
  location?: LocationInfo;
  notes?: string;
}

export interface ResidenceRecord {
  id: string;
  label: 'birthplace' | 'childhood' | 'current' | 'permanent' | 'previous' | 'abroad' | 'other';
  address: LocationInfo;
  fromDate?: GenealogyDate;
  toDate?: GenealogyDate;
  notes?: string;
}

export interface IdentityDocuments {
  nidNumber?: string;
  birthRegistrationNumber?: string;
  passportNumber?: string;
  passportPersonalNumber?: string;
  passportIssueDate?: string;
  passportExpiryDate?: string;
  passportIssuingAuthority?: string;
  previousPassportNumber?: string;
  otherId?: string;
  documentReference?: string;
  verificationStatus: VerificationStatus;
  isProtected?: boolean; // sensitive privacy masking
}

export interface BirthInfo {
  date: GenealogyDate;
  place: LocationInfo;
}

export interface DeathInfo {
  isDeceased: boolean;
  date?: GenealogyDate;
  place?: LocationInfo;
  burialPlace?: string; // Gorosthan / Cemetery
  memorialInfo?: string;
  deathDocumentRef?: string;
  notes?: string;
}

export interface Branch {
  id: string;
  name: string;
  banglaName: string;
  founderMemberId?: string;
  color: string;
  description?: string;
}

export interface MemberDocument {
  id: string;
  title: string;
  documentType: 'photo' | 'birth_certificate' | 'nid' | 'passport' | 'driving_licence' | 'marriage_certificate' | 'death_certificate' | 'education' | 'other';
  fileName: string;
  mimeType: string;
  dataUrl?: string;
  uploadedAt: string;
  note?: string;
  /** Canonical archive record for documents uploaded from a member profile. */
  archiveRecordId?: string;
  /** OCR evidence captured when the document was added from a member profile. */
  ocrText?: string;
  ocrConfidence?: number;
  extractedFields?: ExtractedDocumentFields;
  ocrVerification?: 'unverified' | 'verified' | 'disputed' | 'rejected';
}

export interface Member {
  // Master Rule: "Name may change, Person ID must never change."
  id: string;
  /** Owning family workspace. Not shown in ordinary UI. */
  familyId?: string;
  /** Legacy compatibility only. Never display or ask the user for this value. */
  serialNumber?: string;
  birthOrder?: number;
  generationMode?: GenerationMode;
  generationOverride?: number;
  /** Canonical automatically calculated generation persisted for backup/display. */
  computedGeneration?: number;
  /** Age at death when explicitly known; used to recover an approximate birth year. */
  ageAtDeath?: number;
  fullName: string;
  banglaName: string;
  englishName: string;
  nickname?: string;
  profession?: string;
  mobileNumber?: string;
  email?: string;
  currentAddress?: LocationInfo;
  permanentAddress?: LocationInfo;
  education?: string;
  maritalStatus?: 'unmarried' | 'married' | 'divorced' | 'widowed' | 'widower' | 'separated' | 'unknown';
  formerName?: string;
  gender: Gender;
  profilePhoto?: string;
  isLiving: boolean;
  
  // Lineage & Origin Rule:
  // "A person who joins the family through marriage must retain their own biological lineage."
  birthOrigin: BirthOrigin;
  marriageOrigin: boolean;
  originalLineageNote?: string;
  
  branchId: string;
  biography?: string;
  importantInformation?: string;
  notes?: string;
  tags?: string[];
  lifeEvents?: LifeEvent[];
  educationHistory?: EducationRecord[];
  professionHistory?: ProfessionRecord[];
  residenceHistory?: ResidenceRecord[];
  evidenceReferences?: EvidenceReference[];
  familyOriginStory?: string;
  memorialStory?: string;
  /** Extended genealogy facts; optional for backward-compatible storage. */
  alternativeNames?: string[];
  alternativeBanglaNames?: string[];
  alternativeEnglishNames?: string[];
  /** Alternate spellings with their document/source context, kept separate from the preferred name. */
  alternativeNameRecords?: Array<{ id: string; name: string; language: 'bn' | 'en' | 'other'; sourceType?: string; sourceReference?: string; note?: string }>;
  nationality?: string;
  religion?: string;
  bloodGroup?: BloodGroup;
  languages?: string[];
  physicalDescription?: string;
  militaryService?: string;
  migrationHistory?: string;
  researchNotes?: string;
  researchStatus?: ResearchStatus;
  
  birth: BirthInfo;
  death: DeathInfo;
  identityDocs: IdentityDocuments;
  memberDocuments?: MemberDocument[];
  
  // Direct biological parent links (permanent IDs)
  fatherId?: string;
  motherId?: string;
  /** Parent names captured from identity documents when the biological parent is not yet a family member. */
  fatherNameBn?: string;
  fatherNameEn?: string;
  motherNameBn?: string;
  motherNameEn?: string;
  /** Adoptive parent names are kept separately from biological parent links/names. */
  adoptiveFatherNameBn?: string;
  adoptiveFatherNameEn?: string;
  adoptiveMotherNameBn?: string;
  adoptiveMotherNameEn?: string;
  // Explicit grandparent links help recover lineage when a parent profile is incomplete.
  paternalGrandfatherId?: string;
  paternalGrandmotherId?: string;
  maternalGrandfatherId?: string;
  maternalGrandmotherId?: string;
  // Explicit spouse-parent links for in-law navigation/editing. These never create birth-line membership.
  fatherInLawId?: string;
  motherInLawId?: string;
  /** In-law names may be recorded even when the in-law is not yet a member profile. */
  fatherInLawName?: string;
  motherInLawName?: string;
  
  // Marriage records IDs
  marriageIds: string[];
  
  // Rule: Unmarried members must not have misleading spouse/children panels displayed
  isUnmarried: boolean;
  
  createdAt: string;
  updatedAt: string;
}

export interface DivorceInfo {
  date?: GenealogyDate;
  reason?: string;
  place?: string;
}

export interface MarriageRecord {
  // Master Rule: "Marriage may change, Marriage ID and historical records must remain."
  id: string;
  /** Owning family workspace. Not shown in ordinary UI. */
  familyId?: string;
  serialNumber: string; // e.g. "MR-001"
  husbandId: string;
  wifeId: string;
  marriageDate: GenealogyDate;
  marriagePlace: LocationInfo;
  status: MarriageStatus;
  divorceInfo?: DivorceInfo;
  /** Optional general status-change metadata (separation/divorce/talaq/etc.). */
  statusDate?: GenealogyDate;
  statusReason?: string;
  statusPlace?: string;
  spouseAddress?: LocationInfo; // Legacy combined in-law residence
  /** Per-union residence and in-law identity; separate for every marriage. */
  husbandAddress?: LocationInfo;
  wifeAddress?: LocationInfo;
  husbandFatherName?: string;
  husbandMotherName?: string;
  wifeFatherName?: string;
  wifeMotherName?: string;
  childrenIds: string[]; // Children belonging specifically to this union
  marriageNotes?: string;
  relatedDocuments?: string[];
  photos?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface SuccessionCandidate { memberId: string; priority: 1|2|3|4|5; note?: string; }
export type SuccessionFallback = 'family_rule' | 'applicable_law';

export interface FamilySettings {
  language: 'bn' | 'en' | 'hi' | 'ar';
  theme: string;
  defaultBranchId?: string;
  enableBengaliCalendar: boolean;
  enableHijriCalendar: boolean;
  enablePrivacyMasking: boolean;
  enableLivingPersonPrivacy?: boolean;
  dateFormat?: 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'YYYY-MM-DD';
  numberSystem?: 'bengali' | 'english';
  calendarSystem?: 'gregorian' | 'bengali' | 'hijri';
  privacyLevel?: 'public' | 'family_only' | 'private' | 'restricted';
  fontSize?: 'small' | 'medium' | 'large' | 'extra_large';
  displayDensity?: 'compact' | 'comfortable';
  enableAnimations?: boolean;
  highContrast?: boolean;
  dyslexicFont?: boolean;
  kromikPrefix?: string;
  generationNumbering?: 'bengali' | 'roman' | 'western';
  cousinCalculationRule?: 'bengali_exact' | 'western_degree';
  archiveStorageQuotaMb?: number;
  archiveWatermarkEnabled?: boolean;
  ocrEngine?: 'bengali_hybrid' | 'standard';
  ocrConfidenceThreshold?: number;
  ocrAutoDictionaryCorrection?: boolean;
  cameraAutoCrop?: boolean;
  cameraPerspectiveCorrection?: boolean;
  cameraContrastFilter?: 'none' | 'document_bw' | 'vintage_sepia' | 'enhanced';
  syncProvider?: 'local_only' | 'self_hosted' | 'neon' | 'supabase' | 'firebase' | 'appwrite';
  syncEndpoint?: string;
  syncLastTimestamp?: string;
  syncStatus?: 'synced' | 'pending' | 'offline' | 'error';
  googleConnected?: boolean;
  googleAccountEmail?: string;
  googleLastBackup?: string;
  googlePermissionsGranted?: string[];
  googleAutoBackup?: boolean;
  securityPinEnabled?: boolean;
  securityPinCode?: string;
  sessionTimeoutMinutes?: number;
  remembranceNotifications?: boolean;
  anniversaryAlerts?: boolean;
  birthdayAlerts?: boolean;
  /** Persistent dashboard customization: visibility and order survive reload/backup. */
  dashboardWidgets?: string[];
  dashboardWidgetOrder?: string[];
  dashboardLayout?: 'comfortable' | 'compact' | 'wide';
  /** Dashboard-only visual customization; safe defaults preserve existing appearance. */
  dashboardAccent?: 'amber' | 'blue' | 'green' | 'violet' | 'slate';
  dashboardCardStyle?: 'elevated' | 'outlined' | 'flat' | 'square';
  dashboardShowQuickActions?: boolean;
  successionCandidates?: SuccessionCandidate[];
  successionFallback?: SuccessionFallback;
  ownerSuccessionLastReviewed?: string;
}

export type RecycleEntityType = 'member' | 'marriage' | 'archive';

export interface RecycleBinEntry {
  id: string;
  familyId: string;
  entityType: RecycleEntityType;
  entityId: string;
  label: string;
  deletedAt: string;
  deletedBy?: string;
  payload: {
    member?: Member;
    members?: Member[];
    affectedMembers?: Member[];
    marriage?: MarriageRecord;
    affectedMarriages?: MarriageRecord[];
    archiveRecord?: ArchiveRecord;
  };
}

export interface BackupRecord {
  id: string;
  timestamp: string;
  label: string;
  memberCount: number;
  marriageCount: number;
  checksum: string;
}

export interface Family {
  id: string;
  name: string;
  banglaName: string;
  description: string;
  crestUrl?: string;
  rootAncestorId?: string;
  branches: Branch[];
  settings: FamilySettings;
  backupHistory: BackupRecord[];
  createdAt: string;
  updatedAt: string;
}

export interface ValidationIssue {
  id: string;
  type: 
    | 'circular_parent'
    | 'missing_reciprocal_parent'
    | 'missing_reciprocal_child'
    | 'duplicate_child'
    | 'invalid_spouse'
    | 'broken_marriage'
    | 'invalid_id'
    | 'orphan_record'
    | 'chronology_conflict';
  severity: 'error' | 'warning' | 'info';
  title: string;
  banglaTitle: string;
  description: string;
  affectedMemberIds: string[];
  affectedMarriageIds: string[];
  canAutoRepair: boolean;
}

export interface ValidationReport {
  scannedAt: string;
  isValid: boolean;
  errorCount: number;
  warningCount: number;
  issues: ValidationIssue[];
}

export interface KinshipPathStep {
  fromId: string;
  toId: string;
  relationType: 'father' | 'mother' | 'child' | 'spouse' | 'brother' | 'sister';
  englishLabel: string;
  banglaLabel: string;
}

export interface RelationshipResult {
  personAId: string;
  personBId: string;
  relationshipNameEn: string;
  relationshipNameBn: string;
  category: 'direct' | 'ancestor' | 'descendant' | 'sibling' | 'inlaw' | 'cousin' | 'extended' | 'unrelated';
  generationDifference: number; // 0 = same gen, +1 = B is next gen, -1 = B is parent gen
  path: KinshipPathStep[];
  pathDescriptionEn: string;
  pathDescriptionBn: string;
}

/**
 * =========================================================
 * PART 3: ARCHIVE, DOCUMENTS, OCR & MEDIA INTELLIGENCE
 * =========================================================
 */

export type ArchiveCategory =
  | 'photo'
  | 'document'
  | 'memory'
  | 'story'
  | 'letter'
  | 'event'
  | 'audio'
  | 'identity_document'
  | 'land_document'
  | 'certificate'
  | 'other';

export type DocumentSubtype =
  | 'nid_card'
  | 'birth_registration'
  | 'passport'
  | 'certificate'
  | 'marriage_doc'
  | 'death_doc'
  | 'deed'
  | 'khatian'
  | 'porcha'
  | 'land_record'
  | 'property_doc'
  | 'education_cert'
  | 'employment_doc'
  | 'family_record'
  | 'historical_doc'
  | 'other';

export type ArchiveAccessPermission = 'public' | 'family' | 'admin' | 'restricted';

export type ArchiveAuditAction =
  | 'uploaded'
  | 'edited'
  | 'linked'
  | 'unlinked'
  | 'ocr_performed'
  | 'ocr_verified'
  | 'verification_changed'
  | 'permission_changed'
  | 'archived'
  | 'restored';

export interface ArchiveAuditEntry {
  id: string;
  action: ArchiveAuditAction;
  timestamp: string;
  user: string;
  details: string;
}

export interface DocumentNumbers {
  nid?: string;
  brn?: string;
  passport?: string;
  khatian?: string;
  dag?: string;
  deed?: string;
  mouza?: string;
  jlNo?: string;
  volume?: string;
  otherRef?: string;
}

export type DocumentSide = 'front' | 'back' | 'unknown';

export interface ExtractedFieldCandidate {
  key: string;
  labelBn: string;
  labelEn: string;
  value: string;
  confidence: number;
  category: 'identity' | 'life' | 'relationship' | 'address' | 'document' | 'land' | 'contact' | 'other';
  profileWritable?: boolean;
}

export interface DocumentExtractionConflict {
  fieldKey: string;
  labelBn: string;
  labelEn: string;
  values: string[];
  confidenceByValue?: Record<string, number>;
}

export interface ExtractedDocumentFields {
  documentKind: 'nid' | 'birth_registration' | 'passport' | 'driving_licence' | 'land_deed' | 'marriage_doc' | 'death_doc' | 'general';
  documentSide?: DocumentSide;
  fullNameBn?: string;
  fullNameEn?: string;
  nidNumber?: string;
  passportNumber?: string;
  passportPersonalNumber?: string;
  passportIssueDate?: string;
  passportExpiryDate?: string;
  passportIssuingAuthority?: string;
  previousPassportNumber?: string;
  brnNumber?: string;
  documentNumber?: string;
  documentIssueDate?: string;
  documentDate?: string;
  dateOfBirth?: string;
  placeOfBirth?: string;
  fatherName?: string;
  motherName?: string;
  spouseName?: string;
  childrenNames?: string[];

  occupation?: string;
  mobileNumber?: string;
  email?: string;
  religion?: string;
  nationality?: string;
  gender?: 'male' | 'female' | 'other' | 'unknown';
  bloodGroup?: BloodGroup;
  address?: string;
  presentAddress?: LocationInfo;
  permanentAddress?: LocationInfo;
  holding?: string;
  road?: string;
  village?: string;
  union?: string;
  ward?: string;
  postOffice?: string;
  postalCode?: string;
  upazila?: string;
  district?: string;
  division?: string;
  country?: string;
  mouza?: string;
  khatianNumber?: string;
  dagNumber?: string;
  deedNumber?: string;
  deedYear?: string;
  landAmount?: string;
  restingPlace?: string;
  dateOfDeath?: string;
  issuingAuthority?: string;
  additionalFields?: ExtractedFieldCandidate[];
  conflicts?: DocumentExtractionConflict[];
  rawUnmappedLines?: string[];
  confidence: number;
}

export interface ArchiveRecord {
  id: string;
  title: string;
  titleBn?: string;
  category: ArchiveCategory;
  documentType?: DocumentSubtype;
  date?: string;
  location?: LocationInfo;
  description?: string;
  descriptionBn?: string;
  relatedMemberIds: string[];
  memberRoles?: Record<string, string>;
  relatedFamilyId: string;
  relatedBranchId?: string;
  mediaUrl: string; // Original pristine evidence
  /** Additional original files belonging to the same OCR session (e.g. NID front + back). */
  sourceFiles?: Array<{ fileName: string; mimeType?: string; dataUrl: string; fileSizeBytes?: number }>;
  enhancedMediaUrl?: string; // Optional separate enhanced copy
  mediaType: 'image' | 'audio' | 'document' | 'text';
  originalFilename?: string;
  mimeType?: string;
  fileSizeBytes?: number;
  ocrText?: string;
  ocrConfidence?: number;
  ocrVerification: 'unverified' | 'verified' | 'disputed' | 'rejected';
  extractedFields?: ExtractedDocumentFields;
  source?: string;
  provenance?: string;
  uploader?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
  notes?: string;
  accessPermission: ArchiveAccessPermission;
  documentNumbers?: DocumentNumbers;
  audioMetadata?: {
    speaker?: string;
    durationSeconds?: number;
    transcript?: string;
  };
  history: ArchiveAuditEntry[];
  isArchived?: boolean;
}

export interface FieldConflict {
  fieldKey: string;
  fieldLabelEn: string;
  fieldLabelBn: string;
  existingValue: string;
  extractedValue: string;
  confidence: number;
  sourceDocumentTitle: string;
  decision: 'pending' | 'accepted' | 'rejected' | 'custom';
  customValue?: string;
}

export interface DuplicateCandidate {
  member: Member;
  matchScore: number;
  matchedReasons: string[];
}

