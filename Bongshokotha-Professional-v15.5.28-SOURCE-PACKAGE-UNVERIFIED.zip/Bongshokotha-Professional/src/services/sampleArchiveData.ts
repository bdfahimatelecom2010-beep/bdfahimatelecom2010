/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Authentic Pre-Seeded Family Archive Records
 */

import { ArchiveRecord } from '../types/genealogy';
import { SAMPLE_FAMILY_ID } from './sampleData';

export const SAMPLE_ARCHIVE_RECORDS: ArchiveRecord[] = [
  {
    id: 'arc-land-1948-001',
    title: '1948 C.S. Khatian & Zamindari Land Record (Daudpur)',
    titleBn: '১৯৪৮ সালের সি.এস খতিয়ান ও পৈতৃক ভূমির পরচা (দাউদপুর মৌজা)',
    category: 'land_document',
    documentType: 'khatian',
    date: '1948-04-14',
    location: {
      village: 'দাউদপুর',
      upazila: 'গোলাপগঞ্জ',
      district: 'সিলেট',
      division: 'সিলেট',
      country: 'বাংলাদেশ'
    },
    description: 'খান বাহাদুর আব্দুল লতিফ চৌধুরীর নামে রেকর্ডকৃত পৈতৃক বসতভিটা ও কৃষিজমির সি.এস খতিয়ান এবং খাজনা দাখিলা রসিদ।',
    descriptionBn: 'খান বাহাদুর আব্দুল লতিফ চৌধুরীর নামে রেকর্ডকৃত পৈতৃক বসতভিটা ও কৃষিজমির সি.এস খতিয়ান এবং খাজনা দাখিলা রসিদ।',
    relatedMemberIds: ['mem-chowdhury-001', 'mem-chowdhury-002', 'mem-chowdhury-003'],
    memberRoles: {
      'mem-chowdhury-001': 'মূল খতিয়ানধারী ও পিং (পিতা)',
      'mem-chowdhury-002': 'ওয়ারিশ ও প্রথম পক্ষীয় অংশীদার',
      'mem-chowdhury-003': 'ওয়ারিশ ও দ্বিতীয় পক্ষীয় অংশীদার'
    },
    relatedFamilyId: SAMPLE_FAMILY_ID,
    relatedBranchId: 'branch-borotaraf',
    mediaUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1200&q=80',
    enhancedMediaUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'image',
    originalFilename: 'CS_Khatian_Daudpur_1948.jpg',
    mimeType: 'image/jpeg',
    fileSizeBytes: 2450000,
    ocrText: `বাংলাদেশ ভূমি রেকর্ড ও জরিপ অধিদপ্তর\nসি.এস খতিয়ান নং: ১৪২\nমৌজা: দাউদপুর, জে.এল নং: ৪২\nথানা: গোলাপগঞ্জ, জিলা: সিলেট\nখতিয়ানধারী: খান বাহাদুর আব্দুল লতিফ চৌধুরী\nপিং: মরহুম আমজাদ আলী চৌধুরী\nদাগ নং: ৮০৫, ৮০৬, ৮১২\nজমির শ্রেণী: নাল ও ভিটা, মোট পরিমাণ: ৪ একর ৮৫ শতাংশ।`,
    ocrConfidence: 94,
    ocrVerification: 'verified',
    extractedFields: {
      documentKind: 'land_deed',
      fullNameBn: 'খান বাহাদুর আব্দুল লতিফ চৌধুরী',
      fatherName: 'মরহুম আমজাদ আলী চৌধুরী',
      mouza: 'দাউদপুর',
      khatianNumber: '১৪২',
      dagNumber: '৮০৫',
      deedNumber: '১৮৭৪/১৯৪৮',
      deedYear: '১৯৪৮',
      landAmount: '৪ একর ৮৫ শতাংশ',
      confidence: 94
    },
    source: 'সিলেট জেলা রেকর্ড রুম ও পারিবারিক সিন্দুক',
    provenance: 'আমজাদ আলী চৌধুরীর পর ১৮৭৪ সন হতে বংশানুক্রমে সংরক্ষিত আদি হস্তলিখিত দলিল।',
    uploader: 'মুহম্মদ তারিকুল ইসলাম চৌধুরী',
    createdAt: '2024-01-10T10:00:00.000Z',
    updatedAt: '2024-01-15T14:30:00.000Z',
    tags: ['সিএস খতিয়ান', 'জমিজমা', 'দাউদপুর', 'পৈতৃক ভিটা'],
    notes: 'মৌজার মূল নকশার সাথে দাগ ৮০৫ এর সীমানা সম্পূর্ণ সামঞ্জস্যপূর্ণ।',
    accessPermission: 'family',
    documentNumbers: {
      khatian: '১৪২',
      dag: '৮০৫',
      mouza: 'দাউদপুর',
      jlNo: '৪২',
      deed: '১৮৭৪/১৯৪৮'
    },
    history: [
      {
        id: 'hist-1',
        action: 'uploaded',
        timestamp: '2024-01-10T10:00:00.000Z',
        user: 'তারিকুল ইসলাম',
        details: 'আদি মহাফেজখানা হতে স্ক্যানকৃত ছবি সংযুক্ত করা হয়েছে।'
      },
      {
        id: 'hist-2',
        action: 'ocr_performed',
        timestamp: '2024-01-10T10:05:00.000Z',
        user: 'সিস্টেম ইঞ্জিন',
        details: 'বাংলা হরফ ও সি.এস খতিয়ান বিশ্লেষণ সম্পন্ন। আত্মবিশ্বাস ৯৪%।'
      },
      {
        id: 'hist-3',
        action: 'verification_changed',
        timestamp: '2024-01-15T14:30:00.000Z',
        user: 'পরিবার প্রশাসক',
        details: 'রেকর্ডটি যাচাইকৃত (Verified) হিসেবে চিহ্নিত।'
      }
    ]
  },
  {
    id: 'arc-nid-mem-002',
    title: 'National ID Card: Barrister Altaf Hossain Chowdhury',
    titleBn: 'ব্যারিস্টার আলতাফ হোসেন চৌধুরীর জাতীয় পরিচয়পত্র (NID)',
    category: 'identity_document',
    documentType: 'nid_card',
    date: '2008-06-12',
    location: {
      village: 'দাউদপুর',
      upazila: 'গোলাপগঞ্জ',
      district: 'সিলেট',
      country: 'বাংলাদেশ'
    },
    description: 'নির্বাচন কমিশন বাংলাদেশ কর্তৃক প্রদত্ত জাতীয় পরিচয়পত্র। এনআইডি নম্বর: ১৯৩৮২৬৯২৫১৮৯২০১১১',
    descriptionBn: 'নির্বাচন কমিশন বাংলাদেশ কর্তৃক প্রদত্ত জাতীয় পরিচয়পত্র। এনআইডি নম্বর: ১৯৩৮২৬৯২৫১৮৯২০১১১',
    relatedMemberIds: ['mem-chowdhury-002'],
    memberRoles: {
      'mem-chowdhury-002': 'কার্ডধারী (Self)'
    },
    relatedFamilyId: SAMPLE_FAMILY_ID,
    relatedBranchId: 'branch-borotaraf',
    mediaUrl: 'https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'image',
    originalFilename: 'Altaf_Hossain_NID.jpg',
    mimeType: 'image/jpeg',
    ocrText: `গণপ্রজাতন্ত্রী বাংলাদেশ সরকার\nজাতীয় পরিচয়পত্র / National ID Card\nনাম: আলতাফ হোসেন চৌধুরী\nName: Altaf Hossain Chowdhury\nপিতা: খান বাহাদুর আব্দুল লতিফ চৌধুরী\nমাতা: বেগম জাহানারা লতিফ\nDate of Birth: 12 Jan 1938\nID NO: 19382692518920111`,
    ocrConfidence: 98,
    ocrVerification: 'verified',
    extractedFields: {
      documentKind: 'nid',
      fullNameBn: 'আলতাফ হোসেন চৌধুরী',
      fullNameEn: 'Altaf Hossain Chowdhury',
      nidNumber: '19382692518920111',
      dateOfBirth: '12 Jan 1938',
      fatherName: 'খান বাহাদুর আব্দুল লতিফ চৌধুরী',
      motherName: 'বেগম জাহানারা লতিফ',
      confidence: 98
    },
    source: 'ব্যক্তিগত নথিপত্র',
    provenance: 'পারিবারিক পরিচয়পত্র ফাইল নং ০২',
    uploader: 'মুহম্মদ তারিকুল ইসলাম চৌধুরী',
    createdAt: '2024-01-12T11:00:00.000Z',
    updatedAt: '2024-01-12T11:00:00.000Z',
    tags: ['NID', 'ব্যারিস্টার আলতাফ', 'পরিচয়পত্র'],
    accessPermission: 'restricted',
    documentNumbers: {
      nid: '19382692518920111'
    },
    history: [
      {
        id: 'hist-nid-1',
        action: 'uploaded',
        timestamp: '2024-01-12T11:00:00.000Z',
        user: 'তারিকুল ইসলাম',
        details: 'এনআইডি স্ক্যান কপি আপলোড ও স্বয়ংক্রিয়ভাবে সদস্য প্রোফাইলে সংযুক্ত।'
      }
    ]
  },
  {
    id: 'arc-audio-1971-001',
    title: 'Oral History: Memories of 1971 & Ancestral Resistance',
    titleBn: 'মৌখিক ইতিহাস: ১৯৭১-এর রক্তঝরা দিন ও পারিবারিক স্মৃতিচারণ',
    category: 'audio',
    documentType: 'family_record',
    date: '1998-12-16',
    location: {
      village: 'দাউদপুর',
      district: 'সিলেট',
      country: 'বাংলাদেশ'
    },
    description: 'বেগম রাবেয়া খাতুনের কণ্ঠের দুর্লভ অডিও রেকর্ড — স্বাধীনতা যুদ্ধ চলাকালে পরিবারের সদস্যদের আশ্রয় ও সহায়তা প্রদানের প্রত্যক্ষ বর্ণনা।',
    descriptionBn: 'বেগম রাবেয়া খাতুনের কণ্ঠের দুর্লভ অডিও রেকর্ড — স্বাধীনতা যুদ্ধ চলাকালে পরিবারের সদস্যদের আশ্রয় ও সহায়তা প্রদানের প্রত্যক্ষ বর্ণনা।',
    relatedMemberIds: ['mem-chowdhury-004', 'mem-chowdhury-002'],
    memberRoles: {
      'mem-chowdhury-004': 'বক্তা (Narrator)',
      'mem-chowdhury-002': 'বর্ণিত চরিত্র (Mentioned Subject)'
    },
    relatedFamilyId: SAMPLE_FAMILY_ID,
    relatedBranchId: 'branch-borotaraf',
    mediaUrl: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=ambient-piano-loop-85bpm-112196.mp3',
    mediaType: 'audio',
    originalFilename: 'Rabeya_Khatun_1971_Memoir.mp3',
    mimeType: 'audio/mpeg',
    fileSizeBytes: 3850000,
    ocrVerification: 'unverified',
    source: 'পারিবারিক ক্যাসেট টেপ হতে ডিজিটালাইজড',
    provenance: '১৯৯৮ সালের ১৬ই ডিসেম্বর ঘরোয়া পরিবেশে রেকর্ডকৃত ক্যাসেট টেপ।',
    uploader: 'ফারহানা ইসলাম চৌধুরী',
    createdAt: '2024-02-01T09:00:00.000Z',
    updatedAt: '2024-02-01T09:00:00.000Z',
    tags: ['মৌখিক ইতিহাস', '১৯৭১ মুক্তিযুদ্ধ', 'স্মৃতিচারণ', 'রাবেয়া খাতুন'],
    accessPermission: 'public',
    audioMetadata: {
      speaker: 'বেগম রাবেয়া খাতুন',
      durationSeconds: 165,
      transcript: 'আমাদের বাড়িটি তখন মুক্তিযোদ্ধাদের একটি নিরাপদ আশ্রয়স্থল ছিল। আলতাফ ভাই দিনরাত তরুণদের সীমান্ত পাড় করতে সাহায্য করতেন। আমরা ঘরে চাল ও রুটি বানিয়ে লুকিয়ে রাখতাম। আল্লাহ আমাদের সবাইকে রক্ষা করেছিলেন।'
    },
    history: [
      {
        id: 'hist-aud-1',
        action: 'uploaded',
        timestamp: '2024-02-01T09:00:00.000Z',
        user: 'ফারহানা ইসলাম',
        details: 'পারিবারিক ম্যাগনেটিক টেপ হতে অডিও ও ট্রান্সক্রিপ্ট সংরক্ষণ।'
      }
    ]
  },
  {
    id: 'arc-photo-1958-001',
    title: '1958 Ancestral Haveli & Foundation Portrait',
    titleBn: '১৯৫৮ সালের চৌধুরী বাড়ি ও পারিবারিক সমাবেশ',
    category: 'photo',
    documentType: 'family_record',
    date: '1958-02-21',
    location: {
      village: 'দাউদপুর',
      upazila: 'গোলাপগঞ্জ',
      district: 'সিলেট',
      country: 'বাংলাদেশ'
    },
    description: 'খান বাহাদুর আব্দুল লতিফ চৌধুরীর উপস্থিতিতে পরিবারের দ্বিতীয় প্রজন্মের পূর্ণাঙ্গ সমাবেশ। পেছনে ঐতিহ্যবাহী লাল ইটের হাভেলি ভবন দৃশ্যমান।',
    descriptionBn: 'খান বাহাদুর আব্দুল লতিফ চৌধুরীর উপস্থিতিতে পরিবারের দ্বিতীয় প্রজন্মের পূর্ণাঙ্গ সমাবেশ। পেছনে ঐতিহ্যবাহী লাল ইটের হাভেলি ভবন দৃশ্যমান।',
    relatedMemberIds: ['mem-chowdhury-001', 'mem-chowdhury-002', 'mem-chowdhury-003', 'mem-chowdhury-004'],
    memberRoles: {
      'mem-chowdhury-001': 'কেন্দ্রীয় আদি পুরুষ',
      'mem-chowdhury-002': 'জ্যেষ্ঠ পুত্র',
      'mem-chowdhury-003': 'কনিষ্ঠ পুত্র',
      'mem-chowdhury-004': 'পুত্রবধূ'
    },
    relatedFamilyId: SAMPLE_FAMILY_ID,
    relatedBranchId: 'branch-borotaraf',
    mediaUrl: 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=1200&q=80',
    enhancedMediaUrl: 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'image',
    originalFilename: 'Chowdhury_Haveli_1958.jpg',
    mimeType: 'image/jpeg',
    ocrVerification: 'verified',
    source: 'পারিবারিক অ্যালবাম অ্যালবাম নং ০১',
    provenance: 'তৎকালীন স্টুডিও আলোকচিত্রী এস. রহমান কর্তৃক তোলানো মূল সেপিয়া প্রিন্ট।',
    uploader: 'মুহম্মদ তারিকুল ইসলাম চৌধুরী',
    createdAt: '2024-01-05T08:00:00.000Z',
    updatedAt: '2024-01-05T08:00:00.000Z',
    tags: ['ঐতিহাসিক ছবি', 'হাভেলি', '১৯৫৮', 'পারিবারিক প্রতিকৃতি'],
    accessPermission: 'public',
    history: [
      {
        id: 'hist-pho-1',
        action: 'uploaded',
        timestamp: '2024-01-05T08:00:00.000Z',
        user: 'তারিকুল ইসলাম',
        details: 'অ্যালবাম থেকে স্ক্যান করে ডিজিটাল আর্কাইভে নথিবদ্ধ।'
      }
    ]
  },
  {
    id: 'arc-letter-1978-001',
    title: 'Historic Letter from Lincoln’s Inn, London (1978)',
    titleBn: '১৯৭৮ সালে লিঙ্কনস ইন, লন্ডন থেকে প্রেরিত চিঠি',
    category: 'letter',
    documentType: 'historical_doc',
    date: '1978-09-04',
    location: {
      village: 'লন্ডন',
      country: 'যুক্তরাজ্য'
    },
    description: 'ব্যারিস্টার আলতাফ হোসেন চৌধুরী কর্তৃক তাঁর জ্যেষ্ঠ পুত্র তারিকুল ইসলাম চৌধুরীকে পাঠানো উপদেশমূলক চিঠি।',
    descriptionBn: 'ব্যারিস্টার আলতাফ হোসেন চৌধুরী কর্তৃক তাঁর জ্যেষ্ঠ পুত্র তারিকুল ইসলাম চৌধুরীকে পাঠানো উপদেশমূলক চিঠি।',
    relatedMemberIds: ['mem-chowdhury-002', 'mem-chowdhury-005'],
    memberRoles: {
      'mem-chowdhury-002': 'প্রেরক / পিতা',
      'mem-chowdhury-005': 'প্রাপক / পুত্র'
    },
    relatedFamilyId: SAMPLE_FAMILY_ID,
    relatedBranchId: 'branch-borotaraf',
    mediaUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'image',
    originalFilename: 'London_Letter_1978.jpg',
    mimeType: 'image/jpeg',
    ocrText: `Dear Tariqul,\nI am writing from London. Always remember our roots in Sylhet and respect the land and its people. Your grandfather's values of honesty must guide your life.\nAffectionately,\nYour Father, Altaf.`,
    ocrConfidence: 96,
    ocrVerification: 'verified',
    source: 'পারিবারিক পত্রাবলি সংগ্রহ',
    provenance: 'লন্ডন ডাক বিভাগ মোহরাঙ্কিত মূল এয়ারমেইল খামসহ সংরক্ষিত।',
    uploader: 'মুহম্মদ তারিকুল ইসলাম চৌধুরী',
    createdAt: '2024-01-20T12:00:00.000Z',
    updatedAt: '2024-01-20T12:00:00.000Z',
    tags: ['চিঠি', 'লন্ডন', 'স্মৃতি', 'উপদেশ'],
    accessPermission: 'family',
    history: [
      {
        id: 'hist-let-1',
        action: 'uploaded',
        timestamp: '2024-01-20T12:00:00.000Z',
        user: 'তারিকুল ইসলাম',
        details: 'চিঠির মূল খণ্ড স্ক্যান করা হয়েছে।'
      }
    ]
  }
];
