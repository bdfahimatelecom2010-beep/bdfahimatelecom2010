/** Local security primitives. For cloud deployments, server-side auth must be used as the authoritative boundary. */
const SESSION_KEY = 'bongshokotha_secure_session_v2';
const FAILED_KEY = 'bongshokotha_login_failures_v2';
const MAX_FAILURES = 8;
const LOCK_MINUTES = 15;
const PBKDF2_ITERATIONS = 120000;

const hex = (bytes: Uint8Array) => Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
const bytes = (hexString: string) => new Uint8Array(hexString.match(/.{1,2}/g)?.map(v => parseInt(v, 16)) || []);

export async function hashPassword(password: string, saltHex = hex(crypto.getRandomValues(new Uint8Array(16)))): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: bytes(saltHex), iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' }, key, 256);
  return `pbkdf2-sha256$${PBKDF2_ITERATIONS}$${saltHex}$${hex(new Uint8Array(bits))}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  if (!stored) return false;
  if (stored.startsWith('pbkdf2-sha256$')) {
    const [, iter, salt, expected] = stored.split('$');
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: bytes(salt), iterations: Number(iter), hash: 'SHA-256' }, key, 256);
    return hex(new Uint8Array(bits)) === expected;
  }
  // Legacy SHA-256 accounts are accepted once so they can be upgraded on successful login.
  const data = new TextEncoder().encode(password);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return hex(new Uint8Array(digest)) === stored;
}

export function createSession(accountId: string, timeoutMinutes = 15) {
  const now = Date.now();
  const session = { id: crypto.randomUUID(), accountId, issuedAt: now, lastActivityAt: now, expiresAt: now + timeoutMinutes * 60_000 };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
}

export function getSession(): { id: string; accountId: string; issuedAt: number; lastActivityAt: number; expiresAt: number } | null {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw);
    if (!session?.accountId || Date.now() >= Number(session.expiresAt)) { clearSession(); return null; }
    return session;
  } catch { return null; }
}

export function touchSession(timeoutMinutes = 15) {
  const session = getSession();
  if (!session) return null;
  const now = Date.now();
  const next = { ...session, lastActivityAt: now, expiresAt: now + timeoutMinutes * 60_000 };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(next));
  return next;
}

export function clearSession() {
  try { sessionStorage.removeItem(SESSION_KEY); } catch {}
}

export function isSessionAuthenticated(): boolean { return Boolean(getSession()); }

export function getLoginLockState(contact: string) {
  try {
    const raw = localStorage.getItem(FAILED_KEY);
    const all = JSON.parse(raw || '{}');
    const state = all[contact.toLowerCase()] || { count: 0, lockedUntil: 0 };
    if (state.lockedUntil && Date.now() >= state.lockedUntil) return { count: 0, lockedUntil: 0 };
    return state;
  } catch { return { count: 0, lockedUntil: 0 }; }
}

export function recordLoginFailure(contact: string) {
  const key = contact.toLowerCase();
  try {
    const all = JSON.parse(localStorage.getItem(FAILED_KEY) || '{}');
    const prev = all[key] || { count: 0, lockedUntil: 0 };
    const count = Number(prev.count || 0) + 1;
    all[key] = { count, lockedUntil: count >= MAX_FAILURES ? Date.now() + LOCK_MINUTES * 60_000 : 0 };
    localStorage.setItem(FAILED_KEY, JSON.stringify(all));
  } catch {}
}

export function clearLoginFailures(contact: string) {
  try {
    const all = JSON.parse(localStorage.getItem(FAILED_KEY) || '{}');
    delete all[contact.toLowerCase()];
    localStorage.setItem(FAILED_KEY, JSON.stringify(all));
  } catch {}
}
