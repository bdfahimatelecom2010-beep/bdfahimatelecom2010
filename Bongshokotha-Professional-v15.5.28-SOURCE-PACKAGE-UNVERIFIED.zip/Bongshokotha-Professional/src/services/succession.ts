export interface SuccessionCandidate { memberId: string; priority: 1|2|3|4|5; note?: string; }
export type SuccessionFallback = 'family_rule' | 'applicable_law';
const KEY = 'bongshokotha_succession_v1';
export interface SuccessionPlan { candidates: SuccessionCandidate[]; fallback: SuccessionFallback; updatedAt: string; }
export function getSuccessionPlan(familyId?: string): SuccessionPlan {
  try { const all=JSON.parse(localStorage.getItem(KEY)||'{}'); const p=familyId?all[familyId]:undefined; if(p) return p; } catch {}
  return {candidates:[], fallback:'applicable_law',updatedAt:new Date().toISOString()};
}
export function saveSuccessionPlan(familyId:string, plan:SuccessionPlan){
  const all=JSON.parse(localStorage.getItem(KEY)||'{}');
  const unique = new Map<number,SuccessionCandidate>();
  for(const c of [...plan.candidates].sort((a,b)=>a.priority-b.priority)){ if(c.priority>=1&&c.priority<=5&&c.memberId&&!unique.has(c.priority)) unique.set(c.priority,c); }
  const cleaned={...plan,candidates:[...unique.values()].sort((a,b)=>a.priority-b.priority),updatedAt:new Date().toISOString()};
  all[familyId]=cleaned; localStorage.setItem(KEY,JSON.stringify(all)); return cleaned;
}
