/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Offline-First Persistent Storage Engine
 * 
 * Backed by IndexedDB with synchronous LocalStorage redundancy & complete export/import
 */

import { Family, Member, MarriageRecord, Branch, ArchiveRecord, RecycleBinEntry } from '../types/genealogy';

const DB_NAME = 'bongshokotha_genealogy_db';
const DB_VERSION = 5;

/**
 * Runtime schema guard for legacy/partially populated records.
 * This is additive only: existing canonical values are preserved and missing
 * collections/objects receive safe defaults so old IndexedDB/LocalStorage data
 * cannot crash the UI during a release upgrade.
 */
export function normalizeMemberRecord(raw: Partial<Member>): Member {
  const member = raw as Member;
  return {
    ...member,
    id: member.id || crypto.randomUUID(),
    familyId: member.familyId,
    serialNumber: member.serialNumber,
    birthOrder: member.birthOrder,
    generationMode: member.generationMode || 'automatic',
    computedGeneration: member.computedGeneration,
    fullName: member.fullName || member.banglaName || member.englishName || 'অজ্ঞাত সদস্য',
    banglaName: member.banglaName || member.fullName || '',
    englishName: member.englishName || '',
    gender: member.gender || 'unknown',
    isLiving: member.isLiving ?? true,
    birthOrigin: member.birthOrigin || 'unknown',
    marriageOrigin: Boolean(member.marriageOrigin),
    branchId: member.branchId || '',
    birth: {
      date: { ...(member.birth?.date || { precision: 'unknown' }) },
      place: { ...(member.birth?.place || {}) }
    },
    death: {
      ...(member.death || {}),
      isDeceased: member.death?.isDeceased ?? !(member.isLiving ?? true)
    },
    identityDocs: {
      ...(member.identityDocs || {}),
      verificationStatus: member.identityDocs?.verificationStatus || 'unverified'
    },
    marriageIds: Array.isArray(member.marriageIds) ? member.marriageIds : [],
    maritalStatus: member.maritalStatus || 'unmarried',
    isUnmarried: member.maritalStatus ? member.maritalStatus === 'unmarried' : (member.isUnmarried ?? true),
    tags: Array.isArray(member.tags) ? member.tags : [],
    lifeEvents: Array.isArray(member.lifeEvents) ? member.lifeEvents : [],
    educationHistory: Array.isArray(member.educationHistory) ? member.educationHistory : [],
    professionHistory: Array.isArray(member.professionHistory) ? member.professionHistory : [],
    residenceHistory: Array.isArray(member.residenceHistory) ? member.residenceHistory : [],
    evidenceReferences: Array.isArray(member.evidenceReferences) ? member.evidenceReferences : [],
    alternativeNames: Array.isArray(member.alternativeNames) ? member.alternativeNames : [],
    languages: Array.isArray(member.languages) ? member.languages : [],
    memberDocuments: Array.isArray(member.memberDocuments) ? member.memberDocuments : [],
    createdAt: member.createdAt || new Date().toISOString(),
    updatedAt: member.updatedAt || new Date().toISOString()
  };
}

export function normalizeMarriageRecord(raw: Partial<MarriageRecord>): MarriageRecord {
  const marriage = raw as MarriageRecord;
  return {
    ...marriage,
    id: marriage.id || crypto.randomUUID(),
    serialNumber: marriage.serialNumber || '',
    husbandId: marriage.husbandId || '',
    wifeId: marriage.wifeId || '',
    marriageDate: { ...(marriage.marriageDate || { precision: 'unknown' }) },
    marriagePlace: { ...(marriage.marriagePlace || {}) },
    status: marriage.status || 'current',
    childrenIds: Array.isArray(marriage.childrenIds) ? marriage.childrenIds : [],
    createdAt: marriage.createdAt || new Date().toISOString(),
    updatedAt: marriage.updatedAt || new Date().toISOString()
  };
}


export interface BongshokothaArchive {
  format: 'BONGSHOKOTHA_ARCHIVE';
  version: '1.0' | '1.1' | '1.2';
  exportedAt: string;
  app: 'Bongshokotha / বংশকথা';
  family: Family;
  members: Member[];
  marriages: MarriageRecord[];
  branches: Branch[];
  archiveRecords?: ArchiveRecord[];
  generationSnapshot?: Record<string, number>;
  /** Deleted records are preserved so a full restore can recover the Recycle Bin too. */
  recycleBin?: RecycleBinEntry[];
  /** Integrity metadata for tamper/corruption detection. */
  integrity?: { algorithm: 'SHA-256'; checksum: string; payloadVersion: '1.1' };
}

function sortKeysDeep(value: any): any {
  if (Array.isArray(value)) return value.map(sortKeysDeep);
  if (value && typeof value === 'object') {
    return Object.keys(value).sort().reduce((acc, key) => {
      acc[key] = sortKeysDeep(value[key]);
      return acc;
    }, {} as Record<string, any>);
  }
  return value;
}

export async function computeArchiveChecksum(archive: Omit<BongshokothaArchive, 'integrity'>): Promise<string> {
  const canonical = JSON.stringify(sortKeysDeep(archive));
  const bytes = new TextEncoder().encode(canonical);
  if (globalThis.crypto?.subtle) {
    const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
  }
  throw new Error('SHA-256 crypto support is unavailable in this environment.');
}

export function archivePayloadWithoutIntegrity(archive: BongshokothaArchive): Omit<BongshokothaArchive, 'integrity'> {
  const { integrity: _integrity, ...payload } = archive;
  return payload;
}

class StorageEngine {
  private dbPromise: Promise<IDBDatabase> | null = null;
  private readonly ACTIVE_FAMILY_KEY = 'bk_active_family_id';
  private readonly FAMILIES_KEY = 'bk_families_list';
  private readonly LOCAL_BACKUP_PREFIX = 'bk_backup_';

  constructor() {
    this.initDB();
  }

  private initDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        console.warn('IndexedDB not supported in current context. Falling back to local storage.');
        // @ts-expect-error fallback handling
        resolve(null);
        return;
      }

      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('families')) {
          db.createObjectStore('families', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('members')) {
          const memberStore = db.createObjectStore('members', { keyPath: 'id' });
          memberStore.createIndex('familyId', 'familyId', { unique: false });
          memberStore.createIndex('branchId', 'branchId', { unique: false });
        }
        if (!db.objectStoreNames.contains('marriages')) {
          const marriageStore = db.createObjectStore('marriages', { keyPath: 'id' });
          marriageStore.createIndex('husbandId', 'husbandId', { unique: false });
          marriageStore.createIndex('wifeId', 'wifeId', { unique: false });
        }
        if (!db.objectStoreNames.contains('archive_records')) {
          const archiveStore = db.createObjectStore('archive_records', { keyPath: 'id' });
          archiveStore.createIndex('relatedFamilyId', 'relatedFamilyId', { unique: false });
          archiveStore.createIndex('category', 'category', { unique: false });
        }
        if (!db.objectStoreNames.contains('recycle_bin')) {
          const recycleStore = db.createObjectStore('recycle_bin', { keyPath: 'id' });
          recycleStore.createIndex('familyId', 'familyId', { unique: false });
          recycleStore.createIndex('entityId', 'entityId', { unique: false });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => {
        console.error('IndexedDB open error:', request.error);
        // @ts-expect-error fallback handling
        resolve(null);
      };
    });

    return this.dbPromise;
  }

  // --- Multi-Family Support ---

  public getActiveFamilyId(): string {
    const stored = localStorage.getItem(this.ACTIVE_FAMILY_KEY);
    return stored || '';
  }

  public setActiveFamilyId(id: string): void {
    localStorage.setItem(this.ACTIVE_FAMILY_KEY, id);
  }

  public async getFamilies(): Promise<Family[]> {
    const db = await this.initDB();
    if (db) {
      try {
        const tx = db.transaction('families', 'readonly');
        const store = tx.objectStore('families');
        const req = store.getAll();
        const results = await new Promise<Family[]>((res, rej) => {
          req.onsuccess = () => res(req.result || []);
          req.onerror = () => rej(req.error);
        });

        if (results && results.length > 0) return results;
      } catch (e) {
        console.warn('IDB fetch families failed, checking localStorage fallback', e);
      }
    }

    const local = localStorage.getItem(this.FAMILIES_KEY);
    if (local) {
      try {
        return JSON.parse(local);
      } catch (err) {
        console.error('Failed to parse local families:', err);
      }
    }

    // Default to Sample Family seed on first run
    return [];
  }

  public async saveFamily(family: Family): Promise<void> {
    const db = await this.initDB();
    if (db) {
      try {
        const tx = db.transaction('families', 'readwrite');
        tx.objectStore('families').put(family);
        await new Promise((res, rej) => {
          tx.oncomplete = res;
          tx.onerror = rej;
        });
      } catch (e) {
        console.warn('Failed to save family in IDB', e);
      }
    }

    // Backup in localStorage
    const families = await this.getFamilies();
    const idx = families.findIndex(f => f.id === family.id);
    if (idx >= 0) families[idx] = family;
    else families.push(family);
    localStorage.setItem(this.FAMILIES_KEY, JSON.stringify(families));
  }

  // --- Members Persistence ---

  public async getMembers(familyId: string): Promise<Member[]> {
    const db = await this.initDB();
    if (db) {
      try {
        const tx = db.transaction('members', 'readonly');
        const store = tx.objectStore('members');
        const req = store.getAll();
        const allMembers = await new Promise<Member[]>((res, rej) => {
          req.onsuccess = () => res(req.result || []);
          req.onerror = () => rej(req.error);
        });

        if (allMembers && allMembers.length > 0) {
          const scoped = allMembers.filter(m => m.familyId === familyId);
          const legacy = allMembers.filter(m => !m.familyId);
          // Legacy records without familyId are safe to migrate only when exactly one family exists.
          if (legacy.length) {
            const families = await this.getFamilies();
            if (families.length === 1 && families[0].id === familyId) {
              const txm = db.transaction('members', 'readwrite');
              const storem = txm.objectStore('members');
              legacy.forEach(m => storem.put({ ...m, familyId }));
              await new Promise<void>((res, rej) => { txm.oncomplete = () => res(); txm.onerror = () => rej(txm.error); });
              scoped.push(...legacy.map(m => ({ ...m, familyId })));
            }
          }
          // If IndexedDB has other families but this family has no IDB rows yet,
          // continue to the family-specific localStorage mirror instead of returning
          // an empty set and making a previously saved family appear lost.
          if (scoped.length > 0 || !localStorage.getItem(`${this.LOCAL_BACKUP_PREFIX}members_${familyId}`)) return scoped.map(normalizeMemberRecord);
        }
      } catch (e) {
        console.warn('IDB members fetch error, checking localStorage fallback', e);
      }
    }

    const localKey = `${this.LOCAL_BACKUP_PREFIX}members_${familyId}`;
    const raw = localStorage.getItem(localKey);
    if (raw) {
      try {
        return (JSON.parse(raw) as Partial<Member>[]).map(normalizeMemberRecord);
      } catch (e) {
        console.error('Error parsing local members', e);
      }
    }

    return [];
  }

  public async saveMembers(familyId: string, members: Member[]): Promise<void> {
    const db = await this.initDB();
    let idbSaved = false;
    if (db) {
      try {
        const readTx = db.transaction('members', 'readonly');
        const existingMembers = await new Promise<any[]>((res, rej) => {
          const req = readTx.objectStore('members').getAll();
          req.onsuccess = () => res(req.result || []);
          req.onerror = () => rej(req.error);
        });
        const tx = db.transaction('members', 'readwrite');
        const store = tx.objectStore('members');
        for (const existing of existingMembers) {
          if (existing.familyId === familyId) store.delete(existing.id);
        }
        for (const m of members) store.put({ ...m, familyId });
        await new Promise<void>((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); });
        idbSaved = true;
      } catch (e) {
        console.warn('Failed to save members to IDB; local fallback will be attempted.', e);
      }
    }

    const localKey = `${this.LOCAL_BACKUP_PREFIX}members_${familyId}`;
    try {
      const serialized = JSON.stringify(members);
      localStorage.setItem(localKey, serialized);
      if (localStorage.getItem(localKey) !== serialized) throw new Error('Member persistence verification failed.');
    } catch (e) {
      if (idbSaved) {
        console.warn('Member localStorage mirror could not be updated; IndexedDB copy is intact.', e);
        return;
      }
      console.error('Member save verification failed and no durable fallback succeeded.', e);
      throw e;
    }
  }

  // --- Marriages Persistence ---

  public async getMarriages(familyId: string): Promise<MarriageRecord[]> {
    const db = await this.initDB();
    if (db) {
      try {
        const tx = db.transaction('marriages', 'readonly');
        const store = tx.objectStore('marriages');
        const req = store.getAll();
        const allMarriages = await new Promise<MarriageRecord[]>((res, rej) => {
          req.onsuccess = () => res(req.result || []);
          req.onerror = () => rej(req.error);
        });

        if (allMarriages && allMarriages.length > 0) {
          const scoped = allMarriages.filter(m => m.familyId === familyId);
          const legacy = allMarriages.filter(m => !m.familyId);
          if (legacy.length) {
            const families = await this.getFamilies();
            if (families.length === 1 && families[0].id === familyId) {
              const txm = db.transaction('marriages', 'readwrite');
              const storem = txm.objectStore('marriages');
              legacy.forEach(m => storem.put({ ...m, familyId }));
              await new Promise<void>((res, rej) => { txm.oncomplete = () => res(); txm.onerror = () => rej(txm.error); });
              scoped.push(...legacy.map(m => ({ ...m, familyId })));
            }
          }
          if (scoped.length > 0 || !localStorage.getItem(`${this.LOCAL_BACKUP_PREFIX}marriages_${familyId}`)) return scoped.map(normalizeMarriageRecord);
        }
      } catch (e) {
        console.warn('IDB marriages fetch error, fallback to local', e);
      }
    }

    const localKey = `${this.LOCAL_BACKUP_PREFIX}marriages_${familyId}`;
    const raw = localStorage.getItem(localKey);
    if (raw) {
      try {
        return (JSON.parse(raw) as Partial<MarriageRecord>[]).map(normalizeMarriageRecord);
      } catch (e) {
        console.error('Error parsing local marriages', e);
      }
    }

    return [];
  }

  public async saveMarriages(familyId: string, marriages: MarriageRecord[]): Promise<void> {
    const db = await this.initDB();
    let idbSaved = false;
    if (db) {
      try {
        const readTx = db.transaction('marriages', 'readonly');
        const existingMarriages = await new Promise<any[]>((res, rej) => {
          const req = readTx.objectStore('marriages').getAll();
          req.onsuccess = () => res(req.result || []);
          req.onerror = () => rej(req.error);
        });
        const tx = db.transaction('marriages', 'readwrite');
        const store = tx.objectStore('marriages');
        for (const existing of existingMarriages) {
          if (existing.familyId === familyId) store.delete(existing.id);
        }
        for (const mar of marriages) store.put({ ...mar, familyId });
        await new Promise<void>((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); });
        idbSaved = true;
      } catch (e) {
        console.warn('Failed to save marriages to IDB; local fallback will be attempted.', e);
      }
    }

    const localKey = `${this.LOCAL_BACKUP_PREFIX}marriages_${familyId}`;
    try {
      const serialized = JSON.stringify(marriages);
      localStorage.setItem(localKey, serialized);
      if (localStorage.getItem(localKey) !== serialized) throw new Error('Marriage persistence verification failed.');
    } catch (e) {
      if (idbSaved) {
        console.warn('Marriage localStorage mirror could not be updated; IndexedDB copy is intact.', e);
        return;
      }
      console.error('Marriage save verification failed and no durable fallback succeeded.', e);
      throw e;
    }
  }

  // --- Archive Records Operations ---

  public async getArchiveRecords(familyId: string): Promise<ArchiveRecord[]> {
    const db = await this.initDB();
    if (db && db.objectStoreNames.contains('archive_records')) {
      try {
        const tx = db.transaction('archive_records', 'readonly');
        const store = tx.objectStore('archive_records');
        const index = store.index('relatedFamilyId');
        const req = index.getAll(familyId);
        const results = await new Promise<ArchiveRecord[]>((res, rej) => {
          req.onsuccess = () => res(req.result || []);
          req.onerror = () => rej(req.error);
        });
        if (results && results.length > 0) return results;
      } catch (e) {
        console.warn('IDB getArchiveRecords error', e);
      }
    }

    // Fallback to local storage
    const localKey = `${this.LOCAL_BACKUP_PREFIX}archive_${familyId}`;
    const stored = localStorage.getItem(localKey);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (e) {
        console.error('LocalStorage archive parsing failed', e);
      }
    }
    return [];
  }

  public async saveArchiveRecords(familyId: string, records: ArchiveRecord[]): Promise<void> {
    const db = await this.initDB();
    let idbSaved = false;
    let idbError: unknown = null;
    if (db && db.objectStoreNames.contains('archive_records')) {
      try {
        const tx = db.transaction('archive_records', 'readwrite');
        const store = tx.objectStore('archive_records');
        // Replace the family's archive atomically so deleted/edited records cannot
        // resurrect from a stale local mirror.
        const index = store.index('relatedFamilyId');
        const cursorReq = index.openKeyCursor(IDBKeyRange.only(familyId));
        cursorReq.onsuccess = () => {
          const cursor = cursorReq.result;
          if (cursor) { store.delete(cursor.primaryKey); cursor.continue(); }
          else records.forEach(r => store.put(r));
        };
        await new Promise<void>((res, rej) => {
          tx.oncomplete = () => res();
          tx.onerror = () => rej(tx.error);
          tx.onabort = () => rej(tx.error || new Error('Archive transaction aborted'));
        });
        idbSaved = true;
      } catch (e) {
        idbError = e;
        console.warn('Failed to save archive records to IDB', e);
      }
    }

    const localKey = `${this.LOCAL_BACKUP_PREFIX}archive_${familyId}`;
    let localSaved = false;
    try {
      localStorage.setItem(localKey, JSON.stringify(records));
      localSaved = localStorage.getItem(localKey) === JSON.stringify(records);
    } catch (e) {
      console.warn('LocalStorage quota limit for archive cache', e);
    }

    if (!idbSaved && !localSaved) {
      throw new Error(`Archive persistence failed${idbError instanceof Error ? `: ${idbError.message}` : ''}`);
    }

    // Mandatory read-back verification for the canonical IDs. This catches the
    // exact class of "uploaded but not visible later" failures.
    if (idbSaved) {
      const check = await this.getArchiveRecords(familyId);
      const expected = new Set(records.map(r => r.id));
      const actual = new Set(check.map(r => r.id));
      if (expected.size !== actual.size || [...expected].some(id => !actual.has(id))) {
        throw new Error('Archive persistence verification failed: saved records could not be read back.');
      }
    }
  }

  public async saveArchiveRecord(record: ArchiveRecord): Promise<void> {
    const records = await this.getArchiveRecords(record.relatedFamilyId);
    const idx = records.findIndex(r => r.id === record.id);
    if (idx >= 0) {
      records[idx] = record;
    } else {
      records.unshift(record);
    }
    await this.saveArchiveRecords(record.relatedFamilyId, records);
  }

  public async deleteArchiveRecord(familyId: string, recordId: string): Promise<void> {
    const db = await this.initDB();
    if (db && db.objectStoreNames.contains('archive_records')) {
      try {
        const tx = db.transaction('archive_records', 'readwrite');
        tx.objectStore('archive_records').delete(recordId);
      } catch (e) {
        console.warn('Failed to delete from IDB', e);
      }
    }

    const records = await this.getArchiveRecords(familyId);
    const filtered = records.filter(r => r.id !== recordId);
    await this.saveArchiveRecords(familyId, filtered);
  }

  // --- Recycle Bin / Safe Delete ---

  public async getRecycleBin(familyId: string): Promise<RecycleBinEntry[]> {
    const db = await this.initDB();
    if (db && db.objectStoreNames.contains('recycle_bin')) {
      try {
        const tx = db.transaction('recycle_bin', 'readonly');
        const req = tx.objectStore('recycle_bin').index('familyId').getAll(familyId);
        const rows = await new Promise<RecycleBinEntry[]>((res, rej) => { req.onsuccess = () => res(req.result || []); req.onerror = () => rej(req.error); });
        if (rows) return rows.sort((a,b) => b.deletedAt.localeCompare(a.deletedAt));
      } catch (e) { console.warn('IDB recycle-bin read failed', e); }
    }
    try { return JSON.parse(localStorage.getItem(`${this.LOCAL_BACKUP_PREFIX}recycle_${familyId}`) || '[]'); }
    catch { return []; }
  }

  public async saveRecycleEntry(entry: RecycleBinEntry): Promise<void> {
    const db = await this.initDB();
    if (db && db.objectStoreNames.contains('recycle_bin')) {
      try { const tx = db.transaction('recycle_bin', 'readwrite'); tx.objectStore('recycle_bin').put(entry); await new Promise<void>((res,rej)=>{tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error);}); }
      catch (e) { console.warn('IDB recycle-bin write failed', e); }
    }
    const rows = await this.getRecycleBin(entry.familyId);
    const next = [entry, ...rows.filter(r => r.id !== entry.id)];
    try { localStorage.setItem(`${this.LOCAL_BACKUP_PREFIX}recycle_${entry.familyId}`, JSON.stringify(next)); } catch (e) { console.warn('Recycle-bin local cache full', e); }
  }

  public async deleteRecycleEntry(familyId: string, entryId: string): Promise<void> {
    const db = await this.initDB();
    if (db && db.objectStoreNames.contains('recycle_bin')) {
      try { const tx=db.transaction('recycle_bin','readwrite'); tx.objectStore('recycle_bin').delete(entryId); await new Promise<void>((res,rej)=>{tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error);}); } catch {}
    }
    const rows = await this.getRecycleBin(familyId);
    try { localStorage.setItem(`${this.LOCAL_BACKUP_PREFIX}recycle_${familyId}`, JSON.stringify(rows.filter(r=>r.id!==entryId))); } catch {}
  }

  public async clearRecycleBin(familyId: string): Promise<void> {
    const db = await this.initDB();
    if (db && db.objectStoreNames.contains('recycle_bin')) {
      try { const tx=db.transaction('recycle_bin','readwrite'); const idx=tx.objectStore('recycle_bin').index('familyId'); const req=idx.openKeyCursor(IDBKeyRange.only(familyId)); req.onsuccess=()=>{const c=req.result; if(c){tx.objectStore('recycle_bin').delete(c.primaryKey); c.continue();}}; await new Promise<void>((res,rej)=>{tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error);}); } catch {}
    }
    localStorage.removeItem(`${this.LOCAL_BACKUP_PREFIX}recycle_${familyId}`);
  }

  public async clearAll(): Promise<void> {
    try {
      const db = await this.initDB();
      if (db) {
        const names = Array.from(db.objectStoreNames);
        if (names.length) {
          const tx = db.transaction(names, 'readwrite');
          for (const name of names) tx.objectStore(name).clear();
          await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = rej; });
        }
      }
    } catch (e) { console.warn('IndexedDB clear failed', e); }
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const key = localStorage.key(i);
      if (key && (key.startsWith(this.LOCAL_BACKUP_PREFIX) || key.includes('bongshokotha'))) localStorage.removeItem(key);
    }
    this.setActiveFamilyId('');
  }

  // --- Full Archive Export / Import ---

  public async exportFamilyArchive(
    family: Family,
    members: Member[],
    marriages: MarriageRecord[],
    archiveRecords?: ArchiveRecord[]
  ): Promise<BongshokothaArchive> {
    return {
      format: 'BONGSHOKOTHA_ARCHIVE',
      version: '1.2',
      exportedAt: new Date().toISOString(),
      app: 'Bongshokotha / বংশকথা',
      family,
      members,
      marriages,
      branches: family.branches || [],
      archiveRecords: archiveRecords || []
    };
  }

  public validateArchive(data: unknown): { isValid: boolean; error?: string } {
    if (!data || typeof data !== 'object') {
      return { isValid: false, error: 'Invalid JSON archive format' };
    }
    const archive = data as Partial<BongshokothaArchive>;
    if (archive.format !== 'BONGSHOKOTHA_ARCHIVE') {
      return { isValid: false, error: 'File is not a valid Bongshokotha archive (.bkf / .json)' };
    }
    if (!archive.family || !archive.family.id || !archive.family.name) {
      return { isValid: false, error: 'Archive is missing required Family metadata' };
    }
    if (!Array.isArray(archive.members)) {
      return { isValid: false, error: 'Archive members list is invalid or missing' };
    }
    if (!Array.isArray(archive.marriages)) {
      return { isValid: false, error: 'Archive marriage records list is missing' };
    }
    return { isValid: true };
  }

  /** Delete one family space and only records scoped to that family. */
  public async deleteFamilySpace(familyId: string): Promise<void> {
    const families = await this.getFamilies();
    if (!families.some(f => f.id === familyId)) throw new Error('Family space not found.');
    // Clear scoped records using the same persistence paths used by normal edits.
    await this.saveMembers(familyId, []);
    await this.saveMarriages(familyId, []);
    await this.saveArchiveRecords(familyId, []);
    await this.clearRecycleBin(familyId);
    const db = await this.initDB();
    if (db && db.objectStoreNames.contains('families')) {
      const tx = db.transaction('families', 'readwrite');
      tx.objectStore('families').delete(familyId);
      await new Promise<void>((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error); });
    }
    localStorage.removeItem(`${this.LOCAL_BACKUP_PREFIX}members_${familyId}`);
    localStorage.removeItem(`${this.LOCAL_BACKUP_PREFIX}marriages_${familyId}`);
    localStorage.removeItem(`${this.LOCAL_BACKUP_PREFIX}archive_${familyId}`);
    localStorage.removeItem(`${this.LOCAL_BACKUP_PREFIX}recycle_${familyId}`);
    localStorage.setItem(this.FAMILIES_KEY, JSON.stringify(families.filter(f => f.id !== familyId)));
    if (this.getActiveFamilyId() === familyId) this.setActiveFamilyId('');
  }

  /**
   * Reset all data to factory empty state (Protected by explicit user confirmation in UI)
   */
  public async factoryReset(): Promise<void> {
    const db = await this.initDB();
    if (db) {
      const stores = ['families', 'members', 'marriages'];
      if (db.objectStoreNames.contains('archive_records')) {
        stores.push('archive_records');
      }
      const tx = db.transaction(stores, 'readwrite');
      stores.forEach(s => {
        try {
          tx.objectStore(s).clear();
        } catch (e) {
          console.warn(`Error clearing store ${s}:`, e);
        }
      });
    }
    localStorage.clear();
  }

  /**
   * Clear all members and marriages of a specific family
   */
  public async clearFamilyMembers(familyId: string): Promise<void> {
    await this.saveMembers(familyId, []);
    await this.saveMarriages(familyId, []);
  }
}

export const storage = new StorageEngine();
