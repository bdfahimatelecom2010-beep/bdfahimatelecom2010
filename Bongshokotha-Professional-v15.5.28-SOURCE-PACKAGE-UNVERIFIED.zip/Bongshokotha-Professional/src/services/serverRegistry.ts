export interface ServerProfile {
  id: string;
  nameBn: string;
  nameEn: string;
  endpoint: string;
  loginPath?: string;
  loginUrl?: string;
  provider?: 'bongshokotha' | 'self_hosted' | 'neon' | 'supabase' | 'firebase' | 'appwrite' | 'custom';
  token?: string;
  enabled: boolean;
  lastCheckedAt?: string;
  status?: 'online' | 'offline' | 'unknown';
  version?: string;
}

const STORAGE_KEY = 'bongshokotha_server_profiles_v2';
const ACTIVE_KEY = 'bongshokotha_active_server_v2';

/**
 * Server catalogue shown to Owner/Super Admin. The first-party BONGSHOKOTHA
 * entries are login-ready; external providers open their official console login.
 * A provider is not treated as a BONGSHOKOTHA sync endpoint until an endpoint is configured.
 */
const DEFAULT_SERVERS: ServerProfile[] = [
  { id: 'local', nameBn: 'এই কম্পিউটারের বংশকথা সার্ভার', nameEn: 'This Computer — BONGSHOKOTHA Server', endpoint: 'http://localhost:8787', loginPath: '/login', provider: 'bongshokotha', enabled: true },
  { id: 'lan', nameBn: 'লোকাল নেটওয়ার্কের বংশকথা সার্ভার', nameEn: 'Local Network BONGSHOKOTHA Server', endpoint: '', loginPath: '/login', provider: 'self_hosted', enabled: true },
  { id: 'self_hosted', nameBn: 'নিজস্ব / Self-hosted BONGSHOKOTHA Server', nameEn: 'Self-hosted BONGSHOKOTHA Server', endpoint: '', loginPath: '/login', provider: 'self_hosted', enabled: true },
  { id: 'neon', nameBn: 'Neon PostgreSQL', nameEn: 'Neon PostgreSQL', endpoint: '', loginUrl: 'https://console.neon.tech/sign-in', provider: 'neon', enabled: true },
  { id: 'supabase', nameBn: 'Supabase', nameEn: 'Supabase', endpoint: '', loginUrl: 'https://supabase.com/dashboard/sign-in', provider: 'supabase', enabled: true },
  { id: 'firebase', nameBn: 'Firebase', nameEn: 'Firebase', endpoint: '', loginUrl: 'https://console.firebase.google.com/', provider: 'firebase', enabled: true },
  { id: 'appwrite', nameBn: 'Appwrite', nameEn: 'Appwrite', endpoint: '', loginUrl: 'https://cloud.appwrite.io/console/login', provider: 'appwrite', enabled: true },
  { id: 'custom', nameBn: 'কাস্টম BONGSHOKOTHA সার্ভার', nameEn: 'Custom BONGSHOKOTHA Server', endpoint: '', loginPath: '/login', provider: 'custom', enabled: true }
];

export function normalizeServerEndpoint(value?: string): string { return String(value || '').trim().replace(/\/$/, ''); }
export function getServerProfiles(): ServerProfile[] {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || localStorage.getItem('bongshokotha_server_profiles_v1') || 'null');
    if (Array.isArray(saved)) {
      const byId = new Map(saved.map((x: ServerProfile) => [x.id, x]));
      return DEFAULT_SERVERS.map(d => ({ ...d, ...(byId.get(d.id) || {}) }));
    }
  } catch {}
  return DEFAULT_SERVERS.map(x => ({ ...x }));
}
export function saveServerProfiles(profiles: ServerProfile[]): void { localStorage.setItem(STORAGE_KEY, JSON.stringify(profiles)); }
export function getActiveServerId(): string { return localStorage.getItem(ACTIVE_KEY) || 'local'; }
export function setActiveServerId(id: string): void { localStorage.setItem(ACTIVE_KEY, id); }
export function getActiveServerProfile(): ServerProfile | undefined { return getServerProfiles().find(profile => profile.id === getActiveServerId()); }
export function getServerLoginUrl(profile: ServerProfile): string | undefined {
  if (profile.loginUrl) return profile.loginUrl;
  const endpoint = normalizeServerEndpoint(profile.endpoint);
  if (!endpoint || !profile.loginPath) return undefined;
  try { const u = new URL(`${endpoint}${profile.loginPath}`); u.searchParams.set('origin', window.location.origin); u.searchParams.set('serverId', profile.id); return u.toString(); } catch { return `${endpoint}${profile.loginPath}`; }
}

export async function testServer(profile: ServerProfile): Promise<{ ok: boolean; version?: string; message: string }> {
  const endpoint = normalizeServerEndpoint(profile.endpoint);
  if (!endpoint) return { ok: false, message: 'এই সার্ভারের BONGSHOKOTHA endpoint এখনো দেওয়া হয়নি। আগে Login Page/Server URL নির্ধারণ করুন।' };
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 7000);
  try {
    const res = await fetch(`${endpoint}/health`, { headers: profile.token ? { Authorization: `Bearer ${profile.token}` } : {}, signal: controller.signal });
    const body = await res.json().catch(() => ({}));
    if (!res.ok || body.ok !== true) return { ok: false, message: `সার্ভার সাড়া দিয়েছে, কিন্তু Health check ব্যর্থ (${res.status})।` };
    return { ok: true, version: body.appVersion, message: 'সার্ভার অনলাইন ও ব্যবহারযোগ্য।' };
  } catch (e) { return { ok: false, message: e instanceof Error ? e.message : 'সার্ভারে সংযোগ করা যায়নি।' }; }
  finally { window.clearTimeout(timer); }
}
export function getDefaultServerProfiles(): ServerProfile[] { return DEFAULT_SERVERS.map(x => ({ ...x })); }
