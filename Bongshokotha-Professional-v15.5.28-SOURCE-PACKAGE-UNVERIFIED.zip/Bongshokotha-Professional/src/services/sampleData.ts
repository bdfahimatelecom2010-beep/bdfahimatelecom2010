/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Authentic Verified Sample Genealogy Dataset
 * 
 * "Chowdhury Bongsho of Sylhet / সিলেট চৌধুরী বংশ"
 * Demonstrates:
 * - 4 full generations
 * - Distinct branches (Borotaraf & Chhototaraf)
 * - Multiple marriages with separate children (Tariqul Islam Chowdhury)
 * - In-marrying spouse biological lineage preservation
 * - Separate NID and Birth Registration fields
 * - Authentic Bengali calendar dates
 */

import { Family, Member, MarriageRecord } from '../types/genealogy';

export const SAMPLE_FAMILY_ID = 'fam-chowdhury-sylhet-001';

export const SAMPLE_FAMILY: Family = {
  id: SAMPLE_FAMILY_ID,
  name: 'Chowdhury Bongsho of Sylhet',
  banglaName: 'সিলেট চৌধুরী বংশ',
  description: 'ঐতিহ্যবাহী সিলেট অঞ্চলের একটি সুপ্রাচীন সম্ভ্রান্ত বংশানুক্রমিক পারিবারিক ইতিহাস নথি।',
  crestUrl: '',
  rootAncestorId: 'mem-chowdhury-001',
  createdAt: '2024-01-01T00:00:00.000Z',
  updatedAt: new Date().toISOString(),
  branches: [
    {
      id: 'branch-borotaraf',
      name: 'Borotaraf (Elder Branch)',
      banglaName: 'বড়তরফ শাখা',
      color: '#15803d', // emerald
      description: 'খান বাহাদুর আব্দুল লতিফ চৌধুরীর জ্যেষ্ঠ পুত্র ব্যারিস্টার আলতাফ হোসেন চৌধুরীর বংশধারা।'
    },
    {
      id: 'branch-chhototaraf',
      name: 'Chhototaraf (Younger Branch)',
      banglaName: 'ছোটতরফ শাখা',
      color: '#0369a1', // sky/blue
      description: 'কনিষ্ঠ পুত্র অধ্যাপক আনিসুর রহমান চৌধুরীর বংশধারা।'
    },
    {
      id: 'branch-matriarchal',
      name: 'Banu Matriarchal Lineage',
      banglaName: 'বানু মাতৃক ধারা',
      color: '#a21caf', // fuchsia
      description: 'বিবাহসূত্রে যুক্ত পরিবারবর্গের মূল বংশপরিচয় সংরক্ষণ ধারা।'
    }
  ],
  settings: {
    language: 'bn',
    theme: 'parchment',
    defaultBranchId: 'branch-borotaraf',
    enableBengaliCalendar: true,
    enableHijriCalendar: true,
    enablePrivacyMasking: false
  },
  backupHistory: [
    {
      id: 'bk-initial-seed',
      timestamp: '2024-01-01T00:00:00.000Z',
      label: 'প্রাথমিক পারিবারিক সনাক্তকরণ ব্যাকআপ',
      memberCount: 11,
      marriageCount: 5,
      checksum: 'sha-chw-initial'
    }
  ]
};

export const SAMPLE_MEMBERS: Member[] = [
  // --- GENERATION 1 ---
  {
    id: 'mem-chowdhury-001',
    serialNumber: 'BK-001',
    birthOrder: 1,
    fullName: 'Khan Bahadur Abdul Latif Chowdhury',
    banglaName: 'খান বাহাদুর আব্দুল লতিফ চৌধুরী',
    englishName: 'Khan Bahadur Abdul Latif Chowdhury',
    nickname: 'লতিফ মিয়া',
    gender: 'male',
    isLiving: false,
    birthOrigin: 'born_in_family',
    marriageOrigin: false,
    branchId: 'branch-borotaraf',
    biography: 'সিলেটের বিশিষ্ট জমিদার, শিক্ষানুরাগী ও সমাজসেবক। ব্রিটিশ আমলে খান বাহাদুর খেতাবে ভূষিত হন।',
    importantInformation: '১৯৩৬ সালে নিজ গ্রামে বহুমুখী উচ্চ বিদ্যালয় প্রতিষ্ঠা করেন।',
    birth: {
      date: {
        year: 1888,
        month: 4,
        day: 14,
        precision: 'exact',
        banglaDate: { day: 1, month: 'বৈশাখ', year: 1295 },
        notes: 'পহেলা বৈশাখ ১২৯৫ বঙ্গাব্দে শুভ জন্ম'
      },
      place: {
        village: 'গোয়াইনঘাট জমিদার বাড়ি',
        postOffice: 'গোয়াইনঘাট',
        upazila: 'গোয়াইনঘাট',
        district: 'সিলেট',
        division: 'সিলেট',
        country: 'বাংলাদেশ'
      }
    },
    death: {
      isDeceased: true,
      date: {
        year: 1964,
        month: 11,
        day: 12,
        precision: 'exact',
        banglaDate: { day: 27, month: 'কার্তিক', year: 1371 }
      },
      place: {
        village: 'দরগাহ মহল্লা',
        upazila: 'সিলেট সদর',
        district: 'সিলেট',
        division: 'সিলেট',
        country: 'বাংলাদেশ'
      },
      burialPlace: 'হযরত শাহজালাল (রহ.) মাজার সংলগ্ন পারিবারিক কবরস্থান',
      memorialInfo: 'সিলেট কেন্দ্রীয় লাইব্রেরিতে নামফলক সংরক্ষিত।'
    },
    identityDocs: {
      nidNumber: '',
      birthRegistrationNumber: '',
      passportNumber: 'BRIT-PASSPORT-1928-SYL',
      otherId: 'জমিদারি খতিয়ান নং ১২৮/১৯০৫',
      verificationStatus: 'verified'
    },
    marriageIds: ['mar-001'],
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'mem-chowdhury-002',
    serialNumber: 'BK-002',
    birthOrder: 1,
    fullName: 'Begum Rokeya Banu',
    banglaName: 'বেগম রোকেয়া বানু',
    englishName: 'Begum Rokeya Banu',
    nickname: 'রোকি বেগম',
    gender: 'female',
    isLiving: false,
    birthOrigin: 'joined_by_marriage',
    marriageOrigin: true,
    originalLineageNote: 'মৌলভীবাজারের কুলাউড়া নবাব পরিবারের সৈয়দ বংশোদ্ভূত কন্যা। পিতা: সৈয়দ মোবারক আলী।',
    branchId: 'branch-matriarchal',
    biography: 'মহীয়সী নারী ও পারিবারিক সংহতির অভিভাবক।',
    birth: {
      date: {
        year: 1895,
        month: null,
        day: null,
        precision: 'approximate',
        notes: 'আনুমানিক ১৮৯৫ খ্রিষ্টাব্দ'
      },
      place: {
        village: 'পৃথিমপাশা',
        upazila: 'কুলাউড়া',
        district: 'মৌলভীবাজার',
        division: 'সিলেট',
        country: 'বাংলাদেশ'
      }
    },
    death: {
      isDeceased: true,
      date: {
        year: 1978,
        month: 3,
        day: 20,
        precision: 'exact'
      },
      burialPlace: 'পারিবারিক গোরস্থান, গোয়াইনঘাট'
    },
    identityDocs: {
      nidNumber: '',
      birthRegistrationNumber: '',
      verificationStatus: 'verified'
    },
    marriageIds: ['mar-001'],
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // --- GENERATION 2 ---
  {
    id: 'mem-chowdhury-003',
    serialNumber: 'BK-003',
    birthOrder: 1,
    fullName: 'Barrister Altaf Hossain Chowdhury',
    banglaName: 'ব্যারিস্টার আলতাফ হোসেন চৌধুরী',
    englishName: 'Barrister Altaf Hossain Chowdhury',
    gender: 'male',
    isLiving: false,
    birthOrigin: 'born_in_family',
    marriageOrigin: false,
    branchId: 'branch-borotaraf',
    biography: 'লন্ডনের লিঙ্কনস ইন থেকে বার-অ্যাট-ল সম্পন্ন করেন। সুপ্রিম কোর্টের প্রবীণ আইনজীবী ছিলেন।',
    birth: {
      date: {
        year: 1920,
        month: 8,
        day: 15,
        precision: 'exact',
        banglaDate: { day: 31, month: 'শ্রাবণ', year: 1327 }
      },
      place: {
        village: 'গোয়াইনঘাট',
        upazila: 'গোয়াইনঘাট',
        district: 'সিলেট',
        division: 'সিলেট',
        country: 'বাংলাদেশ'
      }
    },
    death: {
      isDeceased: true,
      date: {
        year: 1998,
        month: 6,
        day: 10,
        precision: 'exact'
      },
      burialPlace: 'বনানী কবরস্থান, ঢাকা'
    },
    identityDocs: {
      nidNumber: '19209112345678901',
      birthRegistrationNumber: '19209112345000012',
      verificationStatus: 'verified'
    },
    fatherId: 'mem-chowdhury-001',
    motherId: 'mem-chowdhury-002',
    marriageIds: ['mar-002'],
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'mem-chowdhury-004',
    serialNumber: 'BK-004',
    birthOrder: 1,
    fullName: 'Syeda Sultana Khatun',
    banglaName: 'সৈয়দা সুলতানা খাতুন',
    englishName: 'Syeda Sultana Khatun',
    gender: 'female',
    isLiving: false,
    birthOrigin: 'joined_by_marriage',
    marriageOrigin: true,
    originalLineageNote: 'হবিগঞ্জের তরফ পরগণার সৈয়দ বংশীয়। পিতা: সৈয়দ এনায়েত উল্লাহ।',
    branchId: 'branch-matriarchal',
    birth: {
      date: {
        year: 1928,
        month: 2,
        day: 14,
        precision: 'exact'
      },
      place: {
        upazila: 'মাধবপুর',
        district: 'হবিগঞ্জ',
        division: 'সিলেট',
        country: 'বাংলাদেশ'
      }
    },
    death: {
      isDeceased: true,
      date: {
        year: 2012,
        month: 9,
        day: 4,
        precision: 'exact'
      },
      burialPlace: 'বনানী কবরস্থান, ঢাকা'
    },
    identityDocs: {
      nidNumber: '19289112345678902',
      birthRegistrationNumber: '19289112345000015',
      verificationStatus: 'verified'
    },
    marriageIds: ['mar-002'],
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'mem-chowdhury-005',
    serialNumber: 'BK-005',
    birthOrder: 2,
    fullName: 'Prof. Anisur Rahman Chowdhury',
    banglaName: 'অধ্যাপক আনিসুর রহমান চৌধুরী',
    englishName: 'Prof. Anisur Rahman Chowdhury',
    gender: 'male',
    isLiving: false,
    birthOrigin: 'born_in_family',
    marriageOrigin: false,
    branchId: 'branch-chhototaraf',
    biography: 'ঢাকা বিশ্ববিদ্যালয়ের রসায়ন বিভাগের সাবেক চেয়ারম্যান ও মুক্তিযোদ্ধা।',
    birth: {
      date: {
        year: 1925,
        month: 12,
        day: 1,
        precision: 'exact'
      },
      place: {
        upazila: 'গোয়াইনঘাট',
        district: 'সিলেট',
        division: 'সিলেট',
        country: 'বাংলাদেশ'
      }
    },
    death: {
      isDeceased: true,
      date: {
        year: 2005,
        month: 5,
        day: 18,
        precision: 'exact'
      },
      burialPlace: 'মিরপুর শহীদ বুদ্ধিজীবী কবরস্থান'
    },
    identityDocs: {
      nidNumber: '19259112345678903',
      birthRegistrationNumber: '19259112345000018',
      verificationStatus: 'verified'
    },
    fatherId: 'mem-chowdhury-001',
    motherId: 'mem-chowdhury-002',
    marriageIds: ['mar-003'],
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'mem-chowdhury-006',
    serialNumber: 'BK-006',
    birthOrder: 1,
    fullName: 'Dr. Nazma Begum',
    banglaName: 'ড. নাজমা বেগম',
    englishName: 'Dr. Nazma Begum',
    gender: 'female',
    isLiving: true,
    birthOrigin: 'joined_by_marriage',
    marriageOrigin: true,
    originalLineageNote: 'চট্টগ্রামের চন্দনাইশের কাজী বংশের কন্যা। পিতা: কাজী মোখলেসুর রহমান।',
    branchId: 'branch-chhototaraf',
    birth: {
      date: {
        year: 1935,
        month: 10,
        day: 5,
        precision: 'exact'
      },
      place: {
        upazila: 'চন্দনাইশ',
        district: 'চট্টগ্রাম',
        division: 'চট্টগ্রাম',
        country: 'বাংলাদেশ'
      }
    },
    death: {
      isDeceased: false
    },
    identityDocs: {
      nidNumber: '19351512345678904',
      birthRegistrationNumber: '19351512345000021',
      verificationStatus: 'verified'
    },
    marriageIds: ['mar-003'],
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // --- GENERATION 3 ---
  // Demonstrating Multiple Marriage: Tariqul Islam Chowdhury (Married twice)
  {
    id: 'mem-chowdhury-007',
    serialNumber: 'BK-007',
    birthOrder: 1,
    fullName: 'Tariqul Islam Chowdhury',
    banglaName: 'তারিকুল ইসলাম চৌধুরী',
    englishName: 'Tariqul Islam Chowdhury',
    gender: 'male',
    isLiving: true,
    birthOrigin: 'born_in_family',
    marriageOrigin: false,
    branchId: 'branch-borotaraf',
    biography: 'সিভিল ইঞ্জিনিয়ার ও ব্যবসায়ী। পারিবারিক ঐতিহ্য সংরক্ষণে উদ্যোগী।',
    birth: {
      date: {
        year: 1956,
        month: 3,
        day: 26,
        precision: 'exact',
        banglaDate: { day: 12, month: 'চৈত্র', year: 1362 }
      },
      place: {
        village: 'ধানমন্ডি',
        district: 'ঢাকা',
        division: 'ঢাকা',
        country: 'বাংলাদেশ'
      }
    },
    death: { isDeceased: false },
    identityDocs: {
      nidNumber: '19562612345678905',
      birthRegistrationNumber: '19562612345000030',
      verificationStatus: 'verified'
    },
    fatherId: 'mem-chowdhury-003',
    motherId: 'mem-chowdhury-004',
    marriageIds: ['mar-004', 'mar-005'], // Multiple marriages
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'mem-chowdhury-008',
    serialNumber: 'BK-008',
    birthOrder: 1,
    fullName: 'Nilufar Yasmin (First Wife - Late)',
    banglaName: 'নীলুফার ইয়াসমিন (প্রথমা স্ত্রী - মরহুমা)',
    englishName: 'Nilufar Yasmin',
    gender: 'female',
    isLiving: false,
    birthOrigin: 'joined_by_marriage',
    marriageOrigin: true,
    originalLineageNote: 'কুমিল্লার মজুমদার বংশের কন্যা। পিতা: আকবর আলী মজুমদার।',
    branchId: 'branch-borotaraf',
    birth: {
      date: {
        year: 1960,
        month: 7,
        day: 10,
        precision: 'exact'
      },
      place: {
        district: 'কুমিল্লা',
        division: 'চট্টগ্রাম',
        country: 'বাংলাদেশ'
      }
    },
    death: {
      isDeceased: true,
      date: {
        year: 1999,
        month: 4,
        day: 12,
        precision: 'exact'
      },
      burialPlace: 'আজিমপুর কবরস্থান, ঢাকা'
    },
    identityDocs: {
      nidNumber: '19601912345678906',
      birthRegistrationNumber: '19601912345000033',
      verificationStatus: 'verified'
    },
    marriageIds: ['mar-004'],
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'mem-chowdhury-009',
    serialNumber: 'BK-009',
    birthOrder: 1,
    fullName: 'Shirin Akhter (Second Wife)',
    banglaName: 'শিরীন আক্তার (দ্বিতীয়া স্ত্রী)',
    englishName: 'Shirin Akhter',
    gender: 'female',
    isLiving: true,
    birthOrigin: 'joined_by_marriage',
    marriageOrigin: true,
    originalLineageNote: 'রাজশাহীর শিকদার পরিবারের কন্যা। পিতা: আমিনুল হক শিকদার।',
    branchId: 'branch-borotaraf',
    birth: {
      date: {
        year: 1970,
        month: 9,
        day: 22,
        precision: 'exact'
      },
      place: {
        district: 'রাজশাহী',
        division: 'রাজশাহী',
        country: 'বাংলাদেশ'
      }
    },
    death: { isDeceased: false },
    identityDocs: {
      nidNumber: '19708112345678907',
      birthRegistrationNumber: '19708112345000041',
      verificationStatus: 'verified'
    },
    marriageIds: ['mar-005'],
    isUnmarried: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // Gen 3: Chhototaraf offspring
  {
    id: 'mem-chowdhury-010',
    serialNumber: 'BK-010',
    birthOrder: 1,
    fullName: 'Asifur Rahman Chowdhury',
    banglaName: 'আসিফুর রহমান চৌধুরী',
    englishName: 'Asifur Rahman Chowdhury',
    gender: 'male',
    isLiving: true,
    birthOrigin: 'born_in_family',
    marriageOrigin: false,
    branchId: 'branch-chhototaraf',
    biography: 'সফটওয়্যার স্থপতি ও প্রযুক্তি গবেষক। বংশকথা সিস্টেমের সমন্বয়ক।',
    birth: {
      date: {
        year: 1968,
        month: 5,
        day: 19,
        precision: 'exact'
      },
      place: {
        district: 'ঢাকা',
        division: 'ঢাকা',
        country: 'বাংলাদেশ'
      }
    },
    death: { isDeceased: false },
    identityDocs: {
      nidNumber: '19682612345678908',
      birthRegistrationNumber: '19682612345000044',
      verificationStatus: 'verified'
    },
    fatherId: 'mem-chowdhury-005',
    motherId: 'mem-chowdhury-006',
    marriageIds: [],
    isUnmarried: true, // Unmarried demonstration rule!
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // --- GENERATION 4 ---
  // Child from Marriage 1 (Nilufar Yasmin)
  {
    id: 'mem-chowdhury-011',
    serialNumber: 'BK-011',
    birthOrder: 1,
    fullName: 'Samiur Rahman Chowdhury',
    banglaName: 'সামিউর রহমান চৌধুরী',
    englishName: 'Samiur Rahman Chowdhury',
    gender: 'male',
    isLiving: true,
    birthOrigin: 'born_in_family',
    marriageOrigin: false,
    branchId: 'branch-borotaraf',
    biography: 'প্রকৌশলী ও গবেষক।',
    birth: {
      date: {
        year: 1994,
        month: 11,
        day: 14,
        precision: 'exact',
        banglaDate: { day: 29, month: 'কার্তিক', year: 1401 }
      },
      place: {
        village: 'উত্তরা',
        district: 'ঢাকা',
        division: 'ঢাকা',
        country: 'বাংলাদেশ'
      }
    },
    death: { isDeceased: false },
    identityDocs: {
      nidNumber: '19942612345678909',
      birthRegistrationNumber: '19942612345000055',
      verificationStatus: 'verified'
    },
    fatherId: 'mem-chowdhury-007',
    motherId: 'mem-chowdhury-008', // Mother is Nilufar Yasmin
    marriageIds: [],
    isUnmarried: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // Child from Marriage 2 (Shirin Akhter)
  {
    id: 'mem-chowdhury-012',
    serialNumber: 'BK-012',
    birthOrder: 1,
    fullName: 'Maisha Chowdhury',
    banglaName: 'মাইশা চৌধুরী',
    englishName: 'Maisha Chowdhury',
    gender: 'female',
    isLiving: true,
    birthOrigin: 'born_in_family',
    marriageOrigin: false,
    branchId: 'branch-borotaraf',
    biography: 'ঢাকা বিশ্ববিদ্যালয়ের শিক্ষার্থী।',
    birth: {
      date: {
        year: 2003,
        month: 6,
        day: 8,
        precision: 'exact',
        banglaDate: { day: 25, month: 'জ্যৈষ্ঠ', year: 1410 }
      },
      place: {
        district: 'ঢাকা',
        division: 'ঢাকা',
        country: 'বাংলাদেশ'
      }
    },
    death: { isDeceased: false },
    identityDocs: {
      nidNumber: '20032612345678910',
      birthRegistrationNumber: '20032612345000062',
      verificationStatus: 'verified'
    },
    fatherId: 'mem-chowdhury-007',
    motherId: 'mem-chowdhury-009', // Mother is Shirin Akhter
    marriageIds: [],
    isUnmarried: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  }
];

export const SAMPLE_MARRIAGES: MarriageRecord[] = [
  // Marriage 1: Khan Bahadur Abdul Latif Chowdhury & Begum Rokeya Banu
  {
    id: 'mar-001',
    serialNumber: 'MR-001',
    husbandId: 'mem-chowdhury-001',
    wifeId: 'mem-chowdhury-002',
    marriageDate: {
      year: 1915,
      month: null,
      day: null,
      precision: 'approximate',
      notes: 'আনুমানিক ১৯১৫ খ্রিষ্টাব্দ'
    },
    marriagePlace: {
      village: 'পৃথিমপাশা জমিদার বাড়ি',
      upazila: 'কুলাউড়া',
      district: 'মৌলভীবাজার',
      country: 'বাংলাদেশ'
    },
    status: 'widowed',
    childrenIds: ['mem-chowdhury-003', 'mem-chowdhury-005'],
    marriageNotes: 'ঐতিহাসিক কুলাউড়া নবাব পরিবারের সঙ্গে বৈবাহিক মিতালী।',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // Marriage 2: Barrister Altaf Hossain Chowdhury & Syeda Sultana Khatun
  {
    id: 'mar-002',
    serialNumber: 'MR-002',
    husbandId: 'mem-chowdhury-003',
    wifeId: 'mem-chowdhury-004',
    marriageDate: {
      year: 1950,
      month: 1,
      day: 20,
      precision: 'exact'
    },
    marriagePlace: {
      district: 'হবিগঞ্জ',
      country: 'বাংলাদেশ'
    },
    status: 'widowed',
    childrenIds: ['mem-chowdhury-007'],
    marriageNotes: 'তরফ পরগণার সৈয়দ পরিবারের সাথে দ্বিতীয় বন্ধন।',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // Marriage 3: Prof. Anisur Rahman Chowdhury & Dr. Nazma Begum
  {
    id: 'mar-003',
    serialNumber: 'MR-003',
    husbandId: 'mem-chowdhury-005',
    wifeId: 'mem-chowdhury-006',
    marriageDate: {
      year: 1965,
      month: 7,
      day: 14,
      precision: 'exact'
    },
    marriagePlace: {
      district: 'চট্টগ্রাম',
      country: 'বাংলাদেশ'
    },
    status: 'widowed',
    childrenIds: ['mem-chowdhury-010'],
    marriageNotes: 'চট্টগ্রাম কাজী পরিবারের সাথে শুভ পরিণয়।',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // Marriage 4 (Tariqul's 1st Marriage): Tariqul Islam Chowdhury & Nilufar Yasmin
  {
    id: 'mar-004',
    serialNumber: 'MR-004',
    husbandId: 'mem-chowdhury-007',
    wifeId: 'mem-chowdhury-008',
    marriageDate: {
      year: 1988,
      month: 12,
      day: 5,
      precision: 'exact'
    },
    marriagePlace: {
      district: 'কুমিল্লা',
      country: 'বাংলাদেশ'
    },
    status: 'widowed',
    childrenIds: ['mem-chowdhury-011'], // Only Samiur is born to this marriage!
    marriageNotes: 'প্রথমা স্ত্রীর আকস্মিক মৃত্যু ১৯৯৯ সালে।',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  },

  // Marriage 5 (Tariqul's 2nd Marriage): Tariqul Islam Chowdhury & Shirin Akhter
  {
    id: 'mar-005',
    serialNumber: 'MR-005',
    husbandId: 'mem-chowdhury-007',
    wifeId: 'mem-chowdhury-009',
    marriageDate: {
      year: 2001,
      month: 2,
      day: 18,
      precision: 'exact'
    },
    marriagePlace: {
      district: 'ঢাকা',
      country: 'বাংলাদেশ'
    },
    status: 'current',
    childrenIds: ['mem-chowdhury-012'], // Only Maisha is born to this marriage!
    marriageNotes: 'দ্বিতীয় বিবাহ। সন্তানদের পারস্পরিক অধিকার ও স্বতন্ত্র পরিচয় সুরক্ষিত।',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z'
  }
];
