import type { Family, Member, MarriageRecord, ArchiveRecord } from '../types/genealogy';
import type { BongshokothaArchive } from './storage';

declare global {
  interface Window {
    google?: any;
  }
}

const CLIENT_ID = (import.meta as any).env?.VITE_GOOGLE_CLIENT_ID || '';
const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.appdata';
let tokenClient: any = null;
let accessToken = '';

function loadGis(): Promise<void> {
  if (window.google?.accounts?.oauth2) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const existing = document.querySelector('script[data-google-gis]');
    if (existing) { existing.addEventListener('load', () => resolve()); existing.addEventListener('error', () => reject(new Error('Google Identity Services could not load.'))); return; }
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client'; script.async = true; script.defer = true; script.dataset.googleGis = '1';
    script.onload = () => resolve(); script.onerror = () => reject(new Error('Google Identity Services could not load.'));
    document.head.appendChild(script);
  });
}

export function isGoogleDriveConfigured(): boolean { return Boolean(CLIENT_ID); }

export async function connectGoogleDrive(prompt: 'consent' | 'none' = 'consent', loginHint?: string): Promise<{ email?: string }> {
  if (!CLIENT_ID) throw new Error('VITE_GOOGLE_CLIENT_ID is not configured.');
  await loadGis();
  return new Promise((resolve, reject) => {
    tokenClient = window.google.accounts.oauth2.initTokenClient({
      client_id: CLIENT_ID,
      scope: DRIVE_SCOPE,
      callback: async (response: any) => {
        if (response.error) { reject(new Error(response.error)); return; }
        accessToken = response.access_token;
        try {
          const profile = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: `Bearer ${accessToken}` } });
          const data = await profile.json();
          resolve({ email: data.email });
        } catch { resolve({}); }
      }
    });
    tokenClient.requestAccessToken({ prompt, login_hint: loginHint?.trim() || undefined });
  });
}

export function disconnectGoogleDrive(): void {
  if (accessToken && window.google?.accounts?.oauth2?.revoke) window.google.accounts.oauth2.revoke(accessToken, () => undefined);
  accessToken = '';
}

async function ensureToken(silent = false, loginHint?: string): Promise<string> {
  if (accessToken) return accessToken;
  await connectGoogleDrive(silent ? 'none' : 'consent', loginHint);
  if (!accessToken) throw new Error('Google authorization did not return an access token.');
  return accessToken;
}

export async function backupFamilyToGoogleDrive(family: Family, members: Member[], marriages: MarriageRecord[], archiveRecords: ArchiveRecord[], silent = false, loginHint?: string): Promise<{ fileId: string }> {
  const token = await ensureToken(silent, loginHint || family.settings?.googleAccountEmail);
  const archive: BongshokothaArchive = { format: 'BONGSHOKOTHA_ARCHIVE', version: '1.2', exportedAt: new Date().toISOString(), app: 'Bongshokotha / বংশকথা', family, members, marriages, branches: family.branches || [], archiveRecords };
  const name = `BONGSHOKOTHA-${family.id}.bkf.json`;
  const body = JSON.stringify(archive);
  const search = await fetch(`https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(`name='${name.replace(/'/g, "\\'")}' and 'appDataFolder' in parents and trashed=false`)}&spaces=appDataFolder&fields=files(id,name)`, { headers: { Authorization: `Bearer ${token}` } });
  if (!search.ok) throw new Error(`Google Drive lookup failed (${search.status}).`);
  const found = await search.json();
  const existingId = found.files?.[0]?.id;
  if (existingId) {
    const res = await fetch(`https://www.googleapis.com/upload/drive/v3/files/${existingId}?uploadType=media&fields=id`, { method:'PATCH', headers:{ Authorization:`Bearer ${token}`, 'Content-Type':'application/json' }, body });
    if (!res.ok) throw new Error(`Google Drive backup update failed (${res.status}).`);
    return await res.json();
  }
  const metadata = { name, mimeType: 'application/json', parents: ['appDataFolder'] };
  const boundary = `bongshokotha_${Date.now()}`;
  const multipart = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n${body}\r\n--${boundary}--`;
  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id', { method:'POST', headers:{ Authorization:`Bearer ${token}`, 'Content-Type':`multipart/related; boundary=${boundary}` }, body:multipart });
  if (!res.ok) throw new Error(`Google Drive upload failed (${res.status}).`);
  return await res.json();
}
