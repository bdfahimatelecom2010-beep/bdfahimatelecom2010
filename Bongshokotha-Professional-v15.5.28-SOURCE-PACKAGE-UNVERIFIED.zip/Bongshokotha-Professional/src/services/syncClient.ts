import type { BongshokothaArchive } from './storage';

export function normalizeSyncEndpoint(value?: string): string { return String(value || '').trim().replace(/\/$/, ''); }
export async function publishInvite(endpoint: string, code: string, familyId: string, archive: BongshokothaArchive, expiresAt: string | null = null, token?: string) {
  const base = normalizeSyncEndpoint(endpoint); if (!base) throw new Error('Sync server URL is not configured.');
  const res = await fetch(`${base}/api/invites`, { method:'POST', headers:{'Content-Type':'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {})}, body:JSON.stringify({ familyId, archive, expiresAt, maxUses: 1 }) });
  if (!res.ok) throw new Error(`Sync server rejected the invite (${res.status}).`); return await res.json();
}
export async function fetchInvite(endpoint: string, code: string, token?: string): Promise<{ archive: BongshokothaArchive; expiresAt: string | null }> {
  const base = normalizeSyncEndpoint(endpoint); if (!base) throw new Error('Sync server URL is not configured.');
  const res = await fetch(`${base}/api/invites/${encodeURIComponent(code)}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} }); const body = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(body.error || `Sync server error (${res.status}).`); return body;
}
export async function revokeInvite(endpoint: string, code: string, token?: string) {
  const base = normalizeSyncEndpoint(endpoint); if (!base) throw new Error('Sync server URL is not configured.');
  const res = await fetch(`${base}/api/invites/${encodeURIComponent(code)}`, { method:'DELETE', headers: token ? { Authorization: `Bearer ${token}` } : {} }); if (!res.ok) throw new Error(`Could not revoke invite (${res.status}).`);
}


export async function pushFamilySnapshot(endpoint: string, familyId: string, archive: BongshokothaArchive, token?: string) {
  const base = normalizeSyncEndpoint(endpoint);
  if (!base) throw new Error('Sync server URL is not configured.');
  const res = await fetch(`${base}/api/families/${encodeURIComponent(familyId)}/snapshot`, { method:'PUT', headers:{'Content-Type':'application/json', ...(token ? { Authorization:`Bearer ${token}` } : {})}, body:JSON.stringify({ archive }) });
  const body = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(body.error || `Family sync upload failed (${res.status}).`);
  return body as { ok:boolean; familyId:string; revision:number; updatedAt:string };
}

export async function pullFamilySnapshot(endpoint: string, familyId: string, token?: string): Promise<{ archive: BongshokothaArchive; revision:number; updatedAt:string }> {
  const base = normalizeSyncEndpoint(endpoint);
  if (!base) throw new Error('Sync server URL is not configured.');
  const res = await fetch(`${base}/api/families/${encodeURIComponent(familyId)}/snapshot`, { headers: token ? { Authorization:`Bearer ${token}` } : {} });
  const body = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(body.error || `Family sync download failed (${res.status}).`);
  return body;
}

export async function checkServerSession(endpoint: string, token?: string): Promise<{ authenticated:boolean; appVersion?:string }> {
  const base = normalizeSyncEndpoint(endpoint);
  if (!base) throw new Error('Sync server URL is not configured.');
  const res = await fetch(`${base}/api/auth/session`, { headers: token ? { Authorization:`Bearer ${token}` } : {} });
  const body = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(body.error || `Server login failed (${res.status}).`);
  return body;
}
