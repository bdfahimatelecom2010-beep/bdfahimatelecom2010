/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Audit Logging & Security Event Tracing (Part 4)
 * 
 * Strict rule: NEVER log passwords, PINs, or OAuth secret tokens.
 */

import { UserRole } from './authRbac';

export type AuditEventType =
  | 'login'
  | 'logout'
  | 'failed_login'
  | 'password_reset'
  | 'role_change'
  | 'invitation'
  | 'backup'
  | 'restore'
  | 'import'
  | 'export'
  | 'deletion_attempt'
  | 'permission_change'
  | 'document_access'
  | 'document_modification'
  | 'relationship_repair'
  | 'settings_reset'
  | 'factory_reset';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  eventType: AuditEventType;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  targetEntity?: string;
  targetId?: string;
  details: string;
  detailsBn: string;
  ipAddress?: string;
  severity: 'info' | 'warning' | 'security_alert';
}

const AUDIT_STORAGE_KEY = 'bongsho_audit_logs';

export function getAuditLogs(): AuditLogEntry[] {
  try {
    const raw = localStorage.getItem(AUDIT_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    // fallback
  }

  return [];
}

export function logAuditEvent(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): void {
  try {
    const logs = getAuditLogs();
    const newEntry: AuditLogEntry = {
      ...entry,
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString()
    };
    // Keep last 150 entries in rolling audit buffer
    const updated = [newEntry, ...logs].slice(0, 150);
    localStorage.setItem(AUDIT_STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to log audit event', e);
  }
}
