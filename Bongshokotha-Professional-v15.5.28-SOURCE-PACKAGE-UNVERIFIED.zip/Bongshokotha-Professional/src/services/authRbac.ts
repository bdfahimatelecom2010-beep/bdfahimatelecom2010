/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Role-Based Access Control (RBAC) & Account Security (Part 4)
 * 
 * Six Distinct Lineage Roles:
 * 1. Owner (বংশমালিক / প্রতিষ্ঠাতা)
 * 2. Super Admin (বংশপ্রধান / অভিভাবক)
 * 3. Admin (বংশধারা প্রশাসক)
 * 4. Editor (বংশ-লেখক / লিপিকার)
 * 5. Contributor (বংশধর / তথ্য অবদানকারী)
 * 6. Viewer (অতিথি / সাধারণ দর্শক) - sharing/access role, not automatically a family member
 */

export type UserRole = 'owner' | 'super_admin' | 'admin' | 'co_admin' | 'tester' | 'editor' | 'contributor' | 'viewer';

export interface FamilyMembership { familyId: string; role: UserRole; status: 'active' | 'pending' | 'suspended' | 'revoked'; grantedBy?: string; grantedAt: string; updatedAt: string; }

export interface UserAccount {
  id: string;
  name: string;
  nameBn: string;
  /** Unique account login handle; separate from the genealogy member's name. */
  username?: string;
  role: UserRole;
  loginMethod: 'mobile' | 'email' | 'guest';
  contact: string; // phone number or email address
  linkedMemberId?: string;
  avatarUrl?: string;
  sessionToken?: string;
  lastLoginAt: string;
  isPinLocked?: boolean;
  memberships?: FamilyMembership[];
}

export interface RolePermissions {
  canManageFamily: boolean;
  canAddMember: boolean;
  canEditMember: boolean;
  canDeleteMember: boolean;
  canAddMarriage: boolean;
  canEditMarriage: boolean;
  canDeleteMarriage: boolean;
  canUploadArchive: boolean;
  canDeleteArchive: boolean;
  canRunIntegrityRepair: boolean;
  canExportFullData: boolean;
  canRestoreData: boolean;
  canImportData: boolean;
  canSwitchFamilies: boolean;
  canCreateFamily: boolean;
  canViewSensitiveDocs: boolean;
  canManageRoles: boolean;
  canConfigureSync: boolean;
  canFactoryReset: boolean;
  /** High-risk capabilities intentionally separated for Co-Admin enforcement. */
  canGmailBackup: boolean;
  canManageServers: boolean;
  canDeleteEntireGenealogy: boolean;
}

export const ROLE_PERMISSIONS: Record<UserRole, RolePermissions> = {
  owner: {
    canManageFamily: true,
    canAddMember: true,
    canEditMember: true,
    canDeleteMember: true,
    canAddMarriage: true,
    canEditMarriage: true,
    canDeleteMarriage: true,
    canUploadArchive: true,
    canDeleteArchive: true,
    canRunIntegrityRepair: true,
    canExportFullData: true,
    canRestoreData: true,
    canImportData: true,
    canSwitchFamilies: true,
    canCreateFamily: true,
    canViewSensitiveDocs: true,
    canManageRoles: true,
    canConfigureSync: true,
    canFactoryReset: true,
    canGmailBackup: true,
    canManageServers: true,
    canDeleteEntireGenealogy: true
  },
  super_admin: {
    canManageFamily: true,
    canAddMember: true,
    canEditMember: true,
    canDeleteMember: true,
    canAddMarriage: true,
    canEditMarriage: true,
    canDeleteMarriage: true,
    canUploadArchive: true,
    canDeleteArchive: true,
    canRunIntegrityRepair: true,
    canExportFullData: true,
    canRestoreData: true,
    canImportData: true,
    canSwitchFamilies: true,
    canCreateFamily: true,
    canViewSensitiveDocs: true,
    canManageRoles: true,
    canConfigureSync: true,
    canFactoryReset: false,
    canGmailBackup: true,
    canManageServers: true,
    canDeleteEntireGenealogy: true
  },
  admin: {
    canManageFamily: true,
    canAddMember: true,
    canEditMember: true,
    canDeleteMember: true,
    canAddMarriage: true,
    canEditMarriage: true,
    canDeleteMarriage: true,
    canUploadArchive: true,
    canDeleteArchive: true,
    canRunIntegrityRepair: true,
    canExportFullData: true,
    canRestoreData: true,
    canImportData: true,
    canSwitchFamilies: true,
    canCreateFamily: true,
    canViewSensitiveDocs: true,
    canManageRoles: true,
    canConfigureSync: true,
    canFactoryReset: false,
    canGmailBackup: true,
    canManageServers: true,
    canDeleteEntireGenealogy: true
  },
  co_admin: {
    canManageFamily: true,
    canAddMember: true,
    canEditMember: true,
    canDeleteMember: true,
    canAddMarriage: true,
    canEditMarriage: true,
    canDeleteMarriage: true,
    canUploadArchive: true,
    canDeleteArchive: true,
    canRunIntegrityRepair: true,
    canExportFullData: true,
    canRestoreData: true,
    canImportData: true,
    canSwitchFamilies: true,
    canCreateFamily: true,
    canViewSensitiveDocs: true,
    canManageRoles: true,
    canConfigureSync: true,
    canFactoryReset: false,
    canGmailBackup: false,
    canManageServers: false,
    canDeleteEntireGenealogy: false
  },
  editor: {
    canManageFamily: false,
    canAddMember: true,
    canEditMember: true,
    canDeleteMember: false,
    canAddMarriage: true,
    canEditMarriage: true,
    canDeleteMarriage: false,
    canUploadArchive: true,
    canDeleteArchive: false,
    canRunIntegrityRepair: false,
    canExportFullData: false,
    canRestoreData: false,
    canImportData: false,
    canSwitchFamilies: true,
    canCreateFamily: false,
    canViewSensitiveDocs: false,
    canManageRoles: false,
    canConfigureSync: false,
    canFactoryReset: false,
    canGmailBackup: false,
    canManageServers: false,
    canDeleteEntireGenealogy: false
  },
  tester: {
    canManageFamily: false, canAddMember: true, canEditMember: true, canDeleteMember: false,
    canAddMarriage: true, canEditMarriage: true, canDeleteMarriage: false,
    canUploadArchive: true, canDeleteArchive: false, canRunIntegrityRepair: false,
    canExportFullData: false, canRestoreData: false, canImportData: false, canSwitchFamilies: true,
    canCreateFamily: false, canViewSensitiveDocs: false, canManageRoles: false, canConfigureSync: false,
    canFactoryReset: false, canGmailBackup: false, canManageServers: false, canDeleteEntireGenealogy: false
  },
  contributor: {
    canManageFamily: false,
    canAddMember: true,
    canEditMember: false,
    canDeleteMember: false,
    canAddMarriage: false,
    canEditMarriage: false,
    canDeleteMarriage: false,
    canUploadArchive: true,
    canDeleteArchive: false,
    canRunIntegrityRepair: false,
    canExportFullData: false,
    canRestoreData: false,
    canImportData: false,
    canSwitchFamilies: false,
    canCreateFamily: false,
    canViewSensitiveDocs: false,
    canManageRoles: false,
    canConfigureSync: false,
    canFactoryReset: false,
    canGmailBackup: false,
    canManageServers: false,
    canDeleteEntireGenealogy: false
  },
  viewer: {
    canManageFamily: false,
    canAddMember: false,
    canEditMember: false,
    canDeleteMember: false,
    canAddMarriage: false,
    canEditMarriage: false,
    canDeleteMarriage: false,
    canUploadArchive: false,
    canDeleteArchive: false,
    canRunIntegrityRepair: false,
    canExportFullData: false,
    canRestoreData: false,
    canImportData: false,
    canSwitchFamilies: false,
    canCreateFamily: false,
    canViewSensitiveDocs: false,
    canManageRoles: false,
    canConfigureSync: false,
    canFactoryReset: false,
    canGmailBackup: false,
    canManageServers: false,
    canDeleteEntireGenealogy: false
  }
};

const RBAC_STORAGE_KEY = 'bongsho_active_account';

export function getEffectiveRole(account: UserAccount | null | undefined, familyId?: string): UserRole {
  if (!account) return 'viewer';
  const membership = familyId ? account.memberships?.find(m => m.familyId === familyId && m.status === 'active') : undefined;
  return membership?.role || account.role || 'viewer';
}

export function hasPermission(account: UserAccount | null | undefined, familyId: string | undefined, action: keyof RolePermissions): boolean {
  const role = getEffectiveRole(account, familyId);
  return Boolean(ROLE_PERMISSIONS[role]?.[action]);
}


export type StoredAccount = UserAccount & { mobile?: string; email?: string; passwordDigest?: string };
const ACCOUNTS_KEY = 'bongshokotha_accounts_v1';
export function listStoredAccounts(): StoredAccount[] {
  try { const raw = localStorage.getItem(ACCOUNTS_KEY); const value = JSON.parse(raw || '[]'); return Array.isArray(value) ? value : []; } catch { return []; }
}
export function saveStoredAccounts(accounts: StoredAccount[]): void { localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts)); }
export function assignStoredAccountRole(actor: UserAccount, targetId: string, role: UserRole, familyId: string): StoredAccount {
  const actorRole = getEffectiveRole(actor, familyId);
  if (!ROLE_PERMISSIONS[actorRole]?.canManageRoles) throw new Error('Permission denied: role management.');
  const rank: Record<UserRole, number> = { viewer:0, contributor:1, editor:2, tester:3, co_admin:4, admin:5, super_admin:6, owner:7 };
  if (role === actorRole || rank[role] >= rank[actorRole] || role === 'owner') throw new Error('You cannot assign a role equal to or higher than your own.');
  const accounts = listStoredAccounts(); const target = accounts.find(a => a.id === targetId);
  if (!target) throw new Error('Account not found.');
  target.role = role;
  const now = new Date().toISOString(); const existing = target.memberships || [];
  const idx = existing.findIndex(m => m.familyId === familyId);
  const membership = { familyId, role, status: 'active' as const, grantedBy: actor.id, grantedAt: idx >= 0 ? existing[idx].grantedAt : now, updatedAt: now };
  target.memberships = idx >= 0 ? existing.map((m,i)=>i===idx?membership:m) : [...existing, membership];
  saveStoredAccounts(accounts);
  return target;
}

export function getStoredAccount(): UserAccount {
  try {
    const raw = localStorage.getItem(RBAC_STORAGE_KEY);
    if (raw) { const account = JSON.parse(raw) as UserAccount; if (account?.id && account?.role && account?.contact) return account; }
  } catch {}
  return { id: '', name: '', nameBn: '', role: 'viewer', loginMethod: 'guest', contact: '', lastLoginAt: '' };
}

export function saveStoredAccount(account: UserAccount): void {
  try { localStorage.setItem(RBAC_STORAGE_KEY, JSON.stringify(account)); } catch (e) { console.error('Failed to save account state', e); }
}
