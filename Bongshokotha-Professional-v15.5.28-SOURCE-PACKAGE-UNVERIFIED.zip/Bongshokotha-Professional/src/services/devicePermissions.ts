import { Capacitor } from '@capacitor/core';

export type DevicePermissionStatus = 'granted' | 'limited' | 'prompt' | 'denied' | 'unavailable';

async function getCameraPlugin() {
  if (!Capacitor.isNativePlatform()) return null;
  try {
    const mod = await import('@capacitor/camera');
    return mod.Camera;
  } catch (error) {
    console.warn('Capacitor Camera plugin is unavailable:', error);
    return null;
  }
}

export async function checkCameraPermission(): Promise<DevicePermissionStatus> {
  const Camera = await getCameraPlugin();
  if (!Camera) {
    return Capacitor.isNativePlatform() ? 'unavailable' : 'prompt';
  }
  try {
    const status = await Camera.checkPermissions();
    return status.camera as DevicePermissionStatus;
  } catch (error) {
    console.warn('Camera permission check failed:', error);
    return 'unavailable';
  }
}

export async function requestCameraPermission(): Promise<DevicePermissionStatus> {
  const Camera = await getCameraPlugin();
  if (!Camera) {
    // Browser/WebView path: getUserMedia will show the browser/native permission prompt.
    return 'prompt';
  }
  try {
    const current = await Camera.checkPermissions();
    if (current.camera === 'granted') return 'granted';
    const requested = await Camera.requestPermissions({ permissions: ['camera'] });
    return requested.camera as DevicePermissionStatus;
  } catch (error) {
    console.warn('Camera permission request failed:', error);
    return 'denied';
  }
}

export async function checkPhotoMediaPermission(): Promise<DevicePermissionStatus> {
  const Camera = await getCameraPlugin();
  if (!Camera) {
    return Capacitor.isNativePlatform() ? 'unavailable' : 'prompt';
  }
  try {
    const status = await Camera.checkPermissions();
    return status.photos as DevicePermissionStatus;
  } catch (error) {
    console.warn('Photo/media permission check failed:', error);
    return 'unavailable';
  }
}

export async function requestPhotoMediaPermission(): Promise<DevicePermissionStatus> {
  const Camera = await getCameraPlugin();
  if (!Camera) {
    // Selecting files/images through the browser/system file picker is already user-consented.
    return 'prompt';
  }
  try {
    const current = await Camera.checkPermissions();
    if (current.photos === 'granted' || current.photos === 'limited') return current.photos as DevicePermissionStatus;
    const requested = await Camera.requestPermissions({ permissions: ['photos'] });
    return requested.photos as DevicePermissionStatus;
  } catch (error) {
    console.warn('Photo/media permission request failed:', error);
    return 'denied';
  }
}

export async function ensureCameraPermission(): Promise<boolean> {
  const state = await requestCameraPermission();
  return state === 'granted' || state === 'limited';
}

export function permissionLabelBn(state: DevicePermissionStatus): string {
  switch (state) {
    case 'granted': return 'অনুমোদিত';
    case 'limited': return 'সীমিত অনুমোদিত';
    case 'denied': return 'অনুমতি বন্ধ';
    case 'unavailable': return 'এই ডিভাইসে উপলভ্য নয়';
    default: return 'অনুমতি প্রয়োজন';
  }
}
