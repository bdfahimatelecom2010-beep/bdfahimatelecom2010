/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Primary Genealogy State Context & Engine Orchestrator
 */

import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Family,
  Member,
  MarriageRecord,
  Branch,
  ValidationReport,
  RelationshipResult,
  GenealogyDate,
  ArchiveRecord,
  RecycleBinEntry
} from '../types/genealogy';
import { storage, BongshokothaArchive, computeArchiveChecksum, archivePayloadWithoutIntegrity, normalizeMemberRecord, normalizeMarriageRecord } from '../services/storage';
import { calculateGenerations, synchronizeComputedGenerations, getGenerationSummary, GenerationSummary } from '../engine/generationEngine';
import { findRelationship } from '../engine/relationshipEngine';
import { reconcileCanonicalRelationships } from '../engine/relationshipIntegrity';
import { validateGenealogyData, repairAllLinks, RepairResult } from '../engine/validationEngine';
import { applyTheme } from '../theme/themeEngine';
import { getStoredAccount, saveStoredAccount, UserAccount, ROLE_PERMISSIONS, getEffectiveRole } from '../services/authRbac';
import { exportToGedcom, parseGedcom } from '../engine/gedcomEngine';
import { SAMPLE_FAMILY, SAMPLE_MEMBERS, SAMPLE_MARRIAGES } from '../services/sampleData';
import { SAMPLE_ARCHIVE_RECORDS } from '../services/sampleArchiveData';

interface GenealogyContextType {
  // Active Family State
  family: Family;
  allFamilies: Family[];
  members: Member[];
  marriages: MarriageRecord[];
  branches: Branch[];
  archiveRecords: ArchiveRecord[];
  isLoading: boolean;

  // Computed Genealogy Metrics
  generations: Map<string, number>;
  generationSummary: GenerationSummary;
  validationReport: ValidationReport;

  // Settings, Localization & Themes (Part 4)
  language: 'bn' | 'en' | 'hi' | 'ar';
  setLanguage: (lang: 'bn' | 'en' | 'hi' | 'ar') => void;
  theme: string;
  setTheme: (themeId: string) => void;

  // Accounts & RBAC Permissions (Part 4)
  userAccount: UserAccount;
  setUserAccount: (acc: UserAccount) => void;
  checkPermission: (action: keyof typeof ROLE_PERMISSIONS['super_admin']) => boolean;

  // Core Mutation Operations
  addMember: (memberData: Omit<Member, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Member>;
  updateMember: (member: Member) => Promise<Member>;
  linkChildrenToMarriage: (marriageId: string, childIds: string[]) => Promise<void>;
  deleteMember: (memberId: string) => Promise<void>;
  deleteMultipleMembers: (memberIds: string[]) => Promise<void>;
  recycleBin: RecycleBinEntry[];
  restoreRecycleEntry: (entryId: string) => Promise<void>;
  permanentDeleteRecycleEntry: (entryId: string) => Promise<void>;
  emptyRecycleBin: () => Promise<void>;
  clearCurrentFamilyData: () => Promise<void>;
  resetToFreshState: () => Promise<void>;

  addMarriage: (marriageData: Omit<MarriageRecord, 'id' | 'createdAt' | 'updatedAt'>) => Promise<MarriageRecord>;
  updateMarriage: (marriage: MarriageRecord) => Promise<void>;
  deleteMarriage: (marriageId: string) => Promise<void>;

  addBranch: (branch: Branch) => Promise<void>;
  updateFamily: (updated: Partial<Family>) => Promise<void>;
  switchFamily: (familyId: string) => Promise<void>;
  deleteFamilySpace: (familyId: string) => Promise<void>;
  renameFamilySpace: (familyId: string, name: string) => Promise<void>;
  createNewFamily: (name: string, banglaName: string, description?: string) => Promise<Family>;

  // Archive & Document Intelligence Operations (PART 3)
  addArchiveRecord: (
    recordData: Omit<ArchiveRecord, 'id' | 'createdAt' | 'updatedAt' | 'history'> & { historyNote?: string }
  ) => Promise<ArchiveRecord>;
  updateArchiveRecord: (record: ArchiveRecord, historyNote?: string) => Promise<void>;
  deleteArchiveRecord: (recordId: string) => Promise<void>;
  batchAddArchiveRecords: (
    records: (Omit<ArchiveRecord, 'id' | 'createdAt' | 'updatedAt' | 'history'> & { historyNote?: string })[]
  ) => Promise<void>;
  linkDocumentToMember: (recordId: string, memberId: string, role?: string) => Promise<void>;
  unlinkDocumentFromMember: (recordId: string, memberId: string) => Promise<void>;

  // Analysis & Engine Utilities
  calculateRelationship: (personAId: string, personBId: string) => RelationshipResult | null;
  runRepair: () => Promise<RepairResult>;
  recalculateAndPersistGenerations: () => Promise<{ changed: boolean; maxGeneration: number }>;
  exportArchiveJSON: () => void;
  importArchiveJSON: (
    jsonString: string,
    strategy?: 'merge_preserve' | 'overwrite_all' | 'keep_existing'
  ) => Promise<{ success: boolean; message: string }>;
  exportGedcomFile: () => void;
  importGedcomText: (text: string) => Promise<{ success: boolean; message: string; count: number }>;
  importUniversalDataset: (
    dataset: { members: Member[]; marriages: MarriageRecord[]; branches?: Branch[] },
    strategy?: 'merge_preserve' | 'overwrite_all'
  ) => Promise<{ success: boolean; message: string; count: number }>;
  loadSampleDataset: () => Promise<void>;
  resetSettings: () => Promise<void>;
  resetToFactoryState: () => Promise<void>;
}


const DEFAULT_FAMILY_SETTINGS = {
  language: 'bn' as const,
  theme: 'heritage',
  enableBengaliCalendar: true,
  enableHijriCalendar: false,
  enablePrivacyMasking: true,
  enableLivingPersonPrivacy: true,
  dateFormat: 'DD/MM/YYYY' as const,
  numberSystem: 'bengali' as const,
  calendarSystem: 'bengali' as const,
  privacyLevel: 'family_only' as const,
  fontSize: 'medium' as const,
  displayDensity: 'comfortable' as const,
  enableAnimations: true,
  highContrast: false,
  dyslexicFont: false,
  archiveStorageQuotaMb: 2048,
  archiveWatermarkEnabled: true,
  ocrEngine: 'bengali_hybrid' as const,
  ocrConfidenceThreshold: 0.75,
  ocrAutoDictionaryCorrection: false,
  cameraAutoCrop: true,
  cameraPerspectiveCorrection: true,
  cameraContrastFilter: 'document_bw' as const,
  syncProvider: 'local_only' as const,
  securityPinEnabled: false,
  sessionTimeoutMinutes: 30,
  remembranceNotifications: true,
  anniversaryAlerts: true,
  birthdayAlerts: true
};

const GenealogyContext = createContext<GenealogyContextType | undefined>(undefined);

export const GenealogyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [allFamilies, setAllFamilies] = useState<Family[]>([]);
  const [family, setFamily] = useState<Family>(() => ({ id: crypto.randomUUID(), name: '', banglaName: '', description: '', branches: [], settings: { ...DEFAULT_FAMILY_SETTINGS }, backupHistory: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }));
  const [members, setMembers] = useState<Member[]>([]);
  const [marriages, setMarriages] = useState<MarriageRecord[]>([]);
  const membersRef = useRef<Member[]>([]);
  const marriagesRef = useRef<MarriageRecord[]>([]);
  const [archiveRecords, setArchiveRecords] = useState<ArchiveRecord[]>([]);
  const [recycleBin, setRecycleBin] = useState<RecycleBinEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [language, setLanguageState] = useState<'bn' | 'en' | 'hi' | 'ar'>('bn');
  const [theme, setThemeState] = useState<string>('heritage');
  const [userAccount, setUserAccountState] = useState<UserAccount>(getStoredAccount());

  const setUserAccount = useCallback((acc: UserAccount) => {
    const current = userAccount;
    const rank: Record<string, number> = { viewer: 0, contributor: 1, editor: 2, tester: 3, co_admin: 4, admin: 5, super_admin: 6, owner: 7 };
    const changingRole = Boolean(current?.id && acc.role !== current.role);
    if (changingRole) {
      const currentRole = getEffectiveRole(current, family.id);
      const canManage = Boolean(ROLE_PERMISSIONS[currentRole]?.canManageRoles);
      if (!canManage || rank[acc.role] >= rank[currentRole] || acc.role === 'owner') {
        throw new Error('Permission denied: role escalation is not allowed.');
      }
    }
    setUserAccountState(acc);
    saveStoredAccount(acc);
  }, [userAccount, family.id]);

  const checkPermission = useCallback(
    (action: keyof typeof ROLE_PERMISSIONS['super_admin']): boolean => {
      const effectiveRole = getEffectiveRole(userAccount, family.id);
      const perms = ROLE_PERMISSIONS[effectiveRole];
      return Boolean(perms && (perms as any)[action]);
    },
    [userAccount, family.id]
  );

  const requirePermission = useCallback((action: keyof typeof ROLE_PERMISSIONS['super_admin']) => {
    if (!checkPermission(action)) throw new Error(`Permission denied: ${String(action)}`);
  }, [checkPermission]);

  // Load initial data
  useEffect(() => {
    async function loadInitialData() {
      setIsLoading(true);
      try {
        let families = await storage.getFamilies();
        if (!families.length) {
          const fresh: Family = {
            id: crypto.randomUUID(), name: '', banglaName: '', description: '', branches: [],
            settings: { ...DEFAULT_FAMILY_SETTINGS },
            backupHistory: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
          };
          await storage.saveFamily(fresh);
          storage.setActiveFamilyId(fresh.id);
          families = [fresh];
        }
        const normalizedFamilies: Family[] = families.map(f => ({ ...f, settings: { ...DEFAULT_FAMILY_SETTINGS, ...(f.settings || {}) } }));
        const activeId = storage.getActiveFamilyId();
        // DEMO SAFETY: never auto-open the sample family, including the edge case
        // where it is the only family left in an older browser database. Preserve
        // the sample records for explicit demo access, but create a blank family
        // workspace rather than presenting sample people as the user's real data.
        let nonDemoFamilies = normalizedFamilies.filter(f => f.id !== 'family-sample-choudhury');
        if (nonDemoFamilies.length === 0) {
          const fresh: Family = {
            id: crypto.randomUUID(), name: '', banglaName: '', description: '', branches: [],
            settings: { ...DEFAULT_FAMILY_SETTINGS }, backupHistory: [],
            createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
          };
          await storage.saveFamily(fresh);
          normalizedFamilies.push(fresh);
          nonDemoFamilies = [fresh];
        }
        setAllFamilies(normalizedFamilies);
        const requestedFamily = normalizedFamilies.find(f => f.id === activeId);
        const activeFamily = requestedFamily && requestedFamily.id !== 'family-sample-choudhury'
          ? requestedFamily
          : nonDemoFamilies[0];
        storage.setActiveFamilyId(activeFamily.id);
        setFamily(activeFamily);
        setLanguageState(activeFamily.settings?.language || 'bn');
        const initialTheme = activeFamily.settings?.theme || 'heritage';
        setThemeState(initialTheme);
        applyTheme(initialTheme);
        window.dispatchEvent(new CustomEvent('bongshokotha:family-theme-changed', { detail: { themeId: initialTheme } }));

        const rawMembers = await storage.getMembers(activeFamily.id);
        const initialMarriages = await storage.getMarriages(activeFamily.id);
        const normalizedInitial = synchronizeComputedGenerations(rawMembers, initialMarriages, activeFamily.rootAncestorId);
        const initialMembers = normalizedInitial.members;
        const initialArchive = await storage.getArchiveRecords(activeFamily.id);
        membersRef.current = initialMembers;
        marriagesRef.current = initialMarriages;
        setMembers(initialMembers);
        setMarriages(initialMarriages);
        if (normalizedInitial.changed) await storage.saveMembers(activeFamily.id, initialMembers);
        setArchiveRecords(initialArchive);
        setRecycleBin(await storage.getRecycleBin(activeFamily.id));
      } catch (err) {
        console.error('Error loading genealogy data:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadInitialData();
  }, []);

  // Keep document direction synchronized with the selected UI language.
  // Stored family data is never translated; only the application chrome changes direction.
  useEffect(() => {
    const direction = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.setAttribute('dir', direction);
    document.documentElement.setAttribute('lang', language);
    document.body.dir = direction;
    return () => {
      document.documentElement.setAttribute('dir', 'ltr');
      document.documentElement.setAttribute('lang', 'bn');
      document.body.dir = 'ltr';
    };
  }, [language]);

  // Sync theme to document element
  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  const branches = useMemo(() => family.branches || [], [family]);

  // Dynamically calculate generations whenever members or marriages change
  const generations = useMemo(() => {
    return calculateGenerations(members, marriages, family.rootAncestorId);
  }, [members, marriages, family.rootAncestorId]);

  const generationSummary = useMemo(() => {
    return getGenerationSummary(members, marriages, family.rootAncestorId);
  }, [members, marriages, family.rootAncestorId]);

  // Validation report dynamically computed
  const validationReport = useMemo(() => {
    return validateGenealogyData(members, marriages);
  }, [members, marriages]);

  // Theme & Language setters with persistence in family settings
  const setLanguage = useCallback((lang: 'bn' | 'en' | 'hi' | 'ar') => {
    setLanguageState(lang);
    setFamily(prev => {
      const updated: Family = {
        ...prev,
        settings: { ...prev.settings, language: lang }
      };
      storage.saveFamily(updated);
      return updated;
    });
  }, []);

  const resetSettings = useCallback(async () => {
    setLanguageState('bn');
    setThemeState('heritage');
    applyTheme('heritage');
    window.dispatchEvent(new CustomEvent('bongshokotha:family-theme-changed', { detail: { themeId: 'heritage' } }));
    setFamily(prev => {
      const updated: Family = {
        ...prev,
        settings: {
          ...DEFAULT_FAMILY_SETTINGS,
          ...prev.settings,
          language: 'bn',
          theme: 'heritage',
          enableBengaliCalendar: true,
          enableHijriCalendar: false,
          enablePrivacyMasking: true,
          enableLivingPersonPrivacy: true,
          dateFormat: 'DD/MM/YYYY',
          numberSystem: 'bengali',
          calendarSystem: 'bengali',
          privacyLevel: 'family_only',
          fontSize: 'medium',
          displayDensity: 'comfortable',
          enableAnimations: true,
          highContrast: false,
          dyslexicFont: false
        }
      };
      storage.saveFamily(updated);
      return updated;
    });
  }, []);

  const setTheme = useCallback((th: string) => {
    setThemeState(th);
    applyTheme(th);
    window.dispatchEvent(new CustomEvent('bongshokotha:family-theme-changed', { detail: { themeId: th } }));
    setFamily(prev => {
      const updated: Family = {
        ...prev,
        settings: { ...prev.settings, theme: th }
      };
      storage.saveFamily(updated);
      return updated;
    });
  }, []);

  // --- Member Operations ---

  const addMember = useCallback(
    async (memberData: Omit<Member, 'id' | 'createdAt' | 'updatedAt'>): Promise<Member> => {
      requirePermission('canAddMember');
      const now = new Date().toISOString();
      const newId = `mem-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;

      const newMember: Member = {
        ...memberData,
        id: newId,
        familyId: family.id,
        maritalStatus: memberData.maritalStatus || 'unmarried',
        isUnmarried: memberData.isUnmarried ?? (memberData.maritalStatus ? memberData.maritalStatus === 'unmarried' : true),
        isLiving: memberData.isLiving ?? true,
        death: { ...(memberData.death || {}), isDeceased: memberData.death?.isDeceased ?? !(memberData.isLiving ?? true) },
        marriageIds: memberData.marriageIds || [],
        createdAt: now,
        updatedAt: now
      };

      const rawList = [...membersRef.current, newMember];
      const reconciled = reconcileCanonicalRelationships(rawList, marriagesRef.current);
      const normalized = synchronizeComputedGenerations(reconciled.members, reconciled.marriages, family.rootAncestorId);
      const persistedNewMember = normalized.members.find(m => m.id === newId) || newMember;
      // Persist the complete relationship snapshot, not just the edited person.
      // Reconciliation may have changed marriage children/spouse links as part of
      // the same mutation. UI state advances only after both registries are saved.
      await Promise.all([
        storage.saveMembers(family.id, normalized.members),
        storage.saveMarriages(family.id, reconciled.marriages)
      ]);
      const verified = await storage.getMembers(family.id);
      const verifiedMarriages = await storage.getMarriages(family.id);
      if (!verified.some(m => m.id === newId)) throw new Error(`Member persistence verification failed: ${newId}`);
      membersRef.current = verified;
      marriagesRef.current = verifiedMarriages;
      setMembers(verified);
      setMarriages(verifiedMarriages);
      return verified.find(m => m.id === newId) || persistedNewMember;
    },
    [family.id, family.rootAncestorId, requirePermission]
  );

  const updateMember = useCallback(
    async (updated: Member): Promise<Member> => {
      requirePermission('canEditMember');
      const now = new Date().toISOString();
      const current = membersRef.current.find(m => m.id === updated.id);
      if (!current) throw new Error(`Member not found: ${updated.id}`);

      // Merge the edit into the latest canonical member object. This prevents an
      // older modal snapshot from restoring stale fields that were changed by
      // another relationship/document operation while the editor was open.
      const updatedWithTimestamp: Member = {
        ...current,
        ...updated,
        id: current.id,
        familyId: current.familyId || family.id,
        createdAt: current.createdAt,
        updatedAt: now
      };

      const rawList = membersRef.current.map(m => (m.id === updatedWithTimestamp.id ? updatedWithTimestamp : m));
      const reconciled = reconcileCanonicalRelationships(rawList, marriagesRef.current);
      const normalized = synchronizeComputedGenerations(reconciled.members, reconciled.marriages, family.rootAncestorId);
      // Persist the whole canonical relationship snapshot before advancing UI
      // state. A member edit can legitimately reconcile a marriage's children.
      await Promise.all([
        storage.saveMembers(family.id, normalized.members),
        storage.saveMarriages(family.id, reconciled.marriages)
      ]);

      const persistedMembers = await storage.getMembers(family.id);
      const persistedMarriages = await storage.getMarriages(family.id);
      const persisted = persistedMembers.find(m => m.id === updatedWithTimestamp.id);
      if (!persisted) throw new Error(`Member persistence verification failed: ${updatedWithTimestamp.id}`);
      membersRef.current = persistedMembers;
      marriagesRef.current = persistedMarriages;
      setMembers(persistedMembers);
      setMarriages(persistedMarriages);
      return persisted;
    },
    [family.id, family.rootAncestorId, requirePermission]
  );

  const linkChildrenToMarriage = useCallback(
    async (marriageId: string, childIds: string[]) => {
      requirePermission('canEditMember');
      requirePermission('canEditMarriage');
      const marriage = marriages.find(m => m.id === marriageId);
      if (!marriage) return;
      const nextMarriages = marriages.map(m => m.id === marriageId ? { ...m, childrenIds: [...new Set(childIds)], updatedAt: new Date().toISOString() } : m);
      const childSet = new Set(childIds);
      const nextMembers = members.map(m => {
        if (!childSet.has(m.id)) return m;
        return {
          ...m,
          fatherId: marriage.husbandId || m.fatherId,
          motherId: marriage.wifeId || m.motherId,
          updatedAt: new Date().toISOString()
        };
      });
      const reconciled = reconcileCanonicalRelationships(nextMembers, nextMarriages);
      const normalized = synchronizeComputedGenerations(reconciled.members, reconciled.marriages, family.rootAncestorId);
      marriagesRef.current = reconciled.marriages;
      membersRef.current = normalized.members;
      setMarriages(reconciled.marriages);
      setMembers(normalized.members);
      await Promise.all([
        storage.saveMarriages(family.id, reconciled.marriages),
        storage.saveMembers(family.id, normalized.members)
      ]);
    },
    [marriages, members, family.id, family.rootAncestorId, requirePermission]
  );

  const createRecycleEntry = useCallback(async (memberIds: string[]) => {
    const ids = new Set(memberIds);
    const deletedMembers = members.filter(m => ids.has(m.id));
    if (!deletedMembers.length) return;
    const removedMarriageIds = new Set(marriages.filter(m => ids.has(m.husbandId) || ids.has(m.wifeId)).map(m => m.id));
    const affectedMembers = members.filter(m => !ids.has(m.id) && (ids.has(m.fatherId || '') || ids.has(m.motherId || '') || (m.marriageIds || []).some(mid => removedMarriageIds.has(mid))));
    const affectedMarriages = marriages.filter(m => removedMarriageIds.has(m.id) || (m.childrenIds || []).some(cid => ids.has(cid)));
    const entry: RecycleBinEntry = {
      id: `recycle-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`,
      familyId: family.id, entityType: 'member', entityId: deletedMembers[0].id,
      label: deletedMembers.length === 1 ? (deletedMembers[0].banglaName || deletedMembers[0].fullName) : `${deletedMembers.length} সদস্য`,
      deletedAt: new Date().toISOString(), deletedBy: userAccount.nameBn || userAccount.name,
      payload: { member: deletedMembers[0], affectedMembers, affectedMarriages }
    };
    if (deletedMembers.length > 1) {
      entry.payload.member = undefined;
      entry.payload.members = deletedMembers;
    }
    await storage.saveRecycleEntry(entry);
    setRecycleBin(await storage.getRecycleBin(family.id));
  }, [members, marriages, family.id, userAccount]);

  const deleteMember = useCallback(async (memberId: string) => {
    requirePermission('canDeleteMember');
    const currentMembers = membersRef.current;
    const currentMarriages = marriagesRef.current;
    if (!currentMembers.some(m => m.id === memberId)) return;
    await createRecycleEntry([memberId]);
    const idsSet = new Set([memberId]);
    const removedMarriageIds = new Set(currentMarriages.filter(m => m.husbandId === memberId || m.wifeId === memberId).map(m => m.id));
    const updatedMarriages = currentMarriages
      .filter(mar => !idsSet.has(mar.husbandId) && !idsSet.has(mar.wifeId))
      .map(mar => ({ ...mar, childrenIds: (mar.childrenIds || []).filter(cid => !idsSet.has(cid)), updatedAt: new Date().toISOString() }));
    const updatedList = currentMembers
      .filter(m => !idsSet.has(m.id))
      .map(m => ({
        ...m,
        fatherId: m.fatherId === memberId ? undefined : m.fatherId,
        motherId: m.motherId === memberId ? undefined : m.motherId,
        fatherInLawId: m.fatherInLawId === memberId ? undefined : m.fatherInLawId,
        motherInLawId: m.motherInLawId === memberId ? undefined : m.motherInLawId,
        marriageIds: (m.marriageIds || []).filter(mid => !removedMarriageIds.has(mid)),
        isUnmarried: (m.marriageIds || []).filter(mid => !removedMarriageIds.has(mid)).length === 0
      }));
    const normalized = synchronizeComputedGenerations(updatedList, updatedMarriages, family.rootAncestorId);
    membersRef.current = normalized.members;
    marriagesRef.current = updatedMarriages;
    setMembers(normalized.members);
    setMarriages(updatedMarriages);
    await Promise.all([
      storage.saveMembers(family.id, normalized.members),
      storage.saveMarriages(family.id, updatedMarriages)
    ]);
    const verifyMembers = await storage.getMembers(family.id);
    if (verifyMembers.some(m => m.id === memberId)) throw new Error(`Delete verification failed: ${memberId}`);
    membersRef.current = verifyMembers;
    setMembers(verifyMembers);
  }, [createRecycleEntry, family.id, family.rootAncestorId, requirePermission]);

  const deleteMultipleMembers = useCallback(async (memberIds: string[]) => {
    requirePermission('canDeleteMember');
    if (!memberIds.length) return;
    const currentMembers = membersRef.current;
    const currentMarriages = marriagesRef.current;
    await createRecycleEntry(memberIds);
    const idsSet = new Set(memberIds);
    const removedMarriageIds = new Set(currentMarriages.filter(m => idsSet.has(m.husbandId) || idsSet.has(m.wifeId)).map(m => m.id));
    const updatedMarriages = currentMarriages.filter(mar => !idsSet.has(mar.husbandId) && !idsSet.has(mar.wifeId)).map(mar => ({ ...mar, childrenIds: (mar.childrenIds || []).filter(cid => !idsSet.has(cid)), updatedAt: new Date().toISOString() }));
    const updatedList = currentMembers.filter(m => !idsSet.has(m.id)).map(m => ({ ...m, fatherId: idsSet.has(m.fatherId || '') ? undefined : m.fatherId, motherId: idsSet.has(m.motherId || '') ? undefined : m.motherId, fatherInLawId: idsSet.has(m.fatherInLawId || '') ? undefined : m.fatherInLawId, motherInLawId: idsSet.has(m.motherInLawId || '') ? undefined : m.motherInLawId, marriageIds: (m.marriageIds || []).filter(mid => !removedMarriageIds.has(mid)) }));
    const normalized = synchronizeComputedGenerations(updatedList, updatedMarriages, family.rootAncestorId);
    membersRef.current = normalized.members; marriagesRef.current = updatedMarriages;
    setMembers(normalized.members); setMarriages(updatedMarriages);
    await Promise.all([storage.saveMembers(family.id, normalized.members), storage.saveMarriages(family.id, updatedMarriages)]);
  }, [createRecycleEntry, family.id, family.rootAncestorId, requirePermission]);

  const restoreRecycleEntry = useCallback(async (entryId: string) => {
    requirePermission('canRestoreData');
    const entry = recycleBin.find(e => e.id === entryId); if (!entry) return;
    const payload = entry.payload as any;
    if (entry.entityType === 'marriage') {
      const restoredMarriage = payload.marriage as MarriageRecord | undefined;
      if (!restoredMarriage || marriagesRef.current.some(m => m.id === restoredMarriage.id)) return;
      const nextMarriages = [...marriagesRef.current, restoredMarriage];
      const nextMembers = membersRef.current.map(m => {
        if (m.id !== restoredMarriage.husbandId && m.id !== restoredMarriage.wifeId) return m;
        const mids = m.marriageIds || [];
        return { ...m, marriageIds: mids.includes(restoredMarriage.id) ? mids : [...mids, restoredMarriage.id], isUnmarried: false };
      });
      const normalized = synchronizeComputedGenerations(nextMembers, nextMarriages, family.rootAncestorId);
      marriagesRef.current = nextMarriages;
      membersRef.current = normalized.members;
      setMarriages(nextMarriages);
      setMembers(normalized.members);
      await storage.saveMarriages(family.id, nextMarriages);
      await storage.saveMembers(family.id, normalized.members);
      await storage.deleteRecycleEntry(family.id, entryId);
      setRecycleBin(await storage.getRecycleBin(family.id));
      return;
    }
    if (entry.entityType !== 'member') return;
    const restoredMembers: Member[] = payload.members || (payload.member ? [payload.member] : []);
    const currentIds = new Set(members.map(m => m.id));
    const nextMembers = [...members];
    for (const restored of restoredMembers) if (!currentIds.has(restored.id)) nextMembers.push(restored);
    for (const affected of (payload.affectedMembers || [])) {
      const idx = nextMembers.findIndex(m => m.id === affected.id);
      if (idx >= 0) nextMembers[idx] = { ...nextMembers[idx], fatherId: affected.fatherId, motherId: affected.motherId, marriageIds: affected.marriageIds };
    }
    const nextMarriages = [...marriages];
    for (const restoredMarriage of (payload.affectedMarriages || [])) {
      const idx = nextMarriages.findIndex(m => m.id === restoredMarriage.id);
      if (idx >= 0) nextMarriages[idx] = restoredMarriage; else nextMarriages.push(restoredMarriage);
    }
    setMembers(nextMembers); setMarriages(nextMarriages);
    await storage.saveMembers(family.id, nextMembers); await storage.saveMarriages(family.id, nextMarriages);
    await storage.deleteRecycleEntry(family.id, entryId); setRecycleBin(await storage.getRecycleBin(family.id));
  }, [recycleBin, members, marriages, family.id, requirePermission]);

  const permanentDeleteRecycleEntry = useCallback(async (entryId: string) => {
    requirePermission('canDeleteMember');
    await storage.deleteRecycleEntry(family.id, entryId); setRecycleBin(await storage.getRecycleBin(family.id));
  }, [family.id, requirePermission]);

  const emptyRecycleBin = useCallback(async () => {
    requirePermission('canDeleteMember');
    await storage.clearRecycleBin(family.id); setRecycleBin([]);
  }, [family.id, requirePermission]);

  const clearCurrentFamilyData = useCallback(async () => {
    requirePermission('canDeleteEntireGenealogy');
    setMembers([]);
    setMarriages([]);
    membersRef.current = [];
    marriagesRef.current = [];
    await storage.clearFamilyMembers(family.id);
    await storage.clearRecycleBin(family.id);
    setRecycleBin([]);
  }, [family.id, requirePermission]);

  // --- Marriage Operations ---

  const addMarriage = useCallback(
    async (marriageData: Omit<MarriageRecord, 'id' | 'createdAt' | 'updatedAt'>): Promise<MarriageRecord> => {
      requirePermission('canAddMarriage');
      const now = new Date().toISOString();
      const newId = `mar-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
      const serialNumber = `MR-${String(marriagesRef.current.length + 1).padStart(3, '0')}`;

      const newMarriage: MarriageRecord = {
        ...marriageData,
        id: newId,
        familyId: family.id,
        serialNumber: marriageData.serialNumber || serialNumber,
        childrenIds: marriageData.childrenIds || [],
        createdAt: now,
        updatedAt: now
      };

      const currentMembers = membersRef.current;
      const currentMarriages = marriagesRef.current;
      const updatedMarriages = [...currentMarriages, newMarriage];

      // Link marriage ID to husband & wife and set marital state.
      // Use refs so a newly-created member can be married in the same save transaction.
      const updatedMembers = currentMembers.map(m => {
        if (m.id === newMarriage.husbandId || m.id === newMarriage.wifeId) {
          const currentMids = m.marriageIds || [];
          return {
            ...m,
            marriageIds: currentMids.includes(newId) ? currentMids : [...currentMids, newId],
            isUnmarried: false
          };
        }
        return m;
      });

      const reconciled = reconcileCanonicalRelationships(updatedMembers, updatedMarriages);
      const normalized = synchronizeComputedGenerations(reconciled.members, reconciled.marriages, family.rootAncestorId);
      await storage.saveMarriages(family.id, reconciled.marriages);
      await storage.saveMembers(family.id, normalized.members);
      marriagesRef.current = reconciled.marriages;
      membersRef.current = normalized.members;
      setMarriages(reconciled.marriages);
      setMembers(normalized.members);

      return reconciled.marriages.find(m => m.id === newId) || newMarriage;
    },
    [family.id, family.rootAncestorId, requirePermission]
  );

  const updateMarriage = useCallback(
    async (updated: MarriageRecord) => {
      requirePermission('canEditMarriage');
      const now = new Date().toISOString();
      const updatedRecord: MarriageRecord = { ...updated, updatedAt: now };
      const updatedList = marriagesRef.current.map(m => (m.id === updated.id ? updatedRecord : m));
      const reconciled = reconcileCanonicalRelationships(membersRef.current, updatedList);
      const normalized = synchronizeComputedGenerations(reconciled.members, reconciled.marriages, family.rootAncestorId);
      await storage.saveMarriages(family.id, reconciled.marriages);
      await storage.saveMembers(family.id, normalized.members);
      marriagesRef.current = reconciled.marriages;
      membersRef.current = normalized.members;
      setMarriages(reconciled.marriages);
      setMembers(normalized.members);
    },
    [family.id, family.rootAncestorId, requirePermission]
  );

  const deleteMarriage = useCallback(
    async (marriageId: string) => {
      requirePermission('canDeleteMarriage');
      const marriageToDelete = marriagesRef.current.find(m => m.id === marriageId);
      if (!marriageToDelete) return;
      const recycleEntry: RecycleBinEntry = {
        id: `recycle-marriage-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`,
        familyId: family.id,
        entityType: 'marriage',
        entityId: marriageId,
        label: `বিবাহ: ${marriageToDelete.serialNumber || marriageId}`,
        deletedAt: new Date().toISOString(),
        deletedBy: userAccount.nameBn || userAccount.name,
        payload: { marriage: marriageToDelete }
      };
      await storage.saveRecycleEntry(recycleEntry);
      const updatedMarriages = marriagesRef.current.filter(m => m.id !== marriageId);
      // Remove marriageId from members
      const updatedMembers = membersRef.current.map(m => ({
        ...m,
        marriageIds: (m.marriageIds || []).filter(mid => mid !== marriageId)
      }));
      const normalized = synchronizeComputedGenerations(updatedMembers, updatedMarriages, family.rootAncestorId);

      marriagesRef.current = updatedMarriages;
      membersRef.current = normalized.members;
      setMarriages(updatedMarriages);
      setMembers(normalized.members);
      await storage.saveMarriages(family.id, updatedMarriages);
      await storage.saveMembers(family.id, normalized.members);
    },
    [family.id, family.rootAncestorId, requirePermission, userAccount]
  );

  // --- Family & Branch Operations

  const addBranch = useCallback(
    async (branch: Branch) => {
      requirePermission('canManageFamily');
      const updatedBranches = [...(family.branches || []), branch];
      const updatedFamily = { ...family, branches: updatedBranches, updatedAt: new Date().toISOString() };
      setFamily(updatedFamily);
      await storage.saveFamily(updatedFamily);
    },
    [family, requirePermission]
  );

  const updateFamily = useCallback(
    async (updated: Partial<Family>) => {
      requirePermission('canManageFamily');
      const newFamily = { ...family, ...updated, settings: { ...DEFAULT_FAMILY_SETTINGS, ...(family.settings || {}), ...(updated.settings || {}) }, updatedAt: new Date().toISOString() };
      setFamily(newFamily);
      setAllFamilies(prev => prev.map(f => (f.id === newFamily.id ? newFamily : f)));
      await storage.saveFamily(newFamily);
    },
    [family, requirePermission]
  );

  const switchFamily = useCallback(
    async (familyId: string) => {
      requirePermission('canSwitchFamilies');
      if (!allFamilies.some(f => f.id === familyId)) throw new Error('Family access denied or family not found.');
      setIsLoading(true);
      try {
        storage.setActiveFamilyId(familyId);
        const rawTarget = allFamilies.find(f => f.id === familyId) || (await storage.getFamilies()).find(f => f.id === familyId) || family;
        const target = { ...rawTarget, settings: { ...DEFAULT_FAMILY_SETTINGS, ...(rawTarget.settings || {}) } };
        setAllFamilies(prev => prev.some(f => f.id === target.id) ? prev : [...prev, target]);
        setFamily(target);
        setLanguageState(target.settings?.language || 'bn');
        const nextTheme = target.settings?.theme || 'heritage';
        setThemeState(nextTheme);
        applyTheme(nextTheme);
        window.dispatchEvent(new CustomEvent('bongshokotha:family-theme-changed', { detail: { themeId: nextTheme } }));

        const rawMembers = await storage.getMembers(familyId);
        const newMarriages = await storage.getMarriages(familyId);
        const normalized = synchronizeComputedGenerations(rawMembers, newMarriages, target.rootAncestorId);
        const newMembers = normalized.members;
        if (normalized.changed) await storage.saveMembers(familyId, newMembers);
        const newArchive = await storage.getArchiveRecords(familyId);
        const newRecycleBin = await storage.getRecycleBin(familyId);
        membersRef.current = newMembers;
        marriagesRef.current = newMarriages;
        setMembers(newMembers);
        setMarriages(newMarriages);
        setArchiveRecords(newArchive);
        setRecycleBin(newRecycleBin);
      } finally {
        setIsLoading(false);
      }
    },
    [allFamilies, family, requirePermission]
  );

  const renameFamilySpace = useCallback(async (familyId: string, name: string) => {
    requirePermission('canManageFamily');
    const existing = allFamilies.find(f => f.id === familyId);
    if (!existing) throw new Error('Family space not found.');
    const renamed = { ...existing, name, banglaName: name, updatedAt: new Date().toISOString() };
    await storage.saveFamily(renamed);
    setAllFamilies(prev => prev.map(f => f.id === familyId ? renamed : f));
    if (family.id === familyId) setFamily(renamed);
  }, [allFamilies, family.id, requirePermission]);

  const deleteFamilySpace = useCallback(async (familyId: string) => {
    requirePermission('canManageFamily');
    if (familyId === 'family-sample-choudhury') throw new Error('The demo family space is protected.');
    const latestFamilies = await storage.getFamilies();
    const remaining = latestFamilies.filter(f => f.id !== familyId);
    if (!latestFamilies.some(f => f.id === familyId)) throw new Error('Family space not found.');
    if (remaining.length < 1) throw new Error('At least one family space must remain.');
    if (family.id === familyId) await switchFamily(remaining[0].id);
    await storage.deleteFamilySpace(familyId);
    setAllFamilies(remaining);
  }, [family.id, requirePermission, switchFamily]);

  // --- Archive & Document Intelligence Operations (PART 3) ---

  const addArchiveRecord = useCallback(
    async (
      recordData: Omit<ArchiveRecord, 'id' | 'createdAt' | 'updatedAt' | 'history'> & { historyNote?: string }
    ): Promise<ArchiveRecord> => {
      requirePermission('canUploadArchive');
      const now = new Date().toISOString();
      const newId = `arc-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
      const { historyNote, ...cleanData } = recordData;

      const newRecord: ArchiveRecord = {
        ...cleanData,
        id: newId,
        relatedFamilyId: family.id,
        createdAt: now,
        updatedAt: now,
        history: [
          {
            id: `hist-${Date.now()}`,
            action: 'uploaded',
            timestamp: now,
            user: cleanData.uploader || 'পরিবার সংগ্রাহক',
            details: historyNote || 'আর্কাইভে নতুন প্রমাণপত্র/মিডিয়া নথিবদ্ধ করা হয়েছে।'
          }
        ]
      };

      await storage.saveArchiveRecord(newRecord);
      setArchiveRecords(prev => [newRecord, ...prev]);
      return newRecord;
    },
    [family.id, requirePermission]
  );

  const updateArchiveRecord = useCallback(
    async (record: ArchiveRecord, historyNote?: string) => {
      requirePermission('canUploadArchive');
      if (record.relatedFamilyId !== family.id) throw new Error('Archive access denied.');
      const now = new Date().toISOString();
      const updatedRecord: ArchiveRecord = {
        ...record,
        updatedAt: now,
        history: [
          ...(record.history || []),
          {
            id: `hist-${Date.now()}`,
            action: 'edited',
            timestamp: now,
            user: 'সিস্টেম ব্যবহারকারী',
            details: historyNote || 'নথির বিবরণ বা সম্পর্ক হালনাগাদ করা হয়েছে।'
          }
        ]
      };

      await storage.saveArchiveRecord(updatedRecord);
      setArchiveRecords(prev => prev.map(r => (r.id === record.id ? updatedRecord : r)));
    },
    [family.id, requirePermission]
  );

  const deleteArchiveRecord = useCallback(
    async (recordId: string) => {
      requirePermission('canDeleteArchive');
      await storage.deleteArchiveRecord(family.id, recordId);
      setArchiveRecords(prev => prev.filter(r => r.id !== recordId));
    },
    [family.id, requirePermission]
  );

  const batchAddArchiveRecords = useCallback(
    async (
      records: (Omit<ArchiveRecord, 'id' | 'createdAt' | 'updatedAt' | 'history'> & { historyNote?: string })[]
    ) => {
      requirePermission('canUploadArchive');
      const now = new Date().toISOString();
      const newRecords: ArchiveRecord[] = records.map((r, idx) => {
        const newId = `arc-${Date.now().toString(36)}-${idx}-${Math.random().toString(36).substring(2, 6)}`;
        const { historyNote, ...clean } = r;
        return {
          ...clean,
          id: newId,
          relatedFamilyId: family.id,
          createdAt: now,
          updatedAt: now,
          history: [
            {
              id: `hist-${Date.now()}-${idx}`,
              action: 'uploaded',
              timestamp: now,
              user: clean.uploader || 'ব্যাচ আপলোডার',
              details: historyNote || 'একত্রে একাধিক নথি ডিজিটাল আর্কাইভে যুক্ত করা হয়েছে।'
            }
          ]
        };
      });

      const combined = [...newRecords, ...archiveRecords];
      await storage.saveArchiveRecords(family.id, combined);
      setArchiveRecords(combined);
    },
    [family.id, archiveRecords, requirePermission]
  );

  const linkDocumentToMember = useCallback(
    async (recordId: string, memberId: string, role: string = 'সংযুক্ত সদস্য') => {
      requirePermission('canUploadArchive');
      const record = archiveRecords.find(r => r.id === recordId);
      if (!record) return;

      const existingIds = new Set(record.relatedMemberIds || []);
      existingIds.add(memberId);
      const updatedRoles = { ...(record.memberRoles || {}), [memberId]: role };

      const now = new Date().toISOString();
      const updated: ArchiveRecord = {
        ...record,
        relatedMemberIds: Array.from(existingIds),
        memberRoles: updatedRoles,
        updatedAt: now,
        history: [
          ...(record.history || []),
          {
            id: `hist-${Date.now()}`,
            action: 'linked',
            timestamp: now,
            user: 'পরিবার গবেষক',
            details: `সদস্য আইডি ${memberId} এর সাথে সম্পর্ক স্থাপন (${role})।`
          }
        ]
      };

      await storage.saveArchiveRecord(updated);
      setArchiveRecords(prev => prev.map(r => (r.id === recordId ? updated : r)));
    },
    [archiveRecords, requirePermission]
  );

  const unlinkDocumentFromMember = useCallback(
    async (recordId: string, memberId: string) => {
      requirePermission('canDeleteArchive');
      const record = archiveRecords.find(r => r.id === recordId);
      if (!record) return;

      const updatedIds = (record.relatedMemberIds || []).filter(id => id !== memberId);
      const updatedRoles = { ...(record.memberRoles || {}) };
      delete updatedRoles[memberId];

      const now = new Date().toISOString();
      const updated: ArchiveRecord = {
        ...record,
        relatedMemberIds: updatedIds,
        memberRoles: updatedRoles,
        updatedAt: now,
        history: [
          ...(record.history || []),
          {
            id: `hist-${Date.now()}`,
            action: 'unlinked',
            timestamp: now,
            user: 'পরিবার গবেষক',
            details: `সদস্য আইডি ${memberId} এর সাথে সংযোগ বিচ্ছিন্ন করা হয়েছে।`
          }
        ]
      };

      await storage.saveArchiveRecord(updated);
      setArchiveRecords(prev => prev.map(r => (r.id === recordId ? updated : r)));
    },
    [archiveRecords, requirePermission]
  );

  const createNewFamily = useCallback(
    async (name: string, banglaName: string, description: string = ''): Promise<Family> => {
      requirePermission('canCreateFamily');
      const now = new Date().toISOString();
      const newId = `fam-${Date.now().toString(36)}`;
      const defaultBranch: Branch = {
        id: `branch-main-${newId}`,
        name: 'Main Branch',
        banglaName: 'মূল ধারা',
        color: '#15803d',
        description: 'প্রধান পারিবারিক শাখা'
      };

      const newFamily: Family = {
        id: newId,
        name,
        banglaName: banglaName || name,
        description,
        createdAt: now,
        updatedAt: now,
        branches: [defaultBranch],
        settings: {
          language,
          theme,
          defaultBranchId: defaultBranch.id,
          enableBengaliCalendar: true,
          enableHijriCalendar: false,
          enablePrivacyMasking: false
        },
        backupHistory: []
      };

      await storage.saveFamily(newFamily);
      setAllFamilies(prev => [...prev, newFamily]);
      await switchFamily(newId);
      return newFamily;
    },
    [language, theme, switchFamily, requirePermission]
  );

  // --- Calculations & Tools ---

  const calculateRelationship = useCallback(
    (personAId: string, personBId: string): RelationshipResult | null => {
      return findRelationship(personAId, personBId, members, marriages, generations);
    },
    [members, marriages, generations]
  );

  const runRepair = useCallback(async (): Promise<RepairResult> => {
    requirePermission('canRunIntegrityRepair');
    const result = repairAllLinks(members, marriages);
    if (result.repairedCount > 0) {
      const normalized = synchronizeComputedGenerations(result.updatedMembers, result.updatedMarriages, family.rootAncestorId);
      setMembers(normalized.members);
      setMarriages(result.updatedMarriages);
      await storage.saveMembers(family.id, normalized.members);
      await storage.saveMarriages(family.id, result.updatedMarriages);
    }
    return result;
  }, [members, marriages, family.id, family.rootAncestorId, requirePermission]);

  const recalculateAndPersistGenerations = useCallback(async () => {
    const normalized = synchronizeComputedGenerations(members, marriages, family.rootAncestorId);
    if (normalized.changed) {
      setMembers(normalized.members);
      await storage.saveMembers(family.id, normalized.members);
    }
    const maxGeneration = Math.max(1, ...Array.from(normalized.generations.values()));
    return { changed: normalized.changed, maxGeneration };
  }, [members, marriages, family.id, family.rootAncestorId]);

  const exportArchiveJSON = useCallback(() => {
    requirePermission('canExportFullData');
    void (async () => {
      const exportedAt = new Date().toISOString();
      const familySnapshot = { ...family, branches: family.branches || [] };
      const archiveData: BongshokothaArchive = {
        format: 'BONGSHOKOTHA_ARCHIVE',
        version: '1.2',
        exportedAt,
        app: 'Bongshokotha / বংশকথা',
        family: familySnapshot,
        members: structuredClone(members),
        marriages: structuredClone(marriages),
        branches: structuredClone(family.branches || []),
        archiveRecords: structuredClone(archiveRecords || []),
        generationSnapshot: Object.fromEntries(generations.entries()),
        recycleBin: structuredClone(recycleBin),
      };
      const checksum = await computeArchiveChecksum(archiveData);
      archiveData.integrity = { algorithm: 'SHA-256', checksum, payloadVersion: '1.1' };

      // Keep an application-side backup history record without altering the snapshot checksum.
      const historyRecord = {
        id: `backup-${Date.now().toString(36)}`,
        timestamp: exportedAt,
        label: 'Manual full backup',
        memberCount: members.length,
        marriageCount: marriages.length,
        checksum,
      };
      const updatedFamily = {
        ...family,
        backupHistory: [...(family.backupHistory || []).slice(-49), historyRecord],
        updatedAt: new Date().toISOString(),
      };
      setFamily(updatedFamily);
      await storage.saveFamily(updatedFamily);

      const json = JSON.stringify(archiveData, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const safeName = (family.banglaName || family.name || 'Family').replace(/[^\p{L}\p{N}_-]+/gu, '_');
      const dateStr = exportedAt.slice(0, 10);
      link.href = url;
      link.download = `Bongshokotha_${safeName}_${dateStr}.bkf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    })().catch((error) => {
      console.error('Bongshokotha backup export failed:', error);
    });
  }, [family, members, marriages, archiveRecords, generations, recycleBin, requirePermission]);

  const importArchiveJSON = useCallback(
    async (
      jsonString: string,
      strategy: 'merge_preserve' | 'overwrite_all' | 'keep_existing' = 'merge_preserve'
    ): Promise<{ success: boolean; message: string }> => {
      try {
        requirePermission(strategy === 'overwrite_all' ? 'canRestoreData' : 'canImportData');
        const parsed = JSON.parse(jsonString);
        const check = storage.validateArchive(parsed);
        if (!check.isValid) {
          return { success: false, message: check.error || 'Invalid archive schema' };
        }

        let archive = parsed as BongshokothaArchive;

        if (archive.integrity?.algorithm === 'SHA-256') {
          const expected = archive.integrity.checksum;
          const actual = await computeArchiveChecksum(archivePayloadWithoutIntegrity(archive));
          if (expected !== actual) {
            return { success: false, message: 'ব্যাকআপের integrity checksum মেলেনি। ফাইলটি পরিবর্তিত/অসম্পূর্ণ হতে পারে; নিরাপত্তার জন্য restore বন্ধ করা হয়েছে।' };
          }
        }

        // Normalize legacy/imported records before merge/restore. Missing person or marriage IDs
        // receive new stable UUIDs; existing IDs are preserved. Duplicate non-empty person IDs
        // are rejected because silently rewriting them could corrupt relationship references.
        const rawImportedMembers = Array.isArray(archive.members) ? archive.members : [];
        const seenImportedIds = new Set<string>();
        for (const rawMember of rawImportedMembers) {
          const id = typeof rawMember?.id === 'string' ? rawMember.id.trim() : '';
          if (id && seenImportedIds.has(id)) {
            return { success: false, message: 'ব্যাকআপে একই Unique ID একাধিক সদস্যের জন্য আছে। সম্পর্ক নষ্ট হওয়ার ঝুঁকি থাকায় Import বন্ধ করা হয়েছে। আগে ডুপ্লিকেট ID ঠিক করুন।' };
          }
          if (id) seenImportedIds.add(id);
        }
        const importedMembersMissingId = rawImportedMembers.filter(m => !m?.id || !String(m.id).trim()).length;
        const stableLegacyId = (raw: unknown, index: number, prefix: string) => {
          // Deterministic for the same legacy backup and row order so importing that same
          // ID-less backup again does not generate a fresh person ID on every attempt.
          const input = `${archive.family?.id || 'family'}|${index}|${JSON.stringify(raw)}`;
          let h1 = 0x811c9dc5, h2 = 0x9e3779b9;
          for (let i = 0; i < input.length; i++) {
            const c = input.charCodeAt(i);
            h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
            h2 = Math.imul(h2 ^ (c + i), 0x85ebca6b) >>> 0;
          }
          return `${prefix}-${h1.toString(16).padStart(8, '0')}${h2.toString(16).padStart(8, '0')}`;
        };
        archive = {
          ...archive,
          members: rawImportedMembers.map((m, index) => {
            const normalized = normalizeMemberRecord(m);
            return m?.id && String(m.id).trim() ? normalized : { ...normalized, id: stableLegacyId(m, index, 'legacy') };
          }),
          marriages: (Array.isArray(archive.marriages) ? archive.marriages : []).map((m, index) => {
            const normalized = normalizeMarriageRecord(m);
            return m?.id && String(m.id).trim() ? normalized : { ...normalized, id: stableLegacyId(m, index, 'legacy-marriage') };
          })
        };

        if (strategy === 'keep_existing') {
          // Keep existing on conflict: only append completely new records
          const currentMemberIds = new Set(members.map(m => m.id));
          const newMembersToAdd = (archive.members || []).filter(m => !currentMemberIds.has(m.id));
          const mergedMembers = [...members, ...newMembersToAdd];

          const currentMarriageIds = new Set(marriages.map(m => m.id));
          const newMarriagesToAdd = (archive.marriages || []).filter(m => !currentMarriageIds.has(m.id));
          const mergedMarriages = [...marriages, ...newMarriagesToAdd];

          const currentArchiveIds = new Set(archiveRecords.map(r => r.id));
          const newArchiveRecords = (archive.archiveRecords || []).filter(r => !currentArchiveIds.has(r.id));
          const mergedArchive = [...archiveRecords, ...newArchiveRecords];

          // Automatic restore repair: first rebuild reciprocal links and marriage-child
          // links, then recalculate generation from the repaired graph. This prevents
          // stale backup ordering/generation metadata from controlling the UI.
          const repairedMerged = repairAllLinks(mergedMembers, mergedMarriages);
          const normalizedMerged = synchronizeComputedGenerations(repairedMerged.updatedMembers, repairedMerged.updatedMarriages, family.rootAncestorId);
          const repairedMergedMarriages = repairedMerged.updatedMarriages;
          await storage.saveMembers(family.id, normalizedMerged.members);
          await storage.saveMarriages(family.id, repairedMergedMarriages);
          await storage.saveArchiveRecords(family.id, mergedArchive);
          const currentRecycleIds = new Set(recycleBin.map(r => r.id));
          const mergedRecycle = [...recycleBin, ...(archive.recycleBin || []).filter(r => !currentRecycleIds.has(r.id))];
          for (const entry of (archive.recycleBin || []).filter(r => !currentRecycleIds.has(r.id))) await storage.saveRecycleEntry(entry);

          setMembers(normalizedMerged.members);
          setMarriages(repairedMergedMarriages);
          setArchiveRecords(mergedArchive);
          setRecycleBin(mergedRecycle);

          return {
            success: true,
            message: `বিদ্যমান তথ্য অগ্রাধিকার সহ আমদানি সম্পন্ন! (নতুন সদস্য: +${newMembersToAdd.length}, নতুন দলিল: +${newArchiveRecords.length}, নতুন ID তৈরি: ${importedMembersMissingId})`
          };
        }

        if (strategy === 'merge_preserve') {
          // Rule: "Never silently overwrite verified information."
          const currentMembersMap = new Map(members.map(m => [m.id, { ...m }]));
          let newMembersAdded = 0;
          let fieldsEnriched = 0;

          archive.members.forEach(incoming => {
            const existing = currentMembersMap.get(incoming.id);
            if (!existing) {
              currentMembersMap.set(incoming.id, incoming);
              newMembersAdded++;
            } else {
              // Non-destructive enrich: only fill missing values
              if (!existing.nickname && incoming.nickname) {
                existing.nickname = incoming.nickname;
                fieldsEnriched++;
              }
              if (!existing.biography && incoming.biography) {
                existing.biography = incoming.biography;
                fieldsEnriched++;
              }
              if (!existing.identityDocs?.nidNumber && incoming.identityDocs?.nidNumber) {
                existing.identityDocs = {
                  ...existing.identityDocs,
                  nidNumber: incoming.identityDocs.nidNumber
                };
                fieldsEnriched++;
              }
              if (!existing.identityDocs?.birthRegistrationNumber && incoming.identityDocs?.birthRegistrationNumber) {
                existing.identityDocs = {
                  ...existing.identityDocs,
                  birthRegistrationNumber: incoming.identityDocs.birthRegistrationNumber
                };
                fieldsEnriched++;
              }
              currentMembersMap.set(incoming.id, existing);
            }
          });

          const mergedMembers = Array.from(currentMembersMap.values());

          // Merge marriages non-destructively
          const currentMarriageIds = new Set(marriages.map(m => m.id));
          const mergedMarriages = [...marriages];
          (archive.marriages || []).forEach(incMar => {
            if (!currentMarriageIds.has(incMar.id)) {
              mergedMarriages.push(incMar);
              currentMarriageIds.add(incMar.id);
            }
          });

          // Merge archive records
          const currentArchiveIds = new Set(archiveRecords.map(r => r.id));
          const mergedArchive = [...archiveRecords];
          (archive.archiveRecords || []).forEach(incRec => {
            if (!currentArchiveIds.has(incRec.id)) {
              mergedArchive.push(incRec);
              currentArchiveIds.add(incRec.id);
            }
          });

          const repairedMerged = repairAllLinks(mergedMembers, mergedMarriages);
          const normalizedMerged = synchronizeComputedGenerations(repairedMerged.updatedMembers, repairedMerged.updatedMarriages, family.rootAncestorId);
          const repairedMergedMarriages = repairedMerged.updatedMarriages;
          await storage.saveMembers(family.id, normalizedMerged.members);
          await storage.saveMarriages(family.id, repairedMergedMarriages);
          await storage.saveArchiveRecords(family.id, mergedArchive);
          const currentRecycleIds = new Set(recycleBin.map(r => r.id));
          const mergedRecycle = [...recycleBin, ...(archive.recycleBin || []).filter(r => !currentRecycleIds.has(r.id))];
          for (const entry of (archive.recycleBin || []).filter(r => !currentRecycleIds.has(r.id))) await storage.saveRecycleEntry(entry);

          setMembers(normalizedMerged.members);
          setMarriages(repairedMergedMarriages);
          setArchiveRecords(mergedArchive);
          setRecycleBin(mergedRecycle);

          return {
            success: true,
            message: `অক্ষুণ্ণ একত্রীকরণ সফল হয়েছে! নতুন সদস্য: +${newMembersAdded}, সমৃদ্ধ ফিল্ড: ${fieldsEnriched}, স্বয়ংক্রিয় repair: ${repairedMerged.repairedCount})`
          };
        }

        // Full overwrite strategy. Prefer the portable generation snapshot when present,
        // then immediately normalize from the restored relationship graph.
        const restoredMembers = (archive.members || []).map(m => {
          const snap = archive.generationSnapshot?.[m.id];
          return m.generationMode === 'manual' || !Number.isFinite(snap) ? m : { ...m, computedGeneration: snap };
        });
        const repairedRestore = repairAllLinks(restoredMembers, archive.marriages || []);
        const normalizedRestore = synchronizeComputedGenerations(repairedRestore.updatedMembers, repairedRestore.updatedMarriages, archive.family.rootAncestorId);
        const repairedRestoreMarriages = repairedRestore.updatedMarriages;
        const repairedFamily = {
          ...archive.family,
          updatedAt: new Date().toISOString(),
          settings: { ...archive.family.settings, syncStatus: 'pending' as const }
        };
        await storage.saveFamily(repairedFamily);
        await storage.saveMembers(repairedFamily.id, normalizedRestore.members);
        await storage.saveMarriages(repairedFamily.id, repairedRestoreMarriages);
        if (archive.archiveRecords) {
          await storage.saveArchiveRecords(archive.family.id, archive.archiveRecords);
          setArchiveRecords(archive.archiveRecords);
        }
        if (Array.isArray(archive.recycleBin)) {
          await storage.clearRecycleBin(archive.family.id);
          for (const entry of archive.recycleBin) await storage.saveRecycleEntry(entry);
          setRecycleBin(archive.recycleBin);
        }

        // Update active
        storage.setActiveFamilyId(repairedFamily.id);
        setFamily(repairedFamily);
        setMembers(normalizedRestore.members);
        setMarriages(repairedRestoreMarriages);
        setAllFamilies(prev => {
          const idx = prev.findIndex(f => f.id === archive.family.id);
          if (idx >= 0) {
            const next = [...prev];
            next[idx] = repairedFamily;
            return next;
          }
          return [...prev, repairedFamily];
        });

        return {
          success: true,
          message: `স্মার্ট পুনরুদ্ধার সম্পন্ন হয়েছে! (${normalizedRestore.members.length} সদস্য, ${repairedRestoreMarriages.length} বৈবাহিক রেকর্ড, ${archive.archiveRecords?.length || 0} পারিবারিক আর্কাইভের দলিল, স্বয়ংক্রিয় repair: ${repairedRestore.repairedCount})`
        };
      } catch (e: unknown) {
        return { success: false, message: `ফাইল রিড করতে ব্যর্থ: ${e instanceof Error ? e.message : 'ত্রুটি'}` };
      }
    },
    [family, members, marriages, archiveRecords, generations, recycleBin, requirePermission]
  );

  const exportGedcomFile = useCallback(() => {
    requirePermission('canExportFullData');
    const gedcomContent = exportToGedcom(family, members, marriages);
    const blob = new Blob([gedcomContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = (family.banglaName || family.name).replace(/\s+/g, '_');
    const dateStr = new Date().toISOString().slice(0, 10);
    link.href = url;
    link.download = `Bongshokotha_${safeName}_${dateStr}.ged`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [family, members, marriages, requirePermission]);

  const importGedcomText = useCallback(
    async (text: string): Promise<{ success: boolean; message: string; count: number }> => {
      requirePermission('canImportData');
      try {
        const parsed = parseGedcom(text);
        if (!parsed.members.length) {
          return { success: false, message: 'GEDCOM ফাইলে কোনো সদস্য পাওয়া যায়নি।', count: 0 };
        }

        const now = new Date().toISOString();
        const incomingMembers: Member[] = parsed.members.map(m => {
          const isDeceased = m.death?.isDeceased ?? false;
          return {
            id: m.id || `indi-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            fullName: m.fullName || 'Unknown Ancestor',
            banglaName: m.banglaName || m.fullName || 'অজ্ঞাত পূর্বপুরুষ',
            englishName: m.englishName || m.fullName || 'Unknown Ancestor',
            nickname: m.nickname,
            gender: m.gender || 'other',
            isLiving: !isDeceased,
            birthOrigin: 'born_in_family',
            marriageOrigin: false,
            branchId: family.branches[0]?.id || 'branch-main',
            biography: m.biography,
            birth: m.birth || { date: { precision: 'unknown' }, place: {} },
            death: m.death || { isDeceased: false, date: { precision: 'unknown' }, place: {} },
            identityDocs: m.identityDocs || { verificationStatus: 'unverified' },
            fatherId: m.fatherId,
            motherId: m.motherId,
            marriageIds: [],
            isUnmarried: false,
            createdAt: now,
            updatedAt: now
          };
        });

        const incomingMarriages: MarriageRecord[] = parsed.marriages.map((mar, i) => ({
          id: mar.id || `mar-${Date.now()}-${i}`,
          serialNumber: mar.serialNumber || `MR-${marriages.length + i + 1}`,
          husbandId: mar.husbandId || '',
          wifeId: mar.wifeId || '',
          marriageDate: mar.marriageDate || { precision: 'unknown' },
          marriagePlace: mar.marriagePlace || {},
          status: mar.status || 'current',
          childrenIds: mar.childrenIds || [],
          createdAt: now,
          updatedAt: now
        }));

        // Link marriage IDs back to members
        incomingMarriages.forEach(mar => {
          const husb = incomingMembers.find(m => m.id === mar.husbandId);
          if (husb && !husb.marriageIds.includes(mar.id)) husb.marriageIds.push(mar.id);
          const wife = incomingMembers.find(m => m.id === mar.wifeId);
          if (wife && !wife.marriageIds.includes(mar.id)) wife.marriageIds.push(mar.id);
        });

        // Non-destructive merge with current members
        const currentMembersMap = new Map(members.map(m => [m.id, m]));
        let addedCount = 0;
        incomingMembers.forEach(im => {
          if (!currentMembersMap.has(im.id)) {
            currentMembersMap.set(im.id, im);
            addedCount++;
          }
        });

        const newMemberList = Array.from(currentMembersMap.values());
        const newMarriageList = [...marriages, ...incomingMarriages];

        await storage.saveMembers(family.id, newMemberList);
        await storage.saveMarriages(family.id, newMarriageList);
        setMembers(newMemberList);
        setMarriages(newMarriageList);

        return {
          success: true,
          message: `GEDCOM 5.5.1 সফলভাবে অন্তর্ভুক্ত হয়েছে! (${addedCount} নতুন পূর্বপুরুষ যুক্ত করা হয়েছে)`,
          count: addedCount
        };
      } catch (err: unknown) {
        return {
          success: false,
          message: `GEDCOM পার্স করতে ব্যর্থ: ${err instanceof Error ? err.message : 'ত্রুটি'}`,
          count: 0
        };
      }
    },
    [family, members, marriages, requirePermission]
  );

  const importUniversalDataset = useCallback(
    async (
      dataset: { members: Member[]; marriages: MarriageRecord[]; branches?: Branch[] },
      strategy: 'merge_preserve' | 'overwrite_all' = 'merge_preserve'
    ): Promise<{ success: boolean; message: string; count: number }> => {
      try {
        requirePermission(strategy === 'overwrite_all' ? 'canRestoreData' : 'canImportData');
        if (!dataset.members || dataset.members.length === 0) {
          return { success: false, message: 'আমদানি করার মতো কোনো সদস্য পাওয়া যায়নি।', count: 0 };
        }

        if (strategy === 'overwrite_all') {
          await storage.saveMembers(family.id, dataset.members);
          await storage.saveMarriages(family.id, dataset.marriages);
          setMembers(dataset.members);
          setMarriages(dataset.marriages);
          return {
            success: true,
            message: `সকল তথ্য প্রতিস্থাপন করে মোট ${dataset.members.length} জন সদস্য ও ${dataset.marriages.length} টি সম্পর্ক সফলভাবে সংরক্ষিত হয়েছে।`,
            count: dataset.members.length
          };
        }

        // Non-destructive smart merge
        const currentMembersMap = new Map(members.map(m => [m.id, { ...m }]));
        let newMembersAdded = 0;
        let fieldsEnriched = 0;

        dataset.members.forEach(incoming => {
          const existing = currentMembersMap.get(incoming.id);
          if (!existing) {
            currentMembersMap.set(incoming.id, incoming);
            newMembersAdded++;
          } else {
            if (!existing.banglaName && incoming.banglaName) { existing.banglaName = incoming.banglaName; fieldsEnriched++; }
            if (!existing.englishName && incoming.englishName) { existing.englishName = incoming.englishName; fieldsEnriched++; }
            if (!existing.fatherId && incoming.fatherId) { existing.fatherId = incoming.fatherId; fieldsEnriched++; }
            if (!existing.motherId && incoming.motherId) { existing.motherId = incoming.motherId; fieldsEnriched++; }
            if (!existing.nickname && incoming.nickname) { existing.nickname = incoming.nickname; fieldsEnriched++; }
            if (!existing.biography && incoming.biography) { existing.biography = incoming.biography; fieldsEnriched++; }
            if (!existing.importantInformation && incoming.importantInformation) { existing.importantInformation = incoming.importantInformation; fieldsEnriched++; }
            if (!existing.identityDocs?.nidNumber && incoming.identityDocs?.nidNumber) {
              existing.identityDocs = { ...existing.identityDocs, nidNumber: incoming.identityDocs.nidNumber };
              fieldsEnriched++;
            }
            if (!existing.identityDocs?.birthRegistrationNumber && incoming.identityDocs?.birthRegistrationNumber) {
              existing.identityDocs = { ...existing.identityDocs, birthRegistrationNumber: incoming.identityDocs.birthRegistrationNumber };
              fieldsEnriched++;
            }
            currentMembersMap.set(incoming.id, existing);
          }
        });

        const mergedMembers = Array.from(currentMembersMap.values());
        const currentMarriageIds = new Set(marriages.map(m => m.id));
        const mergedMarriages = [...marriages];
        (dataset.marriages || []).forEach(incMar => {
          if (!currentMarriageIds.has(incMar.id)) {
            mergedMarriages.push(incMar);
            currentMarriageIds.add(incMar.id);
          }
        });

        await storage.saveMembers(family.id, mergedMembers);
        await storage.saveMarriages(family.id, mergedMarriages);
        setMembers(mergedMembers);
        setMarriages(mergedMarriages);

        return {
          success: true,
          message: `স্বয়ংক্রিয় আমদানি সফলভাবে সম্পন্ন হয়েছে! (নতুন সদস্য: +${newMembersAdded}, সমৃদ্ধ ফিল্ড: ${fieldsEnriched}টি, বৈবাহিক সম্পর্ক: ${dataset.marriages?.length || 0}টি)`,
          count: newMembersAdded
        };
      } catch (err: unknown) {
        return {
          success: false,
          message: `আমদানিতে ত্রুটি: ${err instanceof Error ? err.message : 'অজ্ঞাত ত্রুটি'}`,
          count: 0
        };
      }
    },
    [family.id, members, marriages, requirePermission]
  );

  const loadSampleDataset = useCallback(async () => {
    requirePermission('canCreateFamily');
    // Preserve as separate family space, never overwrite existing custom family!
    await storage.saveFamily(SAMPLE_FAMILY);
    await storage.saveMembers(SAMPLE_FAMILY.id, SAMPLE_MEMBERS);
    await storage.saveMarriages(SAMPLE_FAMILY.id, SAMPLE_MARRIAGES);
    await storage.saveArchiveRecords(SAMPLE_FAMILY.id, SAMPLE_ARCHIVE_RECORDS);

    storage.setActiveFamilyId(SAMPLE_FAMILY.id);
    setFamily(SAMPLE_FAMILY);
    setMembers(SAMPLE_MEMBERS);
    setMarriages(SAMPLE_MARRIAGES);
    setArchiveRecords(SAMPLE_ARCHIVE_RECORDS);
    setAllFamilies(prev => {
      if (!prev.some(f => f.id === SAMPLE_FAMILY.id)) {
        return [SAMPLE_FAMILY, ...prev];
      }
      return prev;
    });
  }, [requirePermission]);

  const resetToFreshState = useCallback(async () => {
    requirePermission('canFactoryReset');
    await storage.factoryReset();
    const freshFamily: Family = {
      id: `fam-${Date.now()}`,
      name: '',
      banglaName: '',
      description: '',
      crestUrl: '',
      branches: [
        { id: 'branch-main', name: 'Main Branch', banglaName: 'মূল শাখা', color: '#b45309' }
      ],
      settings: {
        theme: 'heritage',
        language: 'bn',
        defaultBranchId: 'branch-main',
        enableBengaliCalendar: true,
        enableHijriCalendar: true,
        enablePrivacyMasking: false
      },
      backupHistory: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await storage.saveFamily(freshFamily);
    await storage.saveMembers(freshFamily.id, []);
    await storage.saveMarriages(freshFamily.id, []);
    await storage.saveArchiveRecords(freshFamily.id, []);
    storage.setActiveFamilyId(freshFamily.id);

    setFamily(freshFamily);
    setAllFamilies([freshFamily]);
    setMembers([]);
    setMarriages([]);
    setArchiveRecords([]);
    setRecycleBin([]);
  }, [requirePermission]);

  const resetToFactoryState = useCallback(async () => {
    requirePermission('canFactoryReset');
    await storage.clearAll();
    const emptyFamily: Family = { id: crypto.randomUUID(), name: '', banglaName: '', description: '', branches: [], settings: { ...DEFAULT_FAMILY_SETTINGS }, backupHistory: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    await storage.saveFamily(emptyFamily);
    storage.setActiveFamilyId(emptyFamily.id);
    await storage.saveMembers(emptyFamily.id, []);
    await storage.saveMarriages(emptyFamily.id, []);
    await storage.saveArchiveRecords(emptyFamily.id, []);
    setFamily(emptyFamily);
    setMembers([]);
    setMarriages([]);
    setArchiveRecords([]);
    setRecycleBin([]);
    setAllFamilies([emptyFamily]);
  }, [requirePermission]);

  return (
    <GenealogyContext.Provider
      value={{
        family,
        allFamilies,
        members,
        marriages,
        branches,
        archiveRecords,
        isLoading,
        generations,
        generationSummary,
        validationReport,
        language,
        setLanguage,
        theme,
        setTheme,
        userAccount,
        setUserAccount,
        checkPermission,
        addMember,
        updateMember,
        linkChildrenToMarriage,
        deleteMember,
        deleteMultipleMembers,
        recycleBin,
        restoreRecycleEntry,
        permanentDeleteRecycleEntry,
        emptyRecycleBin,
        clearCurrentFamilyData,
        resetToFreshState,
        addMarriage,
        updateMarriage,
        deleteMarriage,
        addBranch,
        updateFamily,
        switchFamily,
        deleteFamilySpace,
        renameFamilySpace,
        createNewFamily,
        addArchiveRecord,
        updateArchiveRecord,
        deleteArchiveRecord,
        batchAddArchiveRecords,
        linkDocumentToMember,
        unlinkDocumentFromMember,
        calculateRelationship,
        runRepair,
        recalculateAndPersistGenerations,
        exportArchiveJSON,
        importArchiveJSON,
        exportGedcomFile,
        importGedcomText,
        importUniversalDataset,
        loadSampleDataset,
        resetSettings,
        resetToFactoryState
      }}
    >
      {children}
    </GenealogyContext.Provider>
  );
};

export const useGenealogy = () => {
  const context = useContext(GenealogyContext);
  if (!context) {
    throw new Error('useGenealogy must be used within a GenealogyProvider');
  }
  return context;
};
