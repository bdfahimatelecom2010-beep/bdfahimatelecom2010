/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * ThemeRegistry Context — 116 HD Professional Pre-Defined Color Schemes
 * 
 * Provides unified theme management, dynamic switching, color token access,
 * accessibility scoring, and full CSS variable synchronization across desktop & mobile.
 * Correctly propagates CSS variables to FamilyTreeView and all sub-components.
 */

import React, { createContext, useContext, useState, useEffect, useLayoutEffect, useMemo, useCallback } from 'react';
import {
  BONGSHO_THEMES,
  BongshoTheme,
  ThemeComponentStyles,
  ThemeReadability,
  getFullTheme,
  applyTheme,
  getThemeCssVariables
} from '../theme/themeEngine';

export type ThemeCategory = 'all' | 'heritage' | 'royal' | 'nature' | 'dark' | 'minimal' | 'modern' | 'blue' | 'warm';

export interface FullThemeModel extends BongshoTheme, ThemeComponentStyles {
  readability: ThemeReadability;
}

export interface ThemeRegistryContextType {
  currentThemeId: string;
  currentTheme: FullThemeModel;
  allThemes: FullThemeModel[];
  categories: { id: ThemeCategory; labelBn: string; labelEn: string; count: number }[];
  activeCategory: ThemeCategory;
  setActiveCategory: (category: ThemeCategory) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filteredThemes: FullThemeModel[];
  switchTheme: (themeId: string) => void;
  isDark: boolean;
  toggleDarkVariant: () => void;
  customBackgroundUrl: string;
  setCustomBackgroundUrl: (url: string) => void;
  // Full dictionary of active CSS custom properties
  cssVariables: Record<string, string>;
  // Direct color token helpers
  colors: {
    primary: string;
    primaryHover: string;
    secondary: string;
    accent: string;
    bg: string;
    surface: string;
    card: string;
    text: string;
    textMuted: string;
    border: string;
  };
}

const ThemeRegistryContext = createContext<ThemeRegistryContextType | undefined>(undefined);

const STORAGE_KEY = 'bongshokotha_active_theme_id';

export const ThemeRegistryProvider: React.FC<{ children: React.ReactNode; initialThemeId?: string }> = ({
  children,
  initialThemeId
}) => {
  const [currentThemeId, setCurrentThemeId] = useState<string>(() => {
    if (initialThemeId) return initialThemeId;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved && BONGSHO_THEMES.some(t => t.id === saved)) {
        return saved;
      }
    } catch (e) {
      // Local storage fallback
    }
    return 'heritage';
  });

  const [activeCategory, setActiveCategory] = useState<ThemeCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [customBackgroundUrl, setCustomBackgroundUrlState] = useState<string>(() => { try { return localStorage.getItem('bongshokotha_theme_background_v1') || ''; } catch { return ''; } });

  const setCustomBackgroundUrl = useCallback((url: string) => {
    setCustomBackgroundUrlState(url);
    try { localStorage.setItem('bongshokotha_theme_background_v1', url); } catch {}
  }, []);

  // Prepare all 116 full themes with styles & accessibility pre-calculated
  const allThemes: FullThemeModel[] = useMemo(() => {
    return BONGSHO_THEMES.map(t => getFullTheme(t));
  }, []);

  // Active full theme
  const currentTheme: FullThemeModel = useMemo(() => {
    const found = allThemes.find(t => t.id === currentThemeId);
    return found || allThemes[0];
  }, [allThemes, currentThemeId]);

  // CSS variables dictionary for active theme
  const cssVariables = useMemo(() => {
    return getThemeCssVariables(currentTheme);
  }, [currentTheme]);

  // Apply CSS custom properties synchronously whenever currentTheme changes
  useLayoutEffect(() => {
    applyTheme(currentThemeId);
    try {
      localStorage.setItem(STORAGE_KEY, currentThemeId);
    } catch (e) {
      // ignore
    }
  }, [currentThemeId]);

  const switchTheme = useCallback((themeId: string) => {
    const theme = BONGSHO_THEMES.find(t => t.id === themeId);
    if (theme) {
      applyTheme(theme.id);
      setCurrentThemeId(theme.id);
    }
  }, []);

  const toggleDarkVariant = useCallback(() => {
    // If currently dark, find light counterpart, and vice versa
    const targetIsDark = !currentTheme.isDark;
    const counterpart = allThemes.find(t => t.isDark === targetIsDark && (t.category === currentTheme.category || t.category === 'heritage'));
    if (counterpart) {
      switchTheme(counterpart.id);
    } else {
      const fallback = allThemes.find(t => t.isDark === targetIsDark);
      if (fallback) switchTheme(fallback.id);
    }
  }, [currentTheme, allThemes, switchTheme]);

  // Categories list with count
  const categories = useMemo(() => [
    { id: 'all' as ThemeCategory, labelBn: 'সকল ১১৬টি থিম', labelEn: 'All 116 Themes', count: allThemes.length },
    { id: 'heritage' as ThemeCategory, labelBn: 'ঐতিহ্যবাহী বাংলা', labelEn: 'Bengal Heritage', count: allThemes.filter(t => t.category === 'heritage').length },
    { id: 'royal' as ThemeCategory, labelBn: 'রাজকীয় ও জমিদারি', labelEn: 'Royal & Zamindari', count: allThemes.filter(t => t.category === 'royal').length },
    { id: 'nature' as ThemeCategory, labelBn: 'ঋতু ও নদ-নদী', labelEn: 'Rivers & Seasons', count: allThemes.filter(t => t.category === 'nature').length },
    { id: 'dark' as ThemeCategory, labelBn: 'ডার্ক ও ওলেড', labelEn: 'Dark & OLED', count: allThemes.filter(t => t.category === 'dark').length },
    { id: 'minimal' as ThemeCategory, labelBn: 'নির্মল ও লিনেন', labelEn: 'Minimal & Linen', count: allThemes.filter(t => t.category === 'minimal').length },
    { id: 'modern' as ThemeCategory, labelBn: 'আধুনিক', labelEn: 'Modern', count: allThemes.filter(t => t.category === 'modern').length },
    { id: 'blue' as ThemeCategory, labelBn: 'নীল', labelEn: 'Blue', count: allThemes.filter(t => t.category === 'blue').length },
    { id: 'warm' as ThemeCategory, labelBn: 'উষ্ণ', labelEn: 'Warm', count: allThemes.filter(t => t.category === 'warm').length }
  ], [allThemes]);

  // Filtered themes by category and search
  const filteredThemes = useMemo(() => {
    return allThemes.filter(t => {
      const matchesCategory = activeCategory === 'all' || t.category === activeCategory;
      if (!matchesCategory) return false;

      if (!searchQuery.trim()) return true;
      const query = searchQuery.toLowerCase();
      return (
        t.nameBn.toLowerCase().includes(query) ||
        t.nameEn.toLowerCase().includes(query) ||
        t.id.toLowerCase().includes(query) ||
        t.categoryBn.toLowerCase().includes(query)
      );
    });
  }, [allThemes, activeCategory, searchQuery]);

  const colors = useMemo(() => ({
    primary: currentTheme.colors.primary,
    primaryHover: currentTheme.colors.primaryHover,
    secondary: currentTheme.secondary,
    accent: currentTheme.colors.accent,
    bg: currentTheme.colors.bg,
    surface: currentTheme.colors.surface,
    card: currentTheme.colors.card,
    text: currentTheme.colors.text,
    textMuted: currentTheme.colors.textMuted,
    border: currentTheme.colors.border
  }), [currentTheme]);

  useEffect(() => {
    document.documentElement.style.setProperty('--bongshokotha-custom-background', customBackgroundUrl ? `url(\"${customBackgroundUrl}\")` : 'none');
  }, [customBackgroundUrl]);

  // GenealogyContext is the source of truth for the active family. Keep this
  // presentation registry synchronized when a family is opened/switched or
  // its persisted theme changes, so the gallery never shows a stale theme.
  useEffect(() => {
    const handleFamilyTheme = (event: Event) => {
      const themeId = (event as CustomEvent<{ themeId?: string }>).detail?.themeId;
      if (themeId && BONGSHO_THEMES.some(t => t.id === themeId)) {
        setCurrentThemeId(themeId);
        applyTheme(themeId);
      }
    };
    window.addEventListener('bongshokotha:family-theme-changed', handleFamilyTheme);
    return () => window.removeEventListener('bongshokotha:family-theme-changed', handleFamilyTheme);
  }, []);

  return (
    <ThemeRegistryContext.Provider
      value={{
        currentThemeId,
        currentTheme,
        allThemes,
        categories,
        activeCategory,
        setActiveCategory,
        searchQuery,
        setSearchQuery,
        filteredThemes,
        switchTheme,
        isDark: currentTheme.isDark,
        toggleDarkVariant,
        customBackgroundUrl,
        setCustomBackgroundUrl,
        cssVariables,
        colors
      }}
    >
      <div
        className="bongshokotha-theme-root contents"
        style={{ ...(cssVariables as React.CSSProperties), backgroundImage: customBackgroundUrl ? `linear-gradient(var(--theme-overlay),var(--theme-overlay)),url(${customBackgroundUrl})` : undefined, backgroundSize: 'cover', backgroundPosition: 'center', backgroundAttachment: 'fixed' }}
      >
        {children}
      </div>
    </ThemeRegistryContext.Provider>
  );
};

export const useThemeRegistry = (): ThemeRegistryContextType => {
  const context = useContext(ThemeRegistryContext);
  if (!context) {
    throw new Error('useThemeRegistry must be used within a ThemeRegistryProvider');
  }
  return context;
};
