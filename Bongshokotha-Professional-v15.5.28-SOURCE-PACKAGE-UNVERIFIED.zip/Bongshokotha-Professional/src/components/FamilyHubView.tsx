import React, { useEffect, useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { Archive, ArrowRight, BookOpen, Check, Copy, Link2, Plus, QrCode, ScanLine, ShieldCheck, Sparkles, Users, X } from 'lucide-react';
import { useGenealogy } from '../context/GenealogyContext';
import { publishInvite, fetchInvite } from '../services/syncClient';
import { getActiveServerProfile } from '../services/serverRegistry';

const HUB_KEY = 'bongshokotha_family_hub_v1';
const ACTIVE_FAMILY_SELECTED = 'bongshokotha_family_selected_v1';

type InviteRecord = { code: string; familyId: string; createdAt: string; expiresAt: string | null; uses: number; maxUses?: number; };

const readInvites = (): InviteRecord[] => { try { return JSON.parse(localStorage.getItem(HUB_KEY) || '[]'); } catch { return []; } };
const writeInvites = (v: InviteRecord[]) => localStorage.setItem(HUB_KEY, JSON.stringify(v));
const makeCode = () => `BKS-${Math.random().toString(36).slice(2, 6).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;

export const FamilyHubView: React.FC<{ onOpenFamily: () => void }> = ({ onOpenFamily }) => {
  const { family, allFamilies, switchFamily, createNewFamily, loadSampleDataset, language, members, marriages, archiveRecords, userAccount, importArchiveJSON } = useGenealogy();
  const isBn = language === 'bn';
  const [mode, setMode] = useState<'home' | 'join'>('home');
  const [name, setName] = useState('');
  const [banglaName, setBanglaName] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const [joinServerUrl, setJoinServerUrl] = useState('');
  const [invite, setInvite] = useState<InviteRecord | null>(null);
  const [qr, setQr] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  const myFamilies = useMemo(() => allFamilies.filter(f => f.id !== 'family-sample-choudhury'), [allFamilies]);

  useEffect(() => { if (invite) QRCode.toDataURL(JSON.stringify({ type: 'BONGSHOKOTHA_JOIN', code: invite.code }), { width: 320, margin: 2 }).then(setQr).catch(() => setQr('')); }, [invite]);

  const openFamily = async (id: string) => { await switchFamily(id); localStorage.setItem(ACTIVE_FAMILY_SELECTED, '1'); onOpenFamily(); };

  const createFamily = async () => {
    if (!name.trim()) return setNotice(isBn ? 'বংশের নাম দিন।' : 'Enter a family name.');
    setBusy(true); setNotice('');
    try { await createNewFamily(name.trim(), banglaName.trim() || name.trim(), isBn ? 'নতুন পারিবারিক বংশতালিকা' : 'New family genealogy'); localStorage.setItem(ACTIVE_FAMILY_SELECTED, '1'); onOpenFamily(); }
    catch { setNotice(isBn ? 'বংশ তৈরি করা যায়নি।' : 'Could not create the family.'); }
    finally { setBusy(false); }
  };

  const createInvite = async () => {
    const confirmed = window.confirm(isBn
      ? 'এই আমন্ত্রণে সম্পূর্ণ বংশতথ্য, সদস্যদের তথ্য, বিবাহ ও আর্কাইভের রেকর্ড অন্তর্ভুক্ত হতে পারে। যিনি কোড পাবেন তিনি এই প্যাকেজ আমদানি করতে পারবেন। আপনি কি এগোতে চান?'
      : 'This invite may include the full family tree, member details, marriages and archive records. Anyone receiving the code may import this package. Continue?');
    if (!confirmed) return;
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    let record: InviteRecord = { code: makeCode(), familyId: family.id, createdAt: new Date().toISOString(), expiresAt, uses: 0, maxUses: 1 };
    const endpoint = family.settings?.syncEndpoint || '';
    if (endpoint) {
      try {
        const archive = { format:'BONGSHOKOTHA_ARCHIVE' as const, version:'1.0' as const, exportedAt:new Date().toISOString(), app:'Bongshokotha / বংশকথা' as const, family, members, marriages, branches:family.branches || [], archiveRecords };
        const published = await publishInvite(endpoint, record.code, family.id, archive, expiresAt, getActiveServerProfile()?.token);
        if (!published?.code || typeof published.code !== 'string') throw new Error(isBn ? 'সার্ভার বৈধ Join Code ফেরত দেয়নি।' : 'Server did not return a valid join code.');
        record = { ...record, code: published.code };
        setNotice(isBn ? 'Remote Join Code সার্ভারে প্রকাশ হয়েছে।' : 'Remote Join Code published to the sync server.');
      } catch (e) { setNotice(e instanceof Error ? e.message : 'Remote publish failed.'); return; }
    } else setNotice(isBn ? 'স্থানীয় Join Code তৈরি হয়েছে। অন্য ডিভাইসে কাজ করতে Server URL প্রয়োজন।' : 'Local Join Code created. A server URL is required for other devices.');
    const all = [...readInvites().filter(i => i.familyId !== family.id), record]; writeInvites(all);
    setInvite(record);
  };

  const copy = async (value: string) => { try { await navigator.clipboard.writeText(value); setNotice(isBn ? 'কপি হয়েছে।' : 'Copied.'); } catch { setNotice(value); } };

  const scanQrImage = async (file?: File) => {
    if (!file) return;
    try {
      const detectorCtor = (window as any).BarcodeDetector;
      if (!detectorCtor) { setNotice(isBn ? 'এই ব্রাউজারে QR ছবি পড়া সমর্থিত নয়। Code হাতে লিখুন বা সমর্থিত Chrome/Edge ব্যবহার করুন।' : 'QR image scanning is not supported in this browser. Enter the code manually or use a supported Chrome/Edge browser.'); return; }
      const bitmap = await createImageBitmap(file);
      const detector = new detectorCtor({ formats: ['qr_code'] });
      const results = await detector.detect(bitmap);
      bitmap.close?.();
      if (!results.length) { setNotice(isBn ? 'ছবিতে QR Code পাওয়া যায়নি।' : 'No QR code was found in the image.'); return; }
      const raw = String(results[0].rawValue || '');
      let code = raw;
      try { const parsed = JSON.parse(raw); if (parsed?.type === 'BONGSHOKOTHA_JOIN' && parsed.code) code = parsed.code; } catch {}
      setJoinCode(code.trim().toUpperCase());
      setNotice(isBn ? 'QR থেকে কোড পড়া হয়েছে। এখন Join Code দিয়ে বংশ গ্রহণ করুন।' : 'Code read from QR. Now use Join Code to join the family.');
    } catch (e) { setNotice(e instanceof Error ? e.message : (isBn ? 'QR পড়া যায়নি।' : 'Could not read QR code.')); }
  };

  const join = async () => {
    const code = joinCode.trim().toUpperCase();
    const local = readInvites().find(i => i.code.toUpperCase() === code);
    if (local && local.expiresAt && Date.now() > new Date(local.expiresAt).getTime()) return setNotice(isBn ? 'Join Code-এর মেয়াদ শেষ।' : 'The Join Code has expired.');
    const endpoint = joinServerUrl.trim() || family.settings?.syncEndpoint || '';
    if (endpoint) {
      try { const remote = await fetchInvite(endpoint, code, getActiveServerProfile()?.token); const result = await importArchiveJSON(JSON.stringify(remote.archive), 'merge_preserve'); if (!result.success) return setNotice(result.message); localStorage.setItem(ACTIVE_FAMILY_SELECTED,'1'); setNotice(isBn ? 'শেয়ার করা বংশের তথ্য বর্তমান তথ্য না মুছে যোগ করা হয়েছে।' : 'Shared family imported without overwriting existing data.'); onOpenFamily(); return; }
      catch (e) { if (!local) return setNotice(e instanceof Error ? e.message : 'Remote join failed.'); }
    }
    if (!local) return setNotice(isBn ? 'এই Code পাওয়া যায়নি। Remote sharing-এর জন্য Settings → Sync-এ Server URL দিন।' : 'Code not found. Set a sync server URL in Settings for remote sharing.');
    if (local) {
      const localFamily = allFamilies.find(f => f.id === local.familyId);
      if (!localFamily) return setNotice(isBn ? 'এই কোডের বংশ এই ডিভাইসে আর নেই।' : 'The family for this code is not available on this device.');
      await openFamily(local.familyId);
      setNotice(isBn ? 'এই ডিভাইসে থাকা বংশটি খোলা হয়েছে।' : 'Opened the family stored on this device.');
      return;
    }
    setNotice(isBn ? 'বংশ গ্রহণ করা যায়নি। সার্ভারের Join Code ব্যবহার করুন।' : 'Could not join the family. Use a server-issued join code.');
  };

  return <div className="min-h-[calc(100vh-7rem)] space-y-6 py-4">
    <section className="relative overflow-hidden rounded-3xl border border-amber-900/15 bg-gradient-to-br from-amber-100 via-white to-emerald-50 p-6 sm:p-10 shadow-xl">
      <div className="relative z-10 max-w-3xl"><span className="inline-flex items-center gap-2 rounded-full border border-amber-700/20 bg-white/70 px-3 py-1 text-xs font-bold text-amber-900"><Sparkles className="h-4 w-4"/> {isBn ? 'বংশ নির্বাচন কেন্দ্র' : 'Family Hub'}</span><h1 className="mt-4 text-3xl sm:text-5xl font-serif font-black text-stone-900">{isBn ? 'আপনার বংশ কোথা থেকে শুরু করবেন?' : 'Where would you like to begin?'}</h1><p className="mt-3 text-sm sm:text-base text-stone-600">{isBn ? 'নতুন বংশ তৈরি করুন, ডেমো দেখুন, পুরোনো বংশ খুলুন অথবা QR/Code দিয়ে শেয়ার করা বংশ গ্রহণ করুন।' : 'Create a family, explore the demo, open an existing family, or join a shared family.'}</p></div>
    </section>

    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      <button onClick={()=>setMode('home')} className="rounded-2xl border bg-white p-5 text-left shadow-sm hover:shadow-md transition"><Plus className="h-7 w-7 text-amber-700"/><h2 className="mt-4 font-bold">{isBn?'নতুন বংশ':'New Family'}</h2><p className="mt-1 text-xs text-stone-500">{isBn?'নিজের বংশতালিকা শুরু করুন।':'Start a new genealogy.'}</p></button>
      <button onClick={async()=>{await loadSampleDataset(); localStorage.setItem(ACTIVE_FAMILY_SELECTED,'1'); onOpenFamily();}} className="rounded-2xl border bg-white p-5 text-left shadow-sm hover:shadow-md transition"><BookOpen className="h-7 w-7 text-emerald-700"/><h2 className="mt-4 font-bold">{isBn?'ডেমো বংশ':'Demo Family'}</h2><p className="mt-1 text-xs text-stone-500">{isBn?'সম্পূর্ণ নমুনা বংশ দেখুন।':'Explore a safe sample family.'}</p></button>
      <button onClick={()=>setMode('join')} className="rounded-2xl border bg-white p-5 text-left shadow-sm hover:shadow-md transition"><ScanLine className="h-7 w-7 text-blue-700"/><h2 className="mt-4 font-bold">{isBn?'শেয়ার করা বংশ গ্রহণ':'Join Shared Family'}</h2><p className="mt-1 text-xs text-stone-500">{isBn?'QR অথবা সাধারণ Code ব্যবহার করুন।':'Join with QR or code.'}</p></button>
      <div className="rounded-2xl border bg-white p-5 shadow-sm"><Archive className="h-7 w-7 text-purple-700"/><h2 className="mt-4 font-bold">{isBn?'আমার পুরাতন বংশ':'My Families'}</h2><p className="mt-1 text-xs text-stone-500">{myFamilies.length} {isBn?'টি বংশ':'families'}</p></div>
    </div>

    {mode === 'home' && <>
      <section className="rounded-3xl border bg-white p-5 sm:p-7 shadow-sm"><div className="flex items-center gap-2"><Users className="h-5 w-5 text-amber-700"/><h2 className="font-bold text-lg">{isBn?'নতুন বংশ তৈরি করুন':'Create New Family'}</h2></div><div className="mt-4 grid sm:grid-cols-2 gap-3"><input value={name} onChange={e=>setName(e.target.value)} placeholder={isBn?'বংশের নাম':'Family name'} className="rounded-xl border p-3 text-sm"/><input value={banglaName} onChange={e=>setBanglaName(e.target.value)} placeholder={isBn?'বাংলা নাম (ঐচ্ছিক)':'Bangla name (optional)'} className="rounded-xl border p-3 text-sm"/></div><button disabled={busy} onClick={createFamily} className="mt-4 rounded-xl bg-amber-800 px-5 py-3 text-sm font-bold text-white disabled:opacity-50"><Plus className="inline h-4 w-4 mr-2"/>{isBn?'বংশ তৈরি করে প্রবেশ করুন':'Create & Open Family'}</button></section>
      <section className="rounded-3xl border bg-white p-5 sm:p-7 shadow-sm"><h2 className="font-bold text-lg">{isBn?'আমার পুরাতন বংশ':'My Existing Families'}</h2><div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{myFamilies.map(f=><button key={f.id} onClick={()=>openFamily(f.id)} className="rounded-2xl border p-4 text-left hover:border-amber-500"><div className="font-bold">{f.banglaName || f.name}</div><div className="text-xs text-stone-500 mt-1">{f.description || (isBn?'পারিবারিক বংশতালিকা':'Family genealogy')}</div><div className="mt-3 text-xs font-semibold text-amber-700">{isBn?'বংশ খুলুন':'Open family'} <ArrowRight className="inline h-3.5 w-3.5"/></div></button>)}{myFamilies.length===0&&<p className="text-sm text-stone-500">{isBn?'এখনও কোনো পুরাতন বংশ নেই।':'No existing family yet.'}</p>}</div></section>
    </>}

    {mode === 'join' && <section className="rounded-3xl border bg-white p-5 sm:p-7 shadow-sm space-y-6"><div className="flex items-center justify-between"><div><h2 className="font-bold text-xl">{isBn?'শেয়ার করা বংশ গ্রহণ করুন':'Join a Shared Family'}</h2><p className="text-xs text-stone-500 mt-1">{isBn?'কাছের মানুষের জন্য QR, দূরের মানুষের জন্য সাধারণ Code।':'QR for nearby family; code for remote family.'}</p></div><button onClick={()=>setMode('home')}><X className="h-5 w-5"/></button></div><div className="grid lg:grid-cols-2 gap-5"><div className="rounded-2xl border p-5"><QrCode className="h-7 w-7 text-blue-700"/><h3 className="mt-3 font-bold">{isBn?'QR Code দিয়ে':'With QR Code'}</h3><p className="text-xs text-stone-500 mt-1">{isBn?'Owner-এর QR scan করে Join Request পাঠানো যাবে।':'Scan the owner invite QR to start a join request.'}</p><div className="mt-4 rounded-xl bg-stone-50 p-5 text-center text-xs text-stone-600"><ShieldCheck className="mx-auto h-7 w-7 mb-2"/><label className="inline-flex cursor-pointer rounded-xl bg-blue-700 px-4 py-2 font-bold text-white">{isBn?'QR ছবিটি নির্বাচন/স্ক্যান করুন':'Choose QR image to scan'}<input type="file" accept="image/*" capture="environment" className="hidden" onChange={e=>{void scanQrImage(e.target.files?.[0]); e.currentTarget.value='';}} /></label><p className="mt-2">{isBn?'QR ছবির কোড পড়ার পর নিচের Join Code বাটন চাপুন।':'After reading the QR, press the Join Code button below.'}</p></div></div><div className="rounded-2xl border p-5"><Link2 className="h-7 w-7 text-emerald-700"/><h3 className="mt-3 font-bold">{isBn?'সাধারণ Code দিয়ে':'With Join Code'}</h3><input value={joinServerUrl} onChange={e=>setJoinServerUrl(e.target.value)} placeholder={isBn?"Server URL (দূরের বংশের জন্য)":"Server URL for remote family"} className="mt-4 w-full rounded-xl border p-3 text-sm"/><input value={joinCode} onChange={e=>setJoinCode(e.target.value)} placeholder="BKS-XXXX-XXXX" className="mt-3 w-full rounded-xl border p-3 font-mono text-sm uppercase"/><button onClick={join} className="mt-3 rounded-xl bg-emerald-700 px-4 py-2.5 text-sm font-bold text-white">{isBn?'বংশ গ্রহণ করুন':'Join Family'}</button></div></div><div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900">{isBn?'গুরুত্বপূর্ণ: এই Offline build-এ দূরের ডিভাইসের Join Code যাচাই করতে Cloud Sync/Server সংযোগ প্রয়োজন। Code-এর কোনো মেয়াদ না থাকলেও বংশ ও ব্যবহারকারীর কোনো expiry নেই।':'Important: remote device validation requires Cloud Sync/server connection in this offline build. Family and user access do not expire; only an invite may have an optional validity period.'}</div></section>}

    {notice && <div className="fixed bottom-5 right-5 z-50 rounded-2xl bg-stone-900 px-4 py-3 text-sm text-white shadow-2xl"><Check className="inline h-4 w-4 mr-2"/>{notice}</div>}

    {invite && <section className="rounded-3xl border bg-white p-5 sm:p-7 shadow-sm"><div className="flex items-center justify-between"><div><h2 className="font-bold text-xl">{isBn?'বংশ শেয়ার করুন':'Share Family'}</h2><p className="text-xs text-stone-500">{family.banglaName || family.name}</p></div><button onClick={()=>setInvite(null)}><X className="h-5 w-5"/></button></div><div className="mt-5 grid md:grid-cols-2 gap-6 items-center"><div className="text-center">{qr&&<img src={qr} alt="Bongshokotha QR invite" className="mx-auto rounded-xl border p-2"/>}<button onClick={()=>qr&&copy(qr)} className="mt-3 rounded-xl border px-4 py-2 text-xs font-bold"><Copy className="inline h-4 w-4 mr-1"/>{isBn?'QR ডেটা কপি':'Copy QR data'}</button></div><div><div className="rounded-2xl bg-stone-50 p-5"><span className="text-xs text-stone-500">{isBn?'সাধারণ Join Code':'Join Code'}</span><div className="mt-2 font-mono text-2xl font-black tracking-wider">{invite.code}</div><button onClick={()=>copy(invite.code)} className="mt-3 rounded-xl bg-stone-900 px-4 py-2 text-xs font-bold text-white"><Copy className="inline h-4 w-4 mr-1"/>{isBn?'Code কপি করুন':'Copy code'}</button></div><p className="mt-3 text-xs text-stone-500">{isBn?'এই আমন্ত্রণ ৭ দিন পর মেয়াদোত্তীর্ণ হবে এবং একবার ব্যবহারযোগ্য; Server থাকলে আমন্ত্রণ revoke করা যাবে।':'The invite expires after 7 days and is limited to one use; server-side revocation depends on the configured sync server.'}</p></div></div></section>}

    {!invite && mode === 'home' && <section className="rounded-3xl border bg-stone-900 p-6 text-white"><div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"><div><h2 className="font-serif text-2xl font-bold">{isBn?'বংশ শেয়ার করার প্রস্তুতি':'Ready to share your family?'}</h2><p className="mt-1 text-xs text-stone-300">{isBn?'বংশ খুলে Admin → Share থেকে QR/Code তৈরি করতে পারবেন।':'Open a family and use Admin → Share to create a QR/code invite.'}</p></div><button onClick={createInvite} className="rounded-xl bg-amber-500 px-5 py-3 text-sm font-bold text-stone-950"><QrCode className="inline h-4 w-4 mr-2"/>{isBn?'QR ও Code তৈরি করুন':'Create QR & Code'}</button></div></section>}
  </div>;
};
