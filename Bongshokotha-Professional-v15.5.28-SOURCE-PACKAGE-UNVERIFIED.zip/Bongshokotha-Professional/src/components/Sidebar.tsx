/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Fixed Left Sidebar Navigation & Responsive Drawer
 * 
 * User Requirement:
 * "ইস্কেনের বামে ফিস্ট বাবে সব মেনু থাকবে।"
 * "বিভিন্ন মোবাইল ছোট, মাঝাড়ি, বড়, বিশাল বড় মোবাইলে যেন সুন্দর ভাবে কাজ করে।"
 * 
 * Provides:
 * - Desktop: Permanently fixed left sidebar (w-64 or w-72, h-screen)
 * - Mobile: Responsive fixed slide-out drawer + mobile top header toggle
 * - Full navigation between all 9 modules with icons, badges, and active states
 * - Quick action buttons: "+ নতুন সদস্য", "অনুসন্ধান"
 * - User role & Theme indicator badge
 */

import React from 'react';
import { clearSession } from '../services/security';
import { useGenealogy } from '../context/GenealogyContext';
import { useThemeRegistry } from '../context/ThemeRegistry';
import { APP_VERSION } from '../appVersion';
import {
  LayoutDashboard,
  Users,
  Network,
  GitFork,
  Heart,
  Archive,
  BookOpen,
  Calendar,
  Settings,
  Plus,
  Search,
  TreeDeciduous,
  ShieldCheck,
  Palette,
  ChevronRight,
  X,
  Sparkles,
  ArrowDownUp,
  Printer,
  UserCog,
  UserCircle,
  Trash2,
  MapPinned,
  Share2,
  LogOut
} from 'lucide-react';

export type NavTab = 
  | 'dashboard'
  | 'members'
  | 'tree'
  | 'relations'
  | 'marriages'
  | 'archive'
  | 'book'
  | 'calendar'
  | 'import-export'
  | 'print-export'
  | 'settings'
  | 'share'
  | 'map'
  | 'admin'
  | 'my-account'
  | 'recycle-bin';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  onOpenAddMember: () => void;
  onOpenSearch: () => void;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddMember,
  onOpenSearch,
  isMobileOpen,
  setIsMobileOpen
}) => {
  const { family, members, marriages, archiveRecords, language, userAccount, checkPermission } = useGenealogy();
  const themeRegistry = useThemeRegistry();
  const isBn = language === 'bn';
  // Read role menu assignments on render so newly saved Admin menu rules take effect after navigation/re-render.
  const assignedRoleMenus: string[] = React.useMemo(() => { try { const all = JSON.parse(localStorage.getItem('bongshokotha_role_menus_v1') || '{}'); return Array.isArray(all[userAccount?.role || 'viewer']) ? all[userAccount?.role || 'viewer'].map((id: string) => id === 'social' ? 'share' : id) : (userAccount?.role === 'viewer' ? ['dashboard','members','tree','book'] : ['dashboard','members','tree','relations','marriages','archive','book','calendar']); } catch { return userAccount?.role === 'viewer' ? ['dashboard','members','tree','book'] : ['dashboard','members','tree','relations','marriages','archive','book','calendar']; } }, [userAccount?.role, activeTab]);

  const navItems = [
    {
      id: 'dashboard' as NavTab,
      labelBn: 'ড্যাশবোর্ড',
      labelEn: 'Dashboard',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'members' as NavTab,
      labelBn: 'সকল সদস্য',
      labelEn: 'All Members',
      icon: Users,
      badge: members.length
    },
    {
      id: 'tree' as NavTab,
      labelBn: 'বংশলতিকা বৃক্ষ',
      labelEn: 'Family Tree',
      icon: Network,
      badge: null
    },
    {
      id: 'relations' as NavTab,
      labelBn: 'আত্মীয়তা নির্ণয়',
      labelEn: 'Kinship Finder',
      icon: GitFork,
      badge: null
    },
    {
      id: 'marriages' as NavTab,
      labelBn: 'বৈবাহিক বন্ধন',
      labelEn: 'Marriages',
      icon: Heart,
      badge: marriages.length
    },
    {
      id: 'archive' as NavTab,
      labelBn: 'পারিবারিক আর্কাইভ',
      labelEn: 'Family Archive',
      icon: Archive,
      badge: archiveRecords.length
    },
    {
      id: 'book' as NavTab,
      labelBn: 'বংশপুস্তক ও ইতিহাস',
      labelEn: 'Family Book',
      icon: BookOpen,
      badge: null
    },
    {
      id: 'calendar' as NavTab,
      labelBn: 'ঐতিহাসিক বর্ষপঞ্জি',
      labelEn: 'Heritage Calendar',
      icon: Calendar,
      badge: null
    },
    {
      id: 'import-export' as NavTab,
      labelBn: 'আমদানি ও রপ্তানি',
      labelEn: 'Import And Export',
      icon: ArrowDownUp,
      badge: null
    },
    {
      id: 'print-export' as NavTab,
      labelBn: 'মুদ্রণ ও প্রকাশ',
      labelEn: 'Print & Publication',
      icon: Printer,
      badge: null
    },
    ...((checkPermission('canManageRoles') || checkPermission('canRunIntegrityRepair')) ? [{
      id: 'admin' as NavTab,
      labelBn: 'এ্যাডমিন ও রোলস',
      labelEn: 'Admin & Roles',
      icon: UserCog,
      badge: null
    }] : []),
    {
      id: 'my-account' as NavTab,
      labelBn: 'আমার অ্যাকাউন্ট',
      labelEn: 'My Account',
      icon: UserCircle,
      badge: null
    },
    {
      id: 'recycle-bin' as NavTab,
      labelBn: 'রিসাইকেল বিন',
      labelEn: 'Recycle Bin',
      icon: Trash2,
      badge: null
    },
    {
      id: 'map' as NavTab,
      labelBn: 'পারিবারিক মানচিত্র',
      labelEn: 'Family Map',
      icon: MapPinned,
      badge: null
    },
    {
      id: 'share' as NavTab,
      labelBn: 'বংশতালিকা শেয়ার',
      labelEn: 'Share Family Tree',
      icon: Share2,
      badge: null
    },
    {
      id: 'settings' as NavTab,
      labelBn: 'সেটিংস ও নিরাপত্তা',
      labelEn: 'Settings & Security',
      icon: Settings,
      badge: null
    }
  ];

  // Role menu assignments apply to every role, including administrators. High-risk
  // admin capabilities are never granted by a menu checkbox: the Admin Center is
  // visible only when the account also has the corresponding permission.
  const canOpenAdminCenter = checkPermission('canManageRoles') || checkPermission('canRunIntegrityRepair');
  const visibleNavItems = navItems.filter(item => {
    if (item.id === 'admin') return canOpenAdminCenter;
    // Keep account recovery reachable for every signed-in user. Settings is still
    // visible to all roles, while its sensitive panels are separately permission-gated.
    if (item.id === 'my-account' || item.id === 'settings') return true;
    return assignedRoleMenus.includes(item.id);
  });

  const handleNavClick = (tab: NavTab) => {
    setActiveTab(tab);
    setIsMobileOpen(false);
  };

  const sidebarContent = (
    <div className="h-full flex flex-col justify-between p-4 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-r border-stone-200 dark:border-stone-800 select-none">
      
      {/* Brand & Family Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-md text-white transition-colors"
              style={{ backgroundColor: themeRegistry.colors.primary }}
            >
              <TreeDeciduous className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-serif font-black text-lg text-stone-900 dark:text-white tracking-wide leading-tight">
                বংশকথা
              </h1>
              <p className="text-[10px] font-mono text-stone-500 uppercase tracking-widest">
                BONGSHOKOTHA
              </p>
            </div>
          </div>

          {/* Close button on mobile */}
          <button
            onClick={() => setIsMobileOpen(false)}
            className="md:hidden p-1.5 rounded-lg text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Active Clan Pill */}
        <div className="p-3 rounded-2xl bg-stone-50 dark:bg-stone-950 border border-stone-200/80 dark:border-stone-800/80 flex items-center justify-between">
          <div className="truncate pr-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block">
              {isBn ? 'সক্রিয় বংশ নথি' : 'Active Clan'}
            </span>
            <span className="text-xs font-bold font-serif text-stone-800 dark:text-stone-200 truncate block">
              {family.name || (isBn ? 'সিলেট চৌধুরী বংশ' : 'Sylhet Chowdhury Clan')}
            </span>
          </div>
          <span
            className="text-[10px] px-2 py-0.5 rounded-md font-bold shrink-0 border"
            style={{
              backgroundColor: `${themeRegistry.colors.primary}15`,
              color: themeRegistry.colors.primary,
              borderColor: `${themeRegistry.colors.primary}30`
            }}
          >
            {members.length} {isBn ? 'জন' : 'p'}
          </span>
        </div>

        {/* Quick Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => {
              onOpenAddMember();
              setIsMobileOpen(false);
            }}
            className="py-2 px-3 rounded-xl text-white text-xs font-bold shadow-xs transition flex items-center justify-center gap-1.5 active:scale-95"
            style={{ backgroundColor: themeRegistry.colors.primary }}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isBn ? 'নতুন সদস্য' : 'Add'}</span>
          </button>

          <button
            onClick={() => {
              onOpenSearch();
              setIsMobileOpen(false);
            }}
            className="py-2 px-3 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold transition flex items-center justify-center gap-1.5 active:scale-95"
          >
            <Search className="w-3.5 h-3.5 text-stone-400" />
            <span>{isBn ? 'খুঁজুন' : 'Search'}</span>
          </button>
        </div>

        {/* Grouped Navigation: easier to scan on desktop and mobile */}
        <nav className="space-y-3 pt-2 overflow-y-auto max-h-[calc(100vh-340px)] pr-1 scrollbar-thin" aria-label={isBn ? 'প্রধান নেভিগেশন' : 'Primary navigation'}>
          {([
            { key: 'overview', bn: 'ওভারভিউ', en: 'Overview', ids: ['dashboard'] },
            { key: 'family', bn: 'পরিবার ও সম্পর্ক', en: 'Family & Relationships', ids: ['members','tree','relations','marriages'] },
            { key: 'heritage', bn: 'ইতিহাস ও দলিল', en: 'Heritage & Records', ids: ['archive','book','calendar'] },
            { key: 'tools', bn: 'ডেটা ও প্রকাশনা', en: 'Data & Publishing', ids: ['import-export','print-export','recycle-bin'] },
            { key: 'map', bn: 'পারিবারিক মানচিত্র', en: 'Family Map', ids: ['map'] },
            { key: 'sharing', bn: 'বংশতালিকা শেয়ার', en: 'Family Tree Sharing', ids: ['share'] },
            { key: 'account', bn: 'অ্যাকাউন্ট ও নিয়ন্ত্রণ', en: 'Account & Controls', ids: ['admin','my-account','settings'] }
          ] as const).map(group => {
            const items = visibleNavItems.filter(item => (group.ids as readonly string[]).includes(item.id));
            if (!items.length) return null;
            return <section key={group.key} className="space-y-1">
              <div className="px-3 py-1 text-[9px] font-extrabold uppercase tracking-[0.14em] text-stone-400">{isBn ? group.bn : group.en}</div>
              {items.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return <button key={item.id} onClick={() => handleNavClick(item.id)} aria-current={isActive ? 'page' : undefined}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all group active:scale-[0.98] ${isActive ? 'font-bold shadow-xs' : 'text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800/60 hover:text-stone-900 dark:hover:text-stone-200'}`}
                  style={isActive ? { backgroundColor: `${themeRegistry.colors.primary}18`, color: themeRegistry.colors.primary, borderLeft: `4px solid ${themeRegistry.colors.primary}` } : {}}>
                  <span className="flex items-center gap-3"><Icon className={`w-4 h-4 transition-transform group-hover:scale-110 ${isActive ? 'text-inherit' : 'text-stone-400 group-hover:text-stone-600 dark:group-hover:text-stone-300'}`}/><span>{isBn ? item.labelBn : item.labelEn}</span></span>
                  {item.badge !== null && item.badge > 0 && <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${isActive ? 'bg-white dark:bg-stone-800 shadow-2xs' : 'bg-stone-100 dark:bg-stone-800 text-stone-500'}`}>{item.badge}</span>}
                </button>;
              })}
            </section>;
          })}
        </nav>
      </div>

      {/* Footer Profile & Theme Info */}
      <div className="pt-3 border-t border-stone-200 dark:border-stone-800 space-y-2 shrink-0">
        {/* Active Theme Chip */}
        <button
          onClick={() => handleNavClick('settings')}
          className="w-full p-2 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between text-left hover:border-amber-500/40 transition group"
        >
          <div className="flex items-center gap-2 truncate">
            <div
              className="w-3.5 h-3.5 rounded-full border border-black/10 shrink-0"
              style={{ backgroundColor: themeRegistry.colors.primary }}
            />
            <div className="truncate">
              <span className="text-[10px] text-stone-400 block truncate">
                {isBn ? 'সক্রিয় কালার স্কিম' : 'Active Theme'}
              </span>
              <span className="text-[11px] font-bold text-stone-800 dark:text-stone-200 truncate block">
                {isBn ? themeRegistry.currentTheme.nameBn : themeRegistry.currentTheme.nameEn}
              </span>
            </div>
          </div>
          <Palette className="w-3.5 h-3.5 text-stone-400 group-hover:text-amber-600 shrink-0" />
        </button>

        {/* User Role & Status */}
        <div className="flex items-center justify-between px-2 text-[10px] text-stone-500">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold text-stone-700 dark:text-stone-300">
              {userAccount?.role === 'super_admin' ? (isBn ? 'সুপার অ্যাডমিন' : 'Super Admin') : (userAccount?.role || 'Admin')}
            </span>
          </div>
          <span className="font-mono text-stone-400">v{APP_VERSION}</span>
        </div>
        <button type="button" onClick={() => { if (window.confirm(isBn ? 'আপনি কি লগআউট করতে চান?' : 'Are you sure you want to log out?')) { clearSession(); window.dispatchEvent(new Event('bongshokotha:logout')); setIsMobileOpen(false); } }} className="mt-3 w-full rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-xs font-bold text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300 flex items-center justify-center gap-2"><LogOut className="w-4 h-4" />{isBn ? 'লগআউট' : 'Logout'}</button>
      </div>

    </div>
  );

  return (
    <>
      {/* DESKTOP FIXED LEFT SIDEBAR (Always Fixed on Left) */}
      <aside className="hidden md:block fixed left-0 top-0 bottom-0 w-64 lg:w-72 z-30 shadow-sm">
        {sidebarContent}
      </aside>

      {/* MOBILE SLIDE-OUT DRAWER */}
      {isMobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setIsMobileOpen(false)}
          />

          {/* Fixed Drawer Panel on the Left */}
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
        </div>
      )}


    </>
  );
};
