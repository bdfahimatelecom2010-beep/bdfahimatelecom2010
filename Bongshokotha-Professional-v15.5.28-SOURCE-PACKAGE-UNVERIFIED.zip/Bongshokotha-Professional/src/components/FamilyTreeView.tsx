/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Generational Family Tree & Interactive Pedigree Chart with Complete Theme Integration
 * 
 * User Requirement:
 * "থীম গুলো পুরা বংশ তালিকায় কাজ করবে।"
 * "সকল সদস্য মেনুতে প্রজন্ম হিসাবে দেখাবে, সর্বদা প্রজন্মের বড় সন্তানের সন্তানদের আগে দেখাবে।"
 * 
 * Critical Tree Rules:
 * 1. Deep theme synchronization with all 72 themes (nodeBg, levelBg, connector, primary, accent).
 * 2. Generational tiering with strict eldest child descendants lineage ordering.
 * 3. Adjacent spouses paired next to member.
 * 4. Interactive zoom, pan, fit-to-screen and responsive scaling on all mobile screens.
 */

import React, { useState, useMemo, useRef } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { useThemeRegistry } from '../context/ThemeRegistry';
import { Member, MarriageRecord } from '../types/genealogy';
import { getVisibleFamilyMembers } from '../engine/familyVisibility';
import { getMemberColor } from '../engine/memberColor';
import { getCanonicalGenealogyOrder } from '../engine/genealogyOrdering';
import { toBanglaDigits, formatGenealogyDate, calculateLifespan } from '../engine/banglaCalendar';
import {
  Layers,
  Search,
  Filter,
  Users,
  Compass,
  Heart,
  Calendar,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  ZoomIn,
  ZoomOut,
  Maximize2,
  RotateCcw,
  GitBranch,
  Network,
  Crown
} from 'lucide-react';

interface FamilyTreeViewProps {
  onSelectMember: (memberId: string) => void;
  onTraceRelationship: (memberId: string) => void;
  onOpenAddMember: () => void;
}

type TreeMode = 'traditional' | 'graph' | 'branch';

// Helper to compute ancestor birth-order sequence for lineage sorting
function computeLineageSortPath(member: Member, memberMap: Map<string, Member>): number[] {
  const path: number[] = [];
  let curr: Member | undefined = member;
  const visited = new Set<string>();

  while (curr && !visited.has(curr.id)) {
    visited.add(curr.id);
    const order = curr.birthOrder ?? (curr.birth?.date?.year ? curr.birth.date.year : 999);
    path.unshift(order);

    const parentId = curr.fatherId || curr.motherId;
    if (parentId) {
      curr = memberMap.get(parentId);
    } else {
      curr = undefined;
    }
  }
  return path;
}

function compareLineagePaths(pathA: number[], pathB: number[]): number {
  const len = Math.max(pathA.length, pathB.length);
  for (let i = 0; i < len; i++) {
    const valA = i < pathA.length ? pathA[i] : 0;
    const valB = i < pathB.length ? pathB[i] : 0;
    if (valA !== valB) return valA - valB;
  }
  return 0;
}

export const FamilyTreeView: React.FC<FamilyTreeViewProps> = ({
  onSelectMember,
  onTraceRelationship,
  onOpenAddMember
}) => {
  const {
    members,
    marriages,
    branches,
    generations,
    generationSummary,
    language
  } = useGenealogy();

  const themeRegistry = useThemeRegistry();
  const { colors, currentTheme, cssVariables } = themeRegistry;

  const isBn = language === 'bn';
  const [treeMode, setTreeMode] = useState<TreeMode>('traditional');
  const [selectedBranch, setSelectedBranch] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [focusGen, setFocusGen] = useState<number | 'all'>('all');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  const treeMembers = useMemo(() => {
    // Canonical visibility rule: biological parents of a married-in person
    // remain available in that person's profile, but do not become birth-line
    // tree nodes unless independently connected to this family.
    return getVisibleFamilyMembers(members, marriages);
  }, [members, marriages]);

  const memberMap = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);

  // Group and sort members by STRICT generational depth AND eldest child lineage first
  const membersByGeneration = useMemo(() => {
    const map = new Map<number, Member[]>();
    for (let i = 1; i <= Math.max(generationSummary.maxGeneration, 1); i++) {
      map.set(i, []);
    }

    treeMembers.forEach(m => {
      if (selectedBranch !== 'all' && m.branchId !== selectedBranch) return;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matches =
          m.fullName?.toLowerCase().includes(q) ||
          m.banglaName?.toLowerCase().includes(q) ||
          m.englishName?.toLowerCase().includes(q) ||
          m.nickname?.toLowerCase().includes(q) ||
          false;
        if (!matches) return;
      }

      const gen = generations.get(m.id) || 1;
      if (!map.has(gen)) map.set(gen, []);
      map.get(gen)!.push(m);
    });

    // RULE: Within each generation, a marriage-origin member must sit immediately
    // after the birth-origin spouse they married. Use the same canonical DFS rank
    // used by the directory so a spouse cannot be displaced by the spouse's children.
    const canonicalOrder = getCanonicalGenealogyOrder(treeMembers, marriages);
    const canonicalRank = new Map(canonicalOrder.map((id, index) => [id, index]));
    const spouseAdjacentRank = (member: Member) => {
      const joined = member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin === true;
      if (!joined) return (canonicalRank.get(member.id) ?? 999999) * 2;
      const linkedMarriage = marriages.find(m => m.husbandId === member.id || m.wifeId === member.id);
      if (!linkedMarriage) return 1999999 + (member.birthOrder ?? 999999);
      const spouseId = linkedMarriage.husbandId === member.id ? linkedMarriage.wifeId : linkedMarriage.husbandId;
      return (canonicalRank.get(spouseId) ?? 999999) * 2 + 1;
    };

    map.forEach((genList) => {
      genList.sort((a, b) => {
        const rankA = spouseAdjacentRank(a);
        const rankB = spouseAdjacentRank(b);
        if (rankA !== rankB) return rankA - rankB;
        const pathA = computeLineageSortPath(a, memberMap);
        const pathB = computeLineageSortPath(b, memberMap);
        const lineageDiff = compareLineagePaths(pathA, pathB);
        if (lineageDiff !== 0) return lineageDiff;

        // Own birth order
        const orderA = a.birthOrder ?? 999;
        const orderB = b.birthOrder ?? 999;
        if (orderA !== orderB) return orderA - orderB;

        // Birth year
        const yearA = a.birth?.date?.year || 9999;
        const yearB = b.birth?.date?.year || 9999;
        if (yearA !== yearB) return yearA - yearB;

        return (a.birthOrder || 999999) - (b.birthOrder || 999999);
      });
    });

    return map;
  }, [treeMembers, members, generations, generationSummary.maxGeneration, selectedBranch, searchQuery, memberMap]);

  const genLabelsBn = [
    '১ম প্রজন্ম — আদি মূল পুরুষ (Root)',
    '২য় প্রজন্ম — দ্বিতীয় স্তর',
    '৩য় প্রজন্ম — তৃতীয় স্তর (জ্যেষ্ঠ সন্তানাদি প্রথমে)',
    '৪র্থ প্রজন্ম — চতুর্থ স্তর',
    '৫ম প্রজন্ম — পঞ্চম স্তর',
    '৬ষ্ঠ প্রজন্ম — ষষ্ঠ স্তর',
    '৭ম প্রজন্ম — সপ্তম স্তর',
    '৮ম প্রজন্ম — অষ্টম স্তর',
    '৯ম প্রজন্ম — নবম স্তর',
    '১০ম প্রজন্ম — দশম স্তর'
  ];

  const genLabelsEn = [
    '1st Gen — Root Ancestor',
    '2nd Gen — Second Tier',
    '3rd Gen — Third Tier (Eldest Lineage First)',
    '4th Gen — Fourth Tier',
    '5th Gen — Fifth Tier',
    '6th Gen — Sixth Tier',
    '7th Gen — Seventh Tier',
    '8th Gen — Eighth Tier',
    '9th Gen — Ninth Tier',
    '10th Gen — Tenth Tier'
  ];

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.15, 2.0));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.15, 0.6));
  const handleResetZoom = () => setZoomLevel(1);

  return (
    <div
      className="space-y-6 pb-20 select-none bongshokotha-tree-root"
      style={{
        ...cssVariables,
        '--tree-node-bg': currentTheme.treeVisualization?.nodeBg || colors.card,
        '--tree-node-border': currentTheme.treeVisualization?.nodeBorder || colors.border,
        '--tree-line': currentTheme.treeVisualization?.lineColor || colors.primary
      } as React.CSSProperties}
    >
      
      {/* Top Banner with Theme Active Styling */}
      <div
        className="rounded-3xl p-5 sm:p-6 shadow-md border transition-all"
        style={{
          backgroundColor: 'var(--surface)',
          borderColor: 'var(--border)'
        }}
      >
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span
                className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border shadow-2xs"
                style={{
                  backgroundColor: 'var(--card)',
                  color: 'var(--primary)',
                  borderColor: 'var(--border)'
                }}
              >
                {isBn ? `সক্রিয় থিম: ${currentTheme.nameBn}` : `Theme: ${currentTheme.nameEn}`}
              </span>
              <span
                className="text-xs font-sans"
                style={{ color: 'var(--text-muted)' }}
              >
                {isBn ? '✓ জ্যেষ্ঠ সন্তানের বংশধর অগ্রাধিকার সাজানো' : '✓ Eldest child lineage priority'}
              </span>
            </div>

            <h2 className="font-serif text-xl sm:text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
              <Network className="h-6 w-6" style={{ color: 'var(--primary)' }} />
              <span>{isBn ? 'বংশলতিকা ও পারিবারিক বংশবৃক্ষ' : 'Generational Lineage Tree'}</span>
            </h2>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
              {isBn
                ? `সর্বমোট ${toBanglaDigits(generationSummary.maxGeneration)}টি প্রজন্মের রক্তধারা ও বৈবাহিক বিস্তার চিত্রায়িত।`
                : `Interactive kinship tree spanning ${generationSummary.maxGeneration} generations.`}
            </p>
          </div>

          {/* Mode Switcher and Zoom */}
          <div className="flex flex-wrap items-center gap-2">
            <div
              className="flex rounded-2xl p-1 border shadow-xs"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              {[
                { id: 'traditional' as TreeMode, labelBn: 'প্রজন্ম স্তর', labelEn: 'Generations', icon: Layers },
                { id: 'graph' as TreeMode, labelBn: 'গ্রাফ নেটওয়ার্ক', labelEn: 'Kinship Graph', icon: Network },
                { id: 'branch' as TreeMode, labelBn: 'শাখাভিত্তিক', labelEn: 'Branches', icon: GitBranch }
              ].map(mode => {
                const Icon = mode.icon;
                const isSelected = treeMode === mode.id;
                return (
                  <button
                    key={mode.id}
                    onClick={() => setTreeMode(mode.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition"
                    style={
                      isSelected
                        ? { backgroundColor: 'var(--primary)', color: '#ffffff' }
                        : { color: 'var(--text)' }
                    }
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span>{isBn ? mode.labelBn : mode.labelEn}</span>
                  </button>
                );
              })}
            </div>

            {/* Zoom Controls */}
            <div
              className="flex items-center rounded-2xl border p-1"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <button
                onClick={handleZoomOut}
                className="p-1.5 hover:opacity-75 transition"
                style={{ color: 'var(--text)' }}
                title="Zoom Out"
              >
                <ZoomOut className="h-4 w-4" />
              </button>
              <button
                onClick={handleResetZoom}
                className="px-2 text-xs font-mono font-bold"
                style={{ color: 'var(--primary)' }}
                title="Reset Zoom"
              >
                {Math.round(zoomLevel * 100)}%
              </button>
              <button
                onClick={handleZoomIn}
                className="p-1.5 hover:opacity-75 transition"
                style={{ color: 'var(--text)' }}
                title="Zoom In"
              >
                <ZoomIn className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Filters Bar */}
        <div
          className="flex flex-wrap items-center justify-between gap-3 pt-4 mt-4 border-t"
          style={{ borderColor: 'var(--border)' }}
        >
          <div className="flex flex-wrap items-center gap-3">
            {/* Search */}
            <div className="relative">
              <Search
                className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2"
                style={{ color: 'var(--text-muted)' }}
              />
              <input
                type="text"
                placeholder={isBn ? 'গাছে সদস্য খুঁজুন...' : 'Search tree...'}
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-xl text-xs border focus:outline-none"
                style={{
                  backgroundColor: 'var(--card)',
                  borderColor: 'var(--border)',
                  color: 'var(--text)'
                }}
              />
            </div>

            {/* Branch filter */}
            <div className="flex items-center gap-1.5 text-xs">
              <Filter className="h-3.5 w-3.5" style={{ color: 'var(--primary)' }} />
              <span className="font-bold" style={{ color: 'var(--text)' }}>
                {isBn ? 'শাখা:' : 'Branch:'}
              </span>
              <select
                value={selectedBranch}
                onChange={e => setSelectedBranch(e.target.value)}
                className="rounded-xl border px-2.5 py-1.5 text-xs font-medium focus:outline-none"
                style={{
                  backgroundColor: 'var(--card)',
                  borderColor: 'var(--border)',
                  color: 'var(--text)'
                }}
              >
                <option value="all">{isBn ? 'সকল শাখা' : 'All Branches'}</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>
                    {isBn ? b.banglaName || b.name : b.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Focus Gen */}
            <div className="flex items-center gap-1.5 text-xs">
              <Layers className="h-3.5 w-3.5" style={{ color: 'var(--primary)' }} />
              <span className="font-bold" style={{ color: 'var(--text)' }}>
                {isBn ? 'প্রজন্ম স্তর:' : 'Tier:'}
              </span>
              <select
                value={focusGen}
                onChange={e => setFocusGen(e.target.value === 'all' ? 'all' : Number(e.target.value))}
                className="rounded-xl border px-2.5 py-1.5 text-xs font-medium focus:outline-none"
                style={{
                  backgroundColor: 'var(--card)',
                  borderColor: 'var(--border)',
                  color: 'var(--text)'
                }}
              >
                <option value="all">{isBn ? 'সকল স্তর' : 'All Tiers'}</option>
                {Array.from({ length: generationSummary.maxGeneration }, (_, i) => i + 1).map(g => (
                  <option key={g} value={g}>
                    {isBn ? `${toBanglaDigits(g)}ম প্রজন্ম` : `Gen ${g}`}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div
            className="text-[11px] font-bold flex items-center gap-1"
            style={{ color: 'var(--primary)' }}
          >
            <Crown className="w-3.5 h-3.5" />
            <span>{isBn ? 'জ্যেষ্ঠ ধারা (বড় সন্তানের সন্তানাদি পূর্বে বিন্যস্ত)' : 'Eldest child line placed first'}</span>
          </div>
        </div>
      </div>

      {/* VIEW MODE 1: TRADITIONAL GENERATIONAL TIERS WITH DYNAMIC CSS VARIABLES */}
      {treeMode === 'traditional' && (
        <div
          className="space-y-8 transition-transform origin-top"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          {Array.from({ length: Math.max(generationSummary.maxGeneration, 1) }, (_, i) => i + 1)
            .filter(gen => focusGen === 'all' || focusGen === gen)
            .map(gen => {
              const genMembers = membersByGeneration.get(gen) || [];
              if (genMembers.length === 0 && searchQuery) return null;

              return (
                <div
                  key={gen}
                  className="rounded-3xl p-5 sm:p-6 border shadow-xs transition-all space-y-4"
                  style={{
                    backgroundColor: 'var(--surface)',
                    borderColor: 'var(--border)'
                  }}
                >
                  {/* Tier Header with Theme Primary Color */}
                  <div
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b"
                    style={{ borderColor: 'var(--border)' }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-2xl flex items-center justify-center font-serif text-base font-bold text-white shadow-sm shrink-0"
                        style={{ backgroundColor: 'var(--primary)' }}
                      >
                        {isBn ? toBanglaDigits(gen) : gen}
                      </div>
                      <div>
                        <h3 className="font-serif text-base sm:text-lg font-bold" style={{ color: 'var(--text)' }}>
                          {isBn ? genLabelsBn[gen - 1] || `${toBanglaDigits(gen)}ম প্রজন্ম` : genLabelsEn[gen - 1] || `Generation ${gen}`}
                        </h3>
                        <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
                          {isBn
                            ? `এই স্তরে মোট ${toBanglaDigits(genMembers.length)} জন সদস্য • বড় সন্তানের শাখা ক্রমানুসারে সজ্জিত`
                            : `${genMembers.length} members in this tier ordered by eldest sibling lineages`}
                        </p>
                      </div>
                    </div>

                    <span
                      className="px-3 py-1 rounded-full text-[10px] font-mono font-bold self-start sm:self-auto border"
                      style={{
                        backgroundColor: 'var(--card)',
                        color: 'var(--primary)',
                        borderColor: 'var(--border)'
                      }}
                    >
                      TIER_{gen}_DEPTH
                    </span>
                  </div>

                  {/* Member Cards in Eldest Lineage Order */}
                  {genMembers.length === 0 ? (
                    <div
                      className="rounded-2xl border border-dashed p-6 text-center text-xs"
                      style={{ borderColor: 'var(--border)', color: 'var(--text-muted)' }}
                    >
                      {isBn ? 'এই প্রজন্মে ফিল্টার অনুযায়ী কোনো সদস্য নেই।' : 'No members matched filters in this tier.'}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {genMembers.map(member => {
                        const branch = branches.find(b => b.id === member.branchId);
                        const memberMarriages = marriages.filter(
                          mar => mar.husbandId === member.id || mar.wifeId === member.id
                        );
                        const father = member.fatherId ? memberMap.get(member.fatherId) : null;
                        const isEldestChild = member.birthOrder === 1;
                        const memberColor = getMemberColor(member);
                        const mother = member.motherId ? memberMap.get(member.motherId) : undefined;
                        const displayAge = calculateLifespan(member.birth?.date, member.death?.date, member.isLiving, language) || '—';

                        return (
                          <div
                            key={member.id}
                            data-member-color={memberColor.key}
                            className="group relative flex flex-col justify-between rounded-2xl border p-4 shadow-xs transition hover:shadow-md"
                            style={{
                              backgroundColor: memberColor.soft,
                              borderColor: memberColor.border
                            }}
                          >
                            <div className="space-y-2">
                              {/* Top Bar: Serial, Birth Order, Living */}
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5">
                                  <span
                                    className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md border"
                                    style={{
                                      backgroundColor: 'var(--badge-bg, var(--surface))',
                                      color: 'var(--badge-text, var(--primary))',
                                      borderColor: 'var(--border)'
                                    }}
                                  >
                                    
                                  </span>

                                  {member.birthOrder !== undefined && (
                                    <span
                                      className="text-[10px] px-2 py-0.5 rounded-md font-bold flex items-center gap-0.5 border"
                                      style={
                                        isEldestChild
                                          ? {
                                              backgroundColor: 'var(--card)',
                                              color: 'var(--primary)',
                                              borderColor: 'var(--primary)'
                                            }
                                          : {
                                              backgroundColor: 'var(--surface)',
                                              color: 'var(--text-muted)',
                                              borderColor: 'var(--border)'
                                            }
                                      }
                                      title={isEldestChild ? 'বড় সন্তান (Eldest Child)' : `জন্মক্রম #${member.birthOrder}`}
                                    >
                                      {isEldestChild && <Crown className="w-2.5 h-2.5" style={{ color: 'var(--primary)' }} />}
                                      <span>#{isBn ? toBanglaDigits(member.birthOrder) : member.birthOrder}</span>
                                      {isEldestChild && <span className="text-[9px]">({isBn ? 'বড়' : '1st'})</span>}
                                    </span>
                                  )}

                                  {branch && (
                                    <span
                                      className="h-2.5 w-2.5 rounded-full ring-1 ring-black/10"
                                      style={{ backgroundColor: branch.color }}
                                      title={branch.name}
                                    />
                                  )}
                                </div>

                                <span
                                  className="text-[10px] font-bold px-2.5 py-0.5 rounded-full border"
                                  style={
                                    { backgroundColor: memberColor.soft, color: memberColor.text, borderColor: memberColor.border }
                                  }
                                >
                                  {member.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}
                                </span>
                              </div>

                              {/* Member Name */}
                              <div>
                                <h4
                                  onClick={() => onSelectMember(member.id)}
                                  className="cursor-pointer font-serif text-base font-bold transition hover:underline"
                                  style={{ color: memberColor.text }}
                                >
                                  {isBn ? member.banglaName || member.fullName : member.englishName || member.fullName}
                                </h4>
                                {member.nickname && (
                                  <span className="text-xs font-normal" style={{ color: 'var(--text-muted)' }}>
                                    ({isBn ? 'ডাকনাম:' : 'Nick:'} {member.nickname})
                                  </span>
                                )}
                                {member.birthOrigin === 'born_in_family' && memberMarriages.length > 0 && (
                                  <div className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-1 text-xs font-semibold" style={{ color: 'var(--accent)' }}>
                                    <span>{isBn ? (member.gender === 'male' ? 'স্ত্রী:' : member.gender === 'female' ? 'স্বামী:' : 'সঙ্গী:') : 'Spouse:'}</span>
                                    {memberMarriages.map((mar, index) => {
                                      const spouseId = mar.husbandId === member.id ? mar.wifeId : mar.husbandId;
                                      const spouse = memberMap.get(spouseId);
                                      return spouse ? (
                                        <React.Fragment key={mar.id}>
                                          {index > 0 && <span style={{ color: 'var(--text-muted)' }}>•</span>}
                                          <button type="button" onClick={() => onSelectMember(spouse.id)} className="hover:underline">
                                            {isBn ? spouse.banglaName || spouse.fullName : spouse.englishName || spouse.fullName}
                                          </button>
                                        </React.Fragment>
                                      ) : null;
                                    })}
                                  </div>
                                )}
                              </div>

                              {/* Parent Lineage Indication */}
                              {father && (
                                <div className="text-[11px] flex items-center gap-1" style={{ color: 'var(--text-muted)' }}>
                                  <span>{isBn ? 'পিতা:' : 'Father:'}</span>
                                  <span className="font-semibold" style={{ color: 'var(--text)' }}>
                                    {isBn ? father.banglaName || father.fullName : father.englishName || father.fullName}
                                  </span>
                                  {father.birthOrder === 1 && (
                                    <span
                                      className="text-[9px] px-1 py-0.5 rounded font-bold border"
                                      style={{
                                        backgroundColor: 'var(--card)',
                                        color: 'var(--primary)',
                                        borderColor: 'var(--primary)'
                                      }}
                                    >
                                      {isBn ? 'জ্যেষ্ঠ শাখা' : 'Eldest Branch'}
                                    </span>
                                  )}
                                </div>
                              )}

                              {/* Compact profile facts */}
                              <div className="grid grid-cols-2 gap-2 rounded-xl border p-2.5" style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)' }}>
                                <div className="text-[10px]">{isBn ? 'প্রজন্ম' : 'Generation'}: <b>{member.computedGeneration ?? 1}</b></div>
                                <div className="text-[10px]">{isBn ? (member.isLiving ? 'বর্তমান বয়স' : 'মৃত্যুকালে বয়স') : (member.isLiving ? 'Current age' : 'Age at death')}: <b>{displayAge}</b></div>
                                <div className="text-[10px] truncate">{isBn ? 'পিতা' : 'Father'}: <b>{father ? (isBn ? (father.banglaName || father.fullName) : (father.englishName || father.fullName)) : '—'}</b></div>
                                <div className="text-[10px] truncate">{isBn ? 'মাতা' : 'Mother'}: <b>{mother ? (isBn ? (mother.banglaName || mother.fullName) : (mother.englishName || mother.fullName)) : '—'}</b></div>
                                <div className="text-[10px]">{isBn ? 'জন্ম' : 'Birth'}: <b>{member.birth?.date?.year ? formatGenealogyDate(member.birth.date, language) : '—'}</b></div>
                                <div className="text-[10px]">{isBn ? 'মৃত্যু' : 'Death'}: <b>{!member.isLiving && member.death?.date?.year ? formatGenealogyDate(member.death.date, language) : (isBn ? 'জীবিত' : 'Living')}</b></div>
                                <div className="text-[10px] truncate">{isBn ? 'পেশা' : 'Occupation'}: <b>{member.profession || '—'}</b></div>
                                <div className="text-[10px]">{isBn ? 'বিবাহ' : 'Marriages'}: <b>{memberMarriages.length ? `${isBn ? toBanglaDigits(memberMarriages.length) : memberMarriages.length}${isBn ? 'টি' : ''}` : (isBn ? 'অবিবাহিত' : 'Unmarried')}</b></div>
                                <div className="text-[10px]">{isBn ? 'উৎস' : 'Origin'}: <b>{isBn ? (member.birthOrigin==='born_in_family'?'জন্মসূত্রে':member.birthOrigin==='joined_by_marriage'?'বিবাহসূত্রে':member.birthOrigin==='adopted'?'দত্তক':'অজানা') : member.birthOrigin}</b></div>
                                <div className="col-span-2 text-[10px] truncate">{isBn ? 'ঠিকানা' : 'Address'}: <b>{member.currentAddress?.fullAddress || member.currentAddress?.village || member.permanentAddress?.fullAddress || member.permanentAddress?.village || '—'}</b></div>
                              </div>
                            </div>

                            {/* Card Footer Actions */}
                            <div
                              className="mt-3 flex items-center justify-between border-t pt-2 text-xs"
                              style={{ borderColor: 'var(--border)' }}
                            >
                              <button
                                onClick={() => onTraceRelationship(member.id)}
                                className="inline-flex items-center gap-1 font-bold hover:underline"
                                style={{ color: 'var(--primary)' }}
                              >
                                <Compass className="h-3.5 w-3.5" />
                                <span>{isBn ? 'সম্পর্ক নির্ণয়' : 'Trace Kinship'}</span>
                              </button>

                              <button
                                onClick={() => onSelectMember(member.id)}
                                className="text-[11px] font-bold hover:opacity-75"
                                style={{ color: 'var(--primary)' }}
                              >
                                {isBn ? 'প্রোফাইল →' : 'Profile →'}
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      )}

      {/* VIEW MODE 2: INTERACTIVE SVG KINSHIP GRAPH WITH FULL THEME CSS VARIABLES */}
      {treeMode === 'graph' && (
        <div
          className="relative min-h-[500px] w-full overflow-hidden rounded-3xl border p-6 shadow-inner transition-colors"
          style={{
            backgroundColor: 'var(--surface)',
            borderColor: 'var(--border)'
          }}
        >
          <div className="text-center pb-4 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>
            {isBn
              ? 'ইন্টারেক্টিভ গ্রাফ: নির্বাচিত থিমের কালার স্কিমে রক্তের সংযোগ ও পিতা-মাতার লাইন রেন্ডার করা হয়েছে।'
              : 'Interactive Pedigree Network rendered with active theme tokens.'}
          </div>

          <svg className="h-[460px] w-full" style={{ overflow: 'visible' }}>
            {/* Draw parent-child connector lines using CSS theme connector variable */}
            {treeMembers.map(child => {
              const gen = generations.get(child.id) || 1;
              const sameGen = treeMembers.filter(m => (generations.get(m.id) || 1) === gen);
              const childIndex = sameGen.indexOf(child);
              const totalInGen = sameGen.length || 1;
              const childX = 80 + (childIndex * (750 / Math.max(totalInGen, 1)));
              const childY = 60 + ((gen - 1) * 90);

              const father = child.fatherId ? memberMap.get(child.fatherId) : null;
              if (father && treeMembers.some(m => m.id === father.id)) {
                const fatherGen = generations.get(father.id) || 1;
                const fatherGenList = members.filter(m => (generations.get(m.id) || 1) === fatherGen);
                const fatherIndex = fatherGenList.indexOf(father);
                const fatherX = 80 + (fatherIndex * (750 / Math.max(fatherGenList.length, 1)));
                const fatherY = 60 + ((fatherGen - 1) * 90);

                return (
                  <path
                    key={`line-${father.id}-${child.id}`}
                    d={`M ${fatherX} ${fatherY} C ${fatherX} ${(fatherY + childY) / 2}, ${childX} ${(fatherY + childY) / 2}, ${childX} ${childY}`}
                    fill="none"
                    stroke="var(--tree-line, var(--primary))"
                    strokeWidth="2.5"
                    strokeOpacity="0.75"
                  />
                );
              }
              return null;
            })}

            {/* Draw member node circles using theme primary & card tokens */}
            {treeMembers.map(member => {
              const gen = generations.get(member.id) || 1;
              const sameGen = treeMembers.filter(m => (generations.get(m.id) || 1) === gen);
              const index = sameGen.indexOf(member);
              const totalInGen = sameGen.length || 1;
              const x = 80 + (index * (750 / Math.max(totalInGen, 1)));
              const y = 60 + ((gen - 1) * 90);

              return (
                <g
                  key={`node-${member.id}`}
                  className="cursor-pointer group"
                  onClick={() => onSelectMember(member.id)}
                >
                  <circle
                    cx={x}
                    cy={y}
                    r="16"
                    fill="var(--card)"
                    stroke="var(--primary)"
                    strokeWidth="3"
                    className="transition group-hover:scale-125 origin-center"
                  />
                  <text
                    x={x}
                    y={y + 4}
                    textAnchor="middle"
                    fontSize="10"
                    fontWeight="bold"
                    fill="var(--text)"
                    className="pointer-events-none"
                  >
                    {(member.banglaName || member.fullName)[0]}
                  </text>
                  <text
                    x={x}
                    y={y + 26}
                    textAnchor="middle"
                    fontSize="10"
                    fontWeight="600"
                    fill="var(--text)"
                    className="pointer-events-none font-serif"
                  >
                    {(isBn ? member.banglaName || member.fullName : member.englishName || member.fullName).split(' ')[0]}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      )}

      {/* VIEW MODE 3: BRANCH TIERS */}
      {treeMode === 'branch' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {branches.map(branch => {
            const branchMembers = members.filter(m => m.branchId === branch.id);
            return (
              <div
                key={branch.id}
                className="rounded-3xl border p-5 space-y-4 shadow-sm"
                style={{
                  backgroundColor: 'var(--card)',
                  borderColor: `${branch.color}50`
                }}
              >
                <div
                  className="flex items-center justify-between pb-3 border-b"
                  style={{ borderColor: 'var(--border)' }}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: branch.color }} />
                    <h3 className="font-serif font-bold text-base" style={{ color: 'var(--text)' }}>
                      {isBn ? branch.banglaName || branch.name : branch.name}
                    </h3>
                  </div>
                  <span
                    className="text-xs font-bold px-2 py-0.5 rounded-md"
                    style={{ backgroundColor: `${branch.color}20`, color: branch.color }}
                  >
                    {branchMembers.length} {isBn ? 'সদস্য' : 'members'}
                  </span>
                </div>

                <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                  {branchMembers.map(m => (
                    <div
                      key={m.id}
                      onClick={() => onSelectMember(m.id)}
                      className="flex items-center justify-between p-2 rounded-xl border cursor-pointer hover:opacity-80 transition"
                      style={{
                        backgroundColor: 'var(--surface)',
                        borderColor: 'var(--border)'
                      }}
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] font-bold" style={{ color: 'var(--text-muted)' }}>
                          
                        </span>
                        <span className="font-bold text-xs" style={{ color: 'var(--text)' }}>
                          {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
                        </span>
                      </div>
                      <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                        {isBn ? `${toBanglaDigits(generations.get(m.id) || 1)}ম প্রজন্ম` : `Gen ${generations.get(m.id) || 1}`}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
