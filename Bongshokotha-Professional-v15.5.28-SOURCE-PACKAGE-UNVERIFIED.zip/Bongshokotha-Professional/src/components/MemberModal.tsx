/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Smart Member Form v3 — guided, responsive, relationship-aware member registration & editing modal
 * Married-in spouse parent links are explicitly separated; do not automatically make them birth-line members.
 * 
 * User Requirement:
 * "সদস্য ফরম মাত্র একটি পেজে দেখাবে, নতুন, সম্পাদনের সময়ও।"
 * (Member form displays on ONE single continuous page for both new registration and editing).
 * 
 * Master Principles Enforced:
 * - "Name may change, Person ID must never change."
 * - "NID and Birth Registration MUST be separate fields."
 * - "Date precision stored separately from date value."
 * - "In-marrying members retain original biological lineage."
 * - "Unmarried member rule: suppress inappropriate spouse/children sections."
 */

import React, { useState, useEffect, useRef } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { Member, Gender, DatePrecision, BirthOrigin, VerificationStatus, GenerationMode, MemberDocument, ResearchStatus, BloodGroup, EducationRecord, ProfessionRecord, ResidenceRecord, LocationInfo } from '../types/genealogy';
import { AvatarUploadModal } from './AvatarUploadModal';
import { BANGLA_MONTHS, toBanglaDigits, gregorianToBangla } from '../engine/banglaCalendar';
import { calculateGenerations } from '../engine/generationEngine';
import { runDocumentOcr } from '../engine/ocrEngine';
import { buildExtractedFieldCandidates, parseDocumentDate } from '../engine/ocrFieldParser';
import {
  X,
  User,
  Calendar,
  MapPin,
  FileText,
  ShieldCheck,
  Heart,
  GitFork,
  HelpCircle,
  Save,
  AlertCircle,
  Sparkles,
  ChevronDown,
  Trash2,
  AlertTriangle
} from 'lucide-react';

const normalizeAddressInfo = (address?: LocationInfo): Partial<LocationInfo> => {
  if (!address) return { country: 'বাংলাদেশ' };
  const hasStructuredFields = Boolean(address.holding || address.road || address.village || address.union || address.ward || address.postOffice || address.postalCode || address.upazila || address.district || address.division || address.country);
  if (hasStructuredFields) return { ...address, country: address.country || 'বাংলাদেশ' };
  // Backward compatibility: old releases stored the address as a comma-separated string only.
  const parts = String(address.fullAddress || '').split(',').map(part => part.trim()).filter(Boolean);
  return { village: parts[0] || '', postOffice: parts[1] || '', upazila: parts[2] || '', district: parts[3] || '', division: parts[4] || '', country: parts[5] || 'বাংলাদেশ', fullAddress: address.fullAddress || '' };
};

const formatLocationInfo = (a: Partial<LocationInfo> = {}, fallback = ''): string => {
  const parts = [
    a.holding ? `বাড়ি/হোল্ডিং ${a.holding}` : '',
    a.road ? `রাস্তা ${a.road}` : '',
    a.village ? `গ্রাম/মহল্লা ${a.village}` : '',
    a.ward ? `ওয়ার্ড ${a.ward}` : '',
    a.union || '',
    a.postOffice ? `ডাকঘর: ${a.postOffice}` : '',
    a.postalCode ? `পোস্ট কোড: ${a.postalCode}` : '',
    a.upazila ? `উপজেলা/থানা ${a.upazila}` : '',
    a.district ? `জেলা ${a.district}` : '',
    a.division ? `বিভাগ ${a.division}` : '',
    a.country || 'বাংলাদেশ'
  ].map(v => String(v || '').trim()).filter(Boolean);
  return parts.join(', ') || fallback || '';
};

type AddressFieldKey = 'holding' | 'road' | 'village' | 'union' | 'ward' | 'postOffice' | 'postalCode' | 'upazila' | 'district' | 'division' | 'country';
const ADDRESS_FIELDS: { key: AddressFieldKey; bn: string; en: string }[] = [
  { key: 'holding', bn: 'বাড়ি / হোল্ডিং নম্বর', en: 'House / Holding No.' },
  { key: 'road', bn: 'রাস্তা / সড়ক', en: 'Road / Street' },
  { key: 'village', bn: 'গ্রাম / মহল্লা', en: 'Village / Locality' },
  { key: 'ward', bn: 'ওয়ার্ড নম্বর', en: 'Ward No.' },
  { key: 'union', bn: 'ইউনিয়ন পরিষদ / পৌরসভা / সিটি কর্পোরেশন', en: 'Union Council / Municipality / City Corporation' },
  { key: 'postOffice', bn: 'ডাকঘরের নাম', en: 'Post Office Name' },
  { key: 'postalCode', bn: 'পোস্ট কোড', en: 'Postal Code' },
  { key: 'upazila', bn: 'উপজেলা / থানা', en: 'Upazila / Thana' },
  { key: 'district', bn: 'জেলা', en: 'District' },
  { key: 'division', bn: 'বিভাগ', en: 'Division' },
  { key: 'country', bn: 'দেশ', en: 'Country' }
];

interface MemberModalProps {
  isOpen: boolean;
  onClose: () => void;
  memberToEdit?: Member | null;
  /** Opens the newly-created child profile immediately after a successful save. */
  onSavedMemberId?: (id: string) => void;
}

export const MemberModal: React.FC<MemberModalProps> = ({
  isOpen,
  onClose,
  memberToEdit,
  onSavedMemberId
}) => {
  const {
    family,
    members,
    branches,
    addMember,
    updateMember,
    addMarriage,
    updateMarriage,
    deleteMember,
    marriages,
    language,
    addArchiveRecord
  } = useGenealogy();

  const isBn = language === 'bn';
  const isEditing = !!memberToEdit;
  const formContainerRef = useRef<HTMLDivElement>(null);
  // Relationship operations can complete while this modal still holds an older
  // render snapshot. Keep a live member list so a newly-created child is never
  // treated as missing during the same save operation.
  const latestMembersRef = useRef<Member[]>(members);
  const pendingChildIdsRef = useRef<string[]>([]);
  useEffect(() => { latestMembersRef.current = members; }, [members]);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  // Form states
  const [banglaName, setBanglaName] = useState('');
  const [englishName, setEnglishName] = useState('');
  const [nickname, setNickname] = useState('');
  const [formerName, setFormerName] = useState('');
  const [profession, setProfession] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [email, setEmail] = useState('');
  const [currentAddress, setCurrentAddress] = useState('');
  const [permanentAddress, setPermanentAddress] = useState('');
  // Structured address fields are stored alongside fullAddress so older saved records remain compatible.
  const [currentAddressDetails, setCurrentAddressDetails] = useState<Partial<LocationInfo>>({ country: 'বাংলাদেশ' });
  const [permanentAddressDetails, setPermanentAddressDetails] = useState<Partial<LocationInfo>>({ country: 'বাংলাদেশ' });
  // Bangladesh administrative hierarchy is loaded from a public bilingual dataset and cached locally.
  // This makes Division → District → Upazila → Union/Pouroshava real selectors instead of saved-address suggestions.
  const [bangladeshGeo, setBangladeshGeo] = useState<any[]>([]);
  const [geoStatus, setGeoStatus] = useState<'loading'|'ready'|'offline'>('loading');
  useEffect(() => {
    let cancelled = false;
    try {
      const cached = localStorage.getItem('bongshokotha:bd-location-catalog:v1');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length) { setBangladeshGeo(parsed); setGeoStatus('ready'); }
      }
    } catch { /* Ignore an invalid cache and try the source. */ }
    fetch('https://iqbalhasandev.github.io/bangladesh-geo-json/bangladesh-geo.json')
      .then(response => { if (!response.ok) throw new Error('Location catalogue unavailable'); return response.json(); })
      .then(data => {
        if (!cancelled && Array.isArray(data) && data.length) {
          setBangladeshGeo(data); setGeoStatus('ready');
          try { localStorage.setItem('bongshokotha:bd-location-catalog:v1', JSON.stringify(data)); } catch { /* Storage may be full or disabled. */ }
        }
      })
      .catch(() => { if (!cancelled) setGeoStatus(current => current === 'ready' ? 'ready' : 'offline'); });
    return () => { cancelled = true; };
  }, []);
  const [education, setEducation] = useState('');
  const [maritalStatus, setMaritalStatus] = useState<'unmarried'|'married'|'divorced'|'widowed'|'widower'|'separated'|'unknown'>('unmarried');
  const [birthOrder, setBirthOrder] = useState<number | undefined>(1);
  const [generationMode, setGenerationMode] = useState<GenerationMode>('automatic');
  const [generationOverride, setGenerationOverride] = useState<number | undefined>(undefined);
  const [gender, setGender] = useState<Gender>('male');
  const [branchId, setBranchId] = useState('');
  const [isLiving, setIsLiving] = useState(true);
  const [birthOrigin, setBirthOrigin] = useState<BirthOrigin>('born_in_family');
  const [originalLineageNote, setOriginalLineageNote] = useState('');
  const [isUnmarried, setIsUnmarried] = useState(true);
  const [spouseId, setSpouseId] = useState('');
  const [spouseIds, setSpouseIds] = useState<string[]>([]);
  const [relationshipGeneration, setRelationshipGeneration] = useState<number | 'current' | 'next'>('current');
  const [childGenderFilter, setChildGenderFilter] = useState<'all' | Gender>('all');
  const [childIds, setChildIds] = useState<string[]>([]);
  const [childNameDrafts, setChildNameDrafts] = useState<string[]>(['']);
  const [childGenderDrafts, setChildGenderDrafts] = useState<Gender[]>(['unknown']);
  const [isSaving, setIsSaving] = useState(false);
  const [memberDocuments, setMemberDocuments] = useState<MemberDocument[]>([]);
  const [selectedOcrFieldsByDoc, setSelectedOcrFieldsByDoc] = useState<Record<string, string[]>>({});
  const [profilePhoto, setProfilePhoto] = useState('');
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);

  // Birth date & location
  const [birthYear, setBirthYear] = useState<number | ''>('');
  const [birthMonth, setBirthMonth] = useState<number | ''>('');
  const [birthDay, setBirthDay] = useState<number | ''>('');
  const [birthPrecision, setBirthPrecision] = useState<DatePrecision>('exact');
  const [birthVillage, setBirthVillage] = useState('');
  const [birthPostOffice, setBirthPostOffice] = useState('');
  const [birthUpazila, setBirthUpazila] = useState('');
  const [birthDistrict, setBirthDistrict] = useState('');
  const [birthDivision, setBirthDivision] = useState('');
  const [birthCountry, setBirthCountry] = useState('বাংলাদেশ');

  // Bengali Date in Birth
  const [banglaDateDay, setBanglaDateDay] = useState<number | ''>('');
  const [banglaDateMonth, setBanglaDateMonth] = useState('');
  const [banglaDateYear, setBanglaDateYear] = useState<number | ''>('');

  // Death info
  const [deathYear, setDeathYear] = useState<number | ''>('');
  const [deathMonth, setDeathMonth] = useState<number | ''>('');
  const [deathDay, setDeathDay] = useState<number | ''>('');
  const [ageAtDeath, setAgeAtDeath] = useState<number | ''>('');
  const [deathPrecision, setDeathPrecision] = useState<DatePrecision>('exact');
  const [deathBurialPlace, setDeathBurialPlace] = useState('');
  const [deathMemorialInfo, setDeathMemorialInfo] = useState('');

  // Identity documents: NID and Birth Registration strictly separate!
  const [nidNumber, setNidNumber] = useState('');
  const [birthRegistrationNumber, setBirthRegistrationNumber] = useState('');
  const [passportNumber, setPassportNumber] = useState('');
  const [otherId, setOtherId] = useState('');
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>('unverified');
  const [researchStatus, setResearchStatus] = useState<ResearchStatus>('unverified');
  const [alternativeNames, setAlternativeNames] = useState('');
  const [alternativeNameSources, setAlternativeNameSources] = useState('');
  const [alternativeEnglishNames, setAlternativeEnglishNames] = useState('');
  const [nationality, setNationality] = useState('');
  const [religion, setReligion] = useState('');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('unknown');
  const [languages, setLanguages] = useState('');
  const [physicalDescription, setPhysicalDescription] = useState('');
  const [militaryService, setMilitaryService] = useState('');
  const [migrationHistory, setMigrationHistory] = useState('');
  const [researchNotes, setResearchNotes] = useState('');
  const [familyOriginStory, setFamilyOriginStory] = useState('');
  const [memorialStory, setMemorialStory] = useState('');
  const [memberNotes, setMemberNotes] = useState('');
  const [tags, setTags] = useState('');
  const [educationHistory, setEducationHistory] = useState<EducationRecord[]>([]);
  const [professionHistory, setProfessionHistory] = useState<ProfessionRecord[]>([]);
  const [residenceHistory, setResidenceHistory] = useState<ResidenceRecord[]>([]);

  // Kinship parents
  const [fatherId, setFatherId] = useState('');
  const [motherId, setMotherId] = useState('');
  const [fatherNameBn, setFatherNameBn] = useState('');
  const [fatherNameEn, setFatherNameEn] = useState('');
  const [motherNameBn, setMotherNameBn] = useState('');
  const [motherNameEn, setMotherNameEn] = useState('');
  const [adoptiveFatherNameBn, setAdoptiveFatherNameBn] = useState('');
  const [adoptiveFatherNameEn, setAdoptiveFatherNameEn] = useState('');
  const [adoptiveMotherNameBn, setAdoptiveMotherNameBn] = useState('');
  const [adoptiveMotherNameEn, setAdoptiveMotherNameEn] = useState('');
  const [paternalGrandfatherId, setPaternalGrandfatherId] = useState('');
  const [paternalGrandmotherId, setPaternalGrandmotherId] = useState('');
  const [maternalGrandfatherId, setMaternalGrandfatherId] = useState('');
  const [maternalGrandmotherId, setMaternalGrandmotherId] = useState('');
  const [fatherInLawId, setFatherInLawId] = useState('');
  const [motherInLawId, setMotherInLawId] = useState('');
  const [fatherInLawName, setFatherInLawName] = useState('');
  const [motherInLawName, setMotherInLawName] = useState('');

  // Bio & notes
  const [biography, setBiography] = useState('');
  const [importantInfo, setImportantInfo] = useState('');

  // Address suggestions are sourced from saved genealogy records, so reused addresses
  // stay consistent and the form works offline. A curated national catalog can extend this source.
  const addressSources = React.useMemo(() => members.flatMap(m => [m.currentAddress, m.permanentAddress])
    .filter((a): a is LocationInfo => Boolean(a))
    .map(normalizeAddressInfo), [members]);
  const addressDependencies: Record<AddressFieldKey, AddressFieldKey[]> = {
    division: [], district: ['division'], upazila: ['division', 'district'], union: ['division', 'district', 'upazila'],
    postOffice: ['division', 'district', 'upazila', 'union'], postalCode: ['division', 'district', 'upazila', 'union', 'postOffice'],
    village: ['division', 'district', 'upazila', 'union'], ward: ['division', 'district', 'upazila', 'union'],
    holding: ['division', 'district', 'upazila', 'union', 'village'], road: ['division', 'district', 'upazila', 'union', 'village'], country: []
  };
  const getAddressSuggestions = (field: AddressFieldKey, details: Partial<LocationInfo>): string[] => {
    const deps = addressDependencies[field];
    // Never fall back to the entire saved-address list when a parent location is selected.
    // That old fallback caused upazilas from unrelated districts to appear in the dropdown.
    const relevant = addressSources.filter(source => deps.every(dep => {
      const selected = String(details[dep] || '').trim();
      if (!selected) return true;
      const saved = String(source[dep] || '').trim();
      return Boolean(saved) && saved.localeCompare(selected, 'bn', { sensitivity: 'accent' }) === 0;
    }));
    const values = relevant.map(row => String(row[field] || '').trim()).filter(Boolean);
    if (field === 'country') values.push('বাংলাদেশ');
    return [...new Set(values)].sort((a, b) => a.localeCompare(b, 'bn'));
  };
  const catalogName = (row: any) => String(row?.bn_name || row?.name || '');
  const findByCatalogName = (rows: any[], name: unknown) => rows.find(row => [row?.bn_name, row?.name].some(value => String(value || '').trim() === String(name || '').trim()));
  const getAddressCatalogOptions = (field: AddressFieldKey, details: Partial<LocationInfo>): string[] => {
    if (!bangladeshGeo.length) return getAddressSuggestions(field, details);
    if (field === 'division') return bangladeshGeo.map(catalogName).filter(Boolean);
    const division = findByCatalogName(bangladeshGeo, details.division);
    const districts = division?.districts || []; // Never offer districts from other divisions when the selected division cannot be resolved.
    if (field === 'district') return districts.map(catalogName).filter(Boolean);
    const district = findByCatalogName(districts, details.district);
    const upazilas = district?.upazilas || []; // Never mix upazilas from other districts.
    if (field === 'upazila') return upazilas.map(catalogName).filter(Boolean);
    const upazila = findByCatalogName(upazilas, details.upazila);
    if (field === 'union') return [...(upazila?.unions || []).map(catalogName), ...(upazila?.pourashavas || []).map(catalogName)].filter(Boolean).sort((a,b)=>a.localeCompare(b,'bn'));
    return getAddressSuggestions(field, details);
  };
  const updateAddressField = (setter: React.Dispatch<React.SetStateAction<Partial<LocationInfo>>>, field: AddressFieldKey, value: string) => {
    setter(prev => {
      const next: Partial<LocationInfo> = { ...prev, [field]: value };
      const clearAfter: Partial<Record<AddressFieldKey, AddressFieldKey[]>> = {
        division: ['district', 'upazila', 'union', 'postOffice', 'postalCode', 'village', 'ward', 'holding', 'road'],
        district: ['upazila', 'union', 'postOffice', 'postalCode', 'village', 'ward', 'holding', 'road'],
        upazila: ['union', 'postOffice', 'postalCode', 'village', 'ward', 'holding', 'road'],
        union: ['postOffice', 'postalCode', 'village', 'ward', 'holding', 'road'],
        postOffice: ['postalCode']
      };
      for (const key of clearAfter[field] || []) if (prev[key] && value.trim() !== String(prev[field] || '').trim()) next[key] = '';
      return next;
    });
  };
  const addressPreview = (details: Partial<LocationInfo>, fallback: string) => formatLocationInfo(details, fallback);

  // Populate or reset form
  useEffect(() => {
    if (memberToEdit) {
      setBanglaName(memberToEdit.banglaName || memberToEdit.fullName || '');
      setEnglishName(memberToEdit.englishName || '');
      setNickname(memberToEdit.nickname || '');
      setFormerName(memberToEdit.formerName || '');
      setProfession(memberToEdit.profession || ''); setMobileNumber(memberToEdit.mobileNumber || ''); setEmail(memberToEdit.email || '');
      setCurrentAddress(memberToEdit.currentAddress?.fullAddress || ''); setPermanentAddress(memberToEdit.permanentAddress?.fullAddress || '');
      setCurrentAddressDetails(normalizeAddressInfo(memberToEdit.currentAddress));
      setPermanentAddressDetails(normalizeAddressInfo(memberToEdit.permanentAddress));
      setEducation(memberToEdit.education || '');
      setMaritalStatus(memberToEdit.maritalStatus || (memberToEdit.isUnmarried ? 'unmarried' : 'unknown'));
      setBirthOrder(memberToEdit.birthOrder || 1);
      setGenerationMode(memberToEdit.generationMode || 'automatic');
      setGenerationOverride(memberToEdit.generationOverride);
      setGender(memberToEdit.gender);
      setBranchId(memberToEdit.branchId || '');
      setIsLiving(memberToEdit.isLiving);
      setBirthOrigin(memberToEdit.birthOrigin || 'born_in_family');
      setOriginalLineageNote(memberToEdit.originalLineageNote || '');
      setIsUnmarried(memberToEdit.isUnmarried ?? (memberToEdit.maritalStatus === 'unmarried'));
      const existingMarriage = marriages.filter(m => m.husbandId === memberToEdit.id || m.wifeId === memberToEdit.id).sort((a, b) => Number(b.status === 'current') - Number(a.status === 'current') || String(b.updatedAt).localeCompare(String(a.updatedAt)))[0];
      const allMemberMarriages = marriages.filter(m => m.husbandId === memberToEdit.id || m.wifeId === memberToEdit.id);
      const allSpouseIds = allMemberMarriages.map(m => m.husbandId === memberToEdit.id ? m.wifeId : m.husbandId);
      const primarySpouseId = existingMarriage ? (existingMarriage.husbandId === memberToEdit.id ? existingMarriage.wifeId : existingMarriage.husbandId) : '';
      setSpouseIds([...new Set(allSpouseIds)]);
      setSpouseId(primarySpouseId);
      setRelationshipGeneration('current');
      const existingChildIds = [...new Set(allMemberMarriages.flatMap(m => m.childrenIds || []))];
      setChildIds(existingChildIds);
      setProfilePhoto(memberToEdit.profilePhoto || '');
      setChildNameDrafts(['']);
      setChildGenderDrafts(['unknown']);
      const existingDocs = memberToEdit.memberDocuments || [];
      setMemberDocuments(existingDocs);
      setSelectedOcrFieldsByDoc(Object.fromEntries(existingDocs.map(doc => [doc.id, buildExtractedFieldCandidates(doc.extractedFields || { documentKind: 'general', confidence: 0 }).filter(c => c.profileWritable !== false).map(c => c.key)])));

      setBirthYear(memberToEdit.birth?.date?.year || '');
      setBirthMonth(memberToEdit.birth?.date?.month || '');
      setBirthDay(memberToEdit.birth?.date?.day || '');
      setBirthPrecision(memberToEdit.birth?.date?.precision || 'exact');

      setBanglaDateDay(memberToEdit.birth?.date?.banglaDate?.day || '');
      setBanglaDateMonth(memberToEdit.birth?.date?.banglaDate?.month || '');
      setBanglaDateYear(memberToEdit.birth?.date?.banglaDate?.year || '');

      setBirthVillage(memberToEdit.birth?.place?.village || '');
      setBirthPostOffice(memberToEdit.birth?.place?.postOffice || '');
      setBirthUpazila(memberToEdit.birth?.place?.upazila || '');
      setBirthDistrict(memberToEdit.birth?.place?.district || '');
      setBirthDivision(memberToEdit.birth?.place?.division || '');
      setBirthCountry(memberToEdit.birth?.place?.country || 'বাংলাদেশ');

      setDeathYear(memberToEdit.death?.date?.year || '');
      setDeathMonth(memberToEdit.death?.date?.month || '');
      setDeathDay(memberToEdit.death?.date?.day || '');
      setAgeAtDeath(memberToEdit.ageAtDeath ?? '');
      setDeathPrecision(memberToEdit.death?.date?.precision || 'exact');
      setDeathBurialPlace(memberToEdit.death?.burialPlace || '');
      setDeathMemorialInfo(memberToEdit.death?.memorialInfo || '');

      setNidNumber(memberToEdit.identityDocs?.nidNumber || '');
      setBirthRegistrationNumber(memberToEdit.identityDocs?.birthRegistrationNumber || '');
      setPassportNumber(memberToEdit.identityDocs?.passportNumber || '');
      setOtherId(memberToEdit.identityDocs?.otherId || '');
      setVerificationStatus(memberToEdit.identityDocs?.verificationStatus || 'unverified');
      setResearchStatus(memberToEdit.researchStatus || 'unverified');
      setAlternativeNames((memberToEdit.alternativeBanglaNames || memberToEdit.alternativeNames || []).join('\n'));
      setAlternativeNameSources((memberToEdit.alternativeNameRecords || []).map(r => [r.name, r.sourceType || '', r.sourceReference || '', r.note || ''].join(' | ')).join('\n'));
      setAlternativeEnglishNames((memberToEdit.alternativeEnglishNames || []).join('\n'));
      setNationality(memberToEdit.nationality || ''); setReligion(memberToEdit.religion || '');
      setBloodGroup(memberToEdit.bloodGroup || 'unknown');
      setLanguages((memberToEdit.languages || []).join(', '));
      setPhysicalDescription(memberToEdit.physicalDescription || ''); setMilitaryService(memberToEdit.militaryService || '');
      setMigrationHistory(memberToEdit.migrationHistory || ''); setResearchNotes(memberToEdit.researchNotes || '');
      setFamilyOriginStory(memberToEdit.familyOriginStory || ''); setMemorialStory(memberToEdit.memorialStory || '');
      setMemberNotes(memberToEdit.notes || ''); setTags((memberToEdit.tags || []).join(', '));
      setEducationHistory(memberToEdit.educationHistory || []);
      setProfessionHistory(memberToEdit.professionHistory || []);
      setResidenceHistory(memberToEdit.residenceHistory || []);

      // A marriage-origin person's biological parents belong to their birth family.
      // Preserve their names as external facts, never as this family's parent-member links.
      setFatherId(memberToEdit.birthOrigin === 'joined_by_marriage' || memberToEdit.marriageOrigin ? '' : (memberToEdit.fatherId || ''));
      setMotherId(memberToEdit.birthOrigin === 'joined_by_marriage' || memberToEdit.marriageOrigin ? '' : (memberToEdit.motherId || ''));
      setFatherNameBn(memberToEdit.fatherNameBn || '');
      setFatherNameEn(memberToEdit.fatherNameEn || '');
      setMotherNameBn(memberToEdit.motherNameBn || '');
      setMotherNameEn(memberToEdit.motherNameEn || '');
      setAdoptiveFatherNameBn(memberToEdit.adoptiveFatherNameBn || '');
      setAdoptiveFatherNameEn(memberToEdit.adoptiveFatherNameEn || '');
      setAdoptiveMotherNameBn(memberToEdit.adoptiveMotherNameBn || '');
      setAdoptiveMotherNameEn(memberToEdit.adoptiveMotherNameEn || '');
      setPaternalGrandfatherId(memberToEdit.paternalGrandfatherId || '');
      setPaternalGrandmotherId(memberToEdit.paternalGrandmotherId || '');
      setMaternalGrandfatherId(memberToEdit.maternalGrandfatherId || '');
      setMaternalGrandmotherId(memberToEdit.maternalGrandmotherId || '');
      setFatherInLawId(memberToEdit.fatherInLawId || '');
      setMotherInLawId(memberToEdit.motherInLawId || '');
      setFatherInLawName(memberToEdit.fatherInLawName || '');
      setMotherInLawName(memberToEdit.motherInLawName || '');
      setBiography(memberToEdit.biography || '');
      setImportantInfo(memberToEdit.importantInformation || '');
    } else {
      setBanglaName('');
      setEnglishName('');
      setNickname('');
      setFormerName('');
      setProfession(''); setMobileNumber(''); setEmail(''); setCurrentAddress(''); setPermanentAddress('');
      setCurrentAddressDetails({ country: 'বাংলাদেশ' }); setPermanentAddressDetails({ country: 'বাংলাদেশ' });
      setEducation(''); setMaritalStatus('unmarried');
      setBirthOrder(1);
      setGenerationMode('automatic');
      setGenerationOverride(undefined);
      setGender('male');
      setBranchId(branches[0]?.id || '');
      setIsLiving(true);
      setBirthOrigin('born_in_family');
      setOriginalLineageNote('');
      setIsUnmarried(true);
      setSpouseId('');
      setSpouseIds([]);
      setChildIds([]);
      setChildNameDrafts(['']);
      setChildGenderDrafts(['unknown']);
      setMemberDocuments([]);
      setSelectedOcrFieldsByDoc({});

      setBirthYear('');
      setBirthMonth('');
      setBirthDay('');
      setBirthPrecision('exact');
      setBanglaDateDay('');
      setBanglaDateMonth('');
      setBanglaDateYear('');
      setBirthVillage('');
      setBirthPostOffice('');
      setBirthUpazila('');
      setBirthDistrict('');
      setBirthDivision('');
      setBirthCountry('বাংলাদেশ');

      setDeathYear('');
      setDeathMonth('');
      setDeathDay('');
      setAgeAtDeath('');
      setDeathPrecision('exact');
      setDeathBurialPlace('');
      setDeathMemorialInfo('');

      setNidNumber('');
      setBirthRegistrationNumber('');
      setPassportNumber('');
      setOtherId('');
      setVerificationStatus('verified');
      setResearchStatus('unverified');
      setAlternativeNames('');
      setAlternativeNameSources('');
      setAlternativeEnglishNames('');
      setNationality(''); setReligion(''); setBloodGroup('unknown'); setLanguages('');
      setPhysicalDescription(''); setMilitaryService(''); setMigrationHistory(''); setResearchNotes('');
      setFamilyOriginStory(''); setMemorialStory(''); setMemberNotes(''); setTags('');
      setEducationHistory([]); setProfessionHistory([]); setResidenceHistory([]);

      setFatherId('');
      setMotherId('');
      setFatherNameBn('');
      setFatherNameEn('');
      setMotherNameBn('');
      setMotherNameEn('');
      setAdoptiveFatherNameBn(''); setAdoptiveFatherNameEn(''); setAdoptiveMotherNameBn(''); setAdoptiveMotherNameEn('');
      setPaternalGrandfatherId('');
      setPaternalGrandmotherId('');
      setMaternalGrandfatherId('');
      setMaternalGrandmotherId('');
      setFatherInLawId('');
      setMotherInLawId('');
      setFatherInLawName('');
      setMotherInLawName('');
      setBiography('');
      setImportantInfo('');
      setChildNameDrafts(['']);
      setChildGenderDrafts(['unknown']);
    }
  }, [memberToEdit?.id, isOpen]);

  if (!isOpen) return null;

  // Auto-calculate Bengali date if year, month, day entered
  const handleAutoCalcBanglaDate = () => {
    if (birthYear && birthMonth && birthDay) {
      const bg = gregorianToBangla(Number(birthYear), Number(birthMonth), Number(birthDay));
      setBanglaDateDay(bg.day);
      setBanglaDateMonth(bg.monthName);
      setBanglaDateYear(bg.year);
    }
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const addChildNameRow = () => { setChildNameDrafts(prev => [...prev, '']); setChildGenderDrafts(prev => [...prev, 'unknown']); };
  const removeChildNameRow = (index: number) => { setChildNameDrafts(prev => prev.filter((_, i) => i !== index)); setChildGenderDrafts(prev => prev.filter((_, i) => i !== index)); };
  const updateChildNameRow = (index: number, value: string) => setChildNameDrafts(prev => prev.map((name, i) => i === index ? value : name));
  const updateChildGenderRow = (index: number, value: Gender) => setChildGenderDrafts(prev => prev.map((gender, i) => i === index ? value : gender));

  const updateEducationRecord = (index: number, patch: Partial<EducationRecord>) => setEducationHistory(prev => prev.map((row, i) => i === index ? { ...row, ...patch } : row));
  const addEducationRecord = () => setEducationHistory(prev => [...prev, { id: crypto.randomUUID(), institution: '', qualification: '', subject: '', year: undefined, result: '', notes: '' }]);
  const removeEducationRecord = (index: number) => setEducationHistory(prev => prev.filter((_, i) => i !== index));
  const updateProfessionRecord = (index: number, patch: Partial<ProfessionRecord>) => setProfessionHistory(prev => prev.map((row, i) => i === index ? { ...row, ...patch } : row));
  const addProfessionRecord = () => setProfessionHistory(prev => [...prev, { id: crypto.randomUUID(), profession: '', organization: '', designation: '', notes: '' }]);
  const removeProfessionRecord = (index: number) => setProfessionHistory(prev => prev.filter((_, i) => i !== index));
  const updateResidenceRecord = (index: number, patch: Partial<ResidenceRecord>) => setResidenceHistory(prev => prev.map((row, i) => i === index ? { ...row, ...patch } : row));
  const addResidenceRecord = () => setResidenceHistory(prev => [...prev, { id: crypto.randomUUID(), label: 'previous', address: { fullAddress: '' }, notes: '' }]);
  const removeResidenceRecord = (index: number) => setResidenceHistory(prev => prev.filter((_, i) => i !== index));

  const createNamedChildren = async (parentMember: Member, otherParentId?: string) => {
    const drafts = childNameDrafts.map((name, index) => ({ name: name.trim(), gender: childGenderDrafts[index] || 'unknown' as Gender })).filter(item => item.name);
    if (!drafts.length) return [] as Member[];
    const startOrder = members.filter(m => m.fatherId === parentMember.id || m.motherId === parentMember.id).length + 1;
    const created: Member[] = [];
    for (let i = 0; i < drafts.length; i++) {
      const fatherIdForChild = parentMember.gender === 'male' ? parentMember.id : otherParentId;
      const motherIdForChild = parentMember.gender === 'female' ? parentMember.id : otherParentId;
      const child = await addMember({
        fullName: drafts[i].name, banglaName: drafts[i].name, englishName: '', gender: drafts[i].gender,
        branchId: parentMember.branchId || branchId || branches[0]?.id || 'branch-borotaraf',
        isLiving: true, birthOrigin: 'born_in_family', marriageOrigin: false, isUnmarried: true,
        birth: { date: { precision: 'unknown' }, place: {} }, death: { isDeceased: false },
        identityDocs: { verificationStatus: 'unverified' }, marriageIds: [], memberDocuments: [],
        fatherId: fatherIdForChild || undefined, motherId: motherIdForChild || undefined,
        birthOrder: startOrder + i
      });
      created.push(child);
      latestMembersRef.current = latestMembersRef.current.some(m => m.id === child.id)
        ? latestMembersRef.current.map(m => m.id === child.id ? child : m)
        : [...latestMembersRef.current, child];
    }
    return created;
  };

  const linkExistingChildrenToParents = async (parentMember: Member, selectedChildIds: string[], otherParentId?: string) => {
    const fatherIdForChild = parentMember.gender === 'male' ? parentMember.id : otherParentId;
    const motherIdForChild = parentMember.gender === 'female' ? parentMember.id : otherParentId;
    if (!fatherIdForChild && !motherIdForChild) return;

    for (const childId of selectedChildIds) {
      const child = latestMembersRef.current.find(m => m.id === childId);
      if (!child || child.id === parentMember.id) continue;

      // Never overwrite an already verified opposite parent. This is critical for
      // families with multiple marriages: an existing child keeps the spouse/union
      // that is already recorded instead of silently moving to the currently selected spouse.
      const nextFatherId = child.fatherId || fatherIdForChild;
      const nextMotherId = child.motherId || motherIdForChild;
      if (nextFatherId !== child.fatherId || nextMotherId !== child.motherId) {
        await updateMember({ ...child, fatherId: nextFatherId, motherId: nextMotherId });
      }

      // Immediately attach the child to the exact marriage whose two parents match.
      // This keeps marriage-1 children separate from marriage-2 children.
      const oppositeParentId = parentMember.gender === 'male' ? (child.motherId || otherParentId) : (child.fatherId || otherParentId);
      if (oppositeParentId) {
        const union = marriages.find(m =>
          (m.husbandId === parentMember.id && m.wifeId === oppositeParentId) ||
          (m.wifeId === parentMember.id && m.husbandId === oppositeParentId)
        );
        if (union && !(union.childrenIds || []).includes(child.id)) {
          await updateMarriage({ ...union, childrenIds: [...new Set([...(union.childrenIds || []), child.id])] });
        }
      }
    }
  };

  const archivePendingMemberDocuments = async (savedMember: Member): Promise<Member> => {
    const pending = (savedMember.memberDocuments || []).filter(doc => doc.dataUrl && !doc.archiveRecordId);
    if (!pending.length) return savedMember;

    const nextDocuments = [...(savedMember.memberDocuments || [])];
    for (const doc of pending) {
      const archiveRecord = await addArchiveRecord({
        title: `${savedMember.banglaName || savedMember.fullName} — ${doc.title}`,
        titleBn: `${savedMember.banglaName || savedMember.fullName} — ${doc.title}`,
        category: doc.documentType === 'photo' ? 'photo' : 'identity_document',
        documentType: doc.documentType === 'birth_certificate' ? 'birth_registration' : doc.documentType === 'nid' ? 'nid_card' : doc.documentType === 'passport' ? 'passport' : doc.documentType === 'marriage_certificate' ? 'marriage_doc' : doc.documentType === 'death_certificate' ? 'death_doc' : doc.documentType === 'education' ? 'education_cert' : 'other',
        relatedMemberIds: [savedMember.id],
        memberRoles: { [savedMember.id]: 'মূল ধারক (Self)' },
        relatedFamilyId: family.id,
        relatedBranchId: savedMember.branchId,
        mediaUrl: doc.dataUrl!,
        mediaType: doc.documentType === 'photo' ? 'image' : 'document',
        originalFilename: doc.fileName,
        mimeType: doc.mimeType,
        fileSizeBytes: undefined,
        ocrText: doc.ocrText,
        ocrConfidence: doc.ocrConfidence,
        ocrVerification: doc.ocrVerification || 'unverified',
        extractedFields: doc.extractedFields,
        source: isBn ? 'সদস্য প্রোফাইল' : 'Member Profile',
        provenance: isBn ? `${savedMember.banglaName || savedMember.fullName}-এর প্রোফাইল থেকে Family Archive-এ canonical সংরক্ষণ` : `Canonical Family Archive copy from ${savedMember.banglaName || savedMember.fullName}'s profile`,
        uploader: isBn ? 'সদস্য প্রোফাইল' : 'Member Profile',
        tags: ['member-profile-upload', `member:${savedMember.id}`],
        accessPermission: 'family',
        documentNumbers: {
          nid: doc.extractedFields?.nidNumber,
          brn: doc.extractedFields?.brnNumber,
          passport: undefined,
          khatian: doc.extractedFields?.khatianNumber,
          dag: doc.extractedFields?.dagNumber,
          deed: doc.extractedFields?.deedNumber,
          mouza: doc.extractedFields?.mouza
        },
        historyNote: isBn ? 'সদস্য প্রোফাইলের ডকুমেন্ট থেকে Family Archive-এ canonical record তৈরি হয়েছে।' : 'Canonical Family Archive record created from member profile document.'
      });

      const index = nextDocuments.findIndex(d => d.id === doc.id);
      if (index >= 0) {
        nextDocuments[index] = {
          ...nextDocuments[index],
          archiveRecordId: archiveRecord.id,
          // The archive is now the canonical file store; avoid keeping a second large copy in the member record.
          dataUrl: undefined
        };
      }
    }

    return { ...savedMember, memberDocuments: nextDocuments };
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;
    setIsSaving(true);
    let savedChildIds = [...childIds];
    let firstCreatedChildId: string | undefined;
    let saveStage = 'validation';

    try {
    const currentMember = isEditing && memberToEdit
      ? (members.find(m => m.id === memberToEdit.id) || memberToEdit)
      : null;

    // Prevent the same national ID from being assigned to two different members.
    // Normalize Bangla/English digits and ignore spaces/hyphens so formatting cannot bypass validation.
    const normalizeIdentityNumber = (value?: string) => (value || '')
      .trim()
      .replace(/[০-৯]/g, digit => String('০১২৩৪৫৬৭৮৯'.indexOf(digit)))
      .replace(/[\s-]+/g, '')
      .toLowerCase();
    const submittedNid = normalizeIdentityNumber(nidNumber);
    if (submittedNid) {
      const duplicateNidMember = members.find(member =>
        member.id !== currentMember?.id &&
        normalizeIdentityNumber(member.identityDocs?.nidNumber) === submittedNid
      );
      if (duplicateNidMember) {
        setIsSaving(false);
        const duplicateName = duplicateNidMember.banglaName || duplicateNidMember.englishName || duplicateNidMember.fullName || duplicateNidMember.id;
        alert(isBn
          ? `এই NID নম্বরটি ইতিমধ্যে “${duplicateName}” সদস্যের প্রোফাইলে সংরক্ষিত আছে। একই NID দিয়ে আরেকজন সদস্য সংরক্ষণ করা যাবে না। NID নম্বর যাচাই করুন।`
          : `This NID number is already assigned to member “${duplicateName}”. The same NID cannot be saved for another member. Please verify the NID number.`);
        return;
      }
    }

    if (!banglaName.trim() && !englishName.trim()) {
      setIsSaving(false);
      alert(isBn ? 'অনুগ্রহ করে সদস্যের নাম লিখুন।' : 'Please enter member name.');
      return;
    }

    // If the user knows death year + age at death but not the birth year,
    // recover an approximate birth year without overwriting a supplied birth date.
    const inferredBirthYear = !birthYear && deathYear && ageAtDeath !== '' ? Number(deathYear) - Number(ageAtDeath) : null;
    if (inferredBirthYear && !window.confirm(isBn ? `জন্মসন দেওয়া হয়নি। মৃত্যুসন ও মৃত্যুকালের বয়স থেকে প্রায় ${inferredBirthYear} সাল অনুমান করা হয়েছে। এটিকে সম্ভাব্য জন্মসন হিসেবে সংরক্ষণ করবেন?` : `Birth year is missing. An approximate year ${inferredBirthYear} was inferred from death year and age at death. Save it as an approximate birth year?`)) {
      setIsSaving(false); return;
    }
    const resolvedBirthYear = birthYear || inferredBirthYear || '';
    const birthDatePrecision = !birthYear && inferredBirthYear ? 'approximate' as DatePrecision : birthPrecision;

    const birthData = {
      date: {
        year: resolvedBirthYear ? Number(resolvedBirthYear) : null,
        month: birthMonth ? Number(birthMonth) : null,
        day: birthDay ? Number(birthDay) : null,
        precision: birthDatePrecision,
        banglaDate: banglaDateYear ? {
          day: banglaDateDay ? Number(banglaDateDay) : undefined,
          month: banglaDateMonth || undefined,
          year: Number(banglaDateYear)
        } : undefined
      },
      place: {
        village: birthVillage,
        postOffice: birthPostOffice,
        upazila: birthUpazila,
        district: birthDistrict,
        division: birthDivision,
        country: birthCountry
      }
    };

    const deathData = {
      isDeceased: !isLiving,
      date: !isLiving && deathYear ? {
        year: Number(deathYear),
        month: deathMonth ? Number(deathMonth) : null,
        day: deathDay ? Number(deathDay) : null,
        precision: deathPrecision
      } : undefined,
      burialPlace: !isLiving ? deathBurialPlace : undefined,
      memorialInfo: !isLiving ? deathMemorialInfo : undefined
    };

    const identityDocs = {
      nidNumber: nidNumber.trim(),
      birthRegistrationNumber: birthRegistrationNumber.trim(),
      passportNumber: passportNumber.trim(),
      otherId: otherId.trim(),
      verificationStatus
    };

    const syncSelectedSpouseParents = async (savedMemberId: string) => {
      const selectedSpouseId = spouseId || spouseIds[0];
      if (!selectedSpouseId) return;
      const spouse = members.find(m => m.id === selectedSpouseId);
      if (!spouse) return;
      const nextSpouse = { ...spouse };
      let changed = false;
      if (!nextSpouse.fatherId && fatherInLawId) { nextSpouse.fatherId = fatherInLawId; changed = true; }
      if (!nextSpouse.motherId && motherInLawId) { nextSpouse.motherId = motherInLawId; changed = true; }
      if (changed && nextSpouse.id !== savedMemberId) await updateMember(nextSpouse);
    };

    if (isEditing && currentMember) {
      const editedMember: Member = {
        ...currentMember,
        fullName: englishName || banglaName,
        banglaName,
        englishName,
        nickname,
        formerName,
        profession, mobileNumber, email, currentAddress: { ...(currentMember?.currentAddress || {}), ...currentAddressDetails, fullAddress: formatLocationInfo(currentAddressDetails, currentAddress) }, permanentAddress: { ...(currentMember?.permanentAddress || {}), ...permanentAddressDetails, fullAddress: formatLocationInfo(permanentAddressDetails, permanentAddress) }, education, maritalStatus,
        birthOrder: birthOrder || 1,
        generationMode,
        generationOverride: generationMode === 'manual' ? generationOverride : undefined,
        ageAtDeath: !isLiving && ageAtDeath !== '' ? Number(ageAtDeath) : undefined,
        gender,
        profilePhoto: profilePhoto || undefined,
        branchId: branchId || branches[0]?.id || 'branch-borotaraf',
        isLiving,
        birthOrigin,
        marriageOrigin: birthOrigin === 'joined_by_marriage',
        originalLineageNote: birthOrigin === 'joined_by_marriage' ? originalLineageNote : undefined,
        isUnmarried: maritalStatus === 'unmarried',
        birth: birthData,
        death: deathData,
        identityDocs,
        memberDocuments,
        fatherId: birthOrigin === 'joined_by_marriage' ? undefined : (fatherId || undefined),
        motherId: birthOrigin === 'joined_by_marriage' ? undefined : (motherId || undefined),
        fatherNameBn: fatherNameBn.trim() || undefined,
        fatherNameEn: fatherNameEn.trim() || undefined,
        motherNameBn: motherNameBn.trim() || undefined,
        motherNameEn: motherNameEn.trim() || undefined,
        adoptiveFatherNameBn: adoptiveFatherNameBn.trim() || undefined,
        adoptiveFatherNameEn: adoptiveFatherNameEn.trim() || undefined,
        adoptiveMotherNameBn: adoptiveMotherNameBn.trim() || undefined,
        adoptiveMotherNameEn: adoptiveMotherNameEn.trim() || undefined,
        paternalGrandfatherId: birthOrigin === 'joined_by_marriage' ? undefined : (paternalGrandfatherId || undefined),
        paternalGrandmotherId: birthOrigin === 'joined_by_marriage' ? undefined : (paternalGrandmotherId || undefined),
        maternalGrandfatherId: birthOrigin === 'joined_by_marriage' ? undefined : (maternalGrandfatherId || undefined),
        maternalGrandmotherId: birthOrigin === 'joined_by_marriage' ? undefined : (maternalGrandmotherId || undefined),
        fatherInLawId: fatherInLawId || undefined,
        motherInLawId: motherInLawId || undefined,
        fatherInLawName: fatherInLawName.trim() || spouseMember?.fatherNameBn || undefined,
        motherInLawName: motherInLawName.trim() || spouseMember?.motherNameBn || undefined,
        biography,
        importantInformation: importantInfo,
        alternativeNames: alternativeNames.split(/\n|,/).map(v => v.trim()).filter(Boolean),
        alternativeBanglaNames: alternativeNames.split(/\n|,/).map(v => v.trim()).filter(Boolean),
        alternativeEnglishNames: alternativeEnglishNames.split(/\n|,/).map(v => v.trim()).filter(Boolean),
        alternativeNameRecords: alternativeNameSources.split(/\n/).map(line => line.split('|').map(v => v.trim())).filter(parts => parts[0]).map(parts => ({ id: crypto.randomUUID(), name: parts[0], language: /[\u0980-\u09FF]/.test(parts[0]) ? 'bn' as const : 'en' as const, sourceType: parts[1] || undefined, sourceReference: parts[2] || undefined, note: parts[3] || undefined })),
        nationality: nationality.trim() || undefined, religion: religion.trim() || undefined, bloodGroup,
        languages: languages.split(',').map(v => v.trim()).filter(Boolean), physicalDescription: physicalDescription.trim() || undefined,
        militaryService: militaryService.trim() || undefined, migrationHistory: migrationHistory.trim() || undefined,
        researchNotes: researchNotes.trim() || undefined, researchStatus,
        familyOriginStory: familyOriginStory.trim() || undefined, memorialStory: memorialStory.trim() || undefined,
        notes: memberNotes.trim() || undefined, tags: tags.split(',').map(v => v.trim()).filter(Boolean),
        educationHistory, professionHistory, residenceHistory
      };
      saveStage = 'archive-documents';
      const archivedEditedMember = await archivePendingMemberDocuments(editedMember);
      saveStage = 'member-and-marriage-persistence';
      await updateMember(archivedEditedMember);
      saveStage = 'spouse-parent-reconciliation';
      await syncSelectedSpouseParents(archivedEditedMember.id);
    } else {
      saveStage = 'create-member';
      const newMember = await addMember({
        fullName: englishName || banglaName,
        banglaName,
        englishName,
        nickname,
        formerName,
        profession, mobileNumber, email, currentAddress: { ...currentAddressDetails, fullAddress: formatLocationInfo(currentAddressDetails, currentAddress) }, permanentAddress: { ...permanentAddressDetails, fullAddress: formatLocationInfo(permanentAddressDetails, permanentAddress) }, education, maritalStatus,
        birthOrder: birthOrder || 1,
        generationMode,
        generationOverride: generationMode === 'manual' ? generationOverride : undefined,
        ageAtDeath: !isLiving && ageAtDeath !== '' ? Number(ageAtDeath) : undefined,
        gender,
        profilePhoto: profilePhoto || undefined,
        branchId: branchId || branches[0]?.id || 'branch-borotaraf',
        isLiving,
        birthOrigin,
        marriageOrigin: birthOrigin === 'joined_by_marriage',
        originalLineageNote: birthOrigin === 'joined_by_marriage' ? originalLineageNote : undefined,
        isUnmarried: maritalStatus === 'unmarried',
        birth: birthData,
        death: deathData,
        identityDocs,
        memberDocuments,
        fatherId: birthOrigin === 'joined_by_marriage' ? undefined : (fatherId || undefined),
        motherId: birthOrigin === 'joined_by_marriage' ? undefined : (motherId || undefined),
        fatherNameBn: fatherNameBn.trim() || undefined,
        fatherNameEn: fatherNameEn.trim() || undefined,
        motherNameBn: motherNameBn.trim() || undefined,
        motherNameEn: motherNameEn.trim() || undefined,
        adoptiveFatherNameBn: adoptiveFatherNameBn.trim() || undefined,
        adoptiveFatherNameEn: adoptiveFatherNameEn.trim() || undefined,
        adoptiveMotherNameBn: adoptiveMotherNameBn.trim() || undefined,
        adoptiveMotherNameEn: adoptiveMotherNameEn.trim() || undefined,
        paternalGrandfatherId: birthOrigin === 'joined_by_marriage' ? undefined : (paternalGrandfatherId || undefined),
        paternalGrandmotherId: birthOrigin === 'joined_by_marriage' ? undefined : (paternalGrandmotherId || undefined),
        maternalGrandfatherId: birthOrigin === 'joined_by_marriage' ? undefined : (maternalGrandfatherId || undefined),
        maternalGrandmotherId: birthOrigin === 'joined_by_marriage' ? undefined : (maternalGrandmotherId || undefined),
        fatherInLawId: fatherInLawId || undefined,
        motherInLawId: motherInLawId || undefined,
        fatherInLawName: fatherInLawName.trim() || spouseMember?.fatherNameBn || undefined,
        motherInLawName: motherInLawName.trim() || spouseMember?.motherNameBn || undefined,
        marriageIds: [],
        biography,
        importantInformation: importantInfo,
        alternativeNames: alternativeNames.split(/\n|,/).map(v => v.trim()).filter(Boolean),
        alternativeBanglaNames: alternativeNames.split(/\n|,/).map(v => v.trim()).filter(Boolean),
        alternativeEnglishNames: alternativeEnglishNames.split(/\n|,/).map(v => v.trim()).filter(Boolean),
        alternativeNameRecords: alternativeNameSources.split(/\n/).map(line => line.split('|').map(v => v.trim())).filter(parts => parts[0]).map(parts => ({ id: crypto.randomUUID(), name: parts[0], language: /[\u0980-\u09FF]/.test(parts[0]) ? 'bn' as const : 'en' as const, sourceType: parts[1] || undefined, sourceReference: parts[2] || undefined, note: parts[3] || undefined })),
        nationality: nationality.trim() || undefined, religion: religion.trim() || undefined, bloodGroup,
        languages: languages.split(',').map(v => v.trim()).filter(Boolean), physicalDescription: physicalDescription.trim() || undefined,
        militaryService: militaryService.trim() || undefined, migrationHistory: migrationHistory.trim() || undefined,
        researchNotes: researchNotes.trim() || undefined, researchStatus,
        familyOriginStory: familyOriginStory.trim() || undefined, memorialStory: memorialStory.trim() || undefined,
        notes: memberNotes.trim() || undefined, tags: tags.split(',').map(v => v.trim()).filter(Boolean),
        educationHistory, professionHistory, residenceHistory
      });
      const archivedNewMember = await archivePendingMemberDocuments(newMember);
      if (archivedNewMember.memberDocuments !== newMember.memberDocuments) {
        await updateMember(archivedNewMember);
      }
      await syncSelectedSpouseParents(archivedNewMember.id);
      const pendingIds = [...new Set([...childIds, ...pendingChildIdsRef.current])];
      if (pendingIds.length) {
        await linkExistingChildrenToParents(archivedNewMember, pendingIds, spouseId || undefined);
      }
      saveStage = 'create-named-children';
      const createdChildren = await createNamedChildren(archivedNewMember, spouseId || undefined);
      firstCreatedChildId = createdChildren[0]?.id || pendingIds[0];
      const allChildIds = [...new Set([...pendingIds, ...createdChildren.map(child => child.id)])];
      setChildIds(allChildIds);
      savedChildIds = allChildIds;
      // IMPORTANT: with multiple marriages, never put every child into the first/selected union.
      // A child belongs to a specific union when the other canonical parent matches that spouse.
      const currentChildren = latestMembersRef.current;
      for (const selectedSpouseId of spouseIds) {
        if (!selectedSpouseId || selectedSpouseId === newMember.id) continue;
        const unionChildIds = allChildIds.filter(childId => {
          const child = currentChildren.find(m => m.id === childId);
          if (!child) return false;
          const otherParentId = newMember.gender === 'male' ? child.motherId : child.fatherId;
          return otherParentId === selectedSpouseId;
        });
        saveStage = 'create-marriage';
        await addMarriage({
          familyId: family.id, serialNumber: '',
          husbandId: newMember.gender === 'male' ? newMember.id : selectedSpouseId,
          wifeId: newMember.gender === 'female' ? newMember.id : selectedSpouseId,
          marriageDate: { precision: 'unknown' }, marriagePlace: {}, status: 'current', childrenIds: unionChildIds
        });
      }
      saveStage = 'link-existing-children';
      await linkExistingChildrenToParents(newMember, childIds, spouseId || undefined);
    }

    if (isEditing && currentMember) {
      saveStage = 'create-named-children';
      const createdChildren = await createNamedChildren(currentMember, spouseId || undefined);
      firstCreatedChildId = createdChildren[0]?.id;
      const allChildIds = [...new Set([...childIds, ...createdChildren.map(child => child.id)])];
      setChildIds(allChildIds);
      savedChildIds = allChildIds;
      const createdChildIds = createdChildren.map(child => child.id);
      const currentMemberMarriageRecords = marriages.filter(m => m.husbandId === currentMember.id || m.wifeId === currentMember.id);
      for (const oldMarriage of currentMemberMarriageRecords) {
        const oldSpouseId = oldMarriage.husbandId === currentMember.id ? oldMarriage.wifeId : oldMarriage.husbandId;
        if (oldMarriage.status === 'current' && !spouseIds.includes(oldSpouseId)) {
          saveStage = 'update-marriage-status';
          await updateMarriage({ ...oldMarriage, status: currentMember.isLiving ? 'separated' : 'widowed' });
        }
      }
      for (const selectedSpouseId of spouseIds) {
        if (!selectedSpouseId || selectedSpouseId === currentMember.id) continue;
        const linkedMarriage = marriages.find(m =>
          (m.husbandId === currentMember.id && m.wifeId === selectedSpouseId) ||
          (m.wifeId === currentMember.id && m.husbandId === selectedSpouseId)
        );
        if (linkedMarriage) {
          saveStage = 'update-marriage-details';
          await updateMarriage({
            ...linkedMarriage,
            status: selectedSpouseId === spouseId ? 'current' : linkedMarriage.status,
            // Preserve existing marriage-specific children. Only newly created children
            // from this save may be added automatically to the selected union.
            childrenIds: [...new Set([...(linkedMarriage.childrenIds || []), ...(selectedSpouseId === spouseId ? createdChildIds : [])])]
          });
        } else {
          await addMarriage({
            familyId: family.id, serialNumber: '',
            husbandId: gender === 'male' ? currentMember.id : selectedSpouseId,
            wifeId: gender === 'female' ? currentMember.id : selectedSpouseId,
            marriageDate: { precision: 'unknown' }, marriagePlace: {}, status: 'current', childrenIds: selectedSpouseId === spouseId ? createdChildIds : []
          });
        }
      }
      saveStage = 'link-existing-children';
      await linkExistingChildrenToParents(currentMember, childIds, spouseId || undefined);
    }

    pendingChildIdsRef.current = [];
    onClose();
    // After saving a child from a parent profile, reopen the parent so the refreshed
    // child list is immediately visible. Do not jump to the newly-created child.
    const profileToReopen = currentMember?.id;
    if (profileToReopen) window.setTimeout(() => onSavedMemberId?.(profileToReopen), 0);
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error ?? 'Unknown error');
      // Keep the user-facing message actionable while retaining exact stage/error
      // details for Android WebView debugging and support reports.
      console.error('[Bongshokotha] Member save failed', { stage: saveStage, memberId: memberToEdit?.id ?? null, error: detail, stack: error instanceof Error ? error.stack : undefined });
      const stageBn: Record<string, string> = {
        validation: 'তথ্য যাচাই', 'archive-documents': 'দলিল আর্কাইভে সংরক্ষণ',
        'member-and-marriage-persistence': 'সদস্য ও বিবাহের তথ্য সংরক্ষণ',
        'spouse-parent-reconciliation': 'স্বামী/স্ত্রীর পিতামাতার সম্পর্ক সমন্বয়',
        'create-member': 'নতুন সদস্য তৈরি', 'archive-new-member-documents': 'নতুন সদস্যের দলিল আর্কাইভে সংরক্ষণ',
        'persist-archive-document-links': 'দলিলের আর্কাইভ সংযোগ সংরক্ষণ',
        'link-pending-children': 'আগে থেকে তৈরি সন্তানের সম্পর্ক সংরক্ষণ',
        'create-named-children': 'সন্তানের তথ্য তৈরি', 'create-marriage': 'বিবাহের তথ্য সংরক্ষণ',
        'link-existing-children': 'সন্তান ও পিতামাতার সম্পর্ক সংরক্ষণ',
        'update-marriage-status': 'বিবাহের অবস্থা হালনাগাদ', 'update-marriage-details': 'বিবাহের বিবরণ হালনাগাদ'
      };
      const stageEn: Record<string, string> = {
        validation: 'data validation', 'archive-documents': 'document archiving',
        'member-and-marriage-persistence': 'member and marriage persistence',
        'spouse-parent-reconciliation': 'spouse-parent relationship reconciliation',
        'create-member': 'member creation', 'archive-new-member-documents': 'new-member document archiving',
        'persist-archive-document-links': 'document archive-link persistence',
        'link-pending-children': 'pending-child relationship linking',
        'create-named-children': 'named-child creation', 'create-marriage': 'marriage persistence',
        'link-existing-children': 'child-parent relationship linking',
        'update-marriage-status': 'marriage status update', 'update-marriage-details': 'marriage details update'
      };
      alert(isBn
        ? `সদস্যের তথ্য সংরক্ষণ করা যায়নি। ব্যর্থ ধাপ: ${stageBn[saveStage] || saveStage}। ${detail}`
        : `Member save failed during ${stageEn[saveStage] || saveStage}. ${detail}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Relationship dropdowns are deliberately constrained by BOTH generation and gender.
  // This prevents the edit form from presenting every family member as a possible
  // father/mother/spouse/child.
  const generationMap = calculateGenerations(members, marriages, family?.rootAncestorId);
  const selectedFather = fatherId ? members.find(m => m.id === fatherId) : undefined;
  const selectedMother = motherId ? members.find(m => m.id === motherId) : undefined;
  const selectedParentGeneration = selectedFather
    ? (generationMap.get(selectedFather.id) || selectedFather.computedGeneration || 1)
    : selectedMother
      ? (generationMap.get(selectedMother.id) || selectedMother.computedGeneration || 1)
      : undefined;
  const currentGeneration = memberToEdit
    ? (memberToEdit.generationMode === 'manual' && memberToEdit.generationOverride ? memberToEdit.generationOverride : (generationMap.get(memberToEdit.id) || memberToEdit.computedGeneration || 1))
    : (selectedParentGeneration ? selectedParentGeneration + 1 : (generationOverride || 1));
  const relationCandidates = (targetGeneration: number, allowedGenders: Gender[], linkedIds: string[] = [], allowAllGenerations = false, requireExactGenerationForExisting = false) => members
    .filter(m => m.id !== memberToEdit?.id && m.id !== spouseId)
    .filter(m => allowedGenders.includes(m.gender) || linkedIds.includes(m.id))
    // For an existing member, a parent must be from an earlier generation.
    // Preserve an already-linked parent even if legacy generation metadata is imperfect,
    // but never offer same-generation/future members as new parent candidates.
    .filter(m => {
      if (linkedIds.includes(m.id)) return true;
      if (allowAllGenerations) return true;
      const candidateGeneration = generationMap.get(m.id) || m.computedGeneration || 1;
      if (memberToEdit && requireExactGenerationForExisting) return candidateGeneration === targetGeneration;
      return memberToEdit ? candidateGeneration < currentGeneration : candidateGeneration === targetGeneration;
    })
    .sort((a, b) => (linkedIds.includes(b.id) ? 1 : 0) - (linkedIds.includes(a.id) ? 1 : 0) || Math.abs((generationMap.get(a.id) || a.computedGeneration || 1) - targetGeneration) - Math.abs((generationMap.get(b.id) || b.computedGeneration || 1) - targetGeneration) || ((generationMap.get(a.id) || a.computedGeneration || 1) - (generationMap.get(b.id) || b.computedGeneration || 1)) || ((a.birthOrder ?? 999999) - (b.birthOrder ?? 999999)) || (a.birth?.date?.year || 9999) - (b.birth?.date?.year || 9999) || (a.birth?.date?.month || 99) - (b.birth?.date?.month || 99) || (a.birth?.date?.day || 99) - (b.birth?.date?.day || 99) || (a.banglaName || a.fullName).localeCompare(b.banglaName || b.fullName, 'bn'));

  // New members do not have a generation yet. Let the user choose a parent from
  // every existing generation; once one parent is selected, constrain the other
  // parent to that same generation. Existing members remain generation-filtered.
  const parentTargetGeneration = Math.max(1, (selectedParentGeneration || currentGeneration - 1));
  const allowAllParentGenerations = !memberToEdit && !selectedParentGeneration;
  const potentialFathers = relationCandidates(parentTargetGeneration, ['male'], fatherId ? [fatherId] : [], allowAllParentGenerations);
  const potentialMothers = relationCandidates(parentTargetGeneration, ['female'], motherId ? [motherId] : [], allowAllParentGenerations);
  const paternalGrandfatherFromFather = fatherId ? members.find(m => m.id === fatherId)?.fatherId : undefined;
  const paternalGrandmotherFromFather = fatherId ? members.find(m => m.id === fatherId)?.motherId : undefined;
  const maternalGrandfatherFromMother = motherId ? members.find(m => m.id === motherId)?.fatherId : undefined;
  const maternalGrandmotherFromMother = motherId ? members.find(m => m.id === motherId)?.motherId : undefined;
  const potentialPaternalGrandfathers = (paternalGrandfatherFromFather ? members.filter(m => m.id === paternalGrandfatherFromFather) : relationCandidates(currentGeneration - 2, ['male']));
  const potentialPaternalGrandmothers = (paternalGrandmotherFromFather ? members.filter(m => m.id === paternalGrandmotherFromFather) : relationCandidates(currentGeneration - 2, ['female']));
  const potentialMaternalGrandfathers = (maternalGrandfatherFromMother ? members.filter(m => m.id === maternalGrandfatherFromMother) : relationCandidates(currentGeneration - 2, ['male']));
  const potentialMaternalGrandmothers = (maternalGrandmotherFromMother ? members.filter(m => m.id === maternalGrandmotherFromMother) : relationCandidates(currentGeneration - 2, ['female']));
  const spouseGenders: Gender[] = gender === 'male' ? ['female'] : gender === 'female' ? ['male'] : ['male', 'female'];
  const relationshipTargetGeneration = relationshipGeneration === 'current' ? currentGeneration : relationshipGeneration === 'next' ? currentGeneration + 1 : relationshipGeneration;
  const potentialSpouses = relationCandidates(relationshipTargetGeneration, spouseGenders, spouseIds);
  const selectedSpouses = spouseIds.map(id => members.find(m => m.id === id)).filter(Boolean) as Member[];
  const spouseMember = members.find(m => m.id === (spouseId || spouseIds[0]));
  // In-laws belong to the selected spouse, not to an arbitrary generation.
  // Keep the spouse's canonical parents first, then offer other same-gender
  // candidates as an explicit fallback for incomplete historical records.
  const spouseFather = spouseMember?.fatherId ? members.find(m => m.id === spouseMember.fatherId) : undefined;
  const spouseMother = spouseMember?.motherId ? members.find(m => m.id === spouseMember.motherId) : undefined;
  const inLawCandidates = (genderFilter: Gender, linkedId?: string) => {
    // Never offer every member as a possible in-law: that caused unrelated names
    // and incorrect generation labels. Only a spouse's canonical parent (or an
    // already-saved explicit legacy link) can be selected here.
    const preferred = linkedId ? members.find(m => m.id === linkedId && m.gender === genderFilter) : undefined;
    return preferred ? [preferred] : [];
  };
  const potentialInLawMen = inLawCandidates('male', fatherInLawId || spouseFather?.id);
  const potentialInLawWomen = inLawCandidates('female', motherInLawId || spouseMother?.id);
  const childTargetGeneration = relationshipGeneration === 'current' ? currentGeneration + 1 : relationshipGeneration === 'next' ? currentGeneration + 1 : relationshipGeneration;
  const potentialChildren = relationCandidates(childTargetGeneration, ['male', 'female', 'other', 'unknown'], childIds, false, true);
  const filteredPotentialChildren = childGenderFilter === 'all' ? potentialChildren : potentialChildren.filter(m => m.gender === childGenderFilter);
  const potentialSons = potentialChildren.filter(m => m.gender === 'male');
  const potentialDaughters = potentialChildren.filter(m => m.gender === 'female');

  const handleMemberDocumentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    try {
      const items: MemberDocument[] = [];
      for (const file of files) {
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ''));
          reader.onerror = () => reject(reader.error);
          reader.readAsDataURL(file);
        });

        const lower = file.name.toLowerCase();
        const isImage = file.type.startsWith('image/');
        let documentType: MemberDocument['documentType'] = 'other';
        if (/nid|national.?id|জাতীয়|জাতীয়/.test(lower)) documentType = 'nid';
        else if (/birth|জন্ম|brn/.test(lower)) documentType = 'birth_certificate';
        else if (/passport|পাসপোর্ট/.test(lower)) documentType = 'passport';
        else if (/driv|licen[cs]e|driver|ড্রাইভিং|লাইসেন্স/.test(lower)) documentType = 'driving_licence';
        else if (/marriage|kabinnama|নিকাহ|বিবাহ/.test(lower)) documentType = 'marriage_certificate';
        else if (/death|মৃত্যু/.test(lower)) documentType = 'death_certificate';
        else if (/education|certificate|শিক্ষা|সনদ/.test(lower)) documentType = 'education';
        else if (isImage) documentType = 'photo';

        const item: MemberDocument = {
          id: `doc-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`,
          title: file.name.replace(/\.[^/.]+$/, ''),
          documentType,
          fileName: file.name,
          mimeType: file.type || 'application/octet-stream',
          dataUrl,
          uploadedAt: new Date().toISOString(),
          ocrVerification: 'unverified'
        };

        // Run OCR immediately for document images and PDFs. The original file
        // remains untouched. Word/Excel files are preserved but are not falsely
        // reported as OCR-processed unless a readable image/PDF was supplied.
        const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
        const ocrCapable = isImage || isPdf;
        if (ocrCapable) {
          try {
            const ocr = await runDocumentOcr(dataUrl, 'ben+eng', undefined, undefined, file.type || (isPdf ? 'application/pdf' : undefined));
            item.ocrText = ocr.text || undefined;
            item.ocrConfidence = ocr.confidence;
            item.extractedFields = ocr.extractedFields;
            item.ocrVerification = 'unverified';

            // Let OCR classify a generically named document.
            if (item.documentType === 'other' || item.documentType === 'photo') {
              const kind = ocr.extractedFields.documentKind;
              if (kind === 'nid') item.documentType = 'nid';
              else if (kind === 'birth_registration') item.documentType = 'birth_certificate';
              else if (kind === 'marriage_doc') item.documentType = 'marriage_certificate';
              else if (kind === 'death_doc') item.documentType = 'death_certificate';
            }
          } catch (ocrError) {
            console.warn('Member document OCR failed; original document will still be preserved.', ocrError);
            item.note = `${item.note || ''}${item.note ? ' ' : ''}OCR ব্যর্থ: ${ocrError instanceof Error ? ocrError.message : String(ocrError)}`.trim();
          }
        }

        items.push(item);
      }

      setMemberDocuments(prev => [...prev, ...items]);
      setSelectedOcrFieldsByDoc(prev => ({
        ...prev,
        ...Object.fromEntries(items.map(doc => [doc.id, buildExtractedFieldCandidates(doc.extractedFields || { documentKind: 'general', confidence: 0 }).filter(c => c.profileWritable !== false).map(c => c.key)]))
      }));
      const ocrCount = items.filter(i => i.ocrText).length;
      alert(isBn
        ? `${items.length}টি ডকুমেন্ট যোগ হয়েছে। ${ocrCount ? `${ocrCount}টির OCR সম্পন্ন হয়েছে; যাচাই না করা পর্যন্ত তথ্য চূড়ান্ত হবে না। ` : ''}সদস্য সংরক্ষণ করলে প্রতিটি ফাইল Family Archive-এ ওই সদস্যের নামে canonical record হিসেবে সংরক্ষিত হবে।`
        : `${items.length} document(s) added. ${ocrCount ? `${ocrCount} OCR result(s) captured; nothing becomes verified until reviewed. ` : ''}When the member is saved, each file will also be stored as a canonical Family Archive record under this member.`);
    } catch (error) {
      console.error('Member document upload failed:', error);
      alert(isBn ? 'ডকুমেন্ট পড়া যায়নি।' : 'Could not read the document.');
    } finally {
      e.currentTarget.value = '';
    }
  };

  const parseOcrDate = (value?: string) => parseDocumentDate(value);

  const applyOcrFieldsToProfile = (doc: MemberDocument) => {
    const fields = doc.extractedFields;
    if (!fields) return;
    const selected = new Set(selectedOcrFieldsByDoc[doc.id] || []);
    const pick = (key: string) => selected.has(key) ? (fields as any)[key] : undefined;
    if (pick('fullNameBn')) setBanglaName(String(pick('fullNameBn')));
    if (pick('fullNameEn')) setEnglishName(String(pick('fullNameEn')));
    if (pick('nidNumber')) setNidNumber(String(pick('nidNumber')));
    if (pick('brnNumber')) setBirthRegistrationNumber(String(pick('brnNumber')));
    if (pick('passportNumber')) setPassportNumber(String(pick('passportNumber')));
    if (pick('occupation')) setProfession(String(pick('occupation')));
    if (pick('mobileNumber')) setMobileNumber(String(pick('mobileNumber')));
    if (pick('email')) setEmail(String(pick('email')));
    if (pick('religion')) setReligion(String(pick('religion')));
    if (pick('nationality')) setNationality(String(pick('nationality')));
    if (pick('bloodGroup')) setBloodGroup((pick('bloodGroup') as BloodGroup) || 'unknown');
    if (pick('gender')) setGender(pick('gender'));
    if (pick('dateOfBirth')) {
      const d = parseOcrDate(String(pick('dateOfBirth')));
      if (d) { setBirthDay(d.day); setBirthMonth(d.month); setBirthYear(d.year); setBirthPrecision('exact'); }
    }
    if (pick('placeOfBirth')) setBirthVillage(String(pick('placeOfBirth')));
    if (pick('address')) setCurrentAddress(typeof pick('address') === 'string' ? String(pick('address')) : JSON.stringify(pick('address')));
    if (pick('presentAddress')) {
      const a = pick('presentAddress'); setCurrentAddress(typeof a === 'string' ? a : [a?.village, a?.postOffice, a?.upazila, a?.district, a?.division, a?.country].filter(Boolean).join(', '));
    }
    if (pick('permanentAddress')) {
      const a = pick('permanentAddress'); setPermanentAddress(typeof a === 'string' ? a : [a?.village, a?.postOffice, a?.upazila, a?.district, a?.division, a?.country].filter(Boolean).join(', '));
    }
    if (pick('village')) setBirthVillage(String(pick('village')));
    if (pick('postOffice')) setBirthPostOffice(String(pick('postOffice')));
    if (pick('upazila')) setBirthUpazila(String(pick('upazila')));
    if (pick('district')) setBirthDistrict(String(pick('district')));
    if (pick('division')) setBirthDivision(String(pick('division')));
    if (pick('country')) setBirthCountry(String(pick('country')));
    const fatherName = pick('fatherName');
    const motherName = pick('motherName');
    if (fatherName) setFatherNameBn(String(fatherName));
    if (motherName) setMotherNameBn(String(motherName));
    // OCR supplies identity-document claims, not proof of a canonical parent link.
    // Keep the extracted parent names as text for review; the user must explicitly
    // choose the correct existing person in the relationship dropdown.
    // This avoids silently replacing a verified father/mother with a same-name person.
    const updated = { ...doc, ocrVerification: 'verified' as const };
    setMemberDocuments(prev => prev.map(d => d.id === doc.id ? updated : d));
    alert(isBn ? 'নির্বাচিত তথ্য সদস্য প্রোফাইলের ফর্মে নেওয়া হয়েছে। এখন যাচাই করে “সদস্য সংরক্ষণ” চাপুন।' : 'Selected OCR fields were placed into the member profile form. Review them and click Save Member.');
  };

  const removeMemberDocument = (id: string) => {
    setMemberDocuments(prev => prev.filter(d => d.id !== id));
    setSelectedOcrFieldsByDoc(prev => { const next = { ...prev }; delete next[id]; return next; });
  };

  const quickAddRelatedMember = async (relation: 'father' | 'mother' | 'spouse' | 'child' | 'fatherInLaw' | 'motherInLaw') => {
    const label = relation === 'father' ? (isBn ? 'পিতার' : 'father') : relation === 'mother' ? (isBn ? 'মাতার' : 'mother') : relation === 'spouse' ? (isBn ? 'সঙ্গীর' : 'spouse') : relation === 'fatherInLaw' ? (isBn ? 'শ্বশুরের' : 'father-in-law') : relation === 'motherInLaw' ? (isBn ? 'শাশুড়ীর' : 'mother-in-law') : (isBn ? 'সন্তানের' : 'child');
    const name = window.prompt(isBn ? `${label} নাম লিখুন:` : `Enter ${label} name:`);
    if (!name?.trim()) return;
    const newGender: Gender = relation === 'father' || relation === 'fatherInLaw'
      ? 'male'
      : relation === 'mother' || relation === 'motherInLaw'
        ? 'female'
        : relation === 'spouse'
          ? (gender === 'male' ? 'female' : gender === 'female' ? 'male' : 'unknown')
          : (childGenderFilter !== 'all' ? childGenderFilter : 'unknown');
    const isSpouseRelation = relation === 'spouse';
    const isInLawRelation = relation === 'fatherInLaw' || relation === 'motherInLaw';
    const newMember = await addMember({
      fullName: name.trim(), banglaName: name.trim(), englishName: '', gender: newGender,
      branchId: branchId || branches[0]?.id || 'branch-borotaraf', isLiving: true,
      // A newly added spouse is an in-married person, never a birth-line member.
      birthOrigin: (isSpouseRelation || isInLawRelation) ? 'joined_by_marriage' : 'born_in_family',
      marriageOrigin: isSpouseRelation || isInLawRelation, isUnmarried: !isSpouseRelation,
      birth: { date: { precision: 'unknown' }, place: {} }, death: { isDeceased: false },
      identityDocs: { verificationStatus: 'unverified' }, marriageIds: [], memberDocuments: []
    });
    latestMembersRef.current = latestMembersRef.current.some(m => m.id === newMember.id)
      ? latestMembersRef.current.map(m => m.id === newMember.id ? newMember : m)
      : [...latestMembersRef.current, newMember];
    if (relation === 'father') setFatherId(newMember.id);
    else if (relation === 'mother') setMotherId(newMember.id);
    else if (relation === 'fatherInLaw') {
      setFatherInLawId(newMember.id);
      // If a spouse is selected, this is the spouse's canonical father.
      if (spouseMember && !spouseMember.fatherId) await updateMember({ ...spouseMember, fatherId: newMember.id });
    }
    else if (relation === 'motherInLaw') {
      setMotherInLawId(newMember.id);
      if (spouseMember && !spouseMember.motherId) await updateMember({ ...spouseMember, motherId: newMember.id });
    }
    else if (relation === 'spouse') { setSpouseId(newMember.id); setSpouseIds(prev => [...new Set([...prev, newMember.id])]); setIsUnmarried(false); setMaritalStatus('married'); }
    else {
      // A quick-added child must be linked to the canonical parent immediately.
      // Previously only childIds UI state was updated, so the child could appear
      // in the editor but remain orphaned after reopening the parent's profile.
      setChildIds(prev => [...new Set([...prev, newMember.id])]);
      if (!memberToEdit) {
        pendingChildIdsRef.current = [...new Set([...pendingChildIdsRef.current, newMember.id])];
      }
      if (memberToEdit) {
        const fatherIdForChild = gender === 'male' ? memberToEdit.id : (spouseId || undefined);
        const motherIdForChild = gender === 'female' ? memberToEdit.id : (spouseId || undefined);
        const linkedChild = { ...newMember, fatherId: fatherIdForChild, motherId: motherIdForChild };
        latestMembersRef.current = latestMembersRef.current.map(m => m.id === linkedChild.id ? linkedChild : m);
        await updateMember(linkedChild);
        if (spouseId) {
          const union = marriages.find(m =>
            (m.husbandId === memberToEdit.id && m.wifeId === spouseId) ||
            (m.wifeId === memberToEdit.id && m.husbandId === spouseId)
          );
          if (union && !(union.childrenIds || []).includes(newMember.id)) {
            await updateMarriage({ ...union, childrenIds: [...new Set([...(union.childrenIds || []), newMember.id])] });
          }
        }
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-2 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-6xl rounded-3xl border border-teal-200/80 dark:border-teal-900/70 bg-white dark:bg-stone-900 shadow-[0_24px_90px_rgba(15,118,110,0.22)] my-2 sm:my-5 flex flex-col max-h-[96vh] overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between gap-3 border-b border-teal-100 dark:border-teal-900/70 px-4 sm:px-6 py-4 bg-gradient-to-br from-teal-50 via-white to-indigo-50 dark:from-teal-950/50 dark:via-stone-950 dark:to-indigo-950/40 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-800 dark:bg-teal-950/70 dark:text-teal-200 border border-teal-300/70 dark:border-teal-800">
                {isEditing ? (isBn ? 'সম্পাদনা মোড' : 'Edit Mode') : (isBn ? 'নতুন নিবন্ধন' : 'New Member')}
              </span>
              <span className="text-xs text-stone-500 hidden sm:inline">
                {isBn ? 'স্মার্ট ফর্ম • সম্পর্ক বুঝে তথ্য দেখায়' : 'Smart form • adapts to family relationships'}
              </span>
            </div>
            <h3 className="font-serif text-lg sm:text-2xl font-bold text-teal-950 dark:text-teal-100 mt-0.5">
              {isEditing
                ? (isBn ? `সদস্য প্রোফাইল: ${memberToEdit.banglaName || memberToEdit.fullName}` : `Edit Member: ${memberToEdit.englishName || memberToEdit.fullName}`)
                : (isBn ? 'স্মার্ট সদস্য ফর্ম' : 'Smart Member Form')}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="rounded-xl p-2 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-stone-800 dark:hover:text-stone-200 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Quick-Jump Section Anchor Bar (Stays pinned for ease of navigation on one page) */}
        <div className="flex items-center gap-2 px-4 sm:px-6 py-2 border-b border-stone-200 dark:border-stone-800 bg-gradient-to-r from-teal-50/90 via-white/90 to-violet-50/90 dark:from-teal-950/30 dark:via-stone-900/90 dark:to-violet-950/30 overflow-x-auto text-xs shrink-0 scrollbar-none">
          <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider shrink-0 mr-1">
            {isBn ? 'তথ্যের বিভাগে যান:' : 'Jump to section:'}
          </span>
          <button
            type="button"
            onClick={() => scrollToSection('sec-basic')}
            className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/40 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-teal-800 dark:text-teal-200 font-medium whitespace-nowrap transition"
          >
            ১. {isBn ? 'মৌলিক পরিচয়' : 'Basic Identity'}
          </button>
          <button type="button" onClick={() => scrollToSection('sec-contact')} className="px-3 py-1 rounded-xl bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 text-sky-700 dark:text-sky-300 font-medium whitespace-nowrap transition">২. {isBn ? 'যোগাযোগ ও বর্তমান তথ্য' : 'Contact & Current Info'}</button>
          <button
            type="button"
            onClick={() => scrollToSection('sec-birth')}
            className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/40 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-teal-800 dark:text-teal-200 font-medium whitespace-nowrap transition"
          >
            ৩. {isBn ? 'জন্ম ও বঙ্গাব্দ' : 'Birth & Calendar'}
          </button>
          <button
            type="button"
            onClick={() => scrollToSection('sec-death')}
            className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/40 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-teal-800 dark:text-teal-200 font-medium whitespace-nowrap transition"
          >
            ৪. {isBn ? 'প্রয়াণ তথ্য' : 'Deceased Info'}
          </button>
          <button
            type="button"
            onClick={() => scrollToSection('sec-parents')}
            className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/40 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-teal-800 dark:text-teal-200 font-medium whitespace-nowrap transition"
          >
            ৫. {isBn ? 'পিতামাতা ও ধারা' : 'Parents & Lineage'}
          </button>
          <button
            type="button"
            onClick={() => scrollToSection('sec-history')}
            className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/40 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-teal-800 dark:text-teal-200 font-medium whitespace-nowrap transition"
          >
            ৮. {isBn ? 'ইতিহাস ও নোট' : 'History & Notes'}
          </button>
          <button
            type="button"
            onClick={() => scrollToSection('sec-documents')}
            className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/40 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-teal-800 dark:text-teal-200 font-medium whitespace-nowrap transition"
          >
            ৬. {isBn ? 'এনআইডি ও সনদ' : 'NID & Documents'}
          </button>
          <button
            type="button"
            onClick={() => scrollToSection('sec-bio')}
            className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/40 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-teal-800 dark:text-teal-200 font-medium whitespace-nowrap transition"
          >
            ৭. {isBn ? 'জীবনবৃত্তান্ত' : 'Biography'}
          </button>
          <button type="button" onClick={() => scrollToSection('sec-extended-data')} className="px-3 py-1 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-amber-100 text-stone-700 dark:text-stone-300 font-medium whitespace-nowrap transition">৯. {isBn ? 'গবেষণা ও অতিরিক্ত তথ্য' : 'Research & Extended Data'}</button>
          <button type="button" onClick={() => scrollToSection('sec-member-documents')} className="px-3 py-1 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-amber-100 text-stone-700 dark:text-stone-300 font-medium whitespace-nowrap transition">১০. {isBn ? 'সদস্যের নথি' : 'Member Documents'}</button>
          <button type="button" onClick={() => scrollToSection('sec-member-photo')} className="px-3 py-1 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-amber-100 text-stone-700 dark:text-stone-300 font-medium whitespace-nowrap transition">১১. {isBn ? 'ছবি ও মিডিয়া' : 'Photos & Media'}</button>
        </div>

        {/* Smart Form v3: guided responsive layout; only the member's Bangla name is required. */}
        <form data-smart-member-form="v3" data-single-page="true" onSubmit={handleSave} className="smart-member-form flex-1 min-h-0 overflow-y-auto scroll-smooth p-3 sm:p-5 lg:p-7 space-y-4 sm:space-y-5">
          <div data-smart-form-intro="true" className="rounded-2xl border border-teal-200 dark:border-teal-900 bg-gradient-to-r from-teal-50 via-white to-sky-50 dark:from-teal-950/40 dark:via-stone-900 dark:to-sky-950/30 px-4 py-3 sm:px-5 sm:py-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
            <div className="flex items-start gap-3 min-w-0"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-teal-600 text-white shadow-sm"><Sparkles className="h-5 w-5" /></span><div className="min-w-0"><p className="text-sm font-extrabold text-teal-950 dark:text-teal-100">{isBn ? 'আপনার পরিবারের তথ্য, ধাপে ধাপে—একই পৃষ্ঠায়' : 'Your family information, organized on one page'}</p><p className="mt-0.5 text-xs leading-5 text-stone-600 dark:text-stone-300">{isBn ? 'নাম দিয়ে শুরু করুন। বৈবাহিক অবস্থা ও সম্পর্ক অনুযায়ী প্রাসঙ্গিক অংশ ব্যবহার করুন; সংরক্ষিত তথ্য সম্পাদনায় অক্ষত থাকবে।' : 'Start with a name. Use the sections relevant to marital status and relationships; existing data is preserved while editing.'}</p></div></div>
            <div className="flex flex-wrap gap-1.5 text-[11px] font-semibold"><span className="rounded-full border border-teal-200 bg-white/80 px-2.5 py-1 text-teal-800 dark:bg-stone-900 dark:text-teal-200">{isBn ? 'এক পৃষ্ঠা' : 'Single page'}</span><span className="rounded-full border border-indigo-200 bg-white/80 px-2.5 py-1 text-indigo-800 dark:bg-stone-900 dark:text-indigo-200">{isBn ? `অবস্থা: ${{unmarried:'অবিবাহিত',married:'বিবাহিত',divorced:'তালাকপ্রাপ্ত',widowed:'বিধবা',widower:'বিপত্নীক',separated:'পৃথক বসবাস',unknown:'অজানা'}[maritalStatus]}` : `Status: ${{unmarried:'Unmarried',married:'Married',divorced:'Divorced',widowed:'Widowed',widower:'Widower',separated:'Separated',unknown:'Unknown'}[maritalStatus]}`}</span><span className="rounded-full border border-sky-200 bg-white/80 px-2.5 py-1 text-sky-800 dark:bg-stone-900 dark:text-sky-200">{isBn ? `সন্তান: ${childIds.length}` : `Children: ${childIds.length}`}</span></div>
          </div>
          <div className="rounded-xl border border-teal-200 dark:border-teal-900 bg-teal-50/80 dark:bg-teal-950/25 px-3 py-2.5 flex flex-wrap items-center justify-between gap-2">
            <div className="min-w-0"><p className="text-xs font-bold text-teal-900 dark:text-teal-100">{isBn ? 'আগে শুধু নাম দিন, বাকিটা পরে যোগ করতে পারবেন' : 'Start with the name; add other details later'}</p><p className="text-[11px] text-teal-800/80 dark:text-teal-200/80">{isBn ? 'তারকা (*) চিহ্নিত ঘর ছাড়া অন্য তথ্য ঐচ্ছিক। সংরক্ষিত তথ্য সম্পাদনার সময় অক্ষত থাকবে।' : 'Only fields marked (*) are required. Other details are optional and can be added later.'}</p></div>
            <span className="shrink-0 rounded-full bg-white dark:bg-stone-900 border border-teal-200 dark:border-teal-800 px-2.5 py-1 text-[10px] font-bold text-teal-800 dark:text-teal-200">{isBn ? 'স্মার্ট ফর্ম v3' : 'SMART FORM v3'}</span>
          </div>
          
          {/* SECTION 1: BASIC IDENTITY */}
          <div id="sec-basic" className="smart-form-section rounded-2xl border border-stone-200 dark:border-stone-800 bg-white/70 dark:bg-stone-950/30 p-3 sm:p-4 space-y-3 pt-3">
            <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center font-bold text-sm">
                ১
              </div>
              <div>
                <h4 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">
                  {isBn ? 'মৌলিক পরিচয় ও বংশীয় অবস্থান' : 'Basic Identity & Clan Position'}
                </h4>
                <p className="text-[11px] text-stone-500">
                  {isBn ? 'নাম, লিঙ্গ, প্রজন্ম ও বৈবাহিক অবস্থা' : 'Name, gender, generation, and marital status'}
                </p>
              </div>
            </div>

            {/* Names: Bangla and English */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">
                  {isBn ? 'বাংলা নাম (Bangla Full Name) *' : 'Bangla Name *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: তারিকুল ইসলাম চৌধুরী"
                  value={banglaName}
                  onChange={e => setBanglaName(e.target.value)}
                  className="w-full rounded-lg border border-stone-300 bg-white px-3 py-2.5 text-sm text-stone-900 focus:border-amber-600 focus:ring-2 focus:ring-amber-500/20 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">
                  {isBn ? 'ইংরেজি নাম (English Name)' : 'English Name'}
                </label>
                <input
                  type="text"
                  placeholder="e.g. Tariqul Islam Chowdhury"
                  value={englishName}
                  onChange={e => setEnglishName(e.target.value)}
                  className="w-full rounded-lg border border-stone-300 bg-white px-3 py-2.5 text-sm text-stone-900 focus:border-amber-600 focus:ring-2 focus:ring-amber-500/20 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="space-y-1.5"><span className="text-xs font-bold">{isBn ? 'বৈবাহিক অবস্থা' : 'Marital status'}</span><select className="w-full rounded-lg border px-3 py-2.5 text-sm" value={maritalStatus} onChange={e=>{const v=e.target.value as any; setMaritalStatus(v); setIsUnmarried(v==='unmarried');}}><option value="unmarried">{isBn?'অবিবাহিত':'Unmarried'}</option><option value="married">{isBn?'বিবাহিত':'Married'}</option><option value="divorced">{isBn?'তালাকপ্রাপ্ত':'Divorced'}</option><option value="widowed">{isBn?'বিধবা':'Widowed'}</option><option value="widower">{isBn?'বিপত্নীক':'Widower'}</option><option value="separated">{isBn?'পৃথক বসবাস':'Separated'}</option><option value="unknown">{isBn?'অজানা':'Unknown'}</option></select></label>
            </div>

            {/* Spouses — shown only when marriage is applicable or an existing marriage must be reviewed. */}
            {(maritalStatus !== 'unmarried' || spouseIds.length > 0) && (
            <div className="mt-4 rounded-2xl border border-rose-200 bg-rose-50/50 p-4 dark:border-rose-900/40 dark:bg-rose-950/20">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div><span className="text-xs font-bold text-rose-900 dark:text-rose-200">{isBn ? 'স্বামী / স্ত্রী / সঙ্গী — একাধিক বিবাহ সমর্থিত' : 'Spouse / Partner — multiple marriages supported'}</span><p className="mt-1 text-[10px] text-stone-500">{isBn ? 'প্রজন্ম ও লিঙ্গ অনুযায়ী তালিকা থেকে নির্বাচন করুন অথবা নতুন সদস্য যোগ করুন।' : 'Select from a generation and gender filtered list, or add a new member.'}</p></div>
                <span className="rounded-full bg-rose-100 px-2 py-1 text-[10px] font-bold text-rose-800 dark:bg-rose-900/40 dark:text-rose-200">{selectedSpouses.length} {isBn ? 'টি' : ''}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <select value={String(relationshipGeneration)} onChange={e => { const v=e.target.value; setRelationshipGeneration(v==='current'?'current':v==='next'?'next':Number(v)); }} className="w-full rounded-lg border px-3 py-2.5 text-sm bg-white dark:bg-stone-800">
                  <option value="current">{isBn ? `বর্তমান প্রজন্ম (${currentGeneration})` : `Current generation (${currentGeneration})`}</option>
                  <option value="next">{isBn ? `পরের প্রজন্ম (${currentGeneration + 1})` : `Next generation (${currentGeneration + 1})`}</option>
                  {Array.from({length:20},(_,i)=>i+1).map(g => <option key={g} value={g}>{isBn ? `${g}ম প্রজন্ম` : `Generation ${g}`}</option>)}
                </select>
                <select value="" onChange={e => { const id=e.target.value; if(id){ setSpouseId(id); setSpouseIds(prev=>[...new Set([...prev,id])]); setIsUnmarried(false); setMaritalStatus('married'); } }} className="w-full rounded-lg border px-3 py-2.5 text-sm bg-white dark:bg-stone-800 sm:col-span-2">
                  <option value="">{isBn ? 'প্রজন্ম + লিঙ্গ অনুযায়ী স্বামী/স্ত্রী নির্বাচন করুন' : 'Select spouse by generation + gender'}</option>
                  {potentialSpouses.filter(m=>!spouseIds.includes(m.id)).map(m => <option key={m.id} value={m.id}>{isBn ? (m.banglaName || m.fullName) : (m.englishName || m.fullName)} — {isBn ? `${generationMap.get(m.id)||m.computedGeneration||1}ম, ${m.gender==='male'?'পুরুষ':m.gender==='female'?'নারী':'অন্যান্য'}` : `Gen ${generationMap.get(m.id)||m.computedGeneration||1}, ${m.gender}`}</option>)}
                </select>
              </div>
              {selectedSpouses.length > 0 && <div className="mt-3 space-y-2">{selectedSpouses.map((spouse,index)=><div key={spouse.id} className="flex items-center gap-2 rounded-xl border bg-white/80 p-2 dark:bg-stone-800"><button type="button" onClick={()=>setSpouseId(spouse.id)} className={`flex-1 text-left text-sm font-semibold ${spouse.id===spouseId?'text-rose-700 dark:text-rose-300':''}`}>{index+1}. {isBn ? (spouse.banglaName||spouse.fullName) : (spouse.englishName||spouse.fullName)} <span className="text-[10px] text-stone-500">— {isBn ? `${generationMap.get(spouse.id)||spouse.computedGeneration||1}ম প্রজন্ম, ${spouse.gender==='male'?'পুরুষ':'নারী'}` : `Gen ${generationMap.get(spouse.id)||spouse.computedGeneration||1}, ${spouse.gender}`}</span></button><button type="button" onClick={()=>{setSpouseIds(prev=>prev.filter(id=>id!==spouse.id)); if(spouseId===spouse.id){const next=spouseIds.find(id=>id!==spouse.id)||'';setSpouseId(next);}}} className="rounded-lg px-2 py-1 text-xs text-red-600">{isBn?'বাদ':'Remove'}</button></div>)}</div>}
              <button type="button" onClick={() => quickAddRelatedMember('spouse')} className="mt-3 text-[11px] font-bold text-rose-700 hover:underline dark:text-rose-300">+ {isBn ? 'নতুন স্বামী/স্ত্রী সদস্য যোগ করুন' : 'Add new spouse member'}</button>
            </div>
            )}

            {/* Children / union children: only show for married members or existing linked children. */}
            {(maritalStatus !== 'unmarried' || spouseIds.length > 0 || childIds.length > 0) && <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50/50 p-4 dark:border-emerald-900/40 dark:bg-emerald-950/20">
                <label className="space-y-1.5 block">
                  <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200">{isBn ? 'সন্তানদের নাম' : 'Children'}</span>
                  <div className="space-y-2">
                    {childIds.length > 0 && (
                      <div className="space-y-1.5">
                        {childIds.map((id, index) => {
                          const child = members.find(m => m.id === id);
                          if (!child) return null;
                          return (
                            <div key={id} className="flex items-center gap-2 rounded-xl border bg-white/80 p-2 dark:bg-stone-800">
                              <span className="flex-1 text-sm font-semibold">{index + 1}. {isBn ? (child.banglaName || child.fullName) : (child.englishName || child.fullName)} <span className="ml-2 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200">{isBn ? (child.gender === 'male' ? 'পুত্র' : child.gender === 'female' ? 'কন্যা' : child.gender === 'other' ? 'অন্যান্য' : 'লিঙ্গ অজানা') : (child.gender === 'male' ? 'Son' : child.gender === 'female' ? 'Daughter' : child.gender === 'other' ? 'Other' : 'Gender unknown')}</span></span>
                              <button type="button" onClick={() => setChildIds(prev => prev.filter(cid => cid !== id))} className="rounded-lg px-2 py-1 text-xs text-red-600 hover:bg-red-50">{isBn ? 'বাদ' : 'Remove'}</button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                    {childNameDrafts.map((name, index) => (
                      <div key={`child-draft-${index}`} className="flex items-center gap-2">
                        <span className="w-7 text-center text-xs font-bold text-emerald-700">{childIds.length + index + 1}</span>
                        <input value={name} onChange={e => updateChildNameRow(index, e.target.value)} placeholder={isBn ? `সন্তানের ${childIds.length + index + 1}ম নাম` : `Child ${childIds.length + index + 1} name`} className="flex-1 rounded-lg border px-3 py-2.5 text-sm bg-white dark:bg-stone-800" />
                        <select value={childGenderDrafts[index] || 'unknown'} onChange={e => updateChildGenderRow(index, e.target.value as Gender)} className="w-32 rounded-lg border px-3 py-2.5 text-sm bg-white dark:bg-stone-800">
                          <option value="male">{isBn ? 'পুত্র' : 'Son'}</option><option value="female">{isBn ? 'কন্যা' : 'Daughter'}</option><option value="unknown">{isBn ? 'অজানা' : 'Unknown'}</option><option value="other">{isBn ? 'অন্যান্য' : 'Other'}</option>
                        </select>
                        {childNameDrafts.length > 1 && <button type="button" onClick={() => removeChildNameRow(index)} className="rounded-lg px-2 py-2 text-xs text-red-600 hover:bg-red-50">×</button>}
                      </div>
                    ))}
                    <button type="button" onClick={addChildNameRow} className="rounded-xl border border-emerald-300 px-3 py-2 text-xs font-bold text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300">+ {isBn ? 'আরও সন্তানের নাম যোগ করুন' : 'Add another child name'}</button>
                    <button type="button" onClick={() => quickAddRelatedMember('child')} className="rounded-xl border border-emerald-300 px-3 py-2 text-xs font-bold text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300">+ {isBn ? 'নতুন সন্তান সদস্য যোগ করুন' : 'Add new child member'}</button>
                  </div>
                  <p className="text-[11px] text-stone-500">{isBn ? 'এখানে একসঙ্গে একাধিক সন্তানের নাম লিখে তালিকা করা যাবে। সেভ করলে প্রতিটি নাম আলাদা সদস্য হিসেবে তৈরি হবে এবং পিতা-মাতা/বিবাহ সম্পর্ক সংরক্ষিত হবে।' : 'Enter multiple child names here. On save, each name becomes a separate member and parent/marriage links are preserved.'}</p>
                  <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <select value={String(relationshipGeneration)} onChange={e => { const v=e.target.value; setRelationshipGeneration(v==='current'?'current':v==='next'?'next':Number(v)); }} className="w-full rounded-lg border px-3 py-2.5 text-sm bg-white dark:bg-stone-800">
                      <option value="next">{isBn ? `সন্তানের প্রজন্ম: ${currentGeneration + 1}ম` : `Child generation: ${currentGeneration + 1}`}</option>
                      {Array.from({length:20},(_,i)=>i+1).map(g => <option key={g} value={g}>{isBn ? `${g}ম প্রজন্ম` : `Generation ${g}`}</option>)}
                    </select>
                    <select value={childGenderFilter} onChange={e => setChildGenderFilter(e.target.value as 'all' | Gender)} className="w-full rounded-lg border px-3 py-2.5 text-sm bg-white dark:bg-stone-800">
                      <option value="all">{isBn ? 'সব লিঙ্গ' : 'All genders'}</option>
                      <option value="male">{isBn ? 'পুরুষ / পুত্র' : 'Male / Son'}</option>
                      <option value="female">{isBn ? 'নারী / কন্যা' : 'Female / Daughter'}</option>
                      <option value="other">{isBn ? 'অন্যান্য' : 'Other'}</option>
                      <option value="unknown">{isBn ? 'অজানা' : 'Unknown'}</option>
                    </select>
                    <select value="" onChange={e => { if (e.target.value) { setChildIds(prev => [...new Set([...prev, e.target.value])]); e.currentTarget.value = ''; } }} className="w-full rounded-lg border px-3 py-2.5 text-sm bg-white dark:bg-stone-800">
                      <option value="">{isBn ? 'তালিকা থেকে সন্তান নির্বাচন করুন' : 'Select child from list'}</option>
                      {filteredPotentialChildren.filter(m=>!childIds.includes(m.id)).map(m => <option key={m.id} value={m.id}>{isBn ? (m.banglaName || m.fullName) : (m.englishName || m.fullName)} — {isBn ? `${generationMap.get(m.id)||m.computedGeneration||childTargetGeneration}ম, ${m.gender==='male'?'পুরুষ':m.gender==='female'?'নারী':m.gender==='other'?'অন্যান্য':'অজানা'}` : `Gen ${generationMap.get(m.id)||m.computedGeneration||childTargetGeneration}, ${m.gender}`}</option>)}
                    </select>
                  </div>
                  <p className="text-[10px] text-stone-500">{isBn ? `প্রজন্ম ${childTargetGeneration} এবং নির্বাচিত লিঙ্গ অনুযায়ী সদস্যের তালিকা থেকে সন্তান নির্বাচন করা যাবে; না থাকলে উপরের নাম/লিঙ্গ দিয়ে নতুন সদস্য তৈরি হবে।` : `Choose an existing child by generation and gender, or create a new child using the name/gender rows above.`}</p>
                </label>
              </div>}

            {/* Generation & Birth Order (serial number is intentionally not part of member UI) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="space-y-1.5"><span className="text-xs font-bold">{isBn ? 'প্রজন্ম *' : 'Generation *'}</span>
                <select value={generationMode === 'automatic' ? 'automatic' : String(generationOverride || '')} onChange={e => { const v=e.target.value; if(v==='automatic'){setGenerationMode('automatic');setGenerationOverride(undefined);} else {setGenerationMode('manual');setGenerationOverride(Number(v));} }} className="w-full rounded-lg border px-3 py-2.5 text-sm">
                  <option value="automatic">{isBn ? 'অটো — পিতা/মাতার সম্পর্ক থেকে' : 'Automatic — from parents'}</option>
                  {Array.from({length:20},(_,i)=><option key={i+1} value={i+1}>{isBn ? `${i+1}ম প্রজন্ম` : `Generation ${i+1}`}</option>)}
                </select>
              </label>
              <div className="rounded-xl border p-3 text-xs text-stone-500 sm:col-span-2">{isBn ? 'প্রজন্ম স্বয়ংক্রিয়ভাবে পিতা-মাতা/বংশসম্পর্ক থেকে নির্ধারিত হবে। Manual নির্বাচন করলে শুধু প্রদর্শনগত override হবে; সম্পর্ক পরিবর্তন হবে না।' : 'Generation is derived from parent relationships. Manual selection is a display/context override only and never changes relationships.'}</div>
            </div>

            {/* Nickname & Birth Order */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">
                  {isBn ? 'ডাকনাম / পরিচিত নাম' : 'Nickname'}
                </label>
                <input
                  type="text"
                  placeholder="যেমন: তারেক"
                  value={nickname}
                  onChange={e => setNickname(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-sm text-stone-900 focus:border-amber-600 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300 flex items-center justify-between">
                  <span>{isBn ? 'জন্মক্রম (Birth Order)' : 'Birth Order'}</span>
                  <span className="text-[10px] text-amber-600 font-semibold">{isBn ? 'বড় সন্তান = ১' : 'Eldest = 1'}</span>
                </label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={birthOrder || 1}
                  onChange={e => setBirthOrder(Number(e.target.value) || 1)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 font-mono text-sm text-stone-900 focus:border-amber-600 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                />
              </div>
            </div>

            {/* Gender & Branch Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">
                  {isBn ? 'লিঙ্গ (Gender) *' : 'Gender *'}
                </label>
                <select value={gender} onChange={e => setGender(e.target.value as Gender)} className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-sm dark:border-stone-700 dark:bg-stone-800 dark:text-white">
                  <option value="male">{isBn ? 'পুরুষ' : 'Male'}</option>
                  <option value="female">{isBn ? 'মহিলা' : 'Female'}</option>
                  <option value="other">{isBn ? 'অন্যান্য' : 'Other'}</option>
                  <option value="unknown">{isBn ? 'অজানা' : 'Unknown'}</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">
                  {isBn ? 'বংশীয় শাখা (Family Branch)' : 'Branch'}
                </label>
                <select
                  value={branchId}
                  onChange={e => setBranchId(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-sm text-stone-900 focus:border-amber-600 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                >
                  <option value="">{isBn ? '-- শাখা নির্বাচন করুন --' : '-- Select Branch --'}</option>
                  {branches.map(b => (
                    <option key={b.id} value={b.id}>
                      {isBn ? b.banglaName || b.name : b.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Living status and Unmarried rule */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <label className="space-y-1.5 p-3 rounded-2xl border border-stone-200 dark:border-stone-800 bg-stone-50/60 dark:bg-stone-950/40">
                <span className="text-xs font-bold block text-stone-900 dark:text-white">{isBn ? 'জীবিত / মৃত *' : 'Living / Deceased *'}</span>
                <select value={isLiving ? 'living' : 'deceased'} onChange={e => setIsLiving(e.target.value === 'living')} className="w-full text-xs p-2 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900">
                  <option value="living">{isBn ? 'জীবিত' : 'Living'}</option><option value="deceased">{isBn ? 'মৃত' : 'Deceased'}</option>
                </select>
              </label>

              <div className="p-3 rounded-2xl border border-stone-200 dark:border-stone-800 bg-stone-50/60 dark:bg-stone-950/40 space-y-1">
                <span className="text-xs font-bold block text-stone-900 dark:text-white">
                  {isBn ? 'বংশে অন্তর্ভুক্তি সূত্র' : 'Lineage Origin'}
                </span>
                <select
                  value={birthOrigin}
                  onChange={e => setBirthOrigin(e.target.value as BirthOrigin)}
                  className="w-full text-xs p-1.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
                >
                  <option value="born_in_family">{isBn ? 'বংশের রক্তের সন্তান (Biological)' : 'Born in Family'}</option>
                  <option value="joined_by_marriage">{isBn ? 'বিবাহসূত্রে আগমন (Spouse In-Law)' : 'Joined by Marriage'}</option>
                  <option value="adopted">{isBn ? 'দত্তক সন্তান (Adopted)' : 'Adopted'}</option>
                </select>
              </div>
            </div>
          </div>

          {/* SECTION 2: CONTACT, CURRENT LIFE & DATA ENTRY */}
          <div id="sec-contact" className="smart-form-section rounded-2xl border border-stone-200 dark:border-stone-800 bg-white/70 dark:bg-stone-950/30 p-3 sm:p-4 space-y-3">
            <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
              <div className="w-8 h-8 rounded-xl bg-sky-500/10 text-sky-700 dark:text-sky-400 flex items-center justify-center font-bold text-sm">২</div>
              <div>
                <h4 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">{isBn ? 'যোগাযোগ, বর্তমান জীবন ও প্রাথমিক তথ্য' : 'Contact, Current Life & Primary Details'}</h4>
                <p className="text-[11px] text-stone-500">{isBn ? 'নাম পরিচয়ের পরে প্রয়োজনীয় যোগাযোগ, ঠিকানা, শিক্ষা ও বর্তমান পেশা একসাথে দিন।' : 'Enter contact, addresses, education and current profession together after identity.'}</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <label className="space-y-1"><span className="text-[11px] font-bold">{isBn ? 'মোবাইল' : 'Mobile'}</span><input className="w-full rounded-lg border px-3 py-2.5 text-sm" placeholder="01XXXXXXXXX" value={mobileNumber} onChange={e=>setMobileNumber(e.target.value)} /></label>
              <label className="space-y-1"><span className="text-[11px] font-bold">Email</span><input className="w-full rounded-lg border px-3 py-2.5 text-sm" type="email" placeholder="name@example.com" value={email} onChange={e=>setEmail(e.target.value)} /></label>
              <label className="space-y-1"><span className="text-[11px] font-bold">{isBn ? 'বর্তমান পেশা' : 'Current profession'}</span><input className="w-full rounded-lg border px-3 py-2.5 text-sm" placeholder={isBn ? 'পেশা' : 'Profession'} value={profession} onChange={e=>setProfession(e.target.value)} /></label>
              <div className="sm:col-span-2 lg:col-span-3 rounded-2xl border border-sky-200/80 dark:border-sky-900/60 bg-gradient-to-br from-sky-50/80 to-white dark:from-sky-950/20 dark:to-stone-900 p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2"><div><h5 className="font-bold text-sm text-sky-950 dark:text-sky-100">{isBn ? 'বর্তমান ঠিকানা — স্মার্ট তালিকা' : 'Current Address — Smart Lists'}</h5><p className="text-[11px] text-stone-500">{isBn ? `বিভাগ → জেলা → উপজেলা → ইউনিয়ন/পৌরসভা। ${geoStatus === 'ready' ? 'প্রশাসনিক তালিকা লোড হয়েছে।' : geoStatus === 'loading' ? 'প্রশাসনিক তালিকা লোড হচ্ছে…' : 'জাতীয় তালিকা পাওয়া যায়নি; এখন শুধু একই এলাকার আগে সংরক্ষিত ঠিকানা থেকে পরামর্শ দেখানো হবে। অন্য জেলার উপজেলা দেখানো হবে না।'}` : `Division → District → Upazila → Union/Municipality. ${geoStatus === 'ready' ? 'Administrative catalogue loaded.' : geoStatus === 'loading' ? 'Loading administrative catalogue…' : 'National catalogue unavailable; only saved addresses in the selected area will be suggested. Upazilas from other districts will not be shown.'}`}</p></div></div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {ADDRESS_FIELDS.map(f => { const listId = `current-address-${f.key}`; const listField = ['division','district','upazila','union'].includes(f.key); const options = getAddressCatalogOptions(f.key, currentAddressDetails); return <label key={listId} className="space-y-1"><span className="text-[11px] font-semibold text-stone-700 dark:text-stone-300">{isBn ? f.bn : f.en}</span>{listField ? <select disabled={(f.key === 'district' && !currentAddressDetails.division) || (f.key === 'upazila' && !currentAddressDetails.district) || (f.key === 'union' && !currentAddressDetails.upazila)} className="w-full rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 p-2.5 text-sm disabled:opacity-60" value={String(currentAddressDetails[f.key] || '')} onChange={e=>updateAddressField(setCurrentAddressDetails, f.key, e.target.value)}><option value="">{isBn ? 'তালিকা থেকে নির্বাচন করুন' : 'Select from list'}</option>{options.map(value => <option key={value} value={value}>{value}</option>)}</select> : <><input list={listId} autoComplete="off" className="w-full rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 p-2.5 text-sm" value={String(currentAddressDetails[f.key] || '')} onChange={e=>updateAddressField(setCurrentAddressDetails, f.key, e.target.value)} /><datalist id={listId}>{getAddressSuggestions(f.key, currentAddressDetails).map(value => <option key={value} value={value} />)}</datalist></>}</label>; })}
                </div>
                <div className="rounded-xl border border-sky-200 bg-white/80 dark:bg-stone-900 p-3"><p className="mb-1 text-[10px] font-bold uppercase tracking-wide text-sky-700 dark:text-sky-300">{isBn ? 'সম্পূর্ণ ঠিকানা — সংরক্ষণের আগে যাচাই করুন' : 'Complete address — review before saving'}</p><p className="text-sm leading-6 text-stone-800 dark:text-stone-100">{addressPreview(currentAddressDetails, currentAddress) || (isBn ? 'ঠিকানার তথ্য নির্বাচন করুন' : 'Choose address details')}</p></div>
              </div>
              <div className="sm:col-span-2 lg:col-span-3 rounded-2xl border border-emerald-200/80 dark:border-emerald-900/60 bg-gradient-to-br from-emerald-50/70 to-white dark:from-emerald-950/20 dark:to-stone-900 p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2"><div><h5 className="font-bold text-sm text-emerald-950 dark:text-emerald-100">{isBn ? 'স্থায়ী ঠিকানা — স্মার্ট তালিকা' : 'Permanent Address — Smart Lists'}</h5><p className="text-[11px] text-stone-500">{isBn ? 'বর্তমান ঠিকানা থেকে আলাদা; সংরক্ষিত ঠিকানার পরামর্শ থেকে বেছে নিন।' : 'Separate from current address; choose from saved-address suggestions.'}</p></div><button type="button" onClick={()=>{setPermanentAddressDetails({...currentAddressDetails});setPermanentAddress(formatLocationInfo(currentAddressDetails, currentAddress));}} className="rounded-lg border border-emerald-300 dark:border-emerald-800 px-3 py-1.5 text-[11px] font-semibold text-emerald-800 dark:text-emerald-200 hover:bg-emerald-100 dark:hover:bg-emerald-950/50">{isBn ? 'বর্তমান ঠিকানা কপি করুন' : 'Copy current address'}</button></div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {ADDRESS_FIELDS.map(f => { const listId = `permanent-address-${f.key}`; const listField = ['division','district','upazila','union'].includes(f.key); const options = getAddressCatalogOptions(f.key, permanentAddressDetails); return <label key={listId} className="space-y-1"><span className="text-[11px] font-semibold text-stone-700 dark:text-stone-300">{isBn ? f.bn : f.en}</span>{listField ? <select disabled={(f.key === 'district' && !permanentAddressDetails.division) || (f.key === 'upazila' && !permanentAddressDetails.district) || (f.key === 'union' && !permanentAddressDetails.upazila)} className="w-full rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 p-2.5 text-sm disabled:opacity-60" value={String(permanentAddressDetails[f.key] || '')} onChange={e=>updateAddressField(setPermanentAddressDetails, f.key, e.target.value)}><option value="">{isBn ? 'তালিকা থেকে নির্বাচন করুন' : 'Select from list'}</option>{options.map(value => <option key={value} value={value}>{value}</option>)}</select> : <><input list={listId} autoComplete="off" className="w-full rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 p-2.5 text-sm" value={String(permanentAddressDetails[f.key] || '')} onChange={e=>updateAddressField(setPermanentAddressDetails, f.key, e.target.value)} /><datalist id={listId}>{getAddressSuggestions(f.key, permanentAddressDetails).map(value => <option key={value} value={value} />)}</datalist></>}</label>; })}
                </div>
                <div className="rounded-xl border border-emerald-200 bg-white/80 dark:bg-stone-900 p-3"><p className="mb-1 text-[10px] font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-300">{isBn ? 'সম্পূর্ণ স্থায়ী ঠিকানা' : 'Complete permanent address'}</p><p className="text-sm leading-6 text-stone-800 dark:text-stone-100">{addressPreview(permanentAddressDetails, permanentAddress) || (isBn ? 'ঠিকানার তথ্য নির্বাচন করুন' : 'Choose address details')}</p></div>
              </div>
              <label className="space-y-1 sm:col-span-2"><span className="text-[11px] font-bold">{isBn ? 'সর্বশেষ/সর্বোচ্চ শিক্ষা' : 'Education'}</span><input className="w-full rounded-lg border px-3 py-2.5 text-sm" placeholder={isBn ? 'প্রতিষ্ঠান — ডিগ্রি/শ্রেণি — বিষয়' : 'Institution — qualification — subject'} value={education} onChange={e=>setEducation(e.target.value)} /></label>
            </div>
            <div className="rounded-xl border border-sky-100 bg-sky-50/60 p-3 text-[11px] text-sky-900 dark:border-sky-900/40 dark:bg-sky-950/20 dark:text-sky-200">{isBn ? 'একই সদস্যের একাধিক শিক্ষা, পেশা ও বসবাসের ইতিহাস নিচের Structured History অংশে আলাদা record হিসেবে যোগ করা যাবে। এখানে শুধু বর্তমান/সংক্ষিপ্ত তথ্য দিন।' : 'Multiple education, career and residence records can be added later in Structured History; use this section for current/summary information.'}</div>
          </div>

          {/* SECTION 3: BIRTH & BANGLA CALENDAR */}
          <div id="sec-birth" className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center font-bold text-sm">
                ২
              </div>
              <div>
                <h4 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">
                  {isBn ? 'জন্ম তারিখ, বঙ্গাব্দ ও জন্মস্থান' : 'Birth Date, Bangla Calendar & Place'}
                </h4>
                <p className="text-[11px] text-stone-500">
                  {isBn ? 'ইংরেজি ও বাংলা সন গণনা এবং মূল আদি নিবাস' : 'Gregorian, Bengali standard year and birthplace details'}
                </p>
              </div>
            </div>

            {/* Gregorian Date Fields */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">{isBn ? 'জন্ম সাল (Year)' : 'Year'}</label>
                <input
                  type="number"
                  placeholder="YYYY (e.g. 1975)"
                  value={birthYear}
                  onChange={e => setBirthYear(e.target.value ? Number(e.target.value) : '')}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 font-mono text-sm text-stone-900 focus:border-amber-600 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">{isBn ? 'মাস (Month)' : 'Month'}</label>
                <select
                  value={birthMonth}
                  onChange={e => setBirthMonth(e.target.value ? Number(e.target.value) : '')}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-xs text-stone-900 focus:border-amber-600 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                >
                  <option value="">{isBn ? '-- মাস --' : '-- Month --'}</option>
                  {[
                    'জানুয়ারি (01)', 'ফেব্রুয়ারি (02)', 'মার্চ (03)', 'এপ্রিল (04)',
                    'মে (05)', 'জুন (06)', 'জুলাই (07)', 'আগস্ট (08)',
                    'সেপ্টেম্বর (09)', 'অক্টোবর (10)', 'নভেম্বর (11)', 'ডিসেম্বর (12)'
                  ].map((m, i) => (
                    <option key={i + 1} value={i + 1}>{m}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">{isBn ? 'দিন (Day)' : 'Day'}</label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  placeholder="DD (1-31)"
                  value={birthDay}
                  onChange={e => setBirthDay(e.target.value ? Number(e.target.value) : '')}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 font-mono text-sm text-stone-900 focus:border-amber-600 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">{isBn ? 'তারিখের নির্ভুলতা' : 'Precision'}</label>
                <select
                  value={birthPrecision}
                  onChange={e => setBirthPrecision(e.target.value as DatePrecision)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-xs text-stone-900 focus:border-amber-600 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                >
                  <option value="exact">{isBn ? 'সুনির্দিষ্ট (Exact)' : 'Exact'}</option>
                  <option value="approximate">{isBn ? 'আনুমানিক (Circa / Approx)' : 'Approximate'}</option>
                  <option value="estimated">{isBn ? 'অনুমিত (Estimated)' : 'Estimated'}</option>
                  <option value="unknown">{isBn ? 'অজ্ঞাত (Unknown)' : 'Unknown'}</option>
                </select>
              </div>
            </div>

            {/* Bangla Calendar Banner & Converter */}
            <div className="p-4 rounded-2xl border border-amber-200 dark:border-amber-900 bg-amber-50/50 dark:bg-amber-950/20 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-xs text-amber-950 dark:text-amber-200 block">
                    {isBn ? 'ঐতিহ্যিক বাংলা বর্ষপঞ্জি (বঙ্গাব্দ):' : 'Bangla Historical Calendar:'}
                  </span>
                  <span className="text-[11px] text-stone-500">
                    {isBn ? 'ইংরেজি তারিখ দিলে স্বয়ংক্রিয়ভাবে বৈশাখ-চৈত্র মাসের সঠিক দিন ও সাল হিসাব করে।' : 'Calculates exact Bengali era date from Gregorian.'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleAutoCalcBanglaDate}
                  disabled={!birthYear || !birthMonth || !birthDay}
                  className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-xs font-bold transition flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isBn ? 'বঙ্গাব্দ অটো-ক্যালকুলেট' : 'Auto Calculate'}</span>
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3 text-xs">
                <input
                  type="number"
                  placeholder="বাংলা দিন (যেমন: ১৫)"
                  value={banglaDateDay}
                  onChange={e => setBanglaDateDay(e.target.value ? Number(e.target.value) : '')}
                  className="p-2 rounded-xl border border-amber-300 dark:border-amber-800 bg-white dark:bg-stone-900"
                />
                <select
                  value={banglaDateMonth}
                  onChange={e => setBanglaDateMonth(e.target.value)}
                  className="p-2 rounded-xl border border-amber-300 dark:border-amber-800 bg-white dark:bg-stone-900"
                >
                  <option value="">-- বাংলা মাস --</option>
                  {BANGLA_MONTHS.map(monthName => (
                    <option key={monthName} value={monthName}>{monthName}</option>
                  ))}
                </select>
                <input
                  type="number"
                  placeholder="বঙ্গাব্দ সাল (যেমন: ১৩৮২)"
                  value={banglaDateYear}
                  onChange={e => setBanglaDateYear(e.target.value ? Number(e.target.value) : '')}
                  className="p-2 rounded-xl border border-amber-300 dark:border-amber-800 bg-white dark:bg-stone-900"
                />
              </div>
            </div>

            {/* Birthplace Details */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'গ্রাম / বাড়ি' : 'Village/House'}</label>
                <input
                  type="text"
                  placeholder="গ্রাম বা বাড়ির নাম"
                  value={birthVillage}
                  onChange={e => setBirthVillage(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'উপজেলা / থানা' : 'Upazila'}</label>
                <input
                  type="text"
                  placeholder="উপজেলা বা থানা"
                  value={birthUpazila}
                  onChange={e => setBirthUpazila(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'জেলা (District)' : 'District'}</label>
                <input
                  type="text"
                  placeholder="যেমন: সিলেট, চট্টগ্রাম"
                  value={birthDistrict}
                  onChange={e => setBirthDistrict(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'দেশ (Country)' : 'Country'}</label>
                <input
                  type="text"
                  value={birthCountry}
                  onChange={e => setBirthCountry(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* SECTION 3: DECEASED INFO (Conditional visual emphasis) */}
          <div id="sec-death" className={`space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800 transition ${isLiving ? 'opacity-60' : 'opacity-100'}`}>
            <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
              <div className="w-8 h-8 rounded-xl bg-stone-500/10 text-stone-700 dark:text-stone-300 flex items-center justify-center font-bold text-sm">
                ৩
              </div>
              <div>
                <h4 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">
                  {isBn ? 'প্রয়াণ ও সমাধি বিবরণ (Deceased / Memorial Details)' : 'Deceased & Memorial Details'}
                </h4>
                <p className="text-[11px] text-stone-500">
                  {isLiving
                    ? (isBn ? 'সদস্য জীবিত থাকায় এই অংশটি প্রযোজ্য নয় (প্রয়োজনে পূরণ করুন)' : 'Member is currently alive')
                    : (isBn ? 'মৃত্যুর তারিখ, নির্ভুলতা ও পারিবারিক কবরস্থান' : 'Death date and burial memorial')}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'মৃত্যু সাল (Year)' : 'Death Year'}</label>
                <input
                  type="number"
                  placeholder="YYYY"
                  disabled={isLiving}
                  value={deathYear}
                  onChange={e => setDeathYear(e.target.value ? Number(e.target.value) : '')}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 font-mono text-stone-900 disabled:bg-stone-100 dark:disabled:bg-stone-950 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'মাস' : 'Month'}</label>
                <select
                  disabled={isLiving}
                  value={deathMonth}
                  onChange={e => setDeathMonth(e.target.value ? Number(e.target.value) : '')}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-stone-900 disabled:bg-stone-100 dark:disabled:bg-stone-950 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                >
                  <option value="">-- মাস --</option>
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'দিন' : 'Day'}</label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  placeholder="DD"
                  disabled={isLiving}
                  value={deathDay}
                  onChange={e => setDeathDay(e.target.value ? Number(e.target.value) : '')}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 font-mono text-stone-900 disabled:bg-stone-100 dark:disabled:bg-stone-950 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'কবরস্থান / সমাধি' : 'Burial Location'}</label>
                <input
                  type="text"
                  placeholder="যেমন: পারিবারিক গোরস্থান"
                  disabled={isLiving}
                  value={deathBurialPlace}
                  onChange={e => setDeathBurialPlace(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-stone-900 disabled:bg-stone-100 dark:disabled:bg-stone-950 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* SECTION 4: PARENTS & LINEAGE */}
          <div id="sec-parents" className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center font-bold text-sm">
                ৪
              </div>
              <div>
                <h4 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">
                  {isBn ? 'পিতামাতা ও রক্তের অবিচ্ছেদ্য ধারা' : 'Parents & Biological Bloodline'}
                </h4>
                <p className="text-[11px] text-stone-500">
                  {isBn ? 'পিতা ও মাতা নির্বাচনের মাধ্যমে বংশবৃক্ষের সঠিক সংযোগ স্থাপিত হয়' : 'Establishes precise parent-child generational node linkages'}
                </p>
              </div>
            </div>

            {birthOrigin === 'joined_by_marriage' ? (
              <div className="rounded-xl border border-amber-200 bg-amber-50/60 p-3 text-xs text-stone-700 dark:border-amber-900/40 dark:bg-amber-950/20 dark:text-stone-200">
                <p className="font-bold">{isBn ? 'বিবাহসূত্রে আসা সদস্যের জন্মপরিবারের তথ্য' : 'Birth-family details for a marriage-origin member'}</p>
                <p className="mt-1">{isBn ? 'এখানে পিতা-মাতার নাম লিখুন। তাঁদের এই পরিবারের সদস্য হিসেবে যোগ করা হবে না এবং তাঁদের দিয়ে এই বংশের প্রজন্ম গণনা হবে না। তথ্যটি প্রোফাইলে সংরক্ষিত থাকবে, যাতে পরে অন্যত্র ব্যবহার করা যায়।' : 'Enter the biological parents below as external facts. They will not be added as members of this family or affect this family’s generation calculation. The names remain saved on this profile for reuse.'}</p>
                <p className="mt-2 font-semibold">{isBn ? `সদস্যের প্রজন্ম: ${Math.max(1, currentGeneration)}ম; জন্মপরিবারে পিতা-মাতার সম্ভাব্য প্রজন্ম: ${Math.max(1, currentGeneration - 1)}ম (শুধু তথ্য, বংশ-সদস্য নয়)` : `Member generation: ${Math.max(1, currentGeneration)}; parents' birth-family generation: ${Math.max(1, currentGeneration - 1)} (informational only, not family members)`}</p>
              </div>
            ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-stone-700 dark:text-stone-300 flex items-center justify-between">
                  <span>{isBn ? 'পিতা (Father)' : 'Father'}</span>
                  <span className="text-[10px] text-stone-400">{isBn ? (allowAllParentGenerations ? 'পূর্ববর্তী প্রজন্মের যেকোনো পুরুষ' : `পূর্ববর্তী প্রজন্মের পুরুষ`) : (allowAllParentGenerations ? 'Male — any previous generation' : `Male — previous generation`)}</span>
                </label>
                <select
                  value={fatherId}
                  onChange={e => setFatherId(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-3 text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                >
                  <option value="">{isBn ? '-- পিতা নির্বাচন করুন (যদি থাকে) --' : '-- Select Father --'}</option>
                  {potentialFathers.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.banglaName || p.fullName} — {isBn ? `${generationMap.get(p.id) || p.computedGeneration || 1}ম প্রজন্ম, পুরুষ` : `Gen ${generationMap.get(p.id) || p.computedGeneration || 1}, Male`}
                    </option>
                  ))}
                </select>
                <button type="button" onClick={() => quickAddRelatedMember('father')} className="text-[11px] font-bold text-amber-700 hover:underline dark:text-amber-300">+ {isBn ? 'নতুন পুরুষ সদস্য / পিতা যোগ করুন' : 'Add new male member / father'}</button>
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-stone-700 dark:text-stone-300 flex items-center justify-between">
                  <span>{isBn ? 'মাতা (Mother)' : 'Mother'}</span>
                  <span className="text-[10px] text-stone-400">{isBn ? (allowAllParentGenerations ? 'পূর্ববর্তী প্রজন্মের যেকোনো নারী' : `পূর্ববর্তী প্রজন্মের নারী`) : (allowAllParentGenerations ? 'Female — any previous generation' : `Female — previous generation`)}</span>
                </label>
                <select
                  value={motherId}
                  onChange={e => setMotherId(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-3 text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                >
                  <option value="">{isBn ? '-- মাতা নির্বাচন করুন (যদি থাকে) --' : '-- Select Mother --'}</option>
                  {potentialMothers.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.banglaName || p.fullName} — {isBn ? `${generationMap.get(p.id) || p.computedGeneration || 1}ম প্রজন্ম, নারী` : `Gen ${generationMap.get(p.id) || p.computedGeneration || 1}, Female`}
                    </option>
                  ))}
                </select>
                <button type="button" onClick={() => quickAddRelatedMember('mother')} className="text-[11px] font-bold text-amber-700 hover:underline dark:text-amber-300">+ {isBn ? 'নতুন নারী সদস্য / মাতা যোগ করুন' : 'Add new female member / mother'}</button>
              </div>
            </div>
            )}

            <div className="mt-3 rounded-2xl border border-sky-200 bg-sky-50/50 p-3 dark:border-sky-900/40 dark:bg-sky-950/10">
              <div className="mb-2">
                <h5 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'পিতামাতার নাম — দলিল/OCR তথ্য' : 'Biological parent names — document/OCR record'}</h5>
                <p className="text-[10px] text-stone-500">{isBn ? 'পিতা/মাতা এই পরিবারের সদস্য হিসেবে নিবন্ধিত না থাকলেও NID/জন্ম নিবন্ধন থেকে পাওয়া নাম এখানে সংরক্ষিত থাকবে।' : 'Names found on NID/birth documents remain stored even when the biological parents are not members of this family workspace.'}</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><label className="block text-[10px] font-bold text-stone-500 mb-1">{isBn ? 'পিতার নাম (বাংলা)' : 'Father Name (Bangla)'}</label><input value={fatherNameBn} onChange={e=>setFatherNameBn(e.target.value)} className="w-full rounded-lg border px-2.5 py-2 text-xs bg-white dark:bg-stone-900" /></div>
                <div><label className="block text-[10px] font-bold text-stone-500 mb-1">Father Name (English, {isBn ? 'ঐচ্ছিক' : 'optional'})</label><input value={fatherNameEn} onChange={e=>setFatherNameEn(e.target.value)} className="w-full rounded-lg border px-2.5 py-2 text-xs bg-white dark:bg-stone-900" /></div>
                <div><label className="block text-[10px] font-bold text-stone-500 mb-1">{isBn ? 'মাতার নাম (বাংলা)' : 'Mother Name (Bangla)'}</label><input value={motherNameBn} onChange={e=>setMotherNameBn(e.target.value)} className="w-full rounded-lg border px-2.5 py-2 text-xs bg-white dark:bg-stone-900" /></div>
                <div><label className="block text-[10px] font-bold text-stone-500 mb-1">Mother Name (English, {isBn ? 'ঐচ্ছিক' : 'optional'})</label><input value={motherNameEn} onChange={e=>setMotherNameEn(e.target.value)} className="w-full rounded-lg border px-2.5 py-2 text-xs bg-white dark:bg-stone-900" /></div>
              </div>
            </div>

            <div className="mt-3 rounded-2xl border border-violet-200 bg-violet-50/50 p-3 dark:border-violet-900/40 dark:bg-violet-950/10">
              <div className="mb-2"><h5 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'পালক পিতা-মাতার তথ্য (জন্মদাতা থেকে আলাদা)' : 'Adoptive parents (separate from biological parents)'}</h5><p className="text-[10px] text-stone-500">{isBn ? 'এখানে লেখা নাম জন্মদাতা পিতা-মাতার তথ্য বা বংশ-সম্পর্ককে প্রতিস্থাপন করবে না।' : 'These names never overwrite biological parent names or lineage links.'}</p></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><label className="block text-[10px] font-bold text-stone-500 mb-1">{isBn ? 'পালক পিতার নাম (বাংলা)' : 'Adoptive father (Bangla)'}</label><input value={adoptiveFatherNameBn} onChange={e=>setAdoptiveFatherNameBn(e.target.value)} className="w-full rounded-lg border px-2.5 py-2 text-xs bg-white dark:bg-stone-900" /></div>
                <div><label className="block text-[10px] font-bold text-stone-500 mb-1">{isBn ? 'পালক পিতার নাম (ইংরেজি)' : 'Adoptive father (English)'}</label><input value={adoptiveFatherNameEn} onChange={e=>setAdoptiveFatherNameEn(e.target.value)} className="w-full rounded-lg border px-2.5 py-2 text-xs bg-white dark:bg-stone-900" /></div>
                <div><label className="block text-[10px] font-bold text-stone-500 mb-1">{isBn ? 'পালক মাতার নাম (বাংলা)' : 'Adoptive mother (Bangla)'}</label><input value={adoptiveMotherNameBn} onChange={e=>setAdoptiveMotherNameBn(e.target.value)} className="w-full rounded-lg border px-2.5 py-2 text-xs bg-white dark:bg-stone-900" /></div>
                <div><label className="block text-[10px] font-bold text-stone-500 mb-1">{isBn ? 'পালক মাতার নাম (ইংরেজি)' : 'Adoptive mother (English)'}</label><input value={adoptiveMotherNameEn} onChange={e=>setAdoptiveMotherNameEn(e.target.value)} className="w-full rounded-lg border px-2.5 py-2 text-xs bg-white dark:bg-stone-900" /></div>
              </div>
            </div>

            {(maritalStatus !== 'unmarried' || spouseIds.length > 0) && <div className="mt-2 rounded-2xl border border-rose-200 bg-rose-50/40 p-4 dark:border-rose-900/40 dark:bg-rose-950/20">
              <div className="mb-3">
                <h5 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'শ্বশুর-শাশুড়ী' : 'Parents-in-law'}</h5>
                <p className="text-[11px] text-stone-500">{isBn ? 'শুধু সঙ্গীর প্রকৃতভাবে সংযুক্ত পিতা-মাতাই এখানে নির্বাচনযোগ্য। সঙ্গীর পিতা-মাতার নাম আলাদা তথ্য হিসেবে থাকলে তা নিচে দেখাবে—অন্য সদস্যদের তালিকা থেকে অনুমান করে নির্বাচন করবেন না।' : 'Only the spouse’s actually linked parents are selectable here. If the spouse’s parent names are stored as external facts, they appear below; unrelated members are not offered as guesses.'}</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="space-y-1.5"><span className="text-xs font-bold">{isBn ? 'শ্বশুরের নাম (সদস্য না হলেও লিখুন)' : 'Father-in-law name (can be external)'}</span><input value={fatherInLawName || spouseMember?.fatherNameBn || ''} onChange={e=>setFatherInLawName(e.target.value)} placeholder={isBn ? 'শ্বশুরের নাম লিখুন' : 'Enter father-in-law name'} className="w-full rounded-xl border p-2.5 text-sm bg-white dark:bg-stone-800" /></label>
                <label className="space-y-1.5"><span className="text-xs font-bold">{isBn ? 'শাশুড়ির নাম (সদস্য না হলেও লিখুন)' : 'Mother-in-law name (can be external)'}</span><input value={motherInLawName || spouseMember?.motherNameBn || ''} onChange={e=>setMotherInLawName(e.target.value)} placeholder={isBn ? 'শাশুড়ির নাম লিখুন' : 'Enter mother-in-law name'} className="w-full rounded-xl border p-2.5 text-sm bg-white dark:bg-stone-800" /></label>
                <label className="space-y-1.5"><span className="text-xs font-bold">{isBn ? 'শ্বশুরের সদস্য প্রোফাইল (ঐচ্ছিক)' : 'Link father-in-law member (optional)'}</span>
                  <select value={fatherInLawId} onChange={e => setFatherInLawId(e.target.value)} className="w-full rounded-xl border p-2.5 text-sm bg-white dark:bg-stone-800"><option value="">{isBn ? '-- নির্বাচন করুন --' : '-- Select --'}</option>{potentialInLawMen.map(p => <option key={p.id} value={p.id}>{p.banglaName || p.fullName} — {isBn ? `${generationMap.get(p.id) || p.computedGeneration || 1}ম প্রজন্ম` : `Gen ${generationMap.get(p.id) || p.computedGeneration || 1}`}</option>)}</select>
                  {spouseMember?.fatherNameBn && <p className="text-[11px] text-stone-500">{isBn ? `সঙ্গীর নথিভুক্ত পিতার নাম: ${spouseMember.fatherNameBn}${spouseMember.fatherNameEn ? ` (${spouseMember.fatherNameEn})` : ''} — বহিরাগত তথ্য, সদস্য নয়` : `Spouse's recorded father: ${spouseMember.fatherNameEn || spouseMember.fatherNameBn} — external information, not a family member`}</p>}
                </label>
                <label className="space-y-1.5"><span className="text-xs font-bold">{isBn ? 'শাশুড়ির সদস্য প্রোফাইল (ঐচ্ছিক)' : 'Link mother-in-law member (optional)'}</span>
                  <select value={motherInLawId} onChange={e => setMotherInLawId(e.target.value)} className="w-full rounded-xl border p-2.5 text-sm bg-white dark:bg-stone-800"><option value="">{isBn ? '-- নির্বাচন করুন --' : '-- Select --'}</option>{potentialInLawWomen.map(p => <option key={p.id} value={p.id}>{p.banglaName || p.fullName} — {isBn ? `${generationMap.get(p.id) || p.computedGeneration || 1}ম প্রজন্ম` : `Gen ${generationMap.get(p.id) || p.computedGeneration || 1}`}</option>)}</select>
                  {spouseMember?.motherNameBn && <p className="text-[11px] text-stone-500">{isBn ? `সঙ্গীর নথিভুক্ত মাতার নাম: ${spouseMember.motherNameBn}${spouseMember.motherNameEn ? ` (${spouseMember.motherNameEn})` : ''} — বহিরাগত তথ্য, সদস্য নয়` : `Spouse's recorded mother: ${spouseMember.motherNameEn || spouseMember.motherNameBn} — external information, not a family member`}</p>}
                </label>
              </div>
              {spouseMember && <p className="mt-2 text-[10px] text-stone-500">{isBn ? `বর্তমান সঙ্গী: ${spouseMember.banglaName || spouseMember.fullName}` : `Current spouse: ${spouseMember.englishName || spouseMember.fullName}`}</p>}
            </div>}

            {birthOrigin !== 'joined_by_marriage' && <div className="mt-2 rounded-2xl border border-amber-200 bg-amber-50/40 p-4 dark:border-stone-700 dark:bg-stone-950/30">
              <div className="mb-3">
                <h5 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'দাদা-দাদি ও নানা-নানি' : 'Grandparents'}</h5>
                <p className="text-[11px] text-stone-500">{isBn ? 'পিতা-মাতার তথ্য অসম্পূর্ণ হলেও এই চারটি সম্পর্ক generation নির্ধারণে সহায়তা করবে।' : 'These links help recover generations even when parent profiles are incomplete.'}</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  ['দাদা', paternalGrandfatherId, setPaternalGrandfatherId, potentialPaternalGrandfathers],
                  ['দাদি', paternalGrandmotherId, setPaternalGrandmotherId, potentialPaternalGrandmothers],
                  ['নানা', maternalGrandfatherId, setMaternalGrandfatherId, potentialMaternalGrandfathers],
                  ['নানি', maternalGrandmotherId, setMaternalGrandmotherId, potentialMaternalGrandmothers]
                ].map(([label,value,setter,options]) => (
                  <label key={String(label)} className="space-y-1.5">
                    <span className="text-xs font-bold text-stone-700 dark:text-stone-300">{isBn ? String(label) : String(label)}</span>
                    <select value={String(value)} onChange={e => (setter as React.Dispatch<React.SetStateAction<string>>)(e.target.value)} className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-sm dark:border-stone-700 dark:bg-stone-800 dark:text-white">
                      <option value="">{isBn ? `-- ${label} নির্বাচন করুন --` : `-- Select ${label} --`}</option>
                      {(options as Member[]).map(p => <option key={p.id} value={p.id}>{p.banglaName || p.fullName}</option>)}
                    </select>
                  </label>
                ))}
              </div>
            </div>}
          </div>

          <div className="rounded-2xl border border-stone-200 bg-stone-50/70 p-4 dark:border-stone-800 dark:bg-stone-950/30">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="space-y-1.5">
                <span className="text-xs font-bold">{isBn ? 'মৃত্যুকালে বয়স' : 'Age at death'}</span>
                <input type="number" min="0" max="130" value={ageAtDeath} onChange={e=>setAgeAtDeath(e.target.value === '' ? '' : Number(e.target.value))} className="w-full rounded-lg border px-3 py-2.5 text-sm" placeholder={isBn ? 'যেমন ৭২' : 'e.g. 72'} />
              </label>
              <div className="sm:col-span-2 text-xs text-stone-500 flex items-center">{isBn ? 'মৃত্যুর বছর ও মৃত্যুকালের বয়স দেওয়া থাকলে জন্মসনের ঘর খালি থাকলে বংশকথা আনুমানিক জন্মসন স্বয়ংক্রিয়ভাবে পূরণ করবে।' : 'If death year and age at death are provided while birth year is blank, the approximate birth year is calculated automatically.'}</div>
            </div>
          </div>

          {/* SECTION 5: NATIONAL IDENTITY & DOCUMENTS */}
          <div id="sec-documents" className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center font-bold text-sm">
                ৫
              </div>
              <div>
                <h4 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">
                  {isBn ? 'জাতীয় পরিচয়পত্র ও সনদপত্র (NID & Birth Certificate)' : 'Identification Records'}
                </h4>
                <p className="text-[11px] text-stone-500">
                  {isBn ? 'এনআইডি এবং জন্ম নিবন্ধন সনদ কঠোরভাবে পৃথক দুটি ফিল্ড হিসেবে সংরক্ষিত হয়' : 'National ID and Birth Registration are strictly separated'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-stone-700 dark:text-stone-300 flex items-center justify-between">
                  <span>{isBn ? 'জাতীয় পরিচয়পত্র নম্বর (NID Number)' : 'NID Number'}</span>
                  <span className="text-[10px] text-stone-400">১০/১৩/১৭ ডিজিট</span>
                </label>
                <input
                  type="text"
                  placeholder="যেমন: 19801234567890"
                  value={nidNumber}
                  onChange={e => setNidNumber(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-3 font-mono text-sm text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-stone-700 dark:text-stone-300 flex items-center justify-between">
                  <span>{isBn ? 'জন্ম নিবন্ধন সনদ নম্বর (Birth Registration No.)' : 'Birth Registration No.'}</span>
                  <span className="text-[10px] text-stone-400">১৭ ডিজিট সনদ</span>
                </label>
                <input
                  type="text"
                  placeholder="যেমন: 20011234567890123"
                  value={birthRegistrationNumber}
                  onChange={e => setBirthRegistrationNumber(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-3 font-mono text-sm text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'পাসপোর্ট নম্বর' : 'Passport Number'}</label>
                <input
                  type="text"
                  placeholder="e.g. A01234567"
                  value={passportNumber}
                  onChange={e => setPassportNumber(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 font-mono text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'তথ্য যাচাইকরণ স্থিতি' : 'Verification Status'}</label>
                <select
                  value={verificationStatus}
                  onChange={e => setVerificationStatus(e.target.value as VerificationStatus)}
                  className="w-full rounded-xl border border-stone-300 bg-white p-2.5 text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                >
                  <option value="verified">{isBn ? '✓ যাচাইকৃত (Verified)' : 'Verified'}</option>
                  <option value="probable">{isBn ? 'সম্ভাব্য (Probable)' : 'Probable'}</option>
                  <option value="oral">{isBn ? 'পারিবারিক/মৌখিক সূত্র (Oral)' : 'Oral / Family reported'}</option>
                  <option value="unverified">{isBn ? 'অযাচাইকৃত (Unverified)' : 'Unverified'}</option>
                  <option value="disputed">{isBn ? 'দ্বিমতযুক্ত / তদন্তাধীন (Disputed)' : 'Disputed'}</option>
                </select>
              </div>
            </div>
          </div>

          {/* EXTENDED GENEALOGY DATA */}
          <div id="sec-extended-data" className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
            <div><h4 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'অতিরিক্ত বংশতথ্য ও গবেষণা তথ্য' : 'Extended Genealogy & Research Data'}</h4><p className="text-[11px] text-stone-500">{isBn ? 'বিকল্প নাম, জাতীয়তা, ভাষা, রক্তের গ্রুপ, সামরিক/অভিবাসন তথ্য ও গবেষণা নোট।' : 'Alternative names, nationality, languages, blood group, service, migration and research notes.'}</p></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div><label className="text-xs font-bold">{isBn?'বাংলা বিকল্প নাম/বানান':'Alternative Bangla names/spellings'}</label><textarea value={alternativeNames} onChange={e=>setAlternativeNames(e.target.value)} placeholder={isBn?'প্রতিটি নাম/বানান নতুন লাইনে লিখুন':'One name/spelling per line'} rows={3} className="mt-1 w-full rounded-xl border p-3 dark:bg-stone-800"/></div>
                <div><label className="text-xs font-bold">{isBn?'English বিকল্প নাম/বানান (ঐচ্ছিক)':'Alternative English names/spellings (optional)'}</label><textarea value={alternativeEnglishNames} onChange={e=>setAlternativeEnglishNames(e.target.value)} placeholder={isBn?'প্রতিটি English বানান নতুন লাইনে লিখুন; ফাঁকা রাখা যাবে':'One English spelling per line; optional'} rows={3} className="mt-1 w-full rounded-xl border p-3 dark:bg-stone-800"/></div>
                <div><label className="text-xs font-bold">{isBn?'বিকল্প নামের নথি/উৎস (ঐচ্ছিক)':'Alternate-name document/source (optional)'}</label><textarea value={alternativeNameSources} onChange={e=>setAlternativeNameSources(e.target.value)} placeholder={isBn?'প্রতি লাইনে: নাম | নথির ধরন | রেফারেন্স | নোট':'One per line: name | document type | reference | note'} rows={3} className="mt-1 w-full rounded-xl border p-3 dark:bg-stone-800"/><p className="mt-1 text-[10px] text-stone-500">{isBn?'উদাহরণ: রুবেল সিকদার | NID | NID-2026 | সরকারি বানান':'Example: Rubel Sikdar | NID | NID-2026 | official spelling'}</p></div>
              </div>
              <input value={nationality} onChange={e=>setNationality(e.target.value)} placeholder={isBn?'জাতীয়তা':'Nationality'} className="w-full rounded-xl border p-3 dark:bg-stone-800"/>
              <input value={religion} onChange={e=>setReligion(e.target.value)} placeholder={isBn?'ধর্মীয় পরিচয় (ঐচ্ছিক)':'Religion (optional)'} className="w-full rounded-xl border p-3 dark:bg-stone-800"/>
              <select value={bloodGroup} onChange={e=>setBloodGroup(e.target.value as BloodGroup)} className="w-full rounded-xl border p-3 dark:bg-stone-800"><option value="unknown">{isBn?'রক্তের গ্রুপ: অজানা':'Blood group: Unknown'}</option>{['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(v=><option key={v} value={v}>{v}</option>)}</select>
              <input value={languages} onChange={e=>setLanguages(e.target.value)} placeholder={isBn?'ভাষা (কমা দিয়ে)':'Languages (comma separated)'} className="w-full rounded-xl border p-3 dark:bg-stone-800"/>
              <select value={researchStatus} onChange={e=>setResearchStatus(e.target.value as ResearchStatus)} className="w-full rounded-xl border p-3 dark:bg-stone-800"><option value="unverified">{isBn?'গবেষণা অবস্থা: অযাচাইকৃত':'Research: Unverified'}</option><option value="verified">Verified</option><option value="probable">Probable</option><option value="family_reported">{isBn?'পারিবারিকভাবে জানা':'Family reported'}</option><option value="disputed">{isBn?'বিতর্কিত':'Disputed'}</option><option value="needs_research">{isBn?'আরও গবেষণা প্রয়োজন':'Needs research'}</option></select>
            </div>
            <textarea value={physicalDescription} onChange={e=>setPhysicalDescription(e.target.value)} placeholder={isBn?'শারীরিক পরিচিতি / বিশেষ চিহ্ন':'Physical description / identifying marks'} className="w-full rounded-xl border p-3 text-xs dark:bg-stone-800" rows={2}/>
            <textarea value={militaryService} onChange={e=>setMilitaryService(e.target.value)} placeholder={isBn?'সামরিক/সরকারি/সেবামূলক ইতিহাস':'Military / government / service history'} className="w-full rounded-xl border p-3 text-xs dark:bg-stone-800" rows={2}/>
            <textarea value={migrationHistory} onChange={e=>setMigrationHistory(e.target.value)} placeholder={isBn?'দেশান্তর/অভিবাসন ইতিহাস':'Migration / immigration history'} className="w-full rounded-xl border p-3 text-xs dark:bg-stone-800" rows={2}/>
            <textarea value={researchNotes} onChange={e=>setResearchNotes(e.target.value)} placeholder={isBn?'গবেষণা নোট: কোন তথ্য অনিশ্চিত, কোন সূত্রে পাওয়া গেছে, কী যাচাই বাকি':'Research notes: uncertainty, source leads, unresolved questions'} className="w-full rounded-xl border p-3 text-xs dark:bg-stone-800" rows={3}/>
          </div>

          {/* PROFILE PHOTO — live camera or file */}
          <div id="sec-member-photo" className="space-y-3 pt-4 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between gap-3">
              {/* SECTION 7: STRUCTURED HISTORY & NOTES */}
            <div id="sec-history" className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
              <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
                <div className="w-8 h-8 rounded-xl bg-violet-500/10 text-violet-700 dark:text-violet-300 flex items-center justify-center font-bold text-sm">৭</div>
                <div>
                  <h4 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">{isBn ? 'শিক্ষা, পেশা, বসবাস ও পারিবারিক ইতিহাস' : 'Education, Career, Residence & Family History'}</h4>
                  <p className="text-[11px] text-stone-500">{isBn ? 'একাধিক রেকর্ড আলাদাভাবে যোগ করুন; পুরোনো তথ্যও সংরক্ষিত থাকবে।' : 'Add multiple historical records without replacing earlier information.'}</p>
                </div>
              </div>

              <div className="rounded-2xl border border-sky-200 bg-sky-50/40 p-4 dark:border-sky-900/40 dark:bg-sky-950/20 space-y-3">
                <div className="flex items-center justify-between gap-2"><div><h5 className="text-xs font-bold">{isBn ? 'শিক্ষার ইতিহাস' : 'Education History'}</h5><p className="text-[10px] text-stone-500">{isBn ? 'প্রতিষ্ঠান, যোগ্যতা, বিষয়, বছর, ফলাফল ও নোট।' : 'Institution, qualification, subject, year, result and notes.'}</p></div><button type="button" onClick={addEducationRecord} className="rounded-lg bg-sky-700 px-3 py-1.5 text-[10px] font-bold text-white">+ {isBn ? 'শিক্ষা যোগ' : 'Add Education'}</button></div>
                {educationHistory.map((row, i) => <div key={row.id} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 rounded-xl border border-sky-100 bg-white/80 p-3 dark:border-sky-900/40 dark:bg-stone-900/60">
                  <input className="rounded-lg border p-2 text-xs" placeholder={isBn ? 'প্রতিষ্ঠান' : 'Institution'} value={row.institution || ''} onChange={e=>updateEducationRecord(i,{institution:e.target.value})}/>
                  <input className="rounded-lg border p-2 text-xs" placeholder={isBn ? 'ডিগ্রি/শ্রেণি/যোগ্যতা' : 'Qualification / Class'} value={row.qualification || ''} onChange={e=>updateEducationRecord(i,{qualification:e.target.value})}/>
                  <input className="rounded-lg border p-2 text-xs" placeholder={isBn ? 'বিষয়' : 'Subject'} value={row.subject || ''} onChange={e=>updateEducationRecord(i,{subject:e.target.value})}/>
                  <input className="rounded-lg border p-2 text-xs" type="number" placeholder={isBn ? 'সন' : 'Year'} value={row.year ?? ''} onChange={e=>updateEducationRecord(i,{year:e.target.value ? Number(e.target.value) : undefined})}/>
                  <input className="rounded-lg border p-2 text-xs" placeholder={isBn ? 'ফলাফল' : 'Result'} value={row.result || ''} onChange={e=>updateEducationRecord(i,{result:e.target.value})}/>
                  <div className="flex gap-2"><input className="min-w-0 flex-1 rounded-lg border p-2 text-xs" placeholder={isBn ? 'নোট/স্থান' : 'Notes / Location'} value={row.notes || ''} onChange={e=>updateEducationRecord(i,{notes:e.target.value})}/><button type="button" onClick={()=>removeEducationRecord(i)} className="rounded-lg border border-red-200 px-2 text-red-600">×</button></div>
                </div>)}
              </div>

              <div className="rounded-2xl border border-emerald-200 bg-emerald-50/40 p-4 dark:border-emerald-900/40 dark:bg-emerald-950/20 space-y-3">
                <div className="flex items-center justify-between gap-2"><div><h5 className="text-xs font-bold">{isBn ? 'পেশা ও কর্মজীবনের ইতিহাস' : 'Profession & Career History'}</h5><p className="text-[10px] text-stone-500">{isBn ? 'একাধিক চাকরি/ব্যবসা/পেশা আলাদা রেকর্ড হিসেবে রাখুন।' : 'Keep each job, business or career period as a separate record.'}</p></div><button type="button" onClick={addProfessionRecord} className="rounded-lg bg-emerald-700 px-3 py-1.5 text-[10px] font-bold text-white">+ {isBn ? 'পেশা যোগ' : 'Add Career'}</button></div>
                {professionHistory.map((row, i) => <div key={row.id} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 rounded-xl border border-emerald-100 bg-white/80 p-3 dark:border-emerald-900/40 dark:bg-stone-900/60">
                  <input className="rounded-lg border p-2 text-xs" placeholder={isBn ? 'পেশা' : 'Profession'} value={row.profession || ''} onChange={e=>updateProfessionRecord(i,{profession:e.target.value})}/>
                  <input className="rounded-lg border p-2 text-xs" placeholder={isBn ? 'প্রতিষ্ঠান/ব্যবসা' : 'Organization / Business'} value={row.organization || ''} onChange={e=>updateProfessionRecord(i,{organization:e.target.value})}/>
                  <input className="rounded-lg border p-2 text-xs" placeholder={isBn ? 'পদবি' : 'Designation'} value={row.designation || ''} onChange={e=>updateProfessionRecord(i,{designation:e.target.value})}/>
                  <input className="rounded-lg border p-2 text-xs" type="number" placeholder={isBn ? 'শুরুর সন' : 'Start year'} value={row.startDate?.year ?? ''} onChange={e=>updateProfessionRecord(i,{startDate:e.target.value ? {year:Number(e.target.value),precision:'approximate'} : undefined})}/>
                  <input className="rounded-lg border p-2 text-xs" type="number" placeholder={isBn ? 'শেষের সন' : 'End year'} value={row.endDate?.year ?? ''} onChange={e=>updateProfessionRecord(i,{endDate:e.target.value ? {year:Number(e.target.value),precision:'approximate'} : undefined})}/>
                  <div className="flex gap-2"><input className="min-w-0 flex-1 rounded-lg border p-2 text-xs" placeholder={isBn ? 'নোট' : 'Notes'} value={row.notes || ''} onChange={e=>updateProfessionRecord(i,{notes:e.target.value})}/><button type="button" onClick={()=>removeProfessionRecord(i)} className="rounded-lg border border-red-200 px-2 text-red-600">×</button></div>
                </div>)}
              </div>

              <div className="rounded-2xl border border-amber-200 bg-amber-50/40 p-4 dark:border-amber-900/40 dark:bg-amber-950/20 space-y-3">
                <div className="flex items-center justify-between gap-2"><div><h5 className="text-xs font-bold">{isBn ? 'বসবাসের ইতিহাস' : 'Residence History'}</h5><p className="text-[10px] text-stone-500">{isBn ? 'জন্মস্থান, শৈশব, আগের ঠিকানা, বর্তমান/স্থায়ী বা বিদেশে বসবাস আলাদা করে রাখুন।' : 'Keep birthplace, childhood, previous, current/permanent and overseas residence records.'}</p></div><button type="button" onClick={addResidenceRecord} className="rounded-lg bg-amber-700 px-3 py-1.5 text-[10px] font-bold text-white">+ {isBn ? 'ঠিকানা ইতিহাস যোগ' : 'Add Residence'}</button></div>
                {residenceHistory.map((row, i) => <div key={row.id} className="grid grid-cols-1 sm:grid-cols-2 gap-2 rounded-xl border border-amber-100 bg-white/80 p-3 dark:border-amber-900/40 dark:bg-stone-900/60">
                  <select className="rounded-lg border p-2 text-xs" value={row.label} onChange={e=>updateResidenceRecord(i,{label:e.target.value as ResidenceRecord['label']})}><option value="birthplace">{isBn?'জন্মস্থান':'Birthplace'}</option><option value="childhood">{isBn?'শৈশব':'Childhood'}</option><option value="current">{isBn?'বর্তমান':'Current'}</option><option value="permanent">{isBn?'স্থায়ী':'Permanent'}</option><option value="previous">{isBn?'পূর্বের':'Previous'}</option><option value="abroad">{isBn?'বিদেশ':'Abroad'}</option><option value="other">{isBn?'অন্যান্য':'Other'}</option></select>
                  <div className="flex gap-2"><input className="min-w-0 flex-1 rounded-lg border p-2 text-xs" placeholder={isBn ? 'পূর্ণ ঠিকানা/স্থান' : 'Full address / place'} value={row.address?.fullAddress || ''} onChange={e=>updateResidenceRecord(i,{address:{...row.address,fullAddress:e.target.value}})}/><button type="button" onClick={()=>removeResidenceRecord(i)} className="rounded-lg border border-red-200 px-2 text-red-600">×</button></div>
                  <input className="rounded-lg border p-2 text-xs sm:col-span-2" placeholder={isBn ? 'সময়কাল/নোট' : 'Period / notes'} value={row.notes || ''} onChange={e=>updateResidenceRecord(i,{notes:e.target.value})}/>
                </div>)}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <textarea value={familyOriginStory} onChange={e=>setFamilyOriginStory(e.target.value)} placeholder={isBn?'পারিবারিক উৎস/বংশের ইতিহাস':'Family origin story'} className="w-full rounded-xl border p-3 text-xs dark:bg-stone-800" rows={3}/>
                <textarea value={memorialStory} onChange={e=>setMemorialStory(e.target.value)} placeholder={isBn?'স্মৃতিচারণ/স্মরণীয় তথ্য':'Memorial story / memories'} className="w-full rounded-xl border p-3 text-xs dark:bg-stone-800" rows={3}/>
                <textarea value={memberNotes} onChange={e=>setMemberNotes(e.target.value)} placeholder={isBn?'অতিরিক্ত ব্যক্তিগত/গবেষণা নোট':'Additional notes'} className="w-full rounded-xl border p-3 text-xs dark:bg-stone-800" rows={3}/>
                <input value={tags} onChange={e=>setTags(e.target.value)} placeholder={isBn?'ট্যাগ (কমা দিয়ে): যেমন মুক্তিযোদ্ধা, শিক্ষক':'Tags, comma separated'} className="w-full rounded-xl border p-3 text-xs dark:bg-stone-800"/>
              </div>
            </div>

            <div><h4 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'সদস্যের প্রোফাইল ছবি' : 'Member Profile Photo'}</h4><p className="text-[11px] text-stone-500">{isBn ? 'ক্যামেরায় লাইভ ছবি তুলুন অথবা ফাইল থেকে ছবি নির্বাচন করুন।' : 'Capture a live photo or choose an image file.'}</p></div>
              <button type="button" onClick={()=>setIsPhotoModalOpen(true)} className="rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white">{isBn ? 'ছবি তুলুন / নির্বাচন করুন' : 'Capture / Choose Photo'}</button>
            </div>
            {profilePhoto && <div className="flex items-center gap-3 rounded-2xl border p-3 dark:border-stone-700"><img src={profilePhoto} alt="Profile preview" className="h-20 w-20 rounded-2xl object-cover border"/><div className="text-xs"><div className="font-bold">{isBn?'বর্তমান নির্বাচিত ছবি':'Selected photo'}</div><button type="button" onClick={()=>setProfilePhoto('')} className="mt-1 text-rose-600 font-bold">{isBn?'ছবি সরান':'Remove photo'}</button></div></div>}
          </div>

          {/* MEMBER DOCUMENTS */}
          <div id="sec-member-documents" className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between gap-3">
              <div><h4 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'সদস্যের ছবি ও বিভিন্ন ডকুমেন্ট' : 'Member Photos & Documents'}</h4><p className="text-[11px] text-stone-500">{isBn ? 'জন্মসনদ, NID, Passport, বিবাহ/মৃত্যু সনদ, ছবি বা অন্য যেকোনো ফাইল যোগ করুন।' : 'Add birth certificate, NID, passport, marriage/death certificate, photos or other files.'}</p></div>
              <label className="cursor-pointer rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white">+ {isBn ? 'ডকুমেন্ট যোগ করুন' : 'Add Document'}<input type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" className="hidden" onChange={handleMemberDocumentUpload}/></label>
            </div>
            {memberDocuments.length > 0 && <div className="grid grid-cols-1 gap-3">{memberDocuments.map(doc => {
              const candidates = buildExtractedFieldCandidates(doc.extractedFields || { documentKind: 'general', confidence: 0 });
              const selected = selectedOcrFieldsByDoc[doc.id] || [];
              const writable = candidates.filter(c => c.profileWritable !== false);
              return <div key={doc.id} className="rounded-2xl border p-3 text-xs dark:border-stone-700">
                <div className="flex items-start justify-between gap-2"><div className="min-w-0"><div className="font-semibold truncate">{doc.title}</div><div className="text-[10px] text-stone-500">{doc.fileName}</div></div><button type="button" onClick={()=>removeMemberDocument(doc.id)} className="text-rose-600 font-bold shrink-0">{isBn?'মুছুন':'Remove'}</button></div>
                {doc.ocrConfidence ? <div className="mt-1 text-[10px] text-emerald-700 dark:text-emerald-300">OCR {doc.ocrConfidence}% · {isBn?'তথ্য যাচাইয়ের জন্য প্রস্তুত':'Ready for review'}</div> : null}
                {candidates.length > 0 ? <div className="mt-3 rounded-xl bg-stone-50 dark:bg-stone-950/40 p-3">
                  <div className="flex items-center justify-between gap-2 mb-2"><div className="font-bold text-stone-700 dark:text-stone-200">{isBn?'ডকুমেন্ট থেকে পাওয়া তথ্য':'Information found in document'}</div><button type="button" onClick={()=>setSelectedOcrFieldsByDoc(v=>({...v,[doc.id]:writable.map(c=>c.key)}))} className="text-[10px] text-amber-700 font-bold">{isBn?'সব নির্বাচন':'Select writable'}</button></div>
                  <div className="space-y-1.5">{candidates.map(c=><label key={c.key} className={`flex items-start gap-2 rounded-lg border p-2 ${c.profileWritable===false?'opacity-60':''}`}><input type="checkbox" disabled={c.profileWritable===false} checked={selected.includes(c.key)} onChange={()=>setSelectedOcrFieldsByDoc(v=>({...v,[doc.id]:(v[doc.id]||[]).includes(c.key)?(v[doc.id]||[]).filter(k=>k!==c.key):[...(v[doc.id]||[]),c.key]}))}/><span className="min-w-0"><b>{isBn?c.labelBn:c.labelEn}:</b> {c.value} <span className="text-[9px] text-stone-400">({c.confidence}%)</span>{c.profileWritable===false && <span className="ml-1 text-[9px]">{isBn?'(প্রোফাইলে সরাসরি নয়)':'(evidence only)'}</span>}</span></label>)}</div>
                  <button type="button" disabled={!selected.length} onClick={()=>applyOcrFieldsToProfile(doc)} className="mt-3 rounded-xl bg-emerald-700 text-white px-4 py-2 text-xs font-bold disabled:opacity-40">{isBn?'নির্বাচিত তথ্য প্রোফাইলে নিন':'Apply Selected to Profile'}</button>
                  <p className="mt-2 text-[10px] text-stone-500">{isBn?'OCR কোনো তথ্য নিজে থেকে প্রোফাইলে লিখবে না। আপনি যেগুলো নির্বাচন করবেন শুধু সেগুলো ফর্মে যাবে; তারপর সংরক্ষণ করতে হবে।':'OCR never silently writes to the profile. Only selected fields are placed into the form; you must review and save.'}</p>
                </div> : doc.note ? <div className="mt-2 text-[10px] text-amber-700 dark:text-amber-300">{doc.note}</div> : null}
              </div>;
            })}</div>}

          </div>

          {/* SECTION 6: BIOGRAPHY & MEMORY NOTES */}
          <div id="sec-bio" className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center font-bold text-sm">
                ৬
              </div>
              <div>
                <h4 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">
                  {isBn ? 'জীবনবৃত্তান্ত ও ঐতিহাসিক স্মৃতিচারণ' : 'Biography & Heritage Notes'}
                </h4>
                <p className="text-[11px] text-stone-500">
                  {isBn ? 'ব্যক্তিগত চরিত্র, শিক্ষা, কর্মজীবন ও পারিবারিক অবদান' : 'Personal character, education, career, and community contributions'}
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold block mb-1 text-stone-700 dark:text-stone-300">
                  {isBn ? 'সংক্ষিপ্ত জীবনী ও পরিচয়:' : 'Biography Summary:'}
                </label>
                <textarea
                  rows={4}
                  placeholder={isBn ? 'সদস্যের শিক্ষা, পেশা, উল্লেখযোগ্য অবদান বা স্মৃতি...' : 'Biography details...'}
                  value={biography}
                  onChange={e => setBiography(e.target.value)}
                  className="w-full rounded-2xl border border-stone-300 bg-white p-3 text-sm text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold block mb-1 text-stone-700 dark:text-stone-300">
                  {isBn ? 'গোপনীয় বা গুরুত্বপূর্ণ পারিবারিক তথ্য (ঐচ্ছিক):' : 'Important Heritage Notes:'}
                </label>
                <textarea
                  rows={2}
                  placeholder={isBn ? 'দলিল রেফারেন্স, খতিয়ান বা উত্তরাধিকার সংক্রান্ত বিশেষ তথ্য...' : 'Reference notes...'}
                  value={importantInfo}
                  onChange={e => setImportantInfo(e.target.value)}
                  className="w-full rounded-2xl border border-stone-300 bg-white p-3 text-xs text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Sticky Bottom Actions Bar */}
          <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex flex-col-reverse sm:flex-row sm:items-center justify-between gap-3 sticky bottom-0 bg-white/95 dark:bg-stone-900/95 py-3">
            <div>
              {isEditing && memberToEdit && (
                <button
                  type="button"
                  onClick={() => setIsDeleteDialogOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 font-bold text-xs transition dark:border-rose-900/40 dark:bg-rose-950/40 dark:text-rose-300"
                >
                  <Trash2 className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                  <span>{isBn ? 'এই সদস্যকে মুছুন' : 'Delete Member'}</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-3 justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 font-bold text-xs hover:bg-stone-100 dark:hover:bg-stone-800 transition"
              >
                {isBn ? 'বাতিল করুন' : 'Cancel'}
              </button>
              <button
                type="submit" disabled={isSaving}
                className="px-8 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>{isEditing ? (isBn ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save Changes') : (isBn ? 'নতুন সদস্য সংরক্ষণ করুন' : 'Save Member')}</span>
              </button>
            </div>
          </div>

        </form>

      </div>

      {/* In-UI Deletion Confirmation Modal */}
      {isDeleteDialogOpen && memberToEdit && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">
                  {isBn ? 'সদস্য স্থায়ীভাবে মুছে ফেলবেন?' : 'Delete Member Record?'}
                </h3>
                <p className="text-xs text-stone-500">
                  {memberToEdit.banglaName || memberToEdit.fullName}
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed bg-stone-50 dark:bg-stone-800/50 p-3.5 rounded-2xl border border-stone-200 dark:border-stone-700">
              {isBn
                ? 'ভুলে সংরক্ষিত এই সদস্যের রেকর্ড মুছে ফেলা হবে। পিতা-মাতা, সন্তান ও বৈবাহিক সম্পর্ক থেকে এই সদস্যকে নিরাপদে বিচ্ছিন্ন করা হবে।'
                : 'This member record will be permanently deleted and cleanly unlinked from parents, children, and marriages.'}
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsDeleteDialogOpen(false)}
                className="px-4 py-2 text-xs font-semibold rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={async () => {
                  await deleteMember(memberToEdit.id);
                  setIsDeleteDialogOpen(false);
                  onClose();
                }}
                className="px-4 py-2 text-xs font-bold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-sm flex items-center gap-1.5 transition"
              >
                <Trash2 className="h-4 w-4" />
                <span>{isBn ? 'হ্যাঁ, স্থায়ীভাবে মুছুন' : 'Yes, Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <AvatarUploadModal
        isOpen={isPhotoModalOpen}
        onClose={() => setIsPhotoModalOpen(false)}
        onSaveAvatar={(avatarDataUrl) => { setProfilePhoto(avatarDataUrl); setIsPhotoModalOpen(false); }}
        currentAvatar={profilePhoto}
        memberName={banglaName || englishName || (isBn ? 'সদস্য' : 'Member')}
        isBn={isBn}
      />
    </div>
  );
};
