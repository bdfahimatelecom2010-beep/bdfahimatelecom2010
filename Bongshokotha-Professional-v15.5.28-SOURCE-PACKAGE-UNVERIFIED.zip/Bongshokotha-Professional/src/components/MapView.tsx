/**
 * Family map: shows only user-selected address text in an external map search.
 * It does not geocode or store precise coordinates, and never publishes the full tree.
 */
import React, { useMemo, useState } from 'react';
import { MapPinned, ExternalLink, ShieldCheck, Search } from 'lucide-react';
import { useGenealogy } from '../context/GenealogyContext';

const addressText = (address: any): string => {
  if (!address) return '';
  if (address.fullAddress) return String(address.fullAddress);
  return [address.holding, address.road, address.village, address.ward, address.union, address.postOffice, address.postalCode, address.upazila, address.district, address.division, address.country]
    .filter(Boolean).join(', ');
};

export const MapView: React.FC = () => {
  const { members, family, language } = useGenealogy();
  const isBn = language === 'bn';
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState('');
  const locations = useMemo(() => members.map(member => ({
    id: member.id,
    name: member.banglaName || member.fullName || member.englishName,
    address: addressText(member.currentAddress) || addressText(member.permanentAddress) || addressText(member.birth?.place as any)
  })).filter(item => item.address), [members]);
  const districtCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const member of members) {
      const current = member.currentAddress as any;
      const permanent = member.permanentAddress as any;
      const district = String(current?.district || permanent?.district || '').trim();
      if (district) counts.set(district, (counts.get(district) || 0) + 1);
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'bn'));
  }, [members]);
  const filtered = locations.filter(item => `${item.name} ${item.address}`.toLowerCase().includes(query.toLowerCase()));
  const selected = locations.find(item => item.id === selectedId) || filtered[0];
  const mapUrl = selected ? `https://www.google.com/maps?q=${encodeURIComponent(selected.address)}&output=embed` : '';
  const externalUrl = selected ? `https://www.openstreetmap.org/search?query=${encodeURIComponent(selected.address)}` : '';

  return <section className="mx-auto max-w-6xl space-y-5">
    <header className="rounded-2xl bg-gradient-to-br from-sky-700 to-indigo-900 p-5 text-white shadow-lg sm:p-7">
      <div className="flex items-center gap-3"><MapPinned className="h-8 w-8"/><div><h2 className="text-2xl font-bold">{isBn ? 'পারিবারিক মানচিত্র' : 'Family Map'}</h2><p className="text-sm text-sky-100">{isBn ? `${family.banglaName || family.name} — সংরক্ষিত ঠিকানা থেকে মানচিত্রে খুঁজুন` : `${family.name} — search maps from saved addresses`}</p></div></div>
    </header>
    <section className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-700 dark:bg-stone-900">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h3 className="text-lg font-bold">{isBn ? 'জেলাভিত্তিক বংশের সদস্যসংখ্যা' : 'Family members by district'}</h3><span className="text-xs text-stone-500">{isBn ? 'সংরক্ষিত বর্তমান ঠিকানা; না থাকলে স্থায়ী ঠিকানা' : 'Saved current address; permanent address as fallback'}</span></div>
      {districtCounts.length ? <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{districtCounts.map(([district, count]) => <div key={district} className="rounded-xl border border-sky-100 bg-sky-50 p-3 dark:border-sky-900 dark:bg-sky-950/30"><div className="flex items-center justify-between gap-2"><span className="font-semibold">{district}</span><strong className="rounded-lg bg-white px-2 py-1 text-sky-800 dark:bg-slate-900 dark:text-sky-200">{count.toLocaleString(isBn ? 'bn-BD' : 'en-US')}</strong></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-sky-100 dark:bg-sky-900"><div className="h-full rounded-full bg-sky-600" style={{ width: `${Math.max(4, count / Math.max(...districtCounts.map(([, n]) => n)) * 100)}%` }} /></div><p className="mt-1 text-xs text-stone-500">{isBn ? 'জন সদস্য' : 'members'}</p></div>)}</div> : <p className="text-sm text-stone-500">{isBn ? 'জেলাভিত্তিক হিসাব দেখাতে সদস্যদের ঠিকানায় জেলা নির্বাচন করে সংরক্ষণ করুন।' : 'Save a district in member addresses to show district totals.'}</p>}
    </section>
    <div className="grid gap-4 lg:grid-cols-[minmax(260px,0.85fr)_minmax(0,1.6fr)]">
      <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-700 dark:bg-stone-900">
        <label className="mb-3 block text-sm font-semibold">{isBn ? 'সদস্য বা ঠিকানা খুঁজুন' : 'Search member or address'}
          <span className="mt-2 flex items-center gap-2 rounded-xl border border-stone-300 px-3 dark:border-stone-600"><Search size={16}/><input className="w-full bg-transparent py-2.5 outline-none" value={query} onChange={e => setQuery(e.target.value)} placeholder={isBn ? 'নাম, গ্রাম, উপজেলা, জেলা…' : 'Name, village, upazila, district…'}/></span>
        </label>
        <div className="max-h-[420px] space-y-2 overflow-auto">{filtered.map(item => <button type="button" key={item.id} onClick={() => setSelectedId(item.id)} className={`w-full rounded-xl border p-3 text-left ${selected?.id === item.id ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/30' : 'border-stone-200 dark:border-stone-700'}`}><span className="block font-semibold">{item.name}</span><span className="mt-1 block text-xs text-stone-500">{item.address}</span></button>)}{filtered.length === 0 && <p className="p-4 text-sm text-stone-500">{isBn ? 'সংরক্ষিত ঠিকানা পাওয়া যায়নি। সদস্যের প্রোফাইলে ঠিকানা যোগ করুন।' : 'No saved address found. Add an address to a member profile.'}</p>}</div>
      </div>
      <div className="overflow-hidden rounded-2xl border border-stone-200 bg-white dark:border-stone-700 dark:bg-stone-900">
        {selected ? <><div className="flex flex-wrap items-start justify-between gap-3 border-b border-stone-200 p-4 dark:border-stone-700"><div><h3 className="font-bold">{selected.name}</h3><p className="mt-1 text-sm text-stone-500">{selected.address}</p></div><a className="inline-flex items-center gap-2 rounded-lg bg-sky-700 px-3 py-2 text-sm font-semibold text-white" href={externalUrl} target="_blank" rel="noopener noreferrer">{isBn ? 'OpenStreetMap খুলুন' : 'Open OpenStreetMap'} <ExternalLink size={15}/></a></div><iframe title={isBn ? 'নির্বাচিত ঠিকানার মানচিত্র' : 'Map of selected address'} src={mapUrl} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-[420px] w-full border-0"/><div className="p-3 text-xs text-stone-500">{isBn ? 'মানচিত্রে ফলাফল ঠিকানার লেখার ওপর নির্ভরশীল; এটি GPS-নির্ভুল অবস্থান নয়।' : 'Map results depend on the saved address text; this is not a GPS-verified location.'}</div></> : <div className="flex h-[420px] flex-col items-center justify-center gap-3 p-6 text-center text-stone-500"><MapPinned size={36}/><p>{isBn ? 'মানচিত্র দেখতে ঠিকানাযুক্ত একজন সদস্য নির্বাচন করুন।' : 'Select a member with an address to view a map.'}</p></div>}
      </div>
    </div>
    <div className="flex gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100"><ShieldCheck className="mt-0.5 shrink-0"/><p>{isBn ? 'গোপনীয়তা: ঠিকানা বহিরাগত মানচিত্র সেবায় পাঠানো হয় শুধু এই পেজে সদস্য নির্বাচন করে মানচিত্র দেখালে। ব্যক্তিগত ঠিকানা শেয়ার করার অনুমতি আছে কি না নিশ্চিত করুন।' : 'Privacy: an address is sent to the external map provider only when you select a member here. Confirm you are allowed to use that address with the provider.'}</p></div>
  </section>;
};
