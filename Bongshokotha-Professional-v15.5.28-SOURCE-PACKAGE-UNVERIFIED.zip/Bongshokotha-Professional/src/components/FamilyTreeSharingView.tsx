/**
 * Family sharing tools. Safe share packages are opt-in and omit contact details,
 * identity documents, archive records, notes and photos by default.
 */
import React, { useMemo, useState } from 'react';
import { Share2, Copy, Check, ShieldCheck, FileDown, Printer, Users, Link2 } from 'lucide-react';
import { useGenealogy } from '../context/GenealogyContext';

export const FamilyTreeSharingView: React.FC = () => {
  const { family, members, marriages, archiveRecords, language, checkPermission } = useGenealogy();
  const isBn = language === 'bn';
  const [customText, setCustomText] = useState('');
  const [notice, setNotice] = useState('');
  const [copied, setCopied] = useState(false);
  const [scope, setScope] = useState<'summary' | 'branch' | 'selected' | 'all-safe'>('summary');
  const [branchId, setBranchId] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [includeBirthYear, setIncludeBirthYear] = useState(true);
  const [includeRelationships, setIncludeRelationships] = useState(true);
  const title = family.banglaName || family.name || (isBn ? 'আমাদের পরিবার' : 'Our Family');
  const branchOptions = useMemo(() => family.branches || [], [family.branches]);
  const eligibleMembers = useMemo(() => {
    if (scope === 'branch') return members.filter(m => branchId && m.branchId === branchId);
    if (scope === 'selected') return members.filter(m => selectedIds.includes(m.id));
    return members;
  }, [members, scope, branchId, selectedIds]);
  const shareText = useMemo(() => {
    const intro = customText.trim() || (isBn
      ? `${title} — আমাদের বংশের ইতিহাস ও পারিবারিক ঐতিহ্য সংরক্ষণের উদ্যোগ।`
      : `${title} — preserving our family history and heritage.`);
    return `${intro}\n${isBn ? 'নথিভুক্ত সদস্য' : 'Recorded members'}: ${scope === 'summary' ? members.length : eligibleMembers.length}`;
  }, [title, customText, members.length, eligibleMembers.length, scope, isBn]);

  const copyText = async () => {
    try { await navigator.clipboard.writeText(shareText); setCopied(true); setNotice(isBn ? 'শেয়ার করার লেখা কপি হয়েছে।' : 'Share text copied.'); }
    catch { setNotice(isBn ? 'কপি করা যায়নি—লেখা নির্বাচন করে কপি করুন।' : 'Clipboard unavailable. Select and copy manually.'); }
  };
  const shareNative = async () => {
    if (!navigator.share) { setNotice(isBn ? 'এই ডিভাইসে Share Sheet নেই; লেখা কপি করে পাঠান।' : 'Native sharing is unavailable; copy the text and send it manually.'); return; }
    try { await navigator.share({ title, text: shareText }); setNotice(isBn ? 'ডিভাইসের Share মেনু খোলা হয়েছে।' : 'Device share sheet opened.'); }
    catch (error) { if ((error as DOMException)?.name !== 'AbortError') setNotice(isBn ? 'শেয়ার করা যায়নি।' : 'Sharing failed.'); }
  };
  const makeSafePackage = () => {
    if (scope === 'summary') { setNotice(isBn ? 'ফাইল তৈরির আগে সদস্য, শাখা অথবা নির্বাচিত সদস্য বেছে নিন।' : 'Choose a branch or selected members before creating a package.'); return; }
    if (!eligibleMembers.length) { setNotice(isBn ? 'শেয়ার করার জন্য কোনো সদস্য নির্বাচিত হয়নি।' : 'No members selected for sharing.'); return; }
    const ids = new Set(eligibleMembers.map(m => m.id));
    const safeMembers = eligibleMembers.map(m => ({
      id: m.id,
      banglaName: m.banglaName,
      englishName: m.englishName,
      fullName: m.fullName,
      gender: m.gender,
      isLiving: m.isLiving,
      maritalStatus: m.maritalStatus,
      generation: m.computedGeneration ?? m.generationOverride ?? null,
      branchId: m.branchId,
      ...(includeBirthYear ? { birthYear: m.birth?.date?.year ?? null, deathYear: m.death?.date?.year ?? null } : {}),
      ...(includeRelationships ? { fatherId: m.fatherId && ids.has(m.fatherId) ? m.fatherId : undefined, motherId: m.motherId && ids.has(m.motherId) ? m.motherId : undefined } : {})
    }));
    const safeMarriages = includeRelationships ? marriages.filter(m => {
      const a = String((m as any).partner1Id || (m as any).spouse1Id || (m as any).person1Id || '');
      const b = String((m as any).partner2Id || (m as any).spouse2Id || (m as any).person2Id || '');
      return ids.has(a) && ids.has(b);
    }) : [];
    const payload = { format: 'BONGSHOKOTHA_SAFE_SHARE', version: '1.1', exportedAt: new Date().toISOString(), scope, family: { name: family.name, banglaName: family.banglaName }, branches: branchOptions.filter(b => new Set(eligibleMembers.map(m => m.branchId)).has(b.id)).map(b => ({ id: b.id, name: b.name, banglaName: b.banglaName })), members: safeMembers, marriages: safeMarriages, privacy: { contactDetails: false, identityDocuments: false, memberDocuments: false, archiveRecords: false, notesAndBiographies: false, profilePhotos: false } };
    const confirmed = window.confirm(isBn ? `নির্বাচিত ${safeMembers.length} জন সদস্যের সীমিত তথ্য ফাইলে থাকবে। ফোন, ইমেইল, NID, দলিল, ছবি, নোট ও আর্কাইভ থাকবে না। ফাইল তৈরি করবেন?` : `The file will contain limited information for ${safeMembers.length} selected members. It excludes contact details, NID, documents, photos, notes and archive records. Create it?`);
    if (!confirmed) return;
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = `Bongshokotha_${title.replace(/[^\p{L}\p{N}_-]+/gu, '_')}_SafeShare.json`; document.body.appendChild(link); link.click(); link.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    setNotice(isBn ? 'সীমিত তথ্যের শেয়ার ফাইল তৈরি হয়েছে। পাঠানোর আগে ফাইল যাচাই করুন।' : 'Safe share package created. Review it before sending.');
  };
  const exportFullPackage = () => {
    if (!checkPermission('canExportFullData')) { setNotice(isBn ? 'পূর্ণ বংশতথ্য রপ্তানির অনুমতি নেই।' : 'You do not have permission to export full family data.'); return; }
    const confirmed = window.confirm(isBn ? 'পূর্ণ ফাইলে ব্যক্তিগত তথ্য, বিবাহ, সম্পর্ক ও আর্কাইভ থাকতে পারে। প্রাপক এগুলো দেখতে পারবেন। নিশ্চিত?' : 'A full package may contain personal information, relationships, marriages and archive records. The recipient may see them. Continue?');
    if (!confirmed) return;
    const payload = { format: 'BONGSHOKOTHA_SHARE_PACKAGE', version: '1.1', exportedAt: new Date().toISOString(), family, members, marriages, archiveRecords };
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })); const link = document.createElement('a'); link.href = url; link.download = `Bongshokotha_${title.replace(/[^\p{L}\p{N}_-]+/gu, '_')}_FULL_PRIVATE.json`; document.body.appendChild(link); link.click(); link.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    setNotice(isBn ? 'পূর্ণ বংশতথ্যের ফাইল তৈরি হয়েছে—এটি ব্যক্তিগত তথ্যযুক্ত ফাইল।' : 'Full family package created; treat this file as sensitive.');
  };
  const exportFamilyTreePackage = exportFullPackage;
  const toggleMember = (id: string) => setSelectedIds(old => old.includes(id) ? old.filter(x => x !== id) : [...old, id]);

  return <section className="space-y-5 max-w-5xl mx-auto print:max-w-none">
    <header className="rounded-2xl p-5 sm:p-7 bg-gradient-to-br from-emerald-700 to-teal-900 text-white shadow-lg print:hidden"><div className="flex items-center gap-3"><Share2 className="w-8 h-8"/><div><h2 className="text-2xl font-bold">{isBn ? 'বংশতালিকা শেয়ার' : 'Share Family Tree'}</h2><p className="text-sm text-emerald-100">{isBn ? 'পরিচিতি, নির্বাচিত শাখা অথবা সীমিত সদস্য-তথ্য শেয়ার করুন' : 'Share an introduction, selected branch or limited member data'}</p></div></div></header>
    <div className="rounded-2xl border p-4 sm:p-6 space-y-4 bg-white dark:bg-stone-900 print:hidden">
      <label className="block font-semibold">{isBn ? 'শেয়ার করার লেখা' : 'Share text'}<textarea value={customText} onChange={e => setCustomText(e.target.value)} rows={3} maxLength={1200} placeholder={isBn ? 'পরিবারের সংক্ষিপ্ত পরিচিতি লিখুন…' : 'Write a short family introduction…'} className="mt-2 w-full rounded-xl border bg-transparent p-3 text-sm" /></label>
      <div className="rounded-xl bg-stone-50 dark:bg-stone-800 p-3 text-sm whitespace-pre-wrap break-words">{shareText}</div>
      <div className="flex flex-wrap gap-2"><button onClick={shareNative} className="rounded-xl bg-emerald-700 text-white px-4 py-2.5 font-semibold"><Share2 className="inline w-4 h-4 mr-2"/>{isBn ? 'ফোনের Share মেনু' : 'Device Share'}</button><button onClick={copyText} className="rounded-xl border px-4 py-2.5 font-semibold flex items-center gap-2">{copied ? <Check size={16}/> : <Copy size={16}/>} {isBn ? 'লেখা কপি' : 'Copy text'}</button><button onClick={() => window.print()} className="rounded-xl border px-4 py-2.5 font-semibold"><Printer className="inline w-4 h-4 mr-2"/>{isBn ? 'প্রিন্ট / PDF' : 'Print / PDF'}</button></div>
    </div>
    <div className="rounded-2xl border p-4 sm:p-6 space-y-4 bg-white dark:bg-stone-900 print:hidden">
      <h3 className="text-lg font-bold flex items-center gap-2"><Users className="w-5 h-5"/>{isBn ? 'নির্বাচিত তথ্যের শেয়ার ফাইল' : 'Selective data share package'}</h3>
      <p className="text-sm text-stone-600 dark:text-stone-300">{isBn ? 'ডিফল্টভাবে ফোন, ইমেইল, NID, দলিল, ছবি, নোট ও আর্কাইভ বাদ থাকবে।' : 'Contact details, identity numbers, documents, photos, notes and archive records are excluded by default.'}</p>
      <div className="grid sm:grid-cols-2 gap-3"><label className="text-sm font-medium">{isBn ? 'কোন তথ্য শেয়ার করবেন' : 'Share scope'}<select value={scope} onChange={e => setScope(e.target.value as typeof scope)} className="mt-1 w-full rounded-xl border bg-transparent p-2.5"><option value="summary">{isBn ? 'শুধু পরিচিতি (ফাইল নয়)' : 'Introduction only (no file)'}</option><option value="branch">{isBn ? 'একটি শাখা' : 'One branch'}</option><option value="selected">{isBn ? 'নির্বাচিত সদস্য' : 'Selected members'}</option><option value="all-safe">{isBn ? 'সব সদস্যের সীমিত তথ্য' : 'Limited data for all members'}</option></select></label>
      {scope === 'branch' && <label className="text-sm font-medium">{isBn ? 'শাখা নির্বাচন' : 'Select branch'}<select value={branchId} onChange={e => setBranchId(e.target.value)} className="mt-1 w-full rounded-xl border bg-transparent p-2.5"><option value="">{isBn ? 'শাখা বেছে নিন' : 'Choose a branch'}</option>{branchOptions.map(b => <option key={b.id} value={b.id}>{b.banglaName || b.name}</option>)}</select></label>}</div>
      {scope === 'selected' && <div className="max-h-56 overflow-auto rounded-xl border p-3 space-y-2">{members.map(m => <label key={m.id} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={selectedIds.includes(m.id)} onChange={() => toggleMember(m.id)}/><span>{m.banglaName || m.fullName || m.englishName}</span><span className="ml-auto text-xs text-stone-500">{m.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'মৃত' : 'Deceased')}</span></label>)}</div>}
      <div className="flex flex-wrap gap-4 text-sm"><label className="flex gap-2 items-center"><input type="checkbox" checked={includeBirthYear} onChange={e => setIncludeBirthYear(e.target.checked)}/>{isBn ? 'জন্ম/মৃত্যুর সাল' : 'Birth/death year'}</label><label className="flex gap-2 items-center"><input type="checkbox" checked={includeRelationships} onChange={e => setIncludeRelationships(e.target.checked)}/>{isBn ? 'নির্বাচনের ভেতরে পিতা-মাতা/বিবাহ সম্পর্ক' : 'Parent/marriage links within selection'}</label></div>
      <div className="flex flex-wrap gap-2"><button onClick={makeSafePackage} disabled={scope === 'summary'} className="rounded-xl bg-amber-700 text-white px-4 py-2.5 font-semibold disabled:opacity-40"><FileDown className="inline w-4 h-4 mr-2"/>{isBn ? 'সীমিত তথ্যের ফাইল তৈরি' : 'Create safe package'}</button><button onClick={exportFullPackage} disabled={!checkPermission('canExportFullData')} className="rounded-xl border border-red-300 text-red-700 px-4 py-2.5 font-semibold disabled:opacity-40">{isBn ? 'অনুমতিসাপেক্ষ পূর্ণ ব্যক্তিগত ফাইল' : 'Authorized full private package'}</button></div>
      <p className="text-xs text-stone-500">{isBn ? 'এখানে পাবলিক ওয়েব লিংক তৈরি হয় না। দূরবর্তী আমন্ত্রণের জন্য Admin/Family Hub-এর সার্ভার-ভিত্তিক Invite ব্যবস্থাটি ব্যবহার করতে হবে; সার্ভার সংযোগ না থাকলে QR/Code স্থানীয় ডিভাইসেই সীমিত থাকতে পারে।' : 'This view does not create a public web link. Remote invites require the server-based Invite flow in Admin/Family Hub; without a configured server, local codes may only work on this device.'}</p>
    </div>
    <div className="rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 p-4 flex gap-3 text-sm"><ShieldCheck className="shrink-0 mt-0.5"/><p>{isBn ? 'গোপনীয়তা: নিরাপদ শেয়ার ফাইলে পরিচয়পত্র, যোগাযোগের তথ্য, ছবি, নোট বা আর্কাইভ থাকে না। পূর্ণ ফাইল আলাদা অনুমতি ও নিশ্চিতকরণ ছাড়া তৈরি হবে না। প্রাপকের পরিচয় যাচাই করুন।' : 'Privacy: safe packages exclude identity documents, contact details, photos, notes and archive records. Full packages require permission and confirmation. Verify the recipient.'}</p></div>
    {notice && <p role="status" className="text-sm text-emerald-700 dark:text-emerald-300" aria-live="polite">{notice}</p>}
  </section>;
};
