/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Family Book Builder & Professional Archival Publisher
 */

import { getVisibleFamilyMembers } from '../engine/familyVisibility';
import React, { useState, useMemo } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { Member } from '../types/genealogy';
import { getCanonicalChildrenForMarriage } from '../engine/relationshipIntegrity';
import { getMemberColor } from '../engine/memberColor';
import { toBanglaDigits, formatGenealogyDate, calculateLifespan } from '../engine/banglaCalendar';
import {
  BookOpen,
  Printer,
  Settings2,
  CheckSquare,
  Layers,
  Award,
  TreeDeciduous,
  Calendar,
  Heart,
  FileText
} from 'lucide-react';

interface FamilyBookViewProps {
  onSelectMember?: (memberId: string) => void;
}

export const FamilyBookView: React.FC<FamilyBookViewProps> = ({ onSelectMember }) => {
  const {
    family,
    members,
    marriages,
    branches,
    generations,
    generationSummary,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const visibleMembers = useMemo(() => getVisibleFamilyMembers(members, marriages), [members, marriages]);

  // Configurable Book Options
  const [bookTitle, setBookTitle] = useState(
    isBn ? `${family.banglaName || family.name}: বংশলতিকা ও পারিবারিক ইতিবৃত্ত` : `${family.name}: Official Family Lineage & Heritage Book`
  );
  const [introText, setIntroText] = useState(
    isBn
      ? 'আমাদের পূর্বপুরুষদের গৌরবোজ্জ্বল ইতিহাস, ত্যাগ ও রক্তের ঐতিহ্য ভবিষ্যৎ প্রজন্মের নিকট অক্ষুণ্ণ রাখার প্রত্যয়ে বংশকথা সংরক্ষণাগার থেকে সঙ্কলিত।'
      : 'Dedicated to preserving our ancestral history, kinship alliances, and heritage for future generations.'
  );

  const [includeCover, setIncludeCover] = useState(true);
  const [includeStats, setIncludeStats] = useState(true);
  const [includeTree, setIncludeTree] = useState(true);
  const [includeBiographies, setIncludeBiographies] = useState(true);
  const [includeMarriages, setIncludeMarriages] = useState(true);
  const [selectedBranches, setSelectedBranches] = useState<string[]>(branches.map(b => b.id));
  const [maxGen, setMaxGen] = useState<number>(generationSummary.maxGeneration);

  const filteredMembers = useMemo(() => {
    return visibleMembers.filter(m => {
      if (!selectedBranches.includes(m.branchId)) return false;
      const gen = generations.get(m.id) || 1;
      if (gen > maxGen) return false;
      return true;
    });
  }, [visibleMembers, selectedBranches, maxGen, generations]);

  const memberMap = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);

  const generationDisplayMembers = useMemo(() => {
    return filteredMembers.slice().sort((a, b) => {
      const ga = generations.get(a.id) || 1;
      const gb = generations.get(b.id) || 1;
      if (ga !== gb) return ga - gb;
      const aJoined = a.birthOrigin === 'joined_by_marriage' || a.marriageOrigin === true;
      const bJoined = b.birthOrigin === 'joined_by_marriage' || b.marriageOrigin === true;
      if (aJoined !== bJoined) return aJoined ? -1 : 1;
      const ao = a.birthOrder ?? 999999;
      const bo = b.birthOrder ?? 999999;
      if (ao !== bo) return ao - bo;
      return (a.banglaName || a.fullName).localeCompare(b.banglaName || b.fullName, 'bn');
    });
  }, [filteredMembers, generations]);

  const handlePrint = () => {
    window.print();
  };

  const toggleBranch = (bId: string) => {
    setSelectedBranches(prev =>
      prev.includes(bId) ? prev.filter(id => id !== bId) : [...prev, bId]
    );
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Book Builder Controls (Hidden in Print) */}
      <div className="no-print rounded-2xl border border-amber-900/10 bg-white p-6 shadow-xs dark:border-stone-800 dark:bg-stone-900 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
          <div>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-amber-950 dark:text-amber-100 flex items-center gap-2">
              <BookOpen className="h-6 w-6 text-amber-800 dark:text-amber-400" />
              <span>{isBn ? 'বংশগ্রন্থ ও প্রকাশনা কেন্দ্র' : 'Family Book Builder & Publisher'}</span>
            </h2>
            <p className="text-xs text-stone-500">
              {isBn
                ? 'পারিবারিক বইয়ের অধ্যায় ও শাখা কাস্টমাইজ করুন এবং প্রকাশনা উপযোগী প্রিন্ট বা PDF তৈরি করুন।'
                : 'Configure chapters, lineage branches, and export archival book layouts.'}
            </p>
          </div>

          <button
            onClick={handlePrint}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber-800 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-md hover:bg-amber-900 transition dark:bg-amber-700"
          >
            <Printer className="h-4 w-4" />
            <span>{isBn ? 'বংশগ্রন্থ প্রিন্ট / PDF সংরক্ষণ' : 'Print / Export PDF'}</span>
          </button>
        </div>

        {/* Builder Settings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                {isBn ? 'গ্রন্থের শিরোনাম (Book Title):' : 'Book Title:'}
              </label>
              <input
                type="text"
                value={bookTitle}
                onChange={e => setBookTitle(e.target.value)}
                className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs sm:text-sm font-serif font-bold text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                {isBn ? 'গ্রন্থের ভূমিকা ও উৎসর্গ (Introduction / Dedication):' : 'Preamble / Dedication:'}
              </label>
              <textarea
                rows={3}
                value={introText}
                onChange={e => setIntroText(e.target.value)}
                className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
              />
            </div>
          </div>

          {/* Chapters & Branches toggles */}
          <div className="space-y-4">
            <div className="space-y-2">
              <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                {isBn ? 'অন্তর্ভুক্ত অধ্যায়সমূহ:' : 'Included Chapters:'}
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={includeCover} onChange={e => setIncludeCover(e.target.checked)} />
                  <span>{isBn ? 'মূল প্রচ্ছদ ও সীল' : 'Cover & Seal'}</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={includeStats} onChange={e => setIncludeStats(e.target.checked)} />
                  <span>{isBn ? 'বংশ পরিসংখ্যান সূচক' : 'Statistics & Index'}</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={includeTree} onChange={e => setIncludeTree(e.target.checked)} />
                  <span>{isBn ? 'বংশানুক্রমিক তালিকা' : 'Generational Tree'}</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={includeBiographies} onChange={e => setIncludeBiographies(e.target.checked)} />
                  <span>{isBn ? 'সদস্য ইতিবৃত্ত ও দলিল' : 'Biographies & Docs'}</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={includeMarriages} onChange={e => setIncludeMarriages(e.target.checked)} />
                  <span>{isBn ? 'বৈবাহিক সম্বন্ধ রেজিস্ট্রি' : 'Marriages Registry'}</span>
                </label>
              </div>
            </div>

            {/* Branches Selector */}
            <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-stone-800">
              <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                {isBn ? 'নির্বাচিত বংশ শাখা:' : 'Included Branches:'}
              </span>
              <div className="flex flex-wrap gap-2">
                {branches.map(b => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => toggleBranch(b.id)}
                    className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                      selectedBranches.includes(b.id)
                        ? 'bg-amber-800 text-white dark:bg-amber-700'
                        : 'bg-stone-100 text-stone-600 dark:bg-stone-800 dark:text-stone-400'
                    }`}
                  >
                    {isBn ? b.banglaName || b.name : b.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* BOOK PREVIEW / PRINT AREA */}
      <div className="mx-auto max-w-4xl space-y-12 bg-white p-8 sm:p-12 shadow-xl border border-amber-900/10 dark:bg-stone-900 print:shadow-none print:border-0 print:p-0">
        {/* CHAPTER 1: ARCHIVAL COVER PAGE */}
        {includeCover && (
          <div className="page-break-after flex min-h-[750px] flex-col items-center justify-between border-8 border-double border-amber-900/30 p-12 text-center">
            <div className="space-y-4 pt-12">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-amber-900 text-amber-100 shadow-xl">
                <TreeDeciduous className="h-12 w-12" />
              </div>
              <div className="text-xs font-bold uppercase tracking-widest text-amber-900">
                BONGSHOKOTHA • বংশকথা আর্কাইভ
              </div>
            </div>

            <div className="space-y-4 max-w-xl">
              <h1 className="font-serif text-3xl sm:text-4xl font-extrabold text-amber-950 dark:text-amber-100 leading-tight">
                {bookTitle}
              </h1>
              <div className="h-1 w-24 bg-amber-800 mx-auto rounded-full" />
              <p className="font-serif italic text-sm text-stone-700 dark:text-stone-300">
                {introText}
              </p>
            </div>

            <div className="space-y-1 pb-8 text-xs text-stone-500 font-serif">
              <div>{isBn ? 'পারিবারিক স্পেস: ' : 'Family Space: '} {family.name}</div>
              <div>{isBn ? 'সংরক্ষিত সদস্য সংখ্যা: ' : 'Total Registered Members: '} {toBanglaDigits(filteredMembers.length)}</div>
              <div>{new Date().toLocaleDateString(isBn ? 'bn-BD' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
            </div>
          </div>
        )}

        {/* CHAPTER 2: LINEAGE SUMMARY & STATISTICS */}
        {includeStats && (
          <div className="page-break-after space-y-6 pt-6">
            <div className="border-b-2 border-amber-900/20 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900">অধ্যায় ১</span>
              <h2 className="font-serif text-2xl font-bold text-amber-950 dark:text-amber-100">
                {isBn ? 'বংশ সংক্ষেপ ও প্রজন্ম বিন্যাস' : 'Lineage Summary & Generations'}
              </h2>
            </div>

            <div className="grid grid-cols-3 gap-4 text-center py-4 bg-amber-50/50 rounded-xl">
              <div>
                <div className="font-serif text-2xl font-bold text-amber-950">{toBanglaDigits(filteredMembers.length)}</div>
                <div className="text-xs text-stone-500">{isBn ? 'মোট সদস্য' : 'Members'}</div>
              </div>
              <div>
                <div className="font-serif text-2xl font-bold text-amber-950">{toBanglaDigits(maxGen)}</div>
                <div className="text-xs text-stone-500">{isBn ? 'প্রজন্মের বিস্তার' : 'Generations'}</div>
              </div>
              <div>
                <div className="font-serif text-2xl font-bold text-amber-950">{toBanglaDigits(marriages.length)}</div>
                <div className="text-xs text-stone-500">{isBn ? 'বৈবাহিক বন্ধন' : 'Marriages'}</div>
              </div>
            </div>

            <div className="space-y-3 pt-4">
              <h3 className="font-serif font-bold text-base text-stone-900">
                {isBn ? 'প্রজন্ম ভিত্তিক বিবরণ:' : 'Generational Breakdown:'}
              </h3>
              {Array.from({ length: maxGen }, (_, i) => i + 1).map(gen => {
                const count = filteredMembers.filter(m => (generations.get(m.id) || 1) === gen).length;
                return (
                  <div key={gen} className="flex items-center justify-between border-b border-stone-200 py-1.5 text-xs">
                    <span className="font-semibold">{isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Generation ${gen}`}</span>
                    <span className="font-mono text-stone-600">{toBanglaDigits(count)} {isBn ? 'জন সদস্য' : 'members'}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* CHAPTER 3: BIOGRAPHIES & DETAILED DOSSIERS */}
        {includeBiographies && (
          <div className="space-y-8 pt-6">
            <div className="border-b-2 border-amber-900/20 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900">অধ্যায় ২</span>
              <h2 className="font-serif text-2xl font-bold text-amber-950 dark:text-amber-100">
                {isBn ? 'বংশধরদের বিস্তারিত ইতিবৃত্ত ও তথ্যপঞ্জি' : 'Biographical Member Dossiers'}
              </h2>
            </div>

            <div className="space-y-6">
              {generationDisplayMembers.map((member, idx) => {
                const father = member.fatherId ? memberMap.get(member.fatherId) : null;
                const mother = member.motherId ? memberMap.get(member.motherId) : null;
                const memberMarriages = marriages.filter(m => m.husbandId === member.id || m.wifeId === member.id)
                  .sort((a, b) => Number(b.status === 'current') - Number(a.status === 'current') || String(b.updatedAt).localeCompare(String(a.updatedAt)));
                const headerSpouses = member.birthOrigin === 'born_in_family'
                  ? memberMarriages.map(m => memberMap.get(m.husbandId === member.id ? m.wifeId : m.husbandId)).filter(Boolean)
                  : [];
                const gen = generations.get(member.id) || 1;
                const lifespan = calculateLifespan(member.birth?.date, member.death?.date, member.isLiving, language);
                const memberColor = getMemberColor(member);

                return (
                  <div
                    key={member.id}
                    data-member-color={memberColor.key}
                    className="page-break-inside-avoid rounded-xl border p-5 space-y-3 print:border-stone-400"
                    style={{ borderColor: memberColor.border, backgroundColor: memberColor.soft }}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-mono text-[10px] font-bold text-amber-900 bg-amber-100 px-1.5 py-0.5 rounded-sm">
                          
                        </span>
                        <h3 className="font-serif font-bold text-lg text-amber-950 mt-1">
                          {isBn ? member.banglaName || member.fullName : member.englishName || member.fullName}
                          {member.nickname && <span className="text-xs font-normal text-stone-500 ml-2">({member.nickname})</span>}
                        </h3>
                        {headerSpouses.length > 0 && (
                          <div className="text-xs font-semibold text-rose-700 mt-1">
                            {isBn ? (member.gender === 'male' ? 'স্ত্রী: ' : member.gender === 'female' ? 'স্বামী: ' : 'সঙ্গী: ') : 'Spouse: '}
                            {headerSpouses.map((spouse:any) => isBn ? spouse.banglaName || spouse.fullName : spouse.englishName || spouse.fullName).join(' • ')}
                          </div>
                        )}
                        <p className="text-xs text-stone-500">
                          {isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Gen ${gen}`} • {lifespan} • {member.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-stone-700 pt-1">
                      <div>
                        <span className="font-semibold">{isBn ? 'পিতা: ' : 'Father: '}</span>
                        {father ? (isBn ? father.banglaName || father.fullName : father.englishName || father.fullName) : (isBn ? 'অজানা' : 'Unknown')}
                      </div>
                      <div>
                        <span className="font-semibold">{isBn ? 'মাতা: ' : 'Mother: '}</span>
                        {mother ? (isBn ? mother.banglaName || mother.fullName : mother.englishName || mother.fullName) : (isBn ? 'অজানা' : 'Unknown')}
                      </div>
                    </div>

                    {member.originalLineageNote && (
                      <div className="text-xs bg-stone-50 p-2 rounded-md italic text-stone-700">
                        <span className="font-semibold not-italic">{isBn ? 'জন্মসূত্রীয় বংশপরিচয়: ' : 'Biological Origin: '}</span>
                        {member.originalLineageNote}
                      </div>
                    )}

                    {member.biography && (
                      <p className="text-xs text-stone-700 leading-relaxed border-t border-stone-100 pt-2">
                        {member.biography}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* CHAPTER 4: MARRIAGES REGISTRY */}
        {includeMarriages && (
          <div className="space-y-6 pt-6">
            <div className="border-b-2 border-amber-900/20 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900">অধ্যায় ৩</span>
              <h2 className="font-serif text-2xl font-bold text-amber-950 dark:text-amber-100">
                {isBn ? 'পারিবারিক বৈবাহিক সংযোগ ও ইন-ল রেজিস্ট্রি' : 'Marriages & In-Law Alliances'}
              </h2>
            </div>

            <div className="space-y-4">
              {marriages.map(mar => {
                const husband = memberMap.get(mar.husbandId);
                const wife = memberMap.get(mar.wifeId);
                const children = getCanonicalChildrenForMarriage(mar, members);

                return (
                  <div key={mar.id} className="page-break-inside-avoid border border-stone-200 rounded-xl p-4 text-xs space-y-2">
                    <div className="flex justify-between font-serif font-bold text-sm">
                      <span>{husband ? (isBn ? husband.banglaName || husband.fullName : husband.englishName || husband.fullName) : mar.husbandId}</span>
                      <span className="text-rose-700 font-sans font-normal">♥</span>
                      <span>{wife ? (isBn ? wife.banglaName || wife.fullName : wife.englishName || wife.fullName) : mar.wifeId}</span>
                    </div>

                    <div className="text-[11px] text-stone-500">
                      {isBn ? 'তারিখ: ' : 'Date: '} {formatGenealogyDate(mar.marriageDate, language)}
                      {mar.marriagePlace?.district && ` • ${mar.marriagePlace.district}`}
                    </div>

                    {children.length > 0 && (
                      <div className="text-[11px] text-stone-700 pt-1">
                        <span className="font-semibold">{isBn ? 'এই বন্ধনের সন্তানবর্গ: ' : 'Children of this union: '}</span>
                        {children.map(c => c ? (isBn ? c.banglaName || c.fullName : c.englishName || c.fullName) : '').join(', ')}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
