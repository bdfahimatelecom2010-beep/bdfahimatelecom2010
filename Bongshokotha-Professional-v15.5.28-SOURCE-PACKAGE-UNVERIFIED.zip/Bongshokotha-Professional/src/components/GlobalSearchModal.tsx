/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Global Offline Fast Search & Member ID / QR Code Navigator
 */

import React, { useState, useMemo, useEffect } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { Member } from '../types/genealogy';
import { getMemberColor } from '../engine/memberColor';
import { toBanglaDigits } from '../engine/banglaCalendar';
import {
  Search,
  X,
  QrCode,
  Users,
  MapPin,
  Calendar,
  FileText,
  ShieldCheck,
  ArrowRight
} from 'lucide-react';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMember: (memberId: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectMember
}) => {
  const {
    members,
    marriages,
    branches,
    generations,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'name' | 'id' | 'location' | 'document'>('all');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const memberMap = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();

    return members.filter(m => {
      // Name & Nickname matches
      const nameMatch =
        m.fullName?.toLowerCase().includes(q) ||
        m.banglaName?.toLowerCase().includes(q) ||
        m.englishName?.toLowerCase().includes(q) ||
        m.nickname?.toLowerCase().includes(q) ||
        m.formerName?.toLowerCase().includes(q);

      // Stable ID & Serial matches
      const idMatch =
        m.id.toLowerCase().includes(q) ||
        false;

      // Identity document matches (NID, Birth Reg, Passport)
      const docMatch =
        m.identityDocs?.nidNumber?.includes(q) ||
        m.identityDocs?.birthRegistrationNumber?.includes(q) ||
        m.identityDocs?.passportNumber?.toLowerCase().includes(q);

      // Location matches
      const locMatch =
        m.birth?.place?.village?.toLowerCase().includes(q) ||
        m.birth?.place?.upazila?.toLowerCase().includes(q) ||
        m.birth?.place?.district?.toLowerCase().includes(q) ||
        m.birth?.place?.division?.toLowerCase().includes(q);

      // Parents or Spouse matches
      const father = m.fatherId ? memberMap.get(m.fatherId) : null;
      const mother = m.motherId ? memberMap.get(m.motherId) : null;
      const parentMatch =
        (father && (father.fullName?.toLowerCase().includes(q) || father.banglaName?.toLowerCase().includes(q))) ||
        (mother && (mother.fullName?.toLowerCase().includes(q) || mother.banglaName?.toLowerCase().includes(q)));

      // Bio & Notes
      const bioMatch =
        m.biography?.toLowerCase().includes(q) ||
        m.notes?.toLowerCase().includes(q);

      if (activeFilter === 'name') return nameMatch;
      if (activeFilter === 'id') return idMatch;
      if (activeFilter === 'location') return locMatch;
      if (activeFilter === 'document') return docMatch;

      return nameMatch || idMatch || docMatch || locMatch || parentMatch || bioMatch;
    });
  }, [members, query, activeFilter, memberMap]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/60 p-4 pt-16 sm:pt-24 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl rounded-2xl border border-amber-900/15 bg-white shadow-2xl dark:border-stone-800 dark:bg-stone-900 overflow-hidden">
        {/* Search Input Box */}
        <div className="relative flex items-center border-b border-stone-200 px-4 py-3.5 dark:border-stone-800">
          <Search className="h-5 w-5 text-amber-800 dark:text-amber-400 shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder={
              isBn
                ? 'নাম, ডাকনাম, সদস্য আইডি, ক্রমিক, এনআইডি, জন্ম নিবন্ধন, বা জেলা দিয়ে খুঁজুন...'
                : 'Search by name, nickname, Member ID, Kromik, NID, Birth Reg, or district...'
            }
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full bg-transparent px-3 text-sm sm:text-base text-stone-900 placeholder:text-stone-400 focus:outline-none dark:text-stone-100"
          />
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-stone-400 hover:bg-stone-100 hover:text-stone-700 dark:hover:bg-stone-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 border-b border-stone-100 bg-stone-50/70 px-4 py-2 text-xs dark:border-stone-800 dark:bg-stone-950/40 overflow-x-auto">
          <span className="text-stone-500 font-medium mr-1">{isBn ? 'ফিল্টার:' : 'Filter:'}</span>
          {[
            { id: 'all', label: isBn ? 'সকল ক্ষেত্রে' : 'All' },
            { id: 'name', label: isBn ? 'নাম ও ডাকনাম' : 'Name & Nickname' },
            { id: 'id', label: isBn ? 'সদস্য আইডি / ক্রমিক' : 'Member ID / Serial' },
            { id: 'document', label: isBn ? 'এনআইডি ও জন্ম সনদ' : 'NID & Documents' },
            { id: 'location', label: isBn ? 'গ্রাম ও জেলা' : 'Location' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id as typeof activeFilter)}
              className={`rounded-full px-2.5 py-1 transition ${
                activeFilter === f.id
                  ? 'bg-amber-800 text-white font-semibold dark:bg-amber-700'
                  : 'text-stone-600 hover:bg-stone-200 dark:text-stone-400 dark:hover:bg-stone-800'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto divide-y divide-stone-100 p-2 dark:divide-stone-800">
          {!query.trim() ? (
            <div className="p-8 text-center text-xs text-stone-400 space-y-2">
              <Search className="mx-auto h-8 w-8 text-stone-300 dark:text-stone-700" />
              <p>
                {isBn
                  ? 'যেকোনো শব্দ বা আইডি লিখে অনুসন্ধান শুরু করুন।'
                  : 'Type any name, Kromik serial, NID, or village to search across the lineage.'}
              </p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-8 text-center text-xs text-stone-400 space-y-2">
              <p>
                {isBn
                  ? `"${query}" এর সাথে মিল রেখে কোনো সদস্য পাওয়া যায়নি।`
                  : `No records found matching "${query}".`}
              </p>
            </div>
          ) : (
            searchResults.map(member => {
              const branch = branches.find(b => b.id === member.branchId);
              const gen = generations.get(member.id) || 1;
              const memberColor = getMemberColor(member);

              return (
                <div
                  key={member.id}
                  data-member-color={memberColor.key}
                  onClick={() => {
                    onSelectMember(member.id);
                    onClose();
                  }}
                  className="flex items-center justify-between p-3 rounded-xl border cursor-pointer transition" style={{backgroundColor:memberColor.soft,borderColor:memberColor.border}}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] font-bold text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded-sm dark:bg-amber-950 dark:text-amber-300">
                        
                      </span>
                      <span className="text-xs text-stone-500">
                        {isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Gen ${gen}`}
                      </span>
                      {branch && (
                        <span
                          className="h-2 w-2 rounded-full"
                          style={{ backgroundColor: branch.color }}
                          title={branch.name}
                        />
                      )}
                      <span className="text-[10px] text-stone-400 font-mono">
                        {member.id}
                      </span>
                    </div>

                    <div className="font-serif font-bold text-sm" style={{color:memberColor.text}}>
                      {isBn ? member.banglaName || member.fullName : member.englishName || member.fullName}
                      {member.nickname && <span className="font-sans text-xs font-normal text-stone-500 ml-1.5">({member.nickname})</span>}
                    </div>

                    <div className="flex flex-wrap gap-2 text-[11px] text-stone-500">
                      {member.birth?.date?.year && (
                        <span>{isBn ? 'জন্ম:' : 'Born:'} {member.birth.date.year}</span>
                      )}
                      {member.birth?.place?.district && (
                        <span>• {member.birth.place.district}</span>
                      )}
                      {member.identityDocs?.nidNumber && (
                        <span>• NID: {member.identityDocs.nidNumber}</span>
                      )}
                    </div>
                  </div>

                  <ArrowRight className="h-4 w-4 text-stone-400 group-hover:text-amber-800 shrink-0 ml-2" />
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
