/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Family Archive View Wrapper
 */

import React from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { FamilyArchiveView as ProductionArchiveView } from './archive/FamilyArchiveView';

interface FamilyArchiveViewProps {
  onSelectMember: (memberId: string) => void;
  onOpenUploadAvatar?: (memberId: string) => void;
}

export const FamilyArchiveView: React.FC<FamilyArchiveViewProps> = ({
  onSelectMember,
  onOpenUploadAvatar
}) => {
  const { language } = useGenealogy();
  const isBn = language === 'bn';

  return (
    <ProductionArchiveView
      onOpenMemberProfile={onSelectMember}
      isBn={isBn}
    />
  );
};
