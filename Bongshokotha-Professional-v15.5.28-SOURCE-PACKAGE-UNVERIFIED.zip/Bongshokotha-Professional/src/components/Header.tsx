/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Top Navigation Header & Family Heritage Bar
 * Integrates with Fixed Left Sidebar
 */

import React, { useState } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { useThemeRegistry } from '../context/ThemeRegistry';
import {
  Menu,
  ShieldCheck,
  AlertTriangle,
  Globe,
  Palette,
  HardDrive,
  Users,
  Plus,
  ChevronDown,
  Search,
  BookOpen,
  Calendar,
  Settings as SettingsIcon,
  Sparkles
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: any) => void;
  onOpenNewFamilyModal: () => void;
  onOpenAddMemberModal: () => void;
  onOpenSearchModal: () => void;
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewFamilyModal,
  onOpenAddMemberModal,
  onOpenSearchModal,
  onToggleMobileMenu
}) => {
  const {
    family,
    allFamilies,
    switchFamily,
    language,
    setLanguage,
    validationReport,
    members
  } = useGenealogy();

  const themeRegistry = useThemeRegistry();
  const isBn = language === 'bn';
  const [isFamilyDropdownOpen, setIsFamilyDropdownOpen] = useState(false);

  return (
    <header className="no-print sticky top-0 z-20 border-b border-stone-200/80 bg-white/90 dark:border-stone-800/80 dark:bg-stone-900/90 backdrop-blur-md transition-colors">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-3">
          
          {/* Left: Mobile Menu Toggle + Family Switcher */}
          <div className="flex items-center gap-3">
            {/* Mobile Hamburger Menu Toggle Button */}
            <button
              onClick={onToggleMobileMenu}
              className="md:hidden p-2 rounded-xl text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition"
              title={isBn ? 'মেনু খুলুন' : 'Open Menu'}
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Active Family Space Selector */}
            <div className="relative">
              <button
                onClick={() => setIsFamilyDropdownOpen(!isFamilyDropdownOpen)}
                className="group flex items-center gap-2 text-left focus:outline-none p-1.5 rounded-xl hover:bg-stone-100 dark:hover:bg-stone-800 transition"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <h1 className="font-serif text-sm sm:text-base font-bold text-stone-900 dark:text-white truncate max-w-[160px] sm:max-w-[260px]">
                      {isBn ? family.banglaName || family.name : family.name}
                    </h1>
                    <ChevronDown className="h-4 w-4 text-stone-400 transition-transform group-hover:translate-y-0.5" />
                  </div>
                  <p className="text-[10px] font-mono text-stone-500 hidden sm:block">
                    {members.length} {isBn ? 'জন সদস্য নথিভুক্ত' : 'verified members'}
                  </p>
                </div>
              </button>

              {/* Dropdown for Families */}
              {isFamilyDropdownOpen && (
                <div className="absolute left-0 mt-2 w-72 rounded-2xl border border-stone-200 bg-white p-2 shadow-2xl dark:border-stone-700 dark:bg-stone-900 z-50">
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-stone-400">
                    {isBn ? 'পারিবারিক স্পেসসমূহ' : 'Family Collections'}
                  </div>
                  {allFamilies.map(f => (
                    <button
                      key={f.id}
                      onClick={() => {
                        switchFamily(f.id);
                        setIsFamilyDropdownOpen(false);
                      }}
                      className={`flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs transition ${
                        f.id === family.id
                          ? 'bg-amber-500/15 font-bold text-amber-900 dark:text-amber-200'
                          : 'text-stone-700 hover:bg-stone-100 dark:text-stone-300 dark:hover:bg-stone-800'
                      }`}
                    >
                      <span className="truncate">{isBn ? f.banglaName || f.name : f.name}</span>
                      {f.id === family.id && <span className="h-2 w-2 rounded-full bg-amber-600" />}
                    </button>
                  ))}

                  <div className="mt-2 pt-2 border-t border-stone-100 dark:border-stone-800">
                    <button
                      onClick={() => {
                        setIsFamilyDropdownOpen(false);
                        onOpenNewFamilyModal();
                      }}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-amber-800 hover:bg-amber-50 dark:text-amber-400 dark:hover:bg-amber-950/40"
                    >
                      <Plus className="h-4 w-4" />
                      <span>{isBn ? 'নতুন পরিবার শুরু করুন' : 'Create New Family'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Header Utility Controls */}
          <div className="flex items-center gap-2">
            {/* Search Button (triggers Ctrl+K modal) */}
            <button
              onClick={onOpenSearchModal}
              className="flex items-center gap-2 rounded-xl border border-stone-200 bg-stone-50 px-3 py-1.5 text-xs text-stone-600 hover:border-amber-600 hover:bg-white transition dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300"
            >
              <Search className="h-3.5 w-3.5 text-stone-400" />
              <span className="hidden sm:inline">{isBn ? 'অনুসন্ধান...' : 'Search...'}</span>
              <kbd className="hidden lg:inline rounded bg-stone-200 px-1.5 py-0.5 text-[9px] font-mono dark:bg-stone-700">⌘K</kbd>
            </button>

            {/* Data Integrity Status */}
            <div
              onClick={() => setActiveTab('settings')}
              className={`hidden sm:flex cursor-pointer items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs font-medium border ${
                validationReport.isValid
                  ? 'border-emerald-500/30 bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300'
                  : 'border-amber-500/30 bg-amber-50 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300'
              }`}
              title={validationReport.isValid ? 'তথ্য সম্পূর্ণ শুদ্ধ' : 'শুদ্ধতা রিপোর্ট দেখুন'}
            >
              {validationReport.isValid ? (
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
              ) : (
                <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              )}
              <span className="text-[11px] font-bold">
                {validationReport.isValid ? (isBn ? 'শুদ্ধতা নিশ্চিত' : 'Valid') : (isBn ? `${validationReport.issues.length}টি সংশোধন` : `${validationReport.issues.length} Issues`)}
              </span>
            </div>

            {/* Language Switcher */}
            <button
              onClick={() => setLanguage(isBn ? 'en' : 'bn')}
              className="flex items-center gap-1 rounded-xl border border-stone-200 bg-stone-50 px-2.5 py-1.5 text-xs font-bold text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200 transition"
              title="Change Language"
            >
              <Globe className="h-3.5 w-3.5 text-stone-400" />
              <span>{isBn ? 'English' : 'বাংলা'}</span>
            </button>

            {/* Quick Add Member Button (on Desktop) */}
            <button
              onClick={onOpenAddMemberModal}
              className="hidden sm:flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold text-white shadow-xs transition"
              style={{ backgroundColor: themeRegistry.colors.primary }}
            >
              <Plus className="h-3.5 w-3.5" />
              <span>{isBn ? 'সদস্য যোগ' : 'Add'}</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
