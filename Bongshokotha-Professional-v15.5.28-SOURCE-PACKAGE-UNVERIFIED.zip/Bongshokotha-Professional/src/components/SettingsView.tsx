/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Comprehensive Master Settings Center (Part 4)
 * 
 * Exactly 25 Curated Categories:
 * 1. Account, 2. Language, 3. Theme, 4. Display, 5. Dashboard, 6. Family,
 * 7. Genealogy, 8. Archive, 9. OCR, 10. Camera, 11. Storage, 12. Privacy,
 * 13. Security, 14. Notifications, 15. Backup, 16. Restore, 17. Import,
 * 18. Export, 19. Synchronization, 20. Permissions, 21. Accessibility,
 * 22. Validation, 23. Data Repair, 24. About, 25. Reset.
 * 
 * Features:
 * - 116 HD Premium Themes with color tokens and accessibility metadata
 * - Extensible 4-language i18n (Bengali, English, Hindi, Arabic)
 * - Safe Reset vs Factory Reset (with destructive safeguard & backup opportunity)
 * - 10-Stage Import Wizard & Safe Restore Conflict Manager
 * - Provider-Neutral Sync & Real Google Account / Drive Status
 * - 6-Role RBAC & Audit Log Viewer
 */

import React, { useState, useRef, useMemo, useEffect } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { useThemeRegistry } from '../context/ThemeRegistry';
import { BONGSHO_THEMES, BongshoTheme, getFullTheme } from '../theme/themeEngine';
import { UserRole, ROLE_PERMISSIONS } from '../services/authRbac';
import { IntegrityRepairView } from './IntegrityRepairView';
import { SafeRestoreDiffModal } from './archive/SafeRestoreDiffModal';
import { ImportWizardModal } from './archive/ImportWizardModal';
import { BongshokothaArchive } from '../services/storage';
import { backupFamilyToGoogleDrive, connectGoogleDrive, disconnectGoogleDrive, isGoogleDriveConfigured } from '../services/googleDriveBackup';
import { getServerProfiles, saveServerProfiles, getActiveServerId, setActiveServerId, testServer, ServerProfile, normalizeServerEndpoint } from '../services/serverRegistry';
import { getAuditLogs, logAuditEvent } from '../services/auditLogger';
import { SUPPORTED_LANGUAGES, SupportedLanguage } from '../i18n/translations';
import { APP_VERSION } from '../appVersion';
import { checkCameraPermission, checkPhotoMediaPermission, requestCameraPermission, requestPhotoMediaPermission, permissionLabelBn, DevicePermissionStatus } from '../services/devicePermissions';
import {
  User,
  Globe,
  Palette,
  Monitor,
  LayoutDashboard,
  Users2,
  GitFork,
  Archive,
  ScanText,
  Camera,
  HardDrive,
  EyeOff,
  Lock,
  Bell,
  CloudUpload,
  RotateCcw,
  Upload,
  Download,
  RefreshCw,
  ShieldCheck,
  Accessibility as AccessibilityIcon,
  CheckCircle,
  Wrench,
  Info,
  Trash2,
  AlertTriangle,
  FileCheck,
  Check,
  ShieldAlert,
  ChevronRight,
  LogOut,
  Mail,
  Phone,
  Sparkles,
  Search,
  ExternalLink,
  Sliders,
  SlidersHorizontal,
  FolderSync,
  Server,
  Wifi,
  LogIn
} from 'lucide-react';

export type SettingsCategoryId =
  | 'account'
  | 'language'
  | 'theme'
  | 'display'
  | 'dashboard'
  | 'family'
  | 'genealogy'
  | 'archive'
  | 'ocr'
  | 'camera'
  | 'storage'
  | 'privacy'
  | 'security'
  | 'notifications'
  | 'backup'
  | 'restore'
  | 'import'
  | 'export'
  | 'sync'
  | 'permissions'
  | 'accessibility'
  | 'validation'
  | 'repair'
  | 'about'
  | 'reset';

interface CategoryItem {
  id: SettingsCategoryId;
  number: number;
  labelBn: string;
  labelEn: string;
  groupBn: string;
  icon: React.ComponentType<{ className?: string }>;
  isAdvanced?: boolean;
}

const SETTINGS_CATEGORIES: CategoryItem[] = [
  // Group 1: ব্যক্তিগত ও সাধারণ
  { id: 'account', number: 1, labelBn: 'অ্যাকাউন্ট ও স্পেস', labelEn: 'Account & Spaces', groupBn: 'ব্যক্তিগত ও সাধারণ', icon: User },
  { id: 'language', number: 2, labelBn: 'ভাষা ও লিপ্যন্তর (i18n)', labelEn: 'Language & i18n', groupBn: 'ব্যক্তিগত ও সাধারণ', icon: Globe },
  { id: 'theme', number: 3, labelBn: '১১৬টি HD প্রিমিয়াম থিম', labelEn: '116 HD Premium Themes', groupBn: 'ব্যক্তিগত ও সাধারণ', icon: Palette },
  { id: 'display', number: 4, labelBn: 'প্রদর্শন ও সংখ্যাপদ্ধতি', labelEn: 'Display & Numerals', groupBn: 'ব্যক্তিগত ও সাধারণ', icon: Monitor },
  { id: 'dashboard', number: 5, labelBn: 'ড্যাশবোর্ড নিয়ন্ত্রণ', labelEn: 'Dashboard Layout', groupBn: 'ব্যক্তিগত ও সাধারণ', icon: LayoutDashboard },
  { id: 'accessibility', number: 21, labelBn: 'সহজগম্যতা (Accessibility)', labelEn: 'Accessibility', groupBn: 'ব্যক্তিগত ও সাধারণ', icon: AccessibilityIcon },

  // Group 2: পারিবারিক ও বংশলতিকা
  { id: 'family', number: 6, labelBn: 'পারিবারিক পরিচয় ও প্রতীক', labelEn: 'Family Identity', groupBn: 'পারিবারিক ও বংশলতিকা', icon: Users2 },
  { id: 'genealogy', number: 7, labelBn: 'বংশক্রমিক ও প্রজন্ম নীতি', labelEn: 'Genealogy Rules', groupBn: 'পারিবারিক ও বংশলতিকা', icon: GitFork },
  { id: 'validation', number: 22, labelBn: 'শুদ্ধতা যাচাই নীতি', labelEn: 'Validation Schema', groupBn: 'পারিবারিক ও বংশলতিকা', icon: CheckCircle },
  { id: 'repair', number: 23, labelBn: '৮-পয়েন্ট ডেটা মেরামত', labelEn: '8-Point Data Repair', groupBn: 'পারিবারিক ও বংশলতিকা', icon: Wrench, isAdvanced: true },
  { id: 'notifications', number: 14, labelBn: 'স্মরণবার্তা ও নোটিফিকেশন', labelEn: 'Remembrance & Alerts', groupBn: 'পারিবারিক ও বংশলতিকা', icon: Bell },

  // Group 3: মহাফেজখানা ও মিডিয়া
  { id: 'archive', number: 8, labelBn: 'পারিবারিক আর্কাইভ সংরক্ষণ', labelEn: 'Archive & Vault', groupBn: 'পারিবারিক আর্কাইভ ও মিডিয়া', icon: Archive },
  { id: 'ocr', number: 9, labelBn: 'বাংলা ওসিআর ইঞ্জিন', labelEn: 'Bangla OCR Engine', groupBn: 'পারিবারিক আর্কাইভ ও মিডিয়া', icon: ScanText },
  { id: 'camera', number: 10, labelBn: 'ক্যামেরা ও দলিল স্ক্যানার', labelEn: 'Camera & Scanner', groupBn: 'পারিবারিক আর্কাইভ ও মিডিয়া', icon: Camera },
  { id: 'storage', number: 11, labelBn: 'ডিভাইস স্টোরেজ ও ক্যাশ', labelEn: 'Device Storage', groupBn: 'পারিবারিক আর্কাইভ ও মিডিয়া', icon: HardDrive },

  // Group 4: নিরাপত্তা ও সংযোগ
  { id: 'privacy', number: 12, labelBn: 'তথ্য গোপনীয়তা ফিল্ড মাস্ক', labelEn: 'Data Privacy & Masking', groupBn: 'নিরাপত্তা ও সংযোগ', icon: EyeOff },
  { id: 'security', number: 13, labelBn: 'নিরাপত্তা ও পিন লক', labelEn: 'Security & PIN Lock', groupBn: 'নিরাপত্তা ও সংযোগ', icon: Lock },
  { id: 'permissions', number: 20, labelBn: 'ভূমিকা ও প্রবেশাধিকার (RBAC)', labelEn: 'Roles & Permissions', groupBn: 'নিরাপত্তা ও সংযোগ', icon: ShieldCheck, isAdvanced: true },
  { id: 'sync', number: 19, labelBn: 'সার্ভার সমন্বয় (Sync & Drive)', labelEn: 'Server Synchronization', groupBn: 'নিরাপত্তা ও সংযোগ', icon: FolderSync, isAdvanced: true },

  // Group 5: ডেটা লাইফসাইকেল ও পরিচালনা
  { id: 'backup', number: 15, labelBn: 'ব্যাকআপ সংরক্ষণ (.bkf)', labelEn: 'Backup Archive', groupBn: 'ডেটা লাইফসাইকেল ও পরিচালনা', icon: CloudUpload },
  { id: 'restore', number: 16, labelBn: 'নিরাপদ রিস্টোর', labelEn: 'Safe Restore', groupBn: 'ডেটা লাইফসাইকেল ও পরিচালনা', icon: RotateCcw },
  { id: 'import', number: 17, labelBn: '১০-ধাপের আমদানি উইজার্ড', labelEn: '10-Step Import Wizard', groupBn: 'ডেটা লাইফসাইকেল ও পরিচালনা', icon: Upload },
  { id: 'export', number: 18, labelBn: 'বহুভাষিক এক্সপোর্ট', labelEn: 'Multilingual Export', groupBn: 'ডেটা লাইফসাইকেল ও পরিচালনা', icon: Download },
  { id: 'reset', number: 25, labelBn: 'রিসেট ও ফ্যাক্টরি মোছা', labelEn: 'Reset & Destruction', groupBn: 'ডেটা লাইফসাইকেল ও পরিচালনা', icon: Trash2, isAdvanced: true },
  { id: 'about', number: 24, labelBn: 'বংশকথা পরিচিতি ও লাইসেন্স', labelEn: 'About & Credits', groupBn: 'ডেটা লাইফসাইকেল ও পরিচালনা', icon: Info }
];

interface SettingsViewProps {
  onOpenNewFamilyModal: () => void;
  onSelectMember: (memberId: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  onOpenNewFamilyModal,
  onSelectMember
}) => {
  const {
    family,
    allFamilies,
    switchFamily,
    members,
    marriages,
    archiveRecords,
    language,
    setLanguage,
    theme,
    setTheme,
    userAccount,
    setUserAccount,
    exportArchiveJSON,
    importArchiveJSON,
    exportGedcomFile,
    importGedcomText,
    loadSampleDataset,
    resetSettings,
    resetToFactoryState,
    updateFamily,
    deleteFamilySpace,
    renameFamilySpace,
    checkPermission
  } = useGenealogy();

  const isBn = language === 'bn';
  const canGmailBackup = checkPermission('canGmailBackup');
  const canManageServers = checkPermission('canManageServers');
  const canDeleteEntireGenealogy = checkPermission('canDeleteEntireGenealogy');
  const canRunIntegrityRepair = checkPermission('canRunIntegrityRepair');
  const canManageRoles = checkPermission('canManageRoles');
  const canConfigureSync = checkPermission('canConfigureSync');
  const canFactoryReset = checkPermission('canFactoryReset');
  // Keep ordinary preferences separate from genealogy administration.
  const personalCategoryIds: SettingsCategoryId[] = ['language', 'theme', 'display', 'dashboard', 'accessibility', 'storage', 'privacy', 'security', 'about'];
  const visibleCategories = SETTINGS_CATEGORIES.filter(cat => {
    if (personalCategoryIds.includes(cat.id)) return true;
    if (!canManageRoles) return false;
    if (cat.id === 'repair') return canRunIntegrityRepair;
    if (cat.id === 'permissions') return canManageRoles;
    if (cat.id === 'sync') return canConfigureSync;
    if (cat.id === 'reset') return canFactoryReset;
    if (cat.id === 'backup') return canGmailBackup || checkPermission('canManageFamily');
    if (cat.id === 'family' || cat.id === 'genealogy' || cat.id === 'validation') return checkPermission('canManageFamily');
    if (cat.id === 'account') return canManageRoles;
    return true;
  });
  const themeRegistry = useThemeRegistry();
  const [activeCategory, setActiveCategory] = useState<SettingsCategoryId>('theme');
  React.useEffect(() => {
    if (!visibleCategories.some(cat => cat.id === activeCategory)) setActiveCategory('theme');
  }, [activeCategory, canManageRoles, canConfigureSync, canFactoryReset, canRunIntegrityRepair]);
  const [familyDraft, setFamilyDraft] = useState({ banglaName: family.banglaName || '', name: family.name || '', description: family.description || '' });
  const [kromikDraft, setKromikDraft] = useState(family.settings?.kromikPrefix || 'BK-');
  const [settingsSaveMessage, setSettingsSaveMessage] = useState('');

  useEffect(() => {
    setFamilyDraft({ banglaName: family.banglaName || '', name: family.name || '', description: family.description || '' });
    setKromikDraft(family.settings?.kromikPrefix || 'BK-');
    setSettingsSaveMessage('');
  }, [family.id, family.banglaName, family.name, family.description, family.settings?.kromikPrefix]);

  const saveFamilyIdentity = async () => {
    setSettingsSaveMessage('');
    await updateFamily({ banglaName: familyDraft.banglaName.trim(), name: familyDraft.name.trim(), description: familyDraft.description.trim() });
    setSettingsSaveMessage(isBn ? 'পারিবারিক পরিচয় সফলভাবে সংরক্ষণ হয়েছে।' : 'Family identity saved successfully.');
  };

  const saveGenealogyRules = async () => {
    setSettingsSaveMessage('');
    await updateFamily({ settings: { ...family.settings, kromikPrefix: kromikDraft.trim() || 'BK-' } });
    setSettingsSaveMessage(isBn ? 'বংশক্রমিক নীতি সফলভাবে সংরক্ষণ হয়েছে।' : 'Genealogy rules saved successfully.');
  };
  
  // Safe Restore Diff Modal state
  const [pendingArchive, setPendingArchive] = useState<BongshokothaArchive | null>(null);
  const [isDiffModalOpen, setIsDiffModalOpen] = useState(false);
  const [isImportWizardOpen, setIsImportWizardOpen] = useState(false);
  const jsonFileInputRef = useRef<HTMLInputElement>(null);

  // Destructive reset dialog state
  const [factoryConfirmText, setFactoryConfirmText] = useState('');
  const [isFactoryDialogOpen, setIsFactoryDialogOpen] = useState(false);
  const [cameraPermissionStatus, setCameraPermissionStatus] = useState<DevicePermissionStatus>('prompt');
  const [photoPermissionStatus, setPhotoPermissionStatus] = useState<DevicePermissionStatus>('prompt');
  const [permissionMessage, setPermissionMessage] = useState('');

  useEffect(() => {
    if (activeCategory !== 'camera') return;
    let cancelled = false;
    (async () => {
      const [cameraState, photoState] = await Promise.all([checkCameraPermission(), checkPhotoMediaPermission()]);
      if (!cancelled) {
        setCameraPermissionStatus(cameraState);
        setPhotoPermissionStatus(photoState);
      }
    })();
    return () => { cancelled = true; };
  }, [activeCategory]);

  const handleCameraPermission = async () => {
    const state = await requestCameraPermission();
    setCameraPermissionStatus(state);
    setPermissionMessage(state === 'granted' ? (isBn ? 'ক্যামেরার অনুমতি দেওয়া হয়েছে।' : 'Camera permission granted.') : (isBn ? 'ক্যামেরার অনুমতি পাওয়া যায়নি।' : 'Camera permission was not granted.'));
  };

  const handlePhotoPermission = async () => {
    const state = await requestPhotoMediaPermission();
    setPhotoPermissionStatus(state);
    setPermissionMessage((state === 'granted' || state === 'limited') ? (isBn ? 'ছবি/মিডিয়া ব্যবহারের অনুমতি দেওয়া হয়েছে।' : 'Photo/media access granted.') : (isBn ? 'ছবি/মিডিয়ার অনুমতি পাওয়া যায়নি।' : 'Photo/media access was not granted.'));
  };
  const [isResetSettingsSuccess, setIsResetSettingsSuccess] = useState(false);

  // Google OAuth / Drive state
  const [googleConnected, setGoogleConnected] = useState(Boolean(family.settings?.googleConnected));
  const [googleAccountEmail, setGoogleAccountEmail] = useState(family.settings?.googleAccountEmail || '');
  const [googleBusy, setGoogleBusy] = useState(false);
  const [googleAutoBackup, setGoogleAutoBackup] = useState(Boolean(family.settings?.googleAutoBackup));

  // Unified server selector: connect to one configured server, then all sharing/sync
  // workflows reuse that endpoint automatically.
  const [serverProfiles, setServerProfiles] = useState<ServerProfile[]>(() => getServerProfiles());
  const [activeServerId, setActiveServerIdState] = useState(() => getActiveServerId());
  const [serverBusyId, setServerBusyId] = useState<string | null>(null);

  const filteredThemes = themeRegistry.filteredThemes;
  const backgroundInputRef = useRef<HTMLInputElement>(null);
  const [storageBytes, setStorageBytes] = useState(0);

  const refreshStorageUsage = React.useCallback(() => {
    try {
      let total = 0;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i) || '';
        total += key.length + (localStorage.getItem(key) || '').length;
      }
      setStorageBytes(total * 2);
    } catch { setStorageBytes(0); }
  }, []);

  React.useEffect(() => { refreshStorageUsage(); }, [refreshStorageUsage, members.length, marriages.length, archiveRecords.length, family.id]);

  const formatStorageSize = (bytes: number) => {
    if (!bytes) return '0 B';
    const units = ['B','KB','MB','GB'];
    const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    return `${(bytes / Math.pow(1024, i)).toFixed(i ? 2 : 0)} ${units[i]}`;
  };


  const handleThemeBackground = (file: File | null) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => themeRegistry.setCustomBackgroundUrl(String(reader.result || ''));
    reader.readAsDataURL(file);
  };

  const auditLogs = useMemo(() => getAuditLogs(), [activeCategory]);

  const handleRoleChange = (newRole: UserRole) => {
    if (!import.meta.env.DEV) {
      alert(isBn ? 'Production সংস্করণে নিজের ভূমিকা পরিবর্তন করা যাবে না।' : 'Production builds do not allow self-role switching.');
      return;
    }
    const roleLabels: Record<UserRole, { en: string; bn: string }> = {
      owner: { en: 'Family Owner', bn: 'বংশমালিক / প্রতিষ্ঠাতা' },
      super_admin: { en: 'Family Head (Super Admin)', bn: 'বংশপ্রধান / অভিভাবক' },
      admin: { en: 'Administrator', bn: 'প্রশাসক' },
      co_admin: { en: 'Co-Admin', bn: 'Co-Admin' },
      tester: { en: 'Tester', bn: 'টেস্টার' },
      editor: { en: 'Family Chronicler (Editor)', bn: 'বংশ-লেখক / লিপিকার' },
      contributor: { en: 'Contributor', bn: 'বংশধর / অবদানকারী' },
      viewer: { en: 'Guest Viewer', bn: 'অতিথি / দর্শক' }
    };
    const updated = {
      ...userAccount,
      role: newRole,
      name: roleLabels[newRole].en,
      nameBn: roleLabels[newRole].bn
    };
    setUserAccount(updated);

    logAuditEvent({
      eventType: 'role_change',
      actorId: userAccount.id,
      actorName: userAccount.name,
      actorRole: userAccount.role,
      targetEntity: newRole,
      details: `Active role updated to ${roleLabels[newRole].en}`,
      detailsBn: `সক্রিয় ভূমিকা পরিবর্তন করে ${roleLabels[newRole].bn} করা হয়েছে।`,
      severity: 'info'
    });
  };

  const handleJsonUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        if (parsed.format === 'BONGSHOKOTHA_ARCHIVE' && parsed.family) {
          setPendingArchive(parsed);
          setIsDiffModalOpen(true);
        } else {
          alert(isBn ? 'অকার্যকর ফাইল ফরম্যাট। অনুগ্রহ করে সঠিক বংশকথা ব্যাকআপ (.bkf / .json) ফাইল ব্যবহার করুন।' : 'Invalid file format.');
        }
      } catch (err) {
        alert(isBn ? 'ফাইল পার্স করতে ব্যর্থ।' : 'Failed to parse JSON file.');
      }
    };
    reader.readAsText(file);
    if (jsonFileInputRef.current) jsonFileInputRef.current.value = '';
  };

  const executeSafeResetSettings = async () => {
    await resetSettings();
    setIsResetSettingsSuccess(true);
    setTimeout(() => setIsResetSettingsSuccess(false), 3000);
  };

  const executeFactoryReset = async () => {
    if (!canDeleteEntireGenealogy) {
      alert(isBn ? 'শুধু Owner এই ধ্বংসাত্মক কাজটি করতে পারবেন।' : 'Only an authorized high-privilege administrator can perform this destructive action.');
      return;
    }
    if (factoryConfirmText !== 'DELETE' && factoryConfirmText !== 'মুছে ফেলুন') {
      alert(isBn ? 'নিশ্চিতকরণ শব্দটি সঠিকভাবে লিখুন।' : 'Please type the exact confirmation word.');
      return;
    }
    try {
      await resetToFactoryState();
      themeRegistry.switchTheme('heritage');
      themeRegistry.setCustomBackgroundUrl('');
      setIsFactoryDialogOpen(false);
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Factory reset failed.');
      return;
    }
    setFactoryConfirmText('');
  };

  const toggleGoogleConnection = async () => {
    if (!canGmailBackup) { alert(isBn ? 'Gmail Backup অনুমতি নেই।' : 'You do not have Gmail Backup permission.'); return; }
    if (googleConnected) {
      disconnectGoogleDrive(); setGoogleConnected(false); setGoogleAccountEmail('');
      updateFamily({ settings: { ...family.settings, googleConnected: false, googleAccountEmail: undefined, googleLastBackup: undefined, googlePermissionsGranted: [] } });
      return;
    }
    if (!isGoogleDriveConfigured()) { alert(isBn ? 'Google OAuth চালু করতে .env.local-এ VITE_GOOGLE_CLIENT_ID সেট করুন।' : 'Set VITE_GOOGLE_CLIENT_ID in .env.local before connecting Google Drive.'); return; }
    setGoogleBusy(true);
    try {
      const result = await connectGoogleDrive('consent', googleAccountEmail || undefined);
      const email = result.email || '';
      setGoogleConnected(true); setGoogleAccountEmail(email);
      // Account connection immediately performs the first backup; only after the upload
      // succeeds do we persist the last-backup timestamp.
      const firstBackup = await backupFamilyToGoogleDrive(family, members, marriages, archiveRecords, false, email || googleAccountEmail || undefined);
      updateFamily({ settings: { ...family.settings, googleConnected: true, googleAccountEmail: email, googleLastBackup: new Date().toISOString(), googlePermissionsGranted: ['https://www.googleapis.com/auth/drive.appdata'] } });
      logAuditEvent({ eventType: 'login', actorId: userAccount.id, actorName: userAccount.name, actorRole: userAccount.role, targetEntity: 'Google Drive Account', details: `Google Drive connected${email ? ` (${email})` : ''}`, detailsBn: `গুগল ড্রাইভ সংযুক্ত${email ? ` (${email})` : ''}`, severity: 'info' });
    } catch (error) { alert(error instanceof Error ? error.message : 'Google authorization failed.'); }
    finally { setGoogleBusy(false); }
  };

  const backupNowToGoogle = async () => {
    if (!canGmailBackup) { alert(isBn ? 'Gmail Backup অনুমতি নেই।' : 'Gmail Backup permission denied.'); return; }
    if (!isGoogleDriveConfigured()) { alert(isBn ? 'VITE_GOOGLE_CLIENT_ID কনফিগার করা হয়নি।' : 'VITE_GOOGLE_CLIENT_ID is not configured.'); return; }
    setGoogleBusy(true);
    try {
      const result = await backupFamilyToGoogleDrive(family, members, marriages, archiveRecords, false, googleAccountEmail || undefined);
      const now = new Date().toISOString();
      updateFamily({ settings: { ...family.settings, googleConnected: true, googleAccountEmail, googleLastBackup: now, googlePermissionsGranted: ['https://www.googleapis.com/auth/drive.appdata'] } });
      logAuditEvent({ eventType: 'backup', actorId: userAccount.id, actorName: userAccount.name, actorRole: userAccount.role, targetEntity: result.fileId, details: 'Family archive backed up to Google Drive appDataFolder', detailsBn: 'পারিবারিক আর্কাইভ গুগল ড্রাইভে নিরাপদ ব্যাকআপ হয়েছে।', severity: 'info' });
      alert(isBn ? 'Google Drive ব্যাকআপ সফল হয়েছে।' : 'Google Drive backup completed successfully.');
    } catch (error) { alert(error instanceof Error ? error.message : 'Google Drive backup failed.'); }
    finally { setGoogleBusy(false); }
  };

  const updateServerProfile = (id: string, patch: Partial<ServerProfile>) => {
    setServerProfiles(prev => {
      const next = prev.map(profile => profile.id === id ? { ...profile, ...patch } : profile);
      saveServerProfiles(next);
      return next;
    });
  };

  const connectServer = async (profile: ServerProfile) => {
    if (!canManageServers) { alert(isBn ? 'Server ব্যবস্থাপনা অনুমোদিত নয়।' : 'Server management is not permitted for this role.'); return; }
    setServerBusyId(profile.id);
    try {
      const result = await testServer(profile);
      const checked = new Date().toISOString();
      updateServerProfile(profile.id, { status: result.ok ? 'online' : 'offline', lastCheckedAt: checked, version: result.version });
      if (!result.ok) { alert(result.message); return; }
      setActiveServerId(profile.id);
      setActiveServerIdState(profile.id);
      const endpoint = normalizeServerEndpoint(profile.endpoint);
      await updateFamily({ settings: { ...family.settings, syncEndpoint: endpoint, syncProvider: 'self_hosted', syncStatus: 'synced', syncLastTimestamp: checked } });
      alert(isBn ? `${profile.nameBn} সংযুক্ত হয়েছে। এখন Share/Join/Sync স্বয়ংক্রিয়ভাবে এই সার্ভার ব্যবহার করবে।` : `${profile.nameEn} connected. Sharing and sync will now use this server automatically.`);
    } finally {
      setServerBusyId(null);
    }
  };

  React.useEffect(() => {
    if (!canGmailBackup || !googleConnected || !googleAutoBackup || !family.settings?.googleLastBackup) return;
    const age = Date.now() - new Date(family.settings.googleLastBackup).getTime();
    if (age < 24 * 60 * 60 * 1000 || googleBusy) return;
    backupFamilyToGoogleDrive(family, members, marriages, archiveRecords, true, googleAccountEmail || undefined).then(() => {
      const now = new Date().toISOString();
      updateFamily({ settings: { ...family.settings, googleLastBackup: now, googleAutoBackup: true } });
    }).catch(() => undefined);
  }, [googleConnected, googleAutoBackup, family.id]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner Header */}
      <div className="p-6 rounded-3xl bg-stone-900 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4 border border-stone-800">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-2xl border border-amber-500/30">
            <SlidersHorizontal className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {isBn ? (canManageRoles ? 'প্রশাসনিক কেন্দ্র' : 'ব্যক্তিগত সেটিংস') : (canManageRoles ? 'Administration Center' : 'Personal Settings')}
              </span>
              <span className="text-xs text-stone-400">২৫টি সমন্বিত ক্যাটাগরি • v{APP_VERSION}</span>
            </div>
            <h1 className="text-2xl font-serif font-bold text-white mt-1">
              {isBn ? (canManageRoles ? 'বংশ পরিচালনা ও প্রশাসনিক নিয়ন্ত্রণ' : 'আপনার ব্যবহার-পছন্দ') : (canManageRoles ? 'Family Administration & Controls' : 'Your Preferences')}
            </h1>
            <p className="text-xs text-stone-300 max-w-xl">
              {isBn
                ? '১১৬টি HD প্রিমিয়াম থিম, ৪টি আন্তর্জাতিক ভাষা, ভূমিকাভিত্তিক নিরাপত্তা (RBAC), নিরাপদ আমদানি/রিস্টোর ও ক্লাউড সিঙ্ক।'
                : '116 HD premium themes, multi-lingual i18n, role-based access control, safe restore and backup engine.'}
            </p>
          </div>
        </div>

        {/* Active Role & Quick Space Pill */}
        <div className="flex flex-wrap items-center gap-2 bg-stone-800/80 p-2.5 rounded-2xl border border-stone-700">
          <div className="text-right px-2">
            <span className="text-[10px] text-stone-400 block">{isBn ? 'বর্তমান ব্যবহারকারী' : 'Active Account'}</span>
            <span className="text-xs font-bold text-amber-300">{userAccount.nameBn || userAccount.name}</span>
          </div>
          <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 text-xs font-semibold uppercase tracking-wider">
            {userAccount.role}
          </span>
        </div>
      </div>

      {/* Main 2-Column Responsive Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Category Navigation Sidebar (4 cols on lg) */}
        <div className="lg:col-span-4 bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 p-3 shadow-sm space-y-4">
          <div className="px-3 pt-2 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400">
              {isBn ? (canManageRoles ? 'সেটিংস ও প্রশাসনিক বিভাগ' : 'ব্যক্তিগত সেটিংস') : (canManageRoles ? 'Settings & Admin Sections' : 'Personal Settings')}
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300">
              {visibleCategories.length}
            </span>
          </div>

          <div className="space-y-1 max-h-[75vh] overflow-y-auto pr-1">
            {visibleCategories.map(cat => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-medium transition-all text-left ${
                    isActive
                      ? 'bg-amber-600 text-white shadow-md font-bold'
                      : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate">
                    <span className={`w-5 h-5 flex items-center justify-center rounded-lg ${isActive ? 'text-white' : 'text-stone-400'}`}>
                      <Icon className="w-4 h-4" />
                    </span>
                    <span className="truncate">
                      {isBn ? `${cat.number}. ${cat.labelBn}` : `${cat.number}. ${cat.labelEn}`}
                    </span>
                  </div>
                  {cat.isAdvanced && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${isActive ? 'bg-amber-700 text-white' : 'bg-stone-100 dark:bg-stone-800 text-stone-400'}`}>
                      {isBn ? 'সুরক্ষিত' : 'Admin'}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Content Work Area (8 cols on lg) */}
        <div className="lg:col-span-8 bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 p-6 shadow-sm min-h-[600px]">

          {/* ========================================== */}
          {/* 1. ACCOUNT */}
          {/* ========================================== */}
          {activeCategory === 'account' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <User className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১. অ্যাকাউন্ট ও পারিবারিক স্পেস ব্যবস্থাপনা' : '1. Account & Family Spaces'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'মোবাইল বা ইমেইল লগইন এবং একাধিক পরিবারের মাঝে নিরাপদে পরিবর্তন।' : 'Login via mobile or email, switch between new, demo, and shared family spaces.'}
                </p>
              </div>

              {/* Login Method Banner */}
              <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
                    {userAccount.loginMethod === 'mobile' ? <Phone className="w-5 h-5" /> : <Mail className="w-5 h-5" />}
                  </div>
                  <div>
                    <span className="text-xs text-stone-500 block">{isBn ? 'নিবন্ধিত যোগাযোগ / লগইন' : 'Registered Contact'}</span>
                    <span className="font-bold text-sm text-stone-900 dark:text-white">{userAccount.contact}</span>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                  {isBn ? 'যাচাইকৃত ও সক্রিয়' : 'Verified & Active'}
                </span>
              </div>

              {/* Family Spaces Selector */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'পারিবারিক স্পেসসমূহ' : 'Family Spaces'}</h3>
                  <button
                    onClick={onOpenNewFamilyModal}
                    className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition flex items-center gap-1.5"
                  >
                    <span>+ {isBn ? 'নতুন পরিবার তৈরি' : 'New Family'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {allFamilies.map(f => {
                    const isSelected = f.id === family.id;
                    const isDemo = f.id === 'family-sample-choudhury';
                    return (
                      <div
                        key={f.id}
                        onClick={() => switchFamily(f.id)}
                        className={`p-4 rounded-2xl border cursor-pointer transition relative ${
                          isSelected
                            ? 'border-amber-600 bg-amber-50/50 dark:bg-amber-950/30 dark:border-amber-500 shadow-sm'
                            : 'border-stone-200 dark:border-stone-800 hover:border-stone-300'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-bold text-sm text-stone-900 dark:text-white">{f.banglaName || f.name}</span>
                          {isDemo && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                              {isBn ? 'ডেমো স্পেস' : 'Demo Space'}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-stone-500 line-clamp-2">{f.description || 'পারিবারিক ইতিহাস'}</p>
                        {isSelected && (
                          <div className="mt-3 flex items-center gap-1.5 text-xs font-bold text-amber-700 dark:text-amber-300">
                            <Check className="w-4 h-4" />
                            <span>{isBn ? 'বর্তমানে সক্রিয়' : 'Currently Active'}</span>
                          </div>
                        )}
                        <div className="mt-3 flex flex-wrap gap-2" onClick={e => e.stopPropagation()}>
                          <button type="button" onClick={async () => {
                            const currentName = f.banglaName || f.name;
                            const nextName = window.prompt(isBn ? 'নতুন বংশের নাম লিখুন' : 'Enter the new family name', currentName);
                            if (nextName === null) return;
                            const trimmed = nextName.trim();
                            if (!trimmed) { window.alert(isBn ? 'বংশের নাম খালি রাখা যাবে না।' : 'Family name cannot be empty.'); return; }
                            try { await renameFamilySpace(f.id, trimmed); }
                            catch (err) { window.alert(err instanceof Error ? err.message : String(err)); }
                          }} className="px-3 py-1.5 rounded-lg border border-stone-300 dark:border-stone-700 text-xs font-semibold hover:bg-stone-100 dark:hover:bg-stone-800">
                            {isBn ? 'নাম পরিবর্তন' : 'Rename'}
                          </button>
                          {!isDemo && allFamilies.length > 1 && <button type="button" onClick={async () => {
                            const ok = window.confirm(isBn ? `“${f.banglaName || f.name}” বংশের নাম ও এই বংশের সদস্য, বিবাহ, আর্কাইভ ও রিসাইকেল বিনের তথ্য স্থায়ীভাবে মুছে যাবে। আগে ব্যাকআপ নিন। আপনি কি নিশ্চিত?` : `Permanently delete “${f.name}” and its members, marriages, archive and recycle-bin records? Back up first. This cannot be undone.`);
                            if (!ok) return;
                            try { await deleteFamilySpace(f.id); }
                            catch (err) { window.alert(err instanceof Error ? err.message : String(err)); }
                          }} className="px-3 py-1.5 rounded-lg border border-red-300 text-red-700 dark:text-red-300 text-xs font-semibold hover:bg-red-50 dark:hover:bg-red-950/30">
                            <Trash2 className="w-3.5 h-3.5 inline mr-1" />{isBn ? 'বংশ মুছুন' : 'Delete family'}
                          </button>}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="p-3 bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 rounded-xl text-xs text-amber-900 dark:text-amber-200 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 flex-shrink-0 text-amber-600" />
                  <span>
                    <strong>{isBn ? 'পবিত্র নিরাপত্তা নীতি:' : 'Guaranteed Rule:'}</strong> {isBn ? 'ডেমো ডেটা কোনো অবস্থাতেই আপনার বাস্তব পারিবারিক তথ্যের উপর ওভাররাইট হবে না।' : 'Demo data will never overwrite real family records.'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 2. LANGUAGE */}
          {/* ========================================== */}
          {activeCategory === 'language' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Globe className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '২. ভাষা ও বহুভাষিক লিপ্যন্তর (i18n)' : '2. Language & Internationalization'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn
                    ? 'ভাষা পরিবর্তন শুধুমাত্র ইন্টারফেস লেবেল পরিবর্তন করে; কোনো অবস্থাতেই ব্যবহারকারীর জীবনী, মূল নাম বা দলিলের পাঠ্য পরিবর্তন করে না।'
                    : 'Changing UI language never alters stored member names, biographies, or archival texts.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SUPPORTED_LANGUAGES.map(lang => {
                  const isSelected = language === lang.code;
                  return (
                    <div
                      key={lang.code}
                      onClick={() => setLanguage(lang.code)}
                      className={`p-4 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                        isSelected
                          ? 'border-amber-600 bg-amber-50/50 dark:bg-amber-950/30 dark:border-amber-500 shadow-md'
                          : 'border-stone-200 dark:border-stone-800 hover:border-stone-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{lang.flag}</span>
                        <div>
                          <span className="font-bold text-sm block text-stone-900 dark:text-white">{lang.nativeName}</span>
                          <span className="text-xs text-stone-500">{lang.name} ({lang.direction.toUpperCase()})</span>
                        </div>
                      </div>
                      {isSelected && <Check className="w-5 h-5 text-amber-600" />}
                    </div>
                  );
                })}
              </div>

              <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-2">
                <span className="text-xs font-bold text-stone-800 dark:text-stone-200 block">
                  {isBn ? 'ভবিষ্যত ভাষা সম্প্রসারণ (Future Extensibility Registry):' : 'Future Language Extension Readiness:'}
                </span>
                <p className="text-xs text-stone-500 leading-relaxed">
                  {isBn
                    ? 'বংশকথার আর্কিটেকচার উর্দু, ফারসি, তুর্কি, মালয়, ইন্দোনেশীয়, ফরাসি, জার্মান, স্প্যানিশ ইত্যাদি আন্তর্জাতিক ভাষার জন্য প্রস্তুত। অ্যাপ্লিকেশন লজিক অক্ষুণ্ণ রেখে নতুন অভিধান যুক্ত করা যায়।'
                    : 'The extensible dictionary architecture supports Urdu, Persian, Turkish, Malay, Indonesian, French, German, and Spanish without modifying core genealogy logic.'}
                </p>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 3. THEME (116 HD Premium Themes) */}
          {/* ========================================== */}
          {activeCategory === 'theme' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                    <Palette className="w-6 h-6 text-amber-600" />
                    <span>{isBn ? '৩. ১১৬টি HD প্রিমিয়াম থিম গ্যালারি (Theme Registry)' : '3. 116 HD Premium Themes (Theme Registry)'}</span>
                  </h2>
                  <p className="text-xs text-stone-500 mt-1">
                    {isBn
                      ? '১১২টি HD পূর্বনির্ধারিত পেশাদার কালার স্কিম (সারফেস, প্রাইমারি, অ্যাকসেন্ট ইত্যাদি) ও অ্যাক্সেসিবিলিটি মেটাডেটা.'
                      : '116 HD pre-defined professional color schemes (surface, primary, accent, etc.) with WCAG ratings.'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={themeRegistry.toggleDarkVariant}
                    className="px-3 py-1.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs font-semibold hover:bg-stone-200 dark:hover:bg-stone-700 transition flex items-center gap-1.5"
                    title="Toggle Dark/Light counterpart"
                  >
                    <span>{themeRegistry.isDark ? '☀️ Light' : '🌙 Dark'}</span>
                  </button>
                  <span className="px-3 py-1 bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold text-xs rounded-full border border-amber-500/30">
                    {filteredThemes.length} / {themeRegistry.allThemes.length} {isBn ? 'থিম' : 'Themes'}
                  </span>
                </div>
              </div>

              {/* Active Theme Inspector Card */}
              <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-stone-900 dark:text-white">
                        {isBn ? themeRegistry.currentTheme.nameBn : themeRegistry.currentTheme.nameEn}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md font-bold bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/30">
                        {themeRegistry.currentTheme.categoryBn}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        WCAG {themeRegistry.currentTheme.readability.accessibilityGrade} ({themeRegistry.currentTheme.readability.contrastRatio}:1)
                      </span>
                    </div>
                    <span className="text-xs text-stone-500">ID: {themeRegistry.currentTheme.id} • {isBn ? 'প্রস্তাবিত ফন্ট:' : 'Font:'} {themeRegistry.currentTheme.readability.recommendedFont}</span>
                  </div>
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                    <CheckCircle className="w-4 h-4" />
                    {isBn ? 'বর্তমানে সক্রিয় থিম' : 'Active Scheme'}
                  </span>
                </div>

                {/* Color Scheme Palette Swatches */}
                <div className="space-y-1.5 pt-2 border-t border-stone-200 dark:border-stone-800">
                  <span className="text-[11px] font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider block">
                    {isBn ? 'সক্রিয় কালার স্কিম টোকেন (Tokens):' : 'Active Color Scheme Tokens:'}
                  </span>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-[10px]">
                    <div className="p-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex items-center gap-2">
                      <div className="w-4 h-4 rounded-md border border-black/10 flex-shrink-0" style={{ backgroundColor: themeRegistry.colors.primary }} />
                      <div className="truncate">
                        <span className="font-bold block truncate">Primary</span>
                        <span className="text-stone-400 font-mono text-[9px]">{themeRegistry.colors.primary}</span>
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex items-center gap-2">
                      <div className="w-4 h-4 rounded-md border border-black/10 flex-shrink-0" style={{ backgroundColor: themeRegistry.colors.accent }} />
                      <div className="truncate">
                        <span className="font-bold block truncate">Accent</span>
                        <span className="text-stone-400 font-mono text-[9px]">{themeRegistry.colors.accent}</span>
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex items-center gap-2">
                      <div className="w-4 h-4 rounded-md border border-black/10 flex-shrink-0" style={{ backgroundColor: themeRegistry.colors.surface }} />
                      <div className="truncate">
                        <span className="font-bold block truncate">Surface</span>
                        <span className="text-stone-400 font-mono text-[9px]">{themeRegistry.colors.surface}</span>
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex items-center gap-2">
                      <div className="w-4 h-4 rounded-md border border-black/10 flex-shrink-0" style={{ backgroundColor: themeRegistry.colors.secondary }} />
                      <div className="truncate">
                        <span className="font-bold block truncate">Secondary</span>
                        <span className="text-stone-400 font-mono text-[9px]">{themeRegistry.colors.secondary}</span>
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex items-center gap-2">
                      <div className="w-4 h-4 rounded-md border border-black/10 flex-shrink-0" style={{ backgroundColor: themeRegistry.colors.card }} />
                      <div className="truncate">
                        <span className="font-bold block truncate">Card</span>
                        <span className="text-stone-400 font-mono text-[9px]">{themeRegistry.colors.card}</span>
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex items-center gap-2">
                      <div className="w-4 h-4 rounded-md border border-black/10 flex-shrink-0" style={{ backgroundColor: themeRegistry.colors.bg }} />
                      <div className="truncate">
                        <span className="font-bold block truncate">Background</span>
                        <span className="text-stone-400 font-mono text-[9px]">{themeRegistry.colors.bg}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Custom dashboard background */}
              <div className="rounded-2xl border border-amber-200 bg-amber-50/60 dark:border-stone-700 dark:bg-stone-950/50 p-4 space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div><h3 className="font-bold text-sm">{isBn ? '🖼️ ড্যাশবোর্ডের পিছনের ছবি' : '🖼️ Custom Dashboard Background'}</h3><p className="text-[11px] text-stone-500 mt-1">{isBn ? 'নিজের ছবি ব্যবহার করুন; বংশের ডেটা অপরিবর্তিত থাকবে।' : 'Use your own image; family data is never changed.'}</p></div>
                  <div className="flex gap-2">
                    <button onClick={() => backgroundInputRef.current?.click()} className="rounded-xl bg-amber-700 px-3 py-2 text-xs font-bold text-white">{isBn ? 'ছবি নির্বাচন' : 'Choose Image'}</button>
                    {themeRegistry.customBackgroundUrl && <button onClick={() => themeRegistry.setCustomBackgroundUrl('')} className="rounded-xl border px-3 py-2 text-xs font-bold">{isBn ? 'সরান' : 'Remove'}</button>}
                  </div>
                  <input ref={backgroundInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleThemeBackground(e.target.files?.[0] || null)} />
                </div>
                {themeRegistry.customBackgroundUrl && <div className="h-28 rounded-xl bg-cover bg-center border" style={{ backgroundImage: `url(${themeRegistry.customBackgroundUrl})` }} />}
              </div>

              {/* Search and Filters Bar */}
              <div className="space-y-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    value={themeRegistry.searchQuery}
                    onChange={(e) => themeRegistry.setSearchQuery(e.target.value)}
                    placeholder={isBn ? '১১৬টি থিমের নাম বা কোড দিয়ে খুঁজুন...' : 'Search across all 116 themes...'}
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-950 text-xs text-stone-900 dark:text-white placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  {themeRegistry.searchQuery && (
                    <button
                      onClick={() => themeRegistry.setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Category Pills */}
                <div className="flex flex-wrap gap-2 text-xs">
                  {themeRegistry.categories.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => themeRegistry.setActiveCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-xl font-medium transition ${
                        themeRegistry.activeCategory === cat.id
                          ? 'bg-stone-900 text-white dark:bg-white dark:text-stone-900 font-bold shadow-sm'
                          : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-200'
                      }`}
                    >
                      {isBn ? cat.labelBn : cat.labelEn} ({cat.count})
                    </button>
                  ))}
                </div>
              </div>

              {/* Theme Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[500px] overflow-y-auto pr-1">
                {filteredThemes.map(t => {
                  const isSelected = themeRegistry.currentThemeId === t.id;
                  return (
                    <div
                      key={t.id}
                      onClick={() => {
                        themeRegistry.switchTheme(t.id);
                        setTheme(t.id);
                      }}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition relative flex flex-col justify-between ${
                        isSelected
                          ? 'border-amber-600 ring-2 ring-amber-600/30 shadow-md bg-stone-50 dark:bg-stone-950'
                          : 'border-stone-200 dark:border-stone-800 hover:border-stone-300 dark:hover:border-stone-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <span className="font-bold text-xs text-stone-900 dark:text-white block">
                            {isBn ? t.nameBn : t.nameEn}
                          </span>
                          <span className="text-[10px] text-stone-500">
                            {t.categoryBn} • WCAG {t.readability.accessibilityGrade} ({t.readability.contrastRatio}:1)
                          </span>
                        </div>
                        {isSelected && (
                          <span className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center">
                            <Check className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>

                      {/* Live miniature preview: actual theme colors, not a generic swatch-only tile */}
                      <div className="bk-theme-preview mt-3 p-2.5" style={{ backgroundColor: t.colors.bg, borderColor: t.colors.border }}>
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span className="bk-theme-dot" style={{ backgroundColor: t.colors.primary }} />
                            <span className="text-[9px] font-bold truncate" style={{ color: t.colors.text }}>{isBn ? 'থিম প্রিভিউ' : 'Theme preview'}</span>
                          </div>
                          <span className="text-[9px] font-semibold" style={{ color: t.colors.textMuted }}>{t.isDark ? 'DARK' : 'LIGHT'}</span>
                        </div>
                        <div className="grid grid-cols-[1fr_1.5fr] gap-2">
                          <div className="rounded-lg p-2 flex flex-col gap-1.5" style={{ backgroundColor: t.colors.surface }}>
                            <div className="h-1.5 rounded-full w-3/4" style={{ backgroundColor: t.colors.primary }} />
                            <div className="h-1 rounded-full w-full" style={{ backgroundColor: t.colors.border }} />
                            <div className="h-1 rounded-full w-2/3" style={{ backgroundColor: t.colors.border }} />
                          </div>
                          <div className="bk-theme-preview-panel p-2" style={{ backgroundColor: t.colors.card, borderColor: t.colors.border }}>
                            <div className="h-1.5 rounded-full w-2/3 mb-2" style={{ backgroundColor: t.colors.text }} />
                            <div className="flex items-center gap-1.5">
                              <div className="h-5 flex-1 rounded-md" style={{ background: `linear-gradient(135deg, ${t.colors.primary}, ${t.colors.accent})` }} />
                              <div className="h-5 w-5 rounded-md" style={{ backgroundColor: t.secondary }} />
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* Accessible labeled palette */}
                      <div className="flex items-center gap-1.5 mt-2 pt-2 border-t" style={{ borderColor: t.colors.border }}>
                        <div className="w-5 h-5 rounded-md border border-black/10 shadow-sm flex-shrink-0" style={{ backgroundColor: t.colors.primary }} title="Primary" aria-label="Primary color" />
                        <div className="w-5 h-5 rounded-md border border-black/10 shadow-sm flex-shrink-0" style={{ backgroundColor: t.colors.accent }} title="Accent" aria-label="Accent color" />
                        <div className="w-5 h-5 rounded-md border border-black/10 shadow-sm flex-shrink-0" style={{ backgroundColor: t.colors.surface }} title="Surface" aria-label="Surface color" />
                        <div className="w-5 h-5 rounded-md border border-black/10 shadow-sm flex-shrink-0" style={{ backgroundColor: t.secondary }} title="Secondary" aria-label="Secondary color" />
                        <div className="w-5 h-5 rounded-md border border-black/10 shadow-sm flex-shrink-0" style={{ backgroundColor: t.colors.bg }} title="Background" aria-label="Background color" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 4. DISPLAY */}
          {/* ========================================== */}
          {activeCategory === 'display' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Monitor className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '৪. প্রদর্শন, বিন্যাস ও সংখ্যাপদ্ধতি' : '4. Display, Layout & Number Systems'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'ফন্ট সাইজ স্কেলিং, টেবিল ঘনত্ব ও বাংলা/ইংরেজি সংখ্যার বিন্যাস।' : 'Font scaling, UI density, and numeral formats.'}
                </p>
              </div>

              {/* Number system preference */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-800 dark:text-stone-200 block">
                  {isBn ? 'সংখ্যাপদ্ধতি পছন্দ (Number System):' : 'Numeral System:'}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {['bengali', 'english'].map(num => {
                    const isSelected = (family.settings?.numberSystem || 'bengali') === num;
                    return (
                      <button
                        key={num}
                        onClick={() => updateFamily({ settings: { ...family.settings, numberSystem: num as any } })}
                        className={`p-3 rounded-2xl border text-xs font-bold text-left transition ${
                          isSelected
                            ? 'border-amber-600 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200'
                            : 'border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
                        }`}
                      >
                        {num === 'bengali' ? 'বাংলা সংখ্যা (১, ২, ৩, ৪)' : 'Western Digits (1, 2, 3, 4)'}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Date Format preference */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-800 dark:text-stone-200 block">
                  {isBn ? 'তারিখের বিন্যাস (Date Format):' : 'Date Format:'}
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD'].map(df => {
                    const isSelected = (family.settings?.dateFormat || 'DD/MM/YYYY') === df;
                    return (
                      <button
                        key={df}
                        onClick={() => updateFamily({ settings: { ...family.settings, dateFormat: df as any } })}
                        className={`p-3 rounded-2xl border text-xs font-bold text-center transition ${
                          isSelected
                            ? 'border-amber-600 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200'
                            : 'border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
                        }`}
                      >
                        {df}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Calendar support toggles */}
              <div className="space-y-3 pt-2">
                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-xs text-stone-900 dark:text-white block">{isBn ? 'বাংলা বর্ষপঞ্জি (বঙ্গাব্দ) গণনা' : 'Bengali Era Calendar (BS)'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'বৈশাখ থেকে চৈত্র মাস পর্যন্ত স্থানীয় নির্ভুল হিসাব' : 'Revised Bengali standard calculation'}</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(family.settings?.enableBengaliCalendar)}
                    onChange={() => updateFamily({ settings: { ...family.settings, enableBengaliCalendar: !family.settings?.enableBengaliCalendar } })}
                    className="w-4 h-4 text-amber-600 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-xs text-stone-900 dark:text-white block">{isBn ? 'হিজরী বর্ষপঞ্জি (AH) গণনা' : 'Hijri Calendar (AH)'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'ঐতিহাসিক ইসলামী দলিল ও কবরফলকের জন্য' : 'Lunar Islamic calendar calculation'}</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(family.settings?.enableHijriCalendar)}
                    onChange={() => updateFamily({ settings: { ...family.settings, enableHijriCalendar: !family.settings?.enableHijriCalendar } })}
                    className="w-4 h-4 text-amber-600 rounded"
                  />
                </label>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 5. DASHBOARD */}
          {/* ========================================== */}
          {activeCategory === 'dashboard' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <LayoutDashboard className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '৫. ড্যাশবোর্ড নিয়ন্ত্রণ ও উইজেট সাজসজ্জা' : '5. Dashboard Controls & Widget Layout'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">{isBn ? 'কোন উইজেট থাকবে, কোন ক্রমে থাকবে এবং ড্যাশবোর্ড কতটা ঘন হবে—সব এখানে সংরক্ষিত হবে।' : 'Control widget visibility, order and dashboard density. Settings are saved per family and included in backup.'}</p>
              </div>
              {(() => {
                const defs = [
                  ['metrics','মূল পরিসংখ্যান','Key Metrics'],['alerts','সতর্কতা ও ডেটা স্বাস্থ্য','Alerts & Data Health'],['generations','প্রজন্ম বিন্যাস','Generation Distribution'],['demographics','লিঙ্গ ও জেলা','Demographics & Districts'],['upcoming','আসন্ন গুরুত্বপূর্ণ দিন','Upcoming Dates'],['completeness','তথ্য পূর্ণতা','Profile Completeness'],['branches','শাখা ও বংশধারা','Branches & Lineages'],['ageProfile','বয়স ও জীবনচিত্র','Age & Life Profile'],['recent','সাম্প্রতিক সদস্য','Recent Members'],['quickTools','দ্রুত কাজ','Quick Tools'],['marriageStatus','বিবাহের অবস্থা','Marriage Status'],['documents','দলিল ও আর্কাইভ','Documents & Archive'],['researchHealth','গবেষণা ও যাচাই','Research & Verification'],['familyMilestones','পারিবারিক মাইলস্টোন','Family Milestones'],['topBranches','শাখাভিত্তিক শীর্ষ সদস্য','Branch Highlights'],['familyOverview','পরিবারের সারসংক্ষেপ','Family Overview'],['genealogyHealth','বংশতথ্য স্বাস্থ্য','Genealogy Health'],['ocrReview','OCR যাচাই','OCR Review'],['backupStatus','ব্যাকআপ অবস্থা','Backup Status'],['anniversaries','বিবাহবার্ষিকী','Marriage Anniversaries'],['lineageMix','রক্তের বংশ ও বিবাহসূত্র','Lineage & In-Marriage'],['sharing','বংশ শেয়ার ও আমন্ত্রণ','Family Sharing & Invites']
                ] as const;
                const defaultOrder = defs.map(x=>x[0]);
                const currentEnabled = new Set(family.settings?.dashboardWidgets?.length ? family.settings.dashboardWidgets : defaultOrder);
                const savedOrder = family.settings?.dashboardWidgetOrder || [];
                const currentOrder = [...savedOrder, ...defaultOrder.filter(id=>!savedOrder.includes(id))];
                const save = (patch: any) => updateFamily({ settings: { ...family.settings, ...patch } });
                const move = (id:string, delta:number) => { const next=[...currentOrder]; const i=next.indexOf(id), j=i+delta; if(i<0||j<0||j>=next.length)return; [next[i],next[j]]=[next[j],next[i]]; save({dashboardWidgetOrder:next}); };
                return <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">{currentOrder.map((id,i)=>{const d=defs.find(x=>x[0]===id)!; const on=currentEnabled.has(id); return <div key={id} className="flex items-center gap-2 rounded-2xl border border-stone-200 dark:border-stone-800 p-3"><button type="button" onClick={()=>save({dashboardWidgets:on?Array.from(currentEnabled).filter(x=>x!==id):[...Array.from(currentEnabled),id]})} className={`w-10 h-6 rounded-full relative transition ${on?'bg-emerald-600':'bg-stone-300 dark:bg-stone-700'}`}><span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition ${on?'left-5':'left-1'}`}/></button><div className="flex-1"><div className="text-xs font-bold">{isBn?d[1]:d[2]}</div><div className="text-[10px] text-stone-400">{i+1}. {id}</div></div><button disabled={i===0} onClick={()=>move(id,-1)} className="p-1 disabled:opacity-20">↑</button><button disabled={i===currentOrder.length-1} onClick={()=>move(id,1)} className="p-1 disabled:opacity-20">↓</button></div>})}</div>
                  <div className="rounded-2xl border p-4 space-y-3"><div className="text-xs font-bold">{isBn?'ড্যাশবোর্ড ঘনত্ব':'Dashboard Density'}</div><div className="flex flex-wrap gap-2">{(['comfortable','compact','wide'] as const).map(x=><button key={x} type="button" onClick={()=>save({dashboardLayout:x})} className={`px-3 py-2 rounded-xl text-xs font-bold ${family.settings?.dashboardLayout===x?'bg-amber-700 text-white':'bg-stone-100 dark:bg-stone-800'}`}>{isBn?(x==='comfortable'?'আরামদায়ক':x==='compact'?'কমপ্যাক্ট':'প্রশস্ত'):x}</button>)}</div></div>
                  <button type="button" onClick={()=>save({dashboardWidgets:defaultOrder,dashboardWidgetOrder:defaultOrder,dashboardLayout:'comfortable'})} className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-xs font-bold"><RotateCcw className="w-4 h-4"/>{isBn?'ড্যাশবোর্ড ডিফল্টে ফিরিয়ে নিন':'Reset Dashboard Defaults'}</button>
                </div>;
              })()}
            </div>
          )}
          {/* ========================================== */}
          {/* 6. FAMILY IDENTITY */}
          {/* ========================================== */}
          {activeCategory === 'family' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Users2 className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '৬. পারিবারিক পরিচয় ও ঐতিহ্যিক প্রতীক' : '6. Family Identity & Emblem'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'পারিবারিক নাম, সিলমোহর, উৎপত্তিস্থল ও বংশের মূল মূলমন্ত্র।' : 'Family name, crest, origin, and motto.'}
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold block mb-1 text-stone-700 dark:text-stone-300">{isBn ? 'পারিবারিক বাংলা নাম:' : 'Bangla Family Name:'}</label>
                  <input
                    type="text"
                    value={familyDraft.banglaName}
                    onChange={(e) => setFamilyDraft(v => ({ ...v, banglaName: e.target.value }))}
                    className="w-full p-3 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-950 text-stone-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="font-bold block mb-1 text-stone-700 dark:text-stone-300">{isBn ? 'ইংরেজি নাম:' : 'English Family Name:'}</label>
                  <input
                    type="text"
                    value={familyDraft.name}
                    onChange={(e) => setFamilyDraft(v => ({ ...v, name: e.target.value }))}
                    className="w-full p-3 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-950 text-stone-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="font-bold block mb-1 text-stone-700 dark:text-stone-300">{isBn ? 'পারিবারিক ঐতিহ্য ও বিবরণ:' : 'Heritage & History Summary:'}</label>
                  <textarea
                    rows={3}
                    value={familyDraft.description}
                    onChange={(e) => setFamilyDraft(v => ({ ...v, description: e.target.value }))}
                    className="w-full p-3 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-950 text-stone-900 dark:text-white"
                  />
                </div>
              </div>
              <div className="flex items-center gap-3 pt-2">
                <button type="button" onClick={saveFamilyIdentity} className="rounded-xl bg-amber-700 px-5 py-3 text-sm font-bold text-white">{isBn ? 'সংরক্ষণ করুন' : 'Save Changes'}</button>
                {settingsSaveMessage && <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">{settingsSaveMessage}</span>}
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 7. GENEALOGY RULES */}
          {/* ========================================== */}
          {activeCategory === 'genealogy' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <GitFork className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '৭. বংশক্রমিক ও প্রজন্ম গণনা নীতি' : '7. Genealogy & Lineage Rules'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'বংশলতিকার ক্রমিক নম্বর প্রিফিক্স এবং আত্মীয়তার পরিভাষা গণনা পদ্ধতি।' : 'Lineage numbering prefixes and Bengali kinship terminology calculation modes.'}
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold block mb-1 text-stone-700 dark:text-stone-300">{isBn ? 'ক্রমিক প্রিফিক্স (Kromik Prefix):' : 'Lineage Prefix:'}</label>
                  <input
                    type="text"
                    value={kromikDraft}
                    onChange={(e) => setKromikDraft(e.target.value)}
                    className="w-48 p-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-950 text-stone-900 dark:text-white font-mono"
                  />
                </div>

                <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-1">
                  <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'বাঙালি আত্মীয়তা ক্যালকুলেটর অ্যালগরিদম' : 'Bengali Exact Kinship Terminology'}</span>
                  <p className="text-stone-500 leading-relaxed">
                    {isBn
                      ? 'পশ্চিমা Cousin-এর স্থলে বাংলা সংস্কৃতি অনুযায়ী চাচাতো, ফুফাতো, মামাতো, খালাতো ভাই/বোন এবং দুলাভাই, ভাবি, শ্যালক পরিভাষা স্বয়ংক্রিয়ভাবে নির্ণয় করা হয়।'
                      : 'Distinguishes between paternal and maternal kinship paths (Paternal uncle, Maternal aunt, First cousin paternal/maternal).'}
                  </p>
                </div>
                <div className="flex items-center gap-3 pt-2">
                  <button type="button" onClick={saveGenealogyRules} className="rounded-xl bg-amber-700 px-5 py-3 text-sm font-bold text-white">{isBn ? 'সংরক্ষণ করুন' : 'Save Changes'}</button>
                  {settingsSaveMessage && <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">{settingsSaveMessage}</span>}
                </div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 8. ARCHIVE & VAULT */}
          {/* ========================================== */}
          {activeCategory === 'archive' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Archive className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '৮. পারিবারিক আর্কাইভ ও সংরক্ষণ কোটা' : '8. Digital Archive & Vault Quota'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'দলিলপত্রের সঞ্চয়স্থান সীমা, জলছাপ ও প্রমাণপত্রের সুরক্ষা।' : 'Storage quota, watermarking, and evidence authenticity.'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800">
                  <span className="text-stone-500 block">{isBn ? 'মোট সংরক্ষিত দলিল' : 'Vault Documents'}</span>
                  <span className="text-lg font-bold text-stone-900 dark:text-white">{archiveRecords.length}</span>
                </div>
                <div className="p-3 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800">
                  <span className="text-stone-500 block">{isBn ? 'ভল্ট কোটা' : 'Storage Quota'}</span>
                  <span className="text-lg font-bold text-stone-900 dark:text-white">2048 MB</span>
                </div>
              </div>

              <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer text-xs">
                <div>
                  <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'ডাউনলোডকৃত সনদে অবিকৃত পারিবারিক জলছাপ যুক্ত করুন' : 'Add Authenticity Watermark on Export'}</span>
                  <span className="text-[10px] text-stone-500">{isBn ? 'দলিল নকল ও অননুমোদিত ব্যবহার রোধকল্পে' : 'Prevents tampering with historic deeds'}</span>
                </div>
                <input
                  type="checkbox"
                  checked={Boolean(family.settings?.archiveWatermarkEnabled)}
                  onChange={e => updateFamily({ settings: { ...family.settings, archiveWatermarkEnabled: e.target.checked } })}
                  className="w-4 h-4 text-amber-600 rounded"
                />
              </label>
            </div>
          )}

          {/* ========================================== */}
          {/* 9. OCR */}
          {/* ========================================== */}
          {activeCategory === 'ocr' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <ScanText className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '৯. বাংলা ও ইংরেজি ওসিআর ইঞ্জিন' : '9. Bangla OCR Engine'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'পাণ্ডুলিপি, খতিয়ান, পর্চা ও এনআইডি হতে স্বয়ংক্রিয় তথ্য নিষ্কাশন।' : 'Automated field extraction from deeds, NID, and land survey records.'}
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-2">
                  <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'সক্রিয় ওসিআর ইঞ্জিন: Tesseract Hybrid Bangla OCR' : 'Engine: Tesseract Hybrid Bangla OCR'}</span>
                  <p className="text-stone-500 leading-relaxed">
                    {isBn
                      ? 'যুক্তাক্ষর, প্রাচীন হরফ ও দাগ/খতিয়ান নম্বর নিখুঁতভাবে শনাক্তকরণের জন্য অপ্টিমাইজড।'
                      : 'Specialized lexicon for Bengali conjoined characters and land measurement terminology.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 10. CAMERA */}
          {/* ========================================== */}
          {activeCategory === 'camera' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Camera className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১০. ক্যামেরা ও স্ক্যানার পরিমার্জন' : '10. Camera & Scanner Enhancements'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'দলিলের অটো-ক্রপ ও পরিপ্রেক্ষিত সংশোধন ফিল্টার।' : 'Auto-cropping and document perspective correction.'}
                </p>
              </div>

              <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/20">
                <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <div className="font-bold text-stone-900 dark:text-white">{isBn ? 'ডিভাইস ক্যামেরা ও ছবি/মিডিয়া অনুমতি' : 'Camera & Photo/Media Permissions'}</div>
                    <p className="mt-1 text-[10px] text-stone-600 dark:text-stone-300">{isBn ? 'ক্যামেরা দিয়ে ছবি/দলিল স্ক্যান এবং গ্যালারি/মিডিয়া বাছাইয়ের আগে প্রয়োজনীয় সিস্টেম অনুমতি চাইবে। PDF/DOCX-এর মতো ফাইল বাছাইয়ে Android-এর সিস্টেম File Picker ব্যবহার করা হবে; পুরো স্টোরেজের স্থায়ী অনুমতি চাওয়া হবে না।' : 'Requests system access needed for camera capture and photo/media selection. PDF/DOCX files use the Android system File Picker instead of broad permanent storage access.'}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 text-[10px]">
                    <button type="button" onClick={handleCameraPermission} className="rounded-xl bg-amber-700 px-3 py-2 font-bold text-white">{isBn ? 'ক্যামেরার অনুমতি দিন' : 'Allow Camera'}</button>
                    <button type="button" onClick={handlePhotoPermission} className="rounded-xl bg-emerald-700 px-3 py-2 font-bold text-white">{isBn ? 'ছবি/মিডিয়ার অনুমতি দিন' : 'Allow Photos/Media'}</button>
                  </div>
                </div>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  <div className="rounded-xl border border-stone-200 bg-white px-3 py-2 dark:border-stone-700 dark:bg-stone-900"><b>{isBn ? 'ক্যামেরা:' : 'Camera:'}</b> {isBn ? permissionLabelBn(cameraPermissionStatus) : cameraPermissionStatus}</div>
                  <div className="rounded-xl border border-stone-200 bg-white px-3 py-2 dark:border-stone-700 dark:bg-stone-900"><b>{isBn ? 'ছবি/মিডিয়া:' : 'Photos/Media:'}</b> {isBn ? permissionLabelBn(photoPermissionStatus) : photoPermissionStatus}</div>
                </div>
                {permissionMessage && <p className="mt-2 text-[10px] font-semibold text-emerald-700 dark:text-emerald-400">{permissionMessage}</p>}
              </div>

              <div className="space-y-3 text-xs">
                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'স্বয়ংক্রিয় সীমানা শনাক্তকরণ (Auto-Edge Detection)' : 'Auto-Edge Detection'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'দলিলের চারপাশের অপ্রয়োজনীয় অংশ ছেঁটে ফেলা' : 'Crops background margins automatically'}</span>
                  </div>
                  <input type="checkbox" checked={Boolean(family.settings?.cameraAutoCrop)} onChange={e => updateFamily({ settings: { ...family.settings, cameraAutoCrop: e.target.checked } })} className="w-4 h-4 text-amber-600 rounded" />
                </label>

                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'ঐতিহাসিক দলিল বৈসাদৃশ্য বর্ধক (B&W High Contrast)' : 'Historic Document B&W Contrast Filter'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'হলুদ হয়ে যাওয়া প্রাচীন দলিলের লেখা স্পষ্ট করে' : 'Improves legibility of faded ink'}</span>
                  </div>
                  <input type="checkbox" checked={family.settings?.cameraContrastFilter === 'document_bw'} onChange={e => updateFamily({ settings: { ...family.settings, cameraContrastFilter: e.target.checked ? 'document_bw' : 'none' } })} className="w-4 h-4 text-amber-600 rounded" />
                </label>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 11. STORAGE */}
          {/* ========================================== */}
          {activeCategory === 'storage' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <HardDrive className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১১. ডিভাইস স্টোরেজ ও ক্যাশ বিশ্লেষণ' : '11. Device Storage & Cache'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'ব্রাউজার লোকাল ডেটাবেস ও অফলাইন ক্যাশের আকার।' : 'IndexedDB and localStorage breakdown.'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800">
                  <span className="text-stone-500 block">{isBn ? 'ব্যবহৃত লোকাল স্টোরেজ' : 'Used Storage'}</span>
                  <span className="text-base font-bold text-stone-900 dark:text-white">{formatStorageSize(storageBytes)}</span>
                </div>
                <div className="p-3 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800">
                  <span className="text-stone-500 block">{isBn ? 'অফলাইন অবস্থা' : 'Offline Readiness'}</span>
                  <span className="text-base font-bold text-emerald-600 dark:text-emerald-400">{typeof navigator !== 'undefined' && navigator.onLine ? (isBn ? 'অনলাইন' : 'Online') : (isBn ? 'অফলাইন' : 'Offline')}</span>
                </div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 12. PRIVACY */}
          {/* ========================================== */}
          {activeCategory === 'privacy' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <EyeOff className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১২. তথ্য গোপনীয়তা ও ফিল্ড মাস্কিং' : '12. Privacy Levels & Field Masking'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'এনআইডি, জন্ম নিবন্ধন, ফোন নম্বর ও ব্যক্তিগত ঠিকানার সুরক্ষা।' : 'Mask sensitive NID, BRN, and phone fields from guest roles.'}
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'সংবেদনশীল পরিচয়পত্র নম্বর মাস্কিং (NID & BRN Masking)' : 'Mask Identification Numbers'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'এনআইডি এবং জন্ম নিবন্ধন নম্বর হিসেবে ***৭৮৯ প্রদর্শন করবে' : 'Displays as 1980***789 for non-admins'}</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(family.settings?.enablePrivacyMasking)}
                    onChange={() => updateFamily({ settings: { ...family.settings, enablePrivacyMasking: !family.settings?.enablePrivacyMasking } })}
                    className="w-4 h-4 text-amber-600 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'জীবিত সদস্যদের গোপনীয়তা সুরক্ষা ঢাল (Living Person Shield)' : 'Living Person Privacy Shield'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'সাধারণ দর্শনার্থীদের নিকট জীবিত সদস্যদের সঠিক জন্মতারিখ গোপন রাখা হবে' : 'Hides exact birth dates for living members'}</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(family.settings?.enableLivingPersonPrivacy)}
                    onChange={() => updateFamily({ settings: { ...family.settings, enableLivingPersonPrivacy: !family.settings?.enableLivingPersonPrivacy } })}
                    className="w-4 h-4 text-amber-600 rounded"
                  />
                </label>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 13. SECURITY */}
          {/* ========================================== */}
          {activeCategory === 'security' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Lock className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১৩. নিরাপত্তা ও নিরাপত্তা অডিট লগ' : '13. Security & Audit Logging'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'নিরাপত্তা ঘটনা ও অডিট ট্রেইল (কখনোই পাসওয়ার্ড বা টোকেন রেকর্ড করা হয় না)।' : 'Security event log. Secret tokens are never logged.'}
                </p>
              </div>

              {/* Audit Log Table */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-stone-800 dark:text-stone-200">
                    {isBn ? 'সাম্প্রতিক অডিট ঘটনাপঞ্জি (Security Audit Trail):' : 'Recent Audit Events:'}
                  </span>
                  <span className="text-[10px] text-stone-500">{auditLogs.length} events</span>
                </div>

                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {auditLogs.map(log => (
                    <div key={log.id} className="p-3 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 text-xs flex items-center justify-between">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-stone-900 dark:text-white uppercase text-[10px] px-1.5 py-0.5 bg-stone-200 dark:bg-stone-800 rounded">
                            {log.eventType}
                          </span>
                          <span className="text-[10px] text-stone-400">
                            {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300">{isBn ? log.detailsBn : log.details}</p>
                      </div>
                      <span className="text-[10px] font-medium text-stone-500">by {log.actorName}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 14. NOTIFICATIONS */}
          {/* ========================================== */}
          {activeCategory === 'notifications' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Bell className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১৪. স্মরণবার্তা ও বংশ নোটিফিকেশন' : '14. Remembrances & Notifications'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'প্রয়াত পূর্বপুরুষদের মৃত্যুবার্ষিকী ও জীবিতদের জন্মদিনের স্মরণবার্তা।' : 'Remembrances for deceased ancestors and birthdays.'}
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'প্রয়াত পূর্বপুরুষদের মৃত্যুবার্ষিকী স্মরণবার্তা' : 'Deceased Ancestor Memorial Alerts'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'মৃত্যুবার্ষিকীর ৩ দিন পূর্বে স্মরণ করিয়ে দেবে' : 'Alerts 3 days before memorial anniversary'}</span>
                  </div>
                  <input type="checkbox" checked={family.settings?.remembranceNotifications !== false} onChange={e => updateFamily({ settings: { ...family.settings, remembranceNotifications: e.target.checked } })} className="w-4 h-4 text-amber-600 rounded" />
                </label>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 15. BACKUP */}
          {/* ========================================== */}
          {activeCategory === 'backup' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <CloudUpload className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১৫. বংশকথা ব্যাকআপ সংরক্ষণ (.bkf)' : '15. Full Backup Preservation'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'পরিবার, সকল সদস্য, সম্পর্ক, বৈবাহিক বন্ধন, সন্তান ও মহাফেজখানা সহ অবিকৃত ব্যাকআপ।' : 'Exports entire family graph and archival documents into standard .bkf archive.'}
                </p>
              </div>

              <div className="p-4 bg-amber-50 dark:bg-amber-950/20 rounded-2xl border border-amber-200 dark:border-amber-900 space-y-3 text-xs">
                <div className="font-bold text-amber-900 dark:text-amber-200">
                  {isBn ? 'ব্যাকআপে যা যা সংরক্ষিত হবে:' : 'Archive Backup Payload Includes:'}
                </div>
                <div className="grid grid-cols-2 gap-2 text-stone-700 dark:text-stone-300">
                  <span>• {members.length} জন সদস্যের বংশলতিকা</span>
                  <span>• {marriages.length} টি বৈবাহিক বন্ধন রেকর্ড</span>
                  <span>• {archiveRecords.length} টি ডিজিটাল ঐতিহাসিক দলিল</span>
                  <span>• ক্রিপ্টোগ্রাফিক চেকসাম সনদ</span>
                </div>

                <button
                  onClick={exportArchiveJSON}
                  className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-md transition"
                >
                  <Download className="w-4 h-4" />
                  <span>{isBn ? 'পূর্ণাঙ্গ ব্যাকআপ ফাইল ডাউনলোড করুন (.bkf)' : 'Download Full Backup (.bkf)'}</span>
                </button>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 16. RESTORE */}
          {/* ========================================== */}
          {activeCategory === 'restore' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <RotateCcw className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১৬. নিরাপদ রিস্টোর ও ডিআইএফএফ পর্যালোচনা' : '16. Safe Non-Destructive Restore'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'বর্তমান তথ্যে হাত দেওয়ার পূর্বে পরিবর্তন পর্যালোচনা ও ৩টি সংঘর্ষ নিষ্পত্তি বিকল্প।' : 'Inspect diffs before committing data. Offers 3 safe conflict options.'}
                </p>
              </div>

              <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-3 text-xs">
                <p className="text-stone-600 dark:text-stone-400">
                  {isBn ? 'বংশকথা ব্যাকআপ ফাইল নির্বাচন করুন। সিস্টেম স্বয়ংক্রিয়ভাবে ডিআইএফএফ বিশ্লেষণ উপস্থাপন করবে।' : 'Select a .bkf / .json backup file to analyze diffs.'}
                </p>
                <label className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-medium rounded-xl cursor-pointer">
                  <Upload className="w-4 h-4" />
                  <span>{isBn ? 'ব্যাকআপ ফাইল আপলোড ও পর্যালোচনা' : 'Upload Backup for Review'}</span>
                  <input ref={jsonFileInputRef} type="file" accept=".json,.bkf" onChange={handleJsonUpload} className="hidden" />
                </label>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 17. IMPORT */}
          {/* ========================================== */}
          {activeCategory === 'import' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Upload className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১৭. ১০-ধাপের নিরাপদ আমদানি উইজার্ড' : '17. 10-Step Safe Import Wizard'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'ফাইল নির্বাচন → যাচাই → প্রিভিউ → ফিল্ড ম্যাপিং → ডুপ্লিকেট নির্ণয় → সংঘর্ষ সমাধান → শুদ্ধতা সনদ।' : 'Multi-stage validation ensuring production data is never silently overwritten.'}
                </p>
              </div>

              <div className="p-6 bg-amber-500/10 rounded-2xl border border-amber-500/20 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-amber-600 text-white flex items-center justify-center mx-auto">
                  <Upload className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-sm text-stone-900 dark:text-white">
                  {isBn ? '১০-ধাপের আমদানি উইজার্ড চালু করুন' : 'Launch 10-Step Import Wizard'}
                </h3>
                <p className="text-xs text-stone-500 max-w-md mx-auto">
                  {isBn
                    ? 'GEDCOM 5.5.1, স্প্রেডশীট CSV, বা পূর্বের বংশকথা ব্যাকআপ থেকে তথ্য নিরাপদে আনুন।'
                    : 'Import from GEDCOM 5.5.1, CSV rosters, or legacy archives safely.'}
                </p>
                <button
                  onClick={() => setIsImportWizardOpen(true)}
                  className="px-6 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow-md transition"
                >
                  {isBn ? 'আমদানি উইজার্ড শুরু করুন' : 'Start Import Wizard'}
                </button>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 18. EXPORT */}
          {/* ========================================== */}
          {activeCategory === 'export' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Download className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১৮. বহুভাষিক ও সার্বজনীন এক্সপোর্ট' : '18. Universal Multilingual Export'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'JSON, আন্তর্জাতিক GEDCOM 5.5.1, স্প্রেডশীট ও মুদ্রিত বংশপুস্তক।' : 'Export into international formats (GEDCOM 5.5.1, JSON, CSV).'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-2">
                  <span className="font-bold text-stone-900 dark:text-white block">GEDCOM 5.5.1 আন্তর্জাতিক ফাইল</span>
                  <p className="text-stone-500 text-[11px]">Ancestry, MyHeritage ও Gramps-এ ব্যবহারযোগ্য স্ট্যান্ডার্ড ফরমেট।</p>
                  <button
                    onClick={exportGedcomFile}
                    className="w-full py-2 bg-stone-900 dark:bg-stone-800 text-white font-bold rounded-xl hover:bg-stone-800 transition"
                  >
                    .GED এক্সপোর্ট করুন
                  </button>
                </div>

                <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-2">
                  <span className="font-bold text-stone-900 dark:text-white block">সম্পূর্ণ পারিবারিক ভল্ট আর্কাইভ (.bkf)</span>
                  <p className="text-stone-500 text-[11px]">বংশকথা ডিজিটাল মহাফেজখানা সহ অবিকৃত চেকসাম ব্যাকআপ।</p>
                  <button
                    onClick={exportArchiveJSON}
                    className="w-full py-2 bg-amber-600 text-white font-bold rounded-xl hover:bg-amber-700 transition"
                  >
                    .bkf এক্সপোর্ট করুন
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 19. SYNCHRONIZATION */}
          {/* ========================================== */}
          {activeCategory === 'sync' && canConfigureSync && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <FolderSync className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '১৯. প্রোভাইডার-নিউট্রাল সার্ভার ও ক্লাউড ড্রাইভ সমন্বয়' : '19. Synchronization & Cloud Drive'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'Local-first স্থাপত্য। Neon, Supabase, Firebase বা Google Drive-এর সাথে নিরাপদ ব্যাকআপ।' : 'Provider-neutral sync architecture and Google Account status.'}
                </p>
              </div>

              {/* Google Drive Card */}
              <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center font-bold">
                      G
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-stone-900 dark:text-white">Google Drive / Gmail Recovery Facility</h4>
                      <p className="text-[10px] text-stone-500">
                        {googleConnected ? `সংযুক্ত: ${googleAccountEmail}` : 'কোনো গুগল অ্যাকাউন্ট বর্তমানে যুক্ত নেই'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={toggleGoogleConnection} disabled={googleBusy}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      googleConnected
                        ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                        : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                  >
                    {googleBusy ? (isBn ? 'অপেক্ষা করুন...' : 'Working...') : googleConnected ? (isBn ? 'বিচ্ছিন্ন করুন' : 'Disconnect') : (isBn ? 'গুগল অ্যাকাউন্ট যুক্ত করুন' : 'Connect Account')}
                  </button>
                </div>
                <div className="rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 p-3">
                  <label className="text-[11px] font-bold text-stone-700 dark:text-stone-300">{isBn ? 'ডিভাইসে থাকা/নির্দিষ্ট Gmail account' : 'Device / Custom Gmail account'}</label>
                  <input value={googleAccountEmail} onChange={e=>setGoogleAccountEmail(e.target.value)} placeholder="name@gmail.com" type="email" className="mt-1.5 w-full rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950 px-3 py-2 text-xs"/>
                  <p className="mt-1.5 text-[10px] text-stone-500">{isBn ? 'ফাঁকা রাখলে Google account chooser ডিভাইস/ব্রাউজারে উপলব্ধ account দেখাবে। Email দিলে সেটিই login_hint হিসেবে ব্যবহার হবে।' : 'Leave blank to use the Google account chooser; entering an email uses it as the OAuth login hint.'}</p>
                </div>

                <label className="flex items-center gap-2 text-xs font-semibold"><input type="checkbox" checked={googleAutoBackup} disabled={!googleConnected || googleBusy} onChange={e=>{setGoogleAutoBackup(e.target.checked); updateFamily({settings:{...family.settings,googleAutoBackup:e.target.checked}})}}/> {isBn?'প্রতি ২৪ ঘণ্টায় স্বয়ংক্রিয় ব্যাকআপ':'Automatic backup every 24 hours'}</label>
                <div className="flex flex-wrap gap-2">
                  <button disabled={!googleConnected || googleBusy} onClick={backupNowToGoogle} className="rounded-xl bg-emerald-600 text-white px-4 py-2 text-xs font-bold disabled:opacity-40">{isBn?'এখনই Google Drive ব্যাকআপ':'Backup to Google Drive now'}</button>
                </div>

                <div className="p-2.5 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900 rounded-xl text-[11px] text-blue-900 dark:text-blue-200">
                  <strong>{isBn ? 'নির্দেশিকা:' : 'Notice:'}</strong> {isBn ? 'Gmail account দিয়ে Google OAuth সংযোগ হলে প্রথম backup সঙ্গে সঙ্গে হবে; এরপর Auto Backup চালু থাকলে স্বয়ংক্রিয়ভাবে চলবে।' : 'After Google OAuth connects, the first backup runs immediately; Auto Backup can continue automatically.'}
                </div>
              </div>

              {/* Unified server selector */}
              <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h4 className="font-bold text-sm text-stone-900 dark:text-white flex items-center gap-2"><Server className="w-5 h-5 text-emerald-600"/> {isBn ? 'সার্ভার তালিকা ও এক-ক্লিক লগইন' : 'Server List & One-Click Login'}</h4>
                    <p className="text-[11px] text-stone-500 mt-1">{isBn ? 'যেকোনো একটি সার্ভার সংযুক্ত করুন। এরপর Family Share, Join Code ও Remote Sync একই সার্ভার ব্যবহার করবে।' : 'Connect one server. Family Share, Join Codes and remote sync will reuse it automatically.'}</p>
                  </div>
                  <Wifi className="w-5 h-5 text-emerald-600"/>
                </div>
                <div className="space-y-3">
                  {serverProfiles.map(profile => {
                    const active = profile.id === activeServerId;
                    return <div key={profile.id} className={`rounded-2xl border p-3 ${active ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/30' : 'border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900'}`}>
                      <div className="flex flex-col lg:flex-row lg:items-center gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2"><span className="font-bold text-xs text-stone-900 dark:text-white">{isBn ? profile.nameBn : profile.nameEn}</span>{active && <span className="text-[9px] rounded-full px-2 py-0.5 bg-emerald-600 text-white font-bold">{isBn?'সক্রিয়':'ACTIVE'}</span>}{profile.status && <span className={`text-[9px] rounded-full px-2 py-0.5 font-bold ${profile.status==='online'?'bg-emerald-100 text-emerald-700':'bg-rose-100 text-rose-700'}`}>{profile.status==='online'?'ONLINE':'OFFLINE'}</span>}</div>
                          <input value={profile.endpoint} onChange={e=>updateServerProfile(profile.id,{endpoint:e.target.value})} placeholder={isBn?'https://your-server.example.com':'https://your-server.example.com'} className="mt-2 w-full rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950 px-3 py-2 text-xs"/>
                          <input value={profile.token || ''} onChange={e=>updateServerProfile(profile.id,{token:e.target.value})} placeholder={isBn?'সার্ভার টোকেন (প্রয়োজনে)':'Server access token (optional)'} type="password" className="mt-2 w-full rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950 px-3 py-2 text-xs"/>
                        </div>
                        <button onClick={()=>connectServer(profile)} disabled={serverBusyId===profile.id || !profile.endpoint.trim()} className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white disabled:opacity-40"><LogIn className="w-4 h-4"/>{serverBusyId===profile.id ? (isBn?'সংযোগ হচ্ছে…':'Connecting…') : (isBn?'লগইন/সংযোগ':'Login / Connect')}</button>
                      </div>
                    </div>;
                  })}
                </div>
                <div className="text-[10px] text-stone-500">{isBn ? 'নিরাপত্তা: সার্ভার URL/টোকেন এই ডিভাইসের local settings-এ রাখা হয়। Token না দিলে server public health/invite policy অনুযায়ী কাজ করবে।' : 'Security: server URL/token are stored in this device settings. Token is optional unless your server requires it.'}</div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 20. PERMISSIONS (RBAC) */}
          {/* ========================================== */}
          {activeCategory === 'permissions' && canManageRoles && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <ShieldCheck className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '২০. ৬টি ভূমিকা ও প্রবেশাধিকার নিয়ন্ত্রণ (RBAC)' : '20. Roles & Permissions (RBAC)'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'Owner, Super Admin, Admin, Editor, Contributor, Viewer ভূমিকা ও তাদের সুনির্দিষ্ট অধিকার।' : 'Strict 6-tier permission enforcement.'}
                </p>
              </div>

              {/* Role Tester Switcher: development-only; production accounts cannot self-elevate */}
              {import.meta.env.DEV && <div className="space-y-3">
                <label className="text-xs font-bold text-stone-800 dark:text-stone-200 block">
                  {isBn ? 'সক্রিয় অ্যাকাউন্ট ভূমিকা পরিবর্তন ও পরীক্ষা করুন:' : 'Switch Role for Testing:'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(['owner', 'super_admin', 'admin', 'co_admin', 'tester', 'editor', 'contributor', 'viewer'] as UserRole[]).map(r => (
                    <button
                      key={r}
                      onClick={() => handleRoleChange(r)}
                      className={`p-2.5 rounded-xl border text-xs font-semibold capitalize text-center transition ${
                        userAccount.role === r
                          ? 'border-amber-600 bg-amber-50 dark:bg-amber-950 text-amber-900 dark:text-amber-200 font-bold'
                          : 'border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-400'
                      }`}
                    >
                      {r.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>}

              {/* Permission Matrix for current role */}
              <div className="space-y-2 pt-2">
                <h4 className="font-bold text-xs text-stone-800 dark:text-stone-200">
                  {isBn ? `সক্রিয় ভূমিকার অধিকার (${userAccount.role}):` : `Active Role Capabilities (${userAccount.role}):`}
                </h4>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {Object.entries(ROLE_PERMISSIONS[userAccount.role]).map(([key, val]) => (
                    <div key={key} className="p-2 bg-stone-50 dark:bg-stone-950 rounded-xl border border-stone-200 dark:border-stone-800 flex items-center justify-between">
                      <span className="text-[11px] text-stone-600 dark:text-stone-400 truncate pr-2">{key}</span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${val ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-stone-200 text-stone-500 dark:bg-stone-800'}`}>
                        {val ? 'অনুমোদিত' : 'অনুমোদনহীন'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 21. ACCESSIBILITY */}
          {/* ========================================== */}
          {activeCategory === 'accessibility' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <AccessibilityIcon className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '২১. সহজগম্যতা (Accessibility & Readability)' : '21. Accessibility & Readability'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'উচ্চ বৈসাদৃশ্য, ডিসলেক্সিক বান্ধব ফন্ট ও মোশন হ্রাসকরণ।' : 'High contrast modes and accessible typography.'}
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'উচ্চ বৈসাদৃশ্য মোড (High Contrast Mode)' : 'High Contrast Mode'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'দৃষ্টি প্রতিবন্ধকতা বা বয়স্কদের জন্য সর্বোচ্চ স্বচ্ছতা' : 'WCAG AAA certified contrast ratio'}</span>
                  </div>
                  <input type="checkbox" checked={Boolean(family.settings?.highContrast)} onChange={e => updateFamily({ settings: { ...family.settings, highContrast: e.target.checked } })} className="w-4 h-4 text-amber-600 rounded" />
                </label>

                <label className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 cursor-pointer">
                  <div>
                    <span className="font-bold text-stone-900 dark:text-white block">{isBn ? 'অ্যানিমেশন হ্রাসকরণ (Reduce Motion)' : 'Reduced Motion'}</span>
                    <span className="text-[10px] text-stone-500">{isBn ? 'স্ক্রিন ফ্লিকার বা মোশন সেনসিটিভ ব্যবহারকারীদের জন্য' : 'Disables non-essential transitions'}</span>
                  </div>
                  <input type="checkbox" checked={!Boolean(family.settings?.enableAnimations)} onChange={e => updateFamily({ settings: { ...family.settings, enableAnimations: !e.target.checked } })} className="w-4 h-4 text-amber-600 rounded" />
                </label>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 22. VALIDATION */}
          {/* ========================================== */}
          {activeCategory === 'validation' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <CheckCircle className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '২২. বংশতালিকা শুদ্ধতা যাচাই নীতি' : '22. Validation Schema Rules'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'চক্রাকার অবিভাবকত্ব ও বয়স কালানুক্রমিক অসঙ্গতি রোধ নীতি।' : 'Rules preventing circular parent loops and chronological impossibility.'}
                </p>
              </div>

              <div className="space-y-2 text-xs">
                {[
                  'সন্তানের জন্ম পিতা বা মাতার জন্মের পূর্বে হতে পারবে না',
                  'কোনো ব্যক্তি নিজের পিতা/মাতা বা পূর্বপুরুষ হতে পারবে না (Anti-Circular Loop)',
                  'বিবাহের তারিখ সংশ্লিষ্ট পক্ষদ্বয়ের মৃত্যুর পরবর্তী হতে পারবে না',
                  'একই ব্যক্তিসংখ্যা (ID) একাধিক ব্যক্তির মাঝে ব্যবহার করা যাবে না'
                ].map((rule, i) => (
                  <div key={i} className="p-3 bg-stone-50 dark:bg-stone-950 rounded-xl border border-stone-200 dark:border-stone-800 flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                    <span className="text-stone-700 dark:text-stone-300">{rule}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 23. DATA REPAIR */}
          {/* ========================================== */}
          {activeCategory === 'repair' && canRunIntegrityRepair && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Wrench className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '২৩. ৮-পয়েন্ট বংশতালিকা ডেটা মেরামত' : '23. 8-Point Data Integrity Repair'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'ভাঙা সংযোগ, সন্তান-পিতা দ্বিমুখী সম্পর্ক ও বিচ্ছিন্ন তথ্য স্বয়ংক্রিয় মেরামত।' : 'Interactive diagnostic & healing suite.'}
                </p>
              </div>

              <IntegrityRepairView onSelectMember={onSelectMember} />
            </div>
          )}

          {/* ========================================== */}
          {/* 24. ABOUT */}
          {/* ========================================== */}
          {activeCategory === 'about' && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Info className="w-6 h-6 text-amber-600" />
                  <span>{isBn ? '২৪. বংশকথা পরিচিতি ও উন্মুক্ত ঐতিহ্য সনদ' : '24. About Bongshokotha & Heritage Manifesto'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? `সংস্করণ v${APP_VERSION} • Apache 2.0 Open Source License.` : `Version v${APP_VERSION} • Apache 2.0 Open Source License.`}
                </p>
              </div>

              <div className="p-4 bg-stone-50 dark:bg-stone-950 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-3 text-xs leading-relaxed text-stone-600 dark:text-stone-400">
                <p>
                  <strong className="text-stone-900 dark:text-white">বংশকথা (BONGSHOKOTHA)</strong> হলো বাঙালি ও আন্তর্জাতিক পরিবারের শেকড় অন্বেষণ ও ইতিহাস সংরক্ষণের সম্পূর্ণ স্বাধীন, লোকাল-ফার্স্ট মুক্ত প্রযুক্তি।
                </p>
                <p>
                  এটি পূর্বপুরুষদের রক্তের সংযোগ, ঐতিহাসিক দলিলপত্রাদি (খতিয়ান, সিএস, এসএ, আরএস, কবুলিয়ত) ও স্মৃতিচারণ অডিও সংরক্ষণের বিশ্বস্ত উন্মুক্ত সনদ।
                </p>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* 25. RESET (Safe Reset Settings vs Destructive Factory Reset) */}
          {/* ========================================== */}
          {activeCategory === 'reset' && canFactoryReset && (
            <div className="space-y-6">
              <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white flex items-center gap-2">
                  <Trash2 className="w-6 h-6 text-rose-600" />
                  <span>{isBn ? '২৫. সেটিংস রিসেট বনাম ফ্যাক্টরি রিসেট' : '25. Reset Settings vs Factory Reset'}</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  {isBn ? 'ইউজার ইন্টারফেস পছন্দ প্রাথমিককরণ (নিরাপদ) অথবা সম্পূর্ণ ডেটাবেস পরিচ্ছন্নকরণ (ধ্বংসাত্মক)।' : 'Safe preference reset vs destructive database wipe.'}
                </p>
              </div>

              {/* LEVEL 1: SAFE RESET SETTINGS */}
              <div className="p-5 rounded-2xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/20 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-200 font-bold text-sm">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                    <span>{isBn ? 'লেভেল ১: সেটিংস রিসেট (নিরাপদ ও অক্ষুণ্ণ)' : 'Level 1: Reset Settings (Safe)'}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                    100% Data Preserved
                  </span>
                </div>
                <p className="text-xs text-stone-600 dark:text-stone-400">
                  {isBn
                    ? 'এটি ইউজার ইন্টারফেস পছন্দসমূহ, থিম ও ভাষা প্রাথমিক অবস্থায় ফিরিয়ে আনে। পারিবারিক কোনো তথ্য, সদস্য, সম্পর্ক বা মহাফেজখানা দলিল মুছে যাবে না।'
                    : 'Restores UI preferences, theme, and language defaults. Family members, marriages, and archive records are untouched.'}
                </p>

                {isResetSettingsSuccess && (
                  <div className="p-2 bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold flex items-center gap-1.5">
                    <Check className="w-4 h-4" />
                    <span>সেটিংস সফলভাবে প্রাথমিক অবস্থায় রিসেট হয়েছে!</span>
                  </div>
                )}

                <button
                  onClick={executeSafeResetSettings}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs shadow-sm transition"
                >
                  {isBn ? 'সেটিংস রিসেট করুন (পারিবারিক তথ্য অক্ষুণ্ণ রেখে)' : 'Reset UI Preferences Only'}
                </button>
              </div>

              {/* LEVEL 2: DESTRUCTIVE FACTORY RESET */}
              <div className="p-5 rounded-2xl border border-rose-300 dark:border-rose-900 bg-rose-50/50 dark:bg-rose-950/20 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-rose-900 dark:text-rose-200 font-bold text-sm">
                    <AlertTriangle className="w-5 h-5 text-rose-600" />
                    <span>{isBn ? 'লেভেল ২: ফ্যাক্টরি রিসেট (সম্পূর্ণ ডেটাবেস মোছা)' : 'Level 2: Factory Reset (Destructive)'}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300">
                    Destructive Action
                  </span>
                </div>
                <p className="text-xs text-stone-600 dark:text-stone-400">
                  {isBn
                    ? 'এটি স্থানীয় সকল পারিবারিক তথ্য, সদস্য তালিকা, বৈবাহিক সম্পর্ক ও মহাফেজখানার দলিল স্থায়ীভাবে মুছে ফেলে খালি প্রাথমিক অবস্থায় ফিরিয়ে নেবে; ডেমো/নমুনা তথ্য পুনরুদ্ধার করবে না।'
                    : 'Permanently wipes local lineage and vaults. Requires explicit verification and backup opportunity.'}
                </p>

                <button
                  onClick={() => setIsFactoryDialogOpen(true)}
                  className="px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white font-bold rounded-xl text-xs shadow-sm transition"
                >
                  {isBn ? 'ফ্যাক্টরি রিসেট প্রক্রিয়া শুরু করুন...' : 'Initiate Factory Reset...'}
                </button>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* FACTORY RESET CONFIRMATION MODAL */}
      {isFactoryDialogOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-stone-900 border border-rose-500 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <AlertTriangle className="w-8 h-8 flex-shrink-0" />
              <div>
                <h3 className="font-bold text-base text-stone-900 dark:text-white">ফ্যাক্টরি রিসেট চূড়ান্ত সতর্কবার্তা!</h3>
                <p className="text-xs text-stone-500">ধ্বংসাত্মক পদক্ষেপ • মুছে ফেলা তথ্য ফিরে পাওয়া সম্ভব নয়</p>
              </div>
            </div>

            <div className="p-3 bg-stone-50 dark:bg-stone-950 rounded-xl border border-stone-200 dark:border-stone-800 text-xs space-y-1.5 text-stone-700 dark:text-stone-300">
              <span className="font-bold block text-stone-900 dark:text-white">মুছে যাওয়ার প্রভাব:</span>
              <div>• {members.length} জন সদস্যের জীবনী ও তথ্য স্থায়ীভাবে অপসারিত হবে</div>
              <div>• {marriages.length} টি বৈবাহিক সংযোগ মুছে যাবে</div>
              <div>• {archiveRecords.length} টি মহাফেজখানা দলিল খালি হয়ে যাবে</div>
            </div>

            <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 rounded-xl text-xs flex items-center justify-between">
              <span className="text-amber-900 dark:text-amber-200">মুছে ফেলার পূর্বে ব্যাকআপ নিতে চান?</span>
              <button
                onClick={exportArchiveJSON}
                className="px-3 py-1 bg-amber-600 text-white font-bold rounded-lg text-xs"
              >
                ব্যাকআপ নিন
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <label className="block text-stone-700 dark:text-stone-300">
                নিশ্চিত করতে নিচে <strong>DELETE</strong> অথবা <strong>মুছে ফেলুন</strong> টাইপ করুন:
              </label>
              <input
                type="text"
                value={factoryConfirmText}
                onChange={(e) => setFactoryConfirmText(e.target.value)}
                placeholder="DELETE"
                className="w-full p-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-950 text-stone-900 dark:text-white font-mono"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setIsFactoryDialogOpen(false)}
                className="flex-1 py-2.5 border border-stone-300 dark:border-stone-700 rounded-xl text-xs font-bold text-stone-700 dark:text-stone-300"
              >
                বাতিল করুন
              </button>
              <button
                onClick={executeFactoryReset}
                disabled={factoryConfirmText !== 'DELETE' && factoryConfirmText !== 'মুছে ফেলুন'}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white font-bold rounded-xl text-xs transition"
              >
                স্থায়ীভাবে মুছে ফেলুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Safe Restore Diff Modal */}
      {pendingArchive && (
        <SafeRestoreDiffModal
          isOpen={isDiffModalOpen}
          onClose={() => {
            setIsDiffModalOpen(false);
            setPendingArchive(null);
          }}
          incomingArchive={pendingArchive}
          currentMembers={members}
          currentMarriages={marriages}
          onConfirmRestore={async (strategy) => {
            const res = await importArchiveJSON(JSON.stringify(pendingArchive), strategy);
            alert(res.message);
          }}
          isBn={isBn}
        />
      )}

      {/* 10-Step Import Wizard Modal */}
      <ImportWizardModal
        isOpen={isImportWizardOpen}
        onClose={() => setIsImportWizardOpen(false)}
      />
    </div>
  );
};
