/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Relationship Integrity Diagnostics & Safe Repair Center
 * 
 * 8-Point Diagnostic Checks:
 * 1. Circular Parent Loops (Cycles)
 * 2. Missing Reciprocal Parent Links
 * 3. Missing Reciprocal Child Links
 * 4. Duplicate Children in Marriage
 * 5. Invalid Spouse References
 * 6. Broken Marriage References
 * 7. Dangling / Non-Existent Member IDs
 * 8. Chronological Conflicts
 */

import React, { useState } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { RepairResult } from '../engine/validationEngine';
import { toBanglaDigits } from '../engine/banglaCalendar';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Wrench,
  RefreshCw,
  Info,
  Layers,
  Heart,
  Users,
  Check,
  AlertCircle
} from 'lucide-react';

interface IntegrityRepairViewProps {
  onSelectMember: (memberId: string) => void;
}

export const IntegrityRepairView: React.FC<IntegrityRepairViewProps> = ({
  onSelectMember
}) => {
  const {
    validationReport,
    runRepair,
    members,
    marriages,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const [isRepairing, setIsRepairing] = useState(false);
  const [lastRepairResult, setLastRepairResult] = useState<RepairResult | null>(null);

  const quality = React.useMemo(() => {
    const normalize = (v?: string) => (v || '').trim().replace(/[০-৯]/g, digit => String('০১২৩৪৫৬৭৮৯'.indexOf(digit))).replace(/[\s-]+/g, '').toLowerCase();
    const byNid = new Map<string, string[]>();
    const byNameDob = new Map<string, string[]>();
    const incomplete = members.filter(m => {
      const missing = [!m.profilePhoto, !m.birth?.date?.year, !m.birth?.place?.district && !m.birth?.place?.village, !m.fatherId && !m.fatherNameBn, !m.motherId && !m.motherNameBn, !m.identityDocs?.nidNumber && !m.identityDocs?.birthRegistrationNumber].filter(Boolean).length;
      return missing >= 3;
    });
    for (const m of members) {
      const nid = normalize(m.identityDocs?.nidNumber);
      if (nid) byNid.set(nid, [...(byNid.get(nid) || []), m.id]);
      const name = normalize(m.banglaName || m.fullName || m.englishName);
      const dob = m.birth?.date?.isoString || [m.birth?.date?.year, m.birth?.date?.month, m.birth?.date?.day].filter(Boolean).join('-');
      if (name && dob) { const k = `${name}|${dob}`; byNameDob.set(k, [...(byNameDob.get(k) || []), m.id]); }
    }
    return {
      duplicateNidGroups: [...byNid.values()].filter(ids => ids.length > 1).length,
      duplicateNameDobGroups: [...byNameDob.values()].filter(ids => ids.length > 1).length,
      incompleteProfiles: incomplete.length
    };
  }, [members]);

  const handleRunRepair = async () => {
    setIsRepairing(true);
    try {
      const result = await runRepair();
      setLastRepairResult(result);
    } finally {
      setIsRepairing(false);
    }
  };

  const checkItems = [
    {
      id: 'cycle',
      titleBn: '১. চক্রাকার বংশতালিকা পরীক্ষা (Circular Ancestry Loop)',
      titleEn: '1. Circular Ancestry Loop Detection',
      descBn: 'কোনো ব্যক্তি নিজেরই পূর্বপুরুষ হিসেবে লুপে আবদ্ধ কিনা যাচাই',
      descEn: 'Ensures no member is recorded as their own ancestor via DFS graph cycles',
      hasIssue: validationReport.issues.some(i => i.type === 'circular_parent')
    },
    {
      id: 'recip_parent',
      titleBn: '২. পারস্পরিক বৈবাহিক ও অভিভাবক সংযোগ (Reciprocal Parent Links)',
      titleEn: '2. Reciprocal Parent-Marriage Synchronization',
      descBn: 'বিবাহের রেকর্ড এবং স্বামী-স্ত্রীর প্রোফাইলে পারস্পরিক রেফারেন্স যাচাই',
      descEn: 'Ensures marriage IDs match both husband and wife profiles',
      hasIssue: validationReport.issues.some(i => i.type === 'missing_reciprocal_parent')
    },
    {
      id: 'recip_child',
      titleBn: '৩. সন্তানের পারস্পরিক সংযোগ যাচাই (Reciprocal Child Links)',
      titleEn: '3. Reciprocal Child-Marriage Links',
      descBn: 'পিতা-মাতার বিবাহ নথিতে সন্তানের অন্তর্ভুক্তি নিশ্চিতকরণ',
      descEn: 'Ensures children with biological parents exist in the marriage record',
      hasIssue: validationReport.issues.some(i => i.type === 'missing_reciprocal_child')
    },
    {
      id: 'dup_child',
      titleBn: '৪. দ্বৈত সন্তান اندراج পরীক্ষা (Duplicate Children Check)',
      titleEn: '4. Duplicate Children Detection',
      descBn: 'একই বিবাহে একই সন্তানের একাধিকবার পুনরাবৃত্তি আছে কিনা পরীক্ষা',
      descEn: 'Ensures no child is duplicated within a marriage record',
      hasIssue: validationReport.issues.some(i => i.type === 'duplicate_child')
    },
    {
      id: 'spouse_ref',
      titleBn: '৫. অস্তিত্বহীন স্বামী/স্ত্রী রেফারেন্স পরীক্ষা (Spouse Reference Validation)',
      titleEn: '5. Spouse Reference Validity',
      descBn: 'বিবাহে উল্লেখিত স্বামী বা স্ত্রী সদস্য তালিকায় বিদ্যমান কিনা যাচাই',
      descEn: 'Validates that husband and wife IDs exist in member records',
      hasIssue: validationReport.issues.some(i => i.type === 'invalid_spouse')
    },
    {
      id: 'broken_mar',
      titleBn: '৬. অবলুপ্ত বিবাহ রেফারেন্স পরিচ্ছন্নতা (Broken Marriage Ref Check)',
      titleEn: '6. Broken Marriage References',
      descBn: 'সদস্যের তালিকায় ডিলিট হওয়া বিবাহের রেফারেন্স পরিষ্কার করা',
      descEn: 'Checks for dangling marriage IDs in member records',
      hasIssue: validationReport.issues.some(i => i.type === 'broken_marriage')
    },
    {
      id: 'invalid_id',
      titleBn: '৭. সদস্য আইডি ও পিতা-মাতার আইডি শুদ্ধতা (Member ID Integrity)',
      titleEn: '7. Member & Parent ID Integrity',
      descBn: 'পিতা বা মাতা হিসেবে অনুল্লিখিত আইডির অবৈধ সংযোগ পরীক্ষা',
      descEn: 'Validates fatherId and motherId point to valid existing members',
      hasIssue: validationReport.issues.some(i => i.type === 'invalid_id')
    },
    {
      id: 'chronology',
      titleBn: '৮. কালানুক্রমিক অসঙ্গতি যাচাই (Chronological Anomaly Check)',
      titleEn: '8. Chronological Anomaly Validation',
      descBn: 'পিতা/মাতার জন্ম সন্তানের পূর্বে এবং জন্ম মৃত্যুর পূর্বে কিনা যাচাই',
      descEn: 'Ensures parents are older than children and death follows birth',
      hasIssue: validationReport.issues.some(i => i.type === 'chronology_conflict')
    }
  ];

  return (
    <div className="space-y-6 pb-16">
      <section className="rounded-2xl border border-amber-900/10 bg-white p-5 shadow-xs dark:border-stone-800 dark:bg-stone-900">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="font-serif text-xl font-bold text-amber-950 dark:text-amber-100">{isBn ? 'ডেটা স্বাস্থ্য কেন্দ্র' : 'Data Health Center'}</h2>
            <p className="text-xs text-stone-500 mt-1">{isBn ? 'সম্ভাব্য ডুপ্লিকেট, অসম্পূর্ণ Profile এবং সম্পর্কের সমস্যা এক জায়গায় যাচাই করুন।' : 'Review duplicate candidates, incomplete profiles and relationship integrity in one place.'}</p>
          </div>
          <ShieldCheck className="w-7 h-7 text-amber-700" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-xl border p-3 bg-rose-50/60 dark:bg-rose-950/20"><b className="text-lg">{isBn ? toBanglaDigits(quality.duplicateNidGroups) : quality.duplicateNidGroups}</b><div className="text-xs text-stone-500">{isBn ? 'একই NID-এর সম্ভাব্য ডুপ্লিকেট' : 'Possible duplicate NID groups'}</div></div>
          <div className="rounded-xl border p-3 bg-amber-50/60 dark:bg-amber-950/20"><b className="text-lg">{isBn ? toBanglaDigits(quality.duplicateNameDobGroups) : quality.duplicateNameDobGroups}</b><div className="text-xs text-stone-500">{isBn ? 'নাম+জন্মতারিখের সম্ভাব্য ডুপ্লিকেট' : 'Possible name+DOB duplicates'}</div></div>
          <div className="rounded-xl border p-3 bg-sky-50/60 dark:bg-sky-950/20"><b className="text-lg">{isBn ? toBanglaDigits(quality.incompleteProfiles) : quality.incompleteProfiles}</b><div className="text-xs text-stone-500">{isBn ? 'গুরুতরভাবে অসম্পূর্ণ Profile' : 'Seriously incomplete profiles'}</div></div>
        </div>
        <p className="text-[10px] text-stone-400 mt-3">{isBn ? 'ডুপ্লিকেট সংখ্যা শুধু সম্ভাব্য মিল—কোনো সদস্য স্বয়ংক্রিয়ভাবে মুছে বা merge করা হয় না।' : 'Duplicate counts are candidates only; no member is automatically deleted or merged.'}</p>
      </section>
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 rounded-2xl border border-amber-900/10 bg-white p-5 shadow-xs dark:border-stone-800 dark:bg-stone-900">
        <div>
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-amber-950 dark:text-amber-100">
            {isBn ? 'ডাটা শুদ্ধতা যাচাই ও নিরাপদ মেরামত' : 'Integrity & Safe Auto-Repair'}
          </h2>
          <p className="text-xs text-stone-500">
            {isBn
              ? '৮-দফা পূর্ণাঙ্গ স্ক্যান। কোনো মনগড়া তথ্য যুক্ত না করে নিরাপদভাবে লিংক মেরামত করে।'
              : '8-point diagnostic scan and safe link repair without inventing unverified facts.'}
          </p>
        </div>

        <button
          onClick={handleRunRepair}
          disabled={isRepairing}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber-800 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm hover:bg-amber-900 transition disabled:opacity-50 dark:bg-amber-700 dark:hover:bg-amber-600"
        >
          {isRepairing ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Wrench className="h-4 w-4" />
          )}
          <span>{isBn ? 'সমস্ত লিংক মেরামত করুন (Repair All Links)' : 'Repair All Links'}</span>
        </button>
      </div>

      {/* Repair Result Log Banner (if repair just ran) */}
      {lastRepairResult && (
        <div className="rounded-2xl border border-emerald-600/20 bg-emerald-50 p-5 dark:border-emerald-500/20 dark:bg-emerald-950/40 space-y-3">
          <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-300 font-serif font-bold text-base">
            <CheckCircle2 className="h-5 w-5 text-emerald-600" />
            <span>
              {isBn
                ? `নিরাপদ মেরামত সম্পন্ন! (${toBanglaDigits(lastRepairResult.repairedCount)}টি ত্রুটি সংশোধিত)`
                : `Safe Repair Finished! (${lastRepairResult.repairedCount} links synchronized)`}
            </span>
          </div>

          {lastRepairResult.repairLog.length > 0 ? (
            <div className="rounded-xl bg-white/80 p-3 text-xs font-mono text-stone-700 space-y-1 dark:bg-stone-900/80 dark:text-stone-300 max-h-48 overflow-y-auto">
              {lastRepairResult.repairLog.map((log, idx) => (
                <div key={idx} className="flex items-center gap-1.5">
                  <Check className="h-3 w-3 text-emerald-600 shrink-0" />
                  <span>{log}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-emerald-800 dark:text-emerald-300">
              {isBn ? 'সমস্ত সংযোগ ইতিপূর্বেই সম্পূর্ণ নিখুঁত ছিল।' : 'All links were already fully synchronized.'}
            </p>
          )}
        </div>
      )}

      {/* 8-Point Diagnostic Checklist Matrix */}
      <div className="rounded-2xl border border-amber-900/10 bg-white p-6 shadow-xs dark:border-stone-800 dark:bg-stone-900 space-y-4">
        <h3 className="font-serif text-base sm:text-lg font-bold text-amber-950 dark:text-amber-100 pb-2 border-b border-stone-100 dark:border-stone-800">
          {isBn ? '৮-দফা শুদ্ধতা যাচাইকরণ তালিকা (8-Point Integrity Audit)' : '8-Point Genealogy Integrity Audit'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {checkItems.map(item => (
            <div
              key={item.id}
              className={`flex items-start gap-3 rounded-xl border p-3.5 transition ${
                item.hasIssue
                  ? 'border-rose-300 bg-rose-50/60 dark:border-rose-900/50 dark:bg-rose-950/30'
                  : 'border-emerald-200 bg-emerald-50/40 dark:border-emerald-900/40 dark:bg-emerald-950/20'
              }`}
            >
              <div className="mt-0.5 shrink-0">
                {item.hasIssue ? (
                  <AlertTriangle className="h-4 w-4 text-rose-600" />
                ) : (
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                )}
              </div>
              <div className="space-y-0.5">
                <div className={`text-xs font-bold ${
                  item.hasIssue ? 'text-rose-950 dark:text-rose-200' : 'text-emerald-950 dark:text-emerald-200'
                }`}>
                  {isBn ? item.titleBn : item.titleEn}
                </div>
                <div className="text-[11px] text-stone-600 dark:text-stone-400">
                  {isBn ? item.descBn : item.descEn}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detected Issues Details List */}
      <div className="rounded-2xl border border-amber-900/10 bg-white p-6 shadow-xs dark:border-stone-800 dark:bg-stone-900 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-stone-100 dark:border-stone-800">
          <h3 className="font-serif text-base sm:text-lg font-bold text-amber-950 dark:text-amber-100">
            {isBn ? 'শনাক্তকৃত অসঙ্গতির বিস্তারিত বিবরণ' : 'Detected Issues & Warnings'}
          </h3>
          <span className="text-xs text-stone-500 font-mono">
            {isBn
              ? `${toBanglaDigits(validationReport.issues.length)}টি বিষয়`
              : `${validationReport.issues.length} items`}
          </span>
        </div>

        {validationReport.issues.length === 0 ? (
          <div className="rounded-xl bg-emerald-50/60 p-8 text-center text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300 space-y-2">
            <CheckCircle2 className="mx-auto h-8 w-8 text-emerald-600" />
            <div className="font-serif font-bold text-base">
              {isBn ? 'বংশলতিকার সমস্ত তথ্য শতভাগ বিশুদ্ধ!' : 'All Genealogy Records are 100% Sound!'}
            </div>
            <p className="text-xs text-stone-600 dark:text-stone-400 max-w-md mx-auto">
              {isBn
                ? 'কোনো চক্রাকার লুপ, দ্বৈত সন্তান বা সংযোগহীন রেকর্ড পাওয়া যায়নি। ডেটা অক্ষুণ্ণ রয়েছে।'
                : 'No circular loops, duplicate children, or broken links detected.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {validationReport.issues.map(issue => (
              <div
                key={issue.id}
                className={`rounded-xl border p-4 space-y-2 ${
                  issue.severity === 'error'
                    ? 'border-rose-300 bg-rose-50/50 dark:border-rose-900/50 dark:bg-rose-950/30'
                    : 'border-amber-300 bg-amber-50/50 dark:border-amber-900/50 dark:bg-amber-950/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                      issue.severity === 'error' ? 'bg-rose-600 text-white' : 'bg-amber-600 text-white'
                    }`}>
                      {issue.severity}
                    </span>
                    <span className="text-xs font-bold text-stone-900 dark:text-stone-100">
                      {isBn ? issue.banglaTitle : issue.title}
                    </span>
                  </div>

                  {issue.canAutoRepair && (
                    <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md dark:bg-emerald-950 dark:text-emerald-300">
                      {isBn ? 'স্বয়ংক্রিয় মেরামতযোগ্য' : 'Auto-Repairable'}
                    </span>
                  )}
                </div>

                <p className="text-xs text-stone-700 dark:text-stone-300">
                  {issue.description}
                </p>

                {issue.affectedMemberIds.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    <span className="text-[10px] font-medium text-stone-500">
                      {isBn ? 'সংশ্লিষ্ট সদস্য:' : 'Affected members:'}
                    </span>
                    {issue.affectedMemberIds.map(mid => {
                      const member = members.find(m => m.id === mid);
                      return member ? (
                        <button
                          key={mid}
                          onClick={() => onSelectMember(mid)}
                          className="rounded-md bg-white border border-stone-200 px-1.5 py-0.5 text-[10px] font-medium text-amber-900 hover:bg-amber-100 transition dark:bg-stone-800 dark:border-stone-700 dark:text-amber-200"
                        >
                          {isBn ? member.banglaName || member.fullName : member.englishName || member.fullName} ()
                        </button>
                      ) : null;
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
