import React from 'react';

interface AppErrorBoundaryProps { children: React.ReactNode; }
interface AppErrorBoundaryState { hasError: boolean; errorId: string; }

/** Keeps a recoverable render failure from leaving the whole application blank. */
export class AppErrorBoundary extends React.Component<AppErrorBoundaryProps, AppErrorBoundaryState> {
  state: AppErrorBoundaryState = { hasError: false, errorId: '' };

  static getDerivedStateFromError(): AppErrorBoundaryState {
    return { hasError: true, errorId: `BK-${Date.now().toString(36).toUpperCase()}` };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // Keep diagnostics local; do not send family/member data to a remote service.
    try {
      const detail = { errorId: this.state.errorId, message: error?.message || 'Unknown render error', componentStack: info?.componentStack || '', occurredAt: new Date().toISOString() };
      sessionStorage.setItem('bongshokotha_last_render_error_v1', JSON.stringify(detail));
    } catch { /* Storage can be disabled; the recovery UI still works. */ }
  }

  private recover = () => {
    this.setState({ hasError: false, errorId: '' });
    window.location.reload();
  };

  render() {
    if (!this.state.hasError) return this.props.children;
    const english = (() => { try { return localStorage.getItem('bongshokotha_language') === 'en'; } catch { return false; } })();
    return (
      <main className="bk-error-screen" role="alert" aria-live="assertive">
        <section className="bk-error-card">
          <div className="bk-error-mark" aria-hidden="true">!</div>
          <p className="bk-error-kicker">BONGSHOKOTHA · RECOVERY</p>
          <h1>{english ? 'Something went wrong' : 'একটি সমস্যা হয়েছে'}</h1>
          <p>{english ? 'Your family data has not been intentionally deleted. Reload the application to try again. If the problem repeats, keep the reference code for support.' : 'অ্যাপের একটি অংশে সমস্যা হয়েছে। আপনার পারিবারিক তথ্য ইচ্ছাকৃতভাবে মুছে ফেলা হয়নি। অ্যাপটি আবার চালু করে দেখুন। সমস্যা আবার হলে সহায়তার জন্য রেফারেন্স কোডটি সংরক্ষণ করুন।'}</p>
          <code>{this.state.errorId}</code>
          <button type="button" onClick={this.recover}>{english ? 'Reload application' : 'অ্যাপ পুনরায় চালু করুন'}</button>
        </section>
      </main>
    );
  }
}
