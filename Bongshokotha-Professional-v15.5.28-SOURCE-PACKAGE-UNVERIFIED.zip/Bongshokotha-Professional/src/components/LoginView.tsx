import React, { useMemo, useState } from 'react';
import { ShieldCheck, TreeDeciduous, Smartphone, Mail, LogIn, UserPlus, KeyRound } from 'lucide-react';
import { useGenealogy } from '../context/GenealogyContext';
import { getStoredAccount, saveStoredAccount, UserAccount, UserRole } from '../services/authRbac';
import { hashPassword, verifyPassword, createSession, isSessionAuthenticated, getLoginLockState, recordLoginFailure, clearLoginFailures } from '../services/security';

const ACCOUNTS_KEY = 'bongshokotha_accounts_v1';

export const isBongshokothaAuthenticated = () => isSessionAuthenticated();

const readAccounts = (): Array<UserAccount & { mobile?: string; email?: string; passwordDigest?: string }> => {
  try { return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || '[]'); } catch { return []; }
};

const normalizeMobile = (v: string) => v.replace(/[\s-]/g, '');

export const LoginView: React.FC<{ onLogin: () => void }> = ({ onLogin }) => {
  const { userAccount, setUserAccount, language } = useGenealogy();
  const isBn = language === 'bn';
  const [page, setPage] = useState<'login' | 'register' | 'recover'>('login');
  const [contact, setContact] = useState('');
  const [username, setUsername] = useState('');
  const [recoveryContact, setRecoveryContact] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const defaultContact = useMemo(() => userAccount.contact || '', [userAccount.contact]);

  const finishLogin = (account: UserAccount) => {
    const session = { ...account, lastLoginAt: new Date().toISOString(), sessionToken: crypto.randomUUID() };
    createSession(account.id, 15);
    saveStoredAccount(session);
    setUserAccount(session);
    onLogin();
  };

  const submitLogin = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setMessage('');
    const value = contact.trim() || defaultContact;
    if (!value || !password) { setError(isBn ? 'Username/মোবাইল/ইমেইল এবং পাসওয়ার্ড দিন।' : 'Enter username/mobile/email and password.'); return; }
    setBusy(true);
    try {
      const lock = getLoginLockState(value);
      if (lock.lockedUntil && Date.now() < lock.lockedUntil) throw new Error(isBn ? 'অতিরিক্ত ভুল লগইনের কারণে ১৫ মিনিটের জন্য লগইন বন্ধ আছে।' : 'Too many failed attempts. Login is temporarily locked for 15 minutes.');
      const accounts = readAccounts();
      const found = accounts.find(a => a.username?.toLowerCase() === value.toLowerCase() || a.mobile === normalizeMobile(value) || a.email?.toLowerCase() === value.toLowerCase() || a.contact?.toLowerCase() === value.toLowerCase());
      if (!found) throw new Error(isBn ? 'এই Username/মোবাইল/ইমেইল দিয়ে কোনো একাউন্ট পাওয়া যায়নি।' : 'No account found for this username/mobile/email.');
      if (!(await verifyPassword(password, found.passwordDigest || ''))) { recordLoginFailure(value); throw new Error(isBn ? 'পাসওয়ার্ড সঠিক নয়।' : 'Incorrect password.'); }
      clearLoginFailures(value);
      if (!(found.passwordDigest || '').startsWith('pbkdf2-sha256$')) found.passwordDigest = await hashPassword(password);
      finishLogin(found);
    } catch (err) { setError(err instanceof Error ? err.message : 'Login failed.'); } finally { setBusy(false); }
  };

  const submitRegister = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setMessage('');
    if (!name.trim() || !username.trim() || (!mobile.trim() && !email.trim()) || password.length < 10) {
      setError(isBn ? 'নাম, Username, মোবাইল/ইমেইলের অন্তত একটি, এবং কমপক্ষে ১০ অক্ষরের পাসওয়ার্ড দিন।' : 'Enter name, username, at least one of mobile/email, and a password of at least 10 characters.'); return;
    }
    if (!/^[a-zA-Z0-9._-]{3,32}$/.test(username.trim())) { setError(isBn ? 'Username ৩–৩২ অক্ষরের হতে হবে; ইংরেজি অক্ষর, সংখ্যা, ডট, আন্ডারস্কোর বা হাইফেন ব্যবহার করুন।' : 'Username must be 3–32 characters and use letters, numbers, dot, underscore or hyphen.'); return; }
    if (mobile.trim() && !/^\+?[0-9]{10,15}$/.test(normalizeMobile(mobile))) { setError(isBn ? 'মোবাইল নম্বর সঠিক নয়।' : 'Invalid mobile number.'); return; }
    if (email.trim() && !/^\S+@\S+\.\S+$/.test(email.trim())) { setError(isBn ? 'ইমেইল সঠিক নয়।' : 'Invalid email address.'); return; }
    setBusy(true);
    try {
      const accounts = readAccounts();
      const exists = accounts.some(a => (a.username && a.username.toLowerCase() === username.trim().toLowerCase()) || (mobile && a.mobile === normalizeMobile(mobile)) || (email && a.email?.toLowerCase() === email.toLowerCase()));
      if (exists) throw new Error(isBn ? 'এই Username, মোবাইল বা ইমেইল আগে থেকেই নিবন্ধিত।' : 'This username, mobile or email is already registered.');
      const first = accounts.length === 0;
      const account: UserAccount & { mobile?: string; email?: string; passwordDigest?: string } = {
        id: crypto.randomUUID(), name: name.trim(), nameBn: name.trim(), username: username.trim(), role: (first ? 'owner' : 'viewer') as UserRole,
        loginMethod: email && !mobile ? 'email' : 'mobile', contact: mobile.trim() || email.trim(), mobile: mobile.trim() ? normalizeMobile(mobile) : undefined,
        email: email.trim() || undefined, passwordDigest: await hashPassword(password), lastLoginAt: new Date().toISOString(), memberships: []
      };
      accounts.push(account); localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
      finishLogin(account);
    } catch (err) { setError(err instanceof Error ? err.message : 'Registration failed.'); } finally { setBusy(false); }
  };

  const submitRecoveryRequest = (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setMessage('');
    if (!recoveryContact.trim()) { setError(isBn ? 'Username, নিবন্ধিত মোবাইল অথবা ইমেইল দিন।' : 'Enter your username, registered mobile or email.'); return; }
    const accounts = readAccounts();
    const value = recoveryContact.trim();
    const found = accounts.some(a => a.username?.toLowerCase() === value.toLowerCase() || a.mobile === normalizeMobile(value) || a.email?.toLowerCase() === value.toLowerCase() || a.contact?.toLowerCase() === value.toLowerCase());
    // This offline-first build has no configured mail/SMS delivery service. Never pretend an OTP was sent.
    setMessage(found
      ? (isBn ? 'অ্যাকাউন্টটি থাকলে পাসওয়ার্ড রিসেটের জন্য আপনার পরিবারের Owner/Admin-এর সঙ্গে যোগাযোগ করুন। এই ইনস্টলে ইমেইল/SMS OTP পাঠানোর সার্ভিস কনফিগার করা নেই।' : 'If the account exists, contact your family Owner/Admin to reset it. Email/SMS OTP delivery is not configured in this installation.')
      : (isBn ? 'তথ্যটি যাচাই করুন অথবা আপনার পরিবারের Owner/Admin-এর সঙ্গে যোগাযোগ করুন।' : 'Check the details or contact your family Owner/Admin.'));
  };

  return <div className="min-h-screen flex items-center justify-center bg-stone-100 px-4 py-8 dark:bg-stone-950">
    <div className="w-full max-w-md rounded-3xl border border-stone-200 bg-white p-7 shadow-2xl dark:border-stone-800 dark:bg-stone-900">
      <div className="flex items-center gap-3 mb-7"><div className="h-14 w-14 rounded-2xl bg-amber-800 text-white flex items-center justify-center"><TreeDeciduous className="h-8 w-8"/></div><div><h1 className="font-serif text-2xl font-black text-amber-950 dark:text-amber-100">বংশকথা</h1><p className="text-xs text-stone-500">BONGSHOKOTHA • Family Heritage</p></div></div>
      <div className="grid grid-cols-2 gap-2 mb-5"><button type="button" onClick={()=>{setPage('login');setError('');setMessage('');}} className={`rounded-xl p-3 text-xs font-bold border ${page==='login'?'bg-amber-700 text-white border-amber-700':'border-stone-200 dark:border-stone-700'}`}><LogIn className="h-4 w-4 inline mr-1"/>{isBn?'লগইন':'Login'}</button><button type="button" onClick={()=>{setPage('register');setError('');setMessage('');}} className={`rounded-xl p-3 text-xs font-bold border ${page==='register'?'bg-amber-700 text-white border-amber-700':'border-stone-200 dark:border-stone-700'}`}><UserPlus className="h-4 w-4 inline mr-1"/>{isBn?'একাউন্ট তৈরি':'Create Account'}</button></div>
      <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4 mb-5 dark:border-stone-700 dark:bg-stone-950/40"><ShieldCheck className="h-5 w-5 text-amber-700 mb-2"/><p className="text-sm font-bold">{page==='login'?(isBn?'নিরাপদ লগইন':'Secure Login'):page==='register'?(isBn?'বংশ তালিকায় একাউন্ট তৈরি':'Create Family Account'):(isBn?'পাসওয়ার্ড পুনরুদ্ধার':'Password Recovery')}</p><p className="text-xs text-stone-500 mt-1">{page==='login'?(isBn?'Username, মোবাইল নম্বর অথবা ইমেইল দিয়ে প্রবেশ করুন।':'Sign in with username, mobile or email.'):page==='register'?(isBn?'মোবাইল, ইমেইল—যেকোনো একটি অথবা দুটিই দিয়ে একাউন্ট তৈরি করতে পারবেন।':'Create an account with mobile, email, or both.'):(isBn?'নিরাপদ পুনরুদ্ধারের নির্দেশনা নিন।':'Get safe recovery instructions.')}</p></div>
      {page==='login' ? <form onSubmit={submitLogin} className="space-y-4"><label className="block text-xs font-bold">{isBn?'Username / মোবাইল / ইমেইল':'Username / Mobile / Email'}<input value={contact} onChange={e=>setContact(e.target.value)} className="mt-1 w-full rounded-xl border border-stone-300 bg-white p-3 text-sm dark:border-stone-700 dark:bg-stone-800" placeholder="username / +8801XXXXXXXXX / name@example.com" /></label><label className="block text-xs font-bold">{isBn?'পাসওয়ার্ড':'Password'}<input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="mt-1 w-full rounded-xl border border-stone-300 bg-white p-3 text-sm dark:border-stone-700 dark:bg-stone-800" /></label><button disabled={busy} className="w-full rounded-xl bg-amber-800 py-3 text-sm font-bold text-white disabled:opacity-50"><LogIn className="h-4 w-4 inline mr-2"/>{busy?(isBn?'প্রবেশ করা হচ্ছে...':'Signing in...'):(isBn?'লগইন করুন':'Login')}</button><button type="button" onClick={()=>{setPage('recover');setError('');setMessage('');}} className="w-full text-xs font-semibold text-amber-800 underline underline-offset-4 dark:text-amber-300">{isBn?'পাসওয়ার্ড ভুলে গেছেন?':'Forgot password?'}</button></form> : page==='register' ? <form onSubmit={submitRegister} className="space-y-3"><label className="block text-xs font-bold">{isBn?'নাম':'Name'}<input value={name} onChange={e=>setName(e.target.value)} className="mt-1 w-full rounded-xl border p-3 text-sm dark:bg-stone-800" /></label><label className="block text-xs font-bold">{isBn?'Username (লগইন নাম)':'Username'}<input value={username} onChange={e=>setUsername(e.target.value)} autoComplete="username" className="mt-1 w-full rounded-xl border p-3 text-sm dark:bg-stone-800" placeholder="rubel.shikder"/><span className="mt-1 block text-[10px] font-normal text-stone-500">{isBn?'৩–৩২ অক্ষর; একাউন্টের জন্য স্বতন্ত্র হতে হবে।':'3–32 characters; must be unique.'}</span></label><label className="block text-xs font-bold"><Smartphone className="h-3.5 w-3.5 inline mr-1"/>{isBn?'মোবাইল নম্বর':'Mobile'}<input value={mobile} onChange={e=>setMobile(e.target.value)} className="mt-1 w-full rounded-xl border p-3 text-sm dark:bg-stone-800" placeholder="+8801XXXXXXXXX" /></label><label className="block text-xs font-bold"><Mail className="h-3.5 w-3.5 inline mr-1"/>{isBn?'ইমেইল':'Email'}<input value={email} onChange={e=>setEmail(e.target.value)} className="mt-1 w-full rounded-xl border p-3 text-sm dark:bg-stone-800" placeholder="name@example.com" /></label><p className="text-[11px] text-stone-500">{isBn?'মোবাইল অথবা ইমেইলের অন্তত একটি আবশ্যক; চাইলে দুটিই দিতে পারবেন।':'At least one of mobile or email is required; you may provide both.'}</p><label className="block text-xs font-bold"><KeyRound className="h-3.5 w-3.5 inline mr-1"/>{isBn?'পাসওয়ার্ড':'Password'}<input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={10} className="mt-1 w-full rounded-xl border p-3 text-sm dark:bg-stone-800" /></label><button disabled={busy} className="w-full rounded-xl bg-amber-800 py-3 text-sm font-bold text-white disabled:opacity-50"><UserPlus className="h-4 w-4 inline mr-2"/>{busy?(isBn?'তৈরি হচ্ছে...':'Creating...'):(isBn?'একাউন্ট তৈরি করুন':'Create Account')}</button></form> : <form onSubmit={submitRecoveryRequest} className="space-y-4"><div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-relaxed text-amber-900 dark:border-stone-700 dark:bg-stone-950 dark:text-amber-200">{isBn?'নিরাপত্তার জন্য এখানে সরাসরি নতুন পাসওয়ার্ড সেট করা হয় না। এই ইনস্টলে ইমেইল/SMS রিসেট সেবা কনফিগার করা নেই; Owner/Admin পরিচয় যাচাই করে রিসেট করতে পারবেন।':'For security, this screen does not directly set a new password. Email/SMS reset delivery is not configured; your Owner/Admin can verify your identity and help reset it.'}</div><label className="block text-xs font-bold">{isBn?'Username / নিবন্ধিত মোবাইল / ইমেইল':'Username / registered mobile / email'}<input value={recoveryContact} onChange={e=>setRecoveryContact(e.target.value)} className="mt-1 w-full rounded-xl border p-3 text-sm dark:bg-stone-800" autoComplete="username"/></label><button disabled={busy} className="w-full rounded-xl bg-amber-800 py-3 text-sm font-bold text-white disabled:opacity-50">{isBn?'পুনরুদ্ধারের নির্দেশনা দেখুন':'Get recovery instructions'}</button><button type="button" onClick={()=>{setPage('login');setError('');setMessage('');}} className="w-full rounded-xl border p-3 text-xs font-bold">{isBn?'লগইনে ফিরে যান':'Back to login'}</button></form>}
      {error && <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-xs font-semibold text-red-700">{error}</div>}
      {message && <div className="mt-4 rounded-xl border border-green-200 bg-green-50 p-3 text-xs font-semibold text-green-700">{message}</div>}
      <p className="mt-5 text-[10px] leading-relaxed text-stone-400">{isBn ? 'প্রথম তৈরি হওয়া একাউন্ট Owner হবে। পরবর্তী একাউন্টগুলো Viewer হিসেবে তৈরি হবে এবং Owner/Admin পরে Role দিতে পারবেন।' : 'The first account becomes Owner. Later accounts start as Viewer and can be assigned a role by the Owner/Admin.'}</p>
    </div>
  </div>;
};
