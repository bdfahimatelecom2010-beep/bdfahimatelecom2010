/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Comprehensive Member Profile Inspector & Heritage Bio Sheet
 * 
 * Full Specification (Prompt Sec 11):
 * - Photo / Portrait with quick update
 * - Full name in English and Bangla + Nickname
 * - Permanent Person ID (Never changes)
 * - Lineage Kromik / Serial & Generation
 * - Branch / Shakkha with color code
 * - Gender & Living status & Lifespan
 * - Birth date (Gregorian & Bangla Calendar)
 * - Birth place (Village, Upazila/Thana, District, Country)
 * - Death date and resting place (Kobor / Cremation grounds)
 * - Father and Mother clickable links
 * - Spouses with marriage status and marriage date
 * - Children in birth order
 * - Siblings in birth order
 * - Biography & titles
 * - Verified documents (NID, Birth Registration) with mask/reveal
 * - QR code identifying stable Member ID
 * - Quick button to Trace Kinship
 */

import React, { useState, useEffect, useRef } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { Member, MemberDocument, ArchiveRecord, ExtractedDocumentFields } from '../types/genealogy';
import { getMemberColor } from '../engine/memberColor';
import { toBanglaDigits, formatGenealogyDate, calculateLifespan, gregorianToBangla } from '../engine/banglaCalendar';
import { getGrandparents } from '../engine/generationEngine';
import { getCanonicalChildren, getCanonicalSiblings, getCanonicalChildrenForMarriage } from '../engine/relationshipIntegrity';
import { runDocumentOcrBatch } from '../engine/ocrEngine';
import { buildExtractedFieldCandidates, parseDocumentDate } from '../engine/ocrFieldParser';
import { ArchiveRecordDetailModal } from './archive/ArchiveRecordDetailModal';
import { DocumentScannerModal } from './archive/DocumentScannerModal';
import QRCode from 'qrcode';
import {
  X,
  User,
  Calendar,
  MapPin,
  FileText,
  ShieldCheck,
  Heart,
  GitFork,
  Compass,
  Edit3,
  Eye,
  EyeOff,
  Layers,
  Award,
  Camera,
  QrCode as QrCodeIcon,
  Plus,
  Radio,
  Sparkles,
  ExternalLink,
  Trash2,
  AlertTriangle,
  Phone,
  Mail,
  BriefcaseBusiness,
  GraduationCap,
  Home,
  Info,
  Clock3,
  BookOpen,
  MapPinned
} from 'lucide-react';

interface MemberProfileModalProps {
  memberId: string | null;
  onClose: () => void;
  onEdit: (member: Member) => void;
  onNavigateToMember: (id: string) => void;
  onTraceRelationship: (id: string) => void;
  onOpenAvatarModal?: (id: string) => void;
}

export const MemberProfileModal: React.FC<MemberProfileModalProps> = ({
  memberId,
  onClose,
  onEdit,
  onNavigateToMember,
  onTraceRelationship,
  onOpenAvatarModal
}) => {
  const {
    members,
    marriages,
    branches,
    generations,
    archiveRecords,
    language,
    deleteMember,
    updateMember,
    addArchiveRecord,
    updateArchiveRecord
  } = useGenealogy();

  const isBn = language === 'bn';
  const [revealNid, setRevealNid] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [selectedArchiveDoc, setSelectedArchiveDoc] = useState<ArchiveRecord | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [pendingProfileOcr, setPendingProfileOcr] = useState<{ fields: ExtractedDocumentFields; archiveRecordId: string } | null>(null);
  const [selectedProfileOcrFields, setSelectedProfileOcrFields] = useState<string[]>([]);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);

  const member = memberId ? members.find(m => m.id === memberId) : undefined;
  const memberMapForHeader = new Map(members.map(m => [m.id, m]));
  const memberMarriagePreview = member ? marriages.filter(m => m.husbandId === member.id || m.wifeId === member.id) : [];
  const inLawByMarriage = memberMarriagePreview.map(marriage => {
    const spouseId = marriage.husbandId === member?.id ? marriage.wifeId : marriage.husbandId;
    const spouse = memberMapForHeader.get(spouseId);
    return { marriage, spouse, father: spouse?.fatherId ? memberMapForHeader.get(spouse.fatherId) : undefined, mother: spouse?.motherId ? memberMapForHeader.get(spouse.motherId) : undefined, fatherExternalName: spouse ? (isBn ? (spouse.fatherNameBn || member?.fatherInLawName) : (spouse.fatherNameEn || spouse.fatherNameBn || member?.fatherInLawName)) : member?.fatherInLawName, motherExternalName: spouse ? (isBn ? (spouse.motherNameBn || member?.motherInLawName) : (spouse.motherNameEn || spouse.motherNameBn || member?.motherInLawName)) : member?.motherInLawName };
  }).filter(item => item.spouse || item.father || item.mother || item.fatherExternalName || item.motherExternalName);
  // Legacy explicit links remain a fallback for historical records where the spouse profile is incomplete.
  const fallbackFatherInLaw = member?.fatherInLawId ? memberMapForHeader.get(member.fatherInLawId) : undefined;
  const fallbackMotherInLaw = member?.motherInLawId ? memberMapForHeader.get(member.motherInLawId) : undefined;
  const savedFatherInLawName = member?.fatherInLawName || undefined;
  const savedMotherInLawName = member?.motherInLawName || undefined;

  // Generate QR Code for stable Person ID
  useEffect(() => {
    if (member) {
      const qrPayload = JSON.stringify({
        bongshokotha: 'person_id',
        id: member.id,
        serial: '',
        name: member.banglaName || member.fullName
      });

      QRCode.toDataURL(qrPayload, {
        width: 120,
        margin: 1,
        color: {
          dark: '#78350f',
          light: '#fef3c7'
        }
      })
        .then(url => setQrCodeDataUrl(url))
        .catch(err => console.error('QR generation error:', err));
    } else {
      setQrCodeDataUrl('');
    }
  }, [member?.id, member?.serialNumber, member?.banglaName, member?.fullName]);

  const handleProfilePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const currentMember = member;
      if (!currentMember) return;
      await updateMember({ ...currentMember, profilePhoto: String(reader.result || '') });
    };
    reader.readAsDataURL(file); e.currentTarget.value = '';
  };

  const handleProfileDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []); if (!files.length) return;
    const currentMember = member;
    if (!currentMember) return;

    Promise.all(files.map(file => new Promise<{ file: File; dataUrl: string }>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve({ file, dataUrl: String(reader.result || '') });
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    }))).then(async items => {
      const sourceFiles = items.map(({ file, dataUrl }) => ({ fileName: file.name, mimeType: file.type || undefined, dataUrl, fileSizeBytes: file.size }));
      const isOcrCapable = items.some(({ file }) => file.type.startsWith('image/') || file.type === 'application/pdf' || /\.pdf$/i.test(file.name));
      const first = items[0];
      const baseTitle = items.length === 1 ? first.file.name.replace(/\.[^/.]+$/, '') : `${items.length} files — ${first.file.name.replace(/\.[^/.]+$/, '')}`;
      let record = await addArchiveRecord({
        title: `${currentMember.banglaName || currentMember.fullName} — ${baseTitle}`,
        titleBn: `${currentMember.banglaName || currentMember.fullName} — ${baseTitle}`,
        category: first.file.type.startsWith('image/') ? 'photo' : 'document',
        relatedMemberIds: [currentMember.id],
        memberRoles: { [currentMember.id]: 'মূল ধারক (Self)' },
        relatedFamilyId: currentMember.familyId || '',
        mediaUrl: first.dataUrl,
        sourceFiles: sourceFiles.length > 1 ? sourceFiles : undefined,
        mediaType: first.file.type.startsWith('image/') ? 'image' : 'document',
        originalFilename: items.map(x => x.file.name).join(' + '),
        mimeType: first.file.type || 'application/octet-stream',
        fileSizeBytes: items.reduce((sum, x) => sum + x.file.size, 0),
        ocrVerification: 'unverified',
        source: isBn ? 'সদস্য প্রোফাইল' : 'Member Profile',
        provenance: isBn ? 'সদস্য প্রোফাইল থেকে পারিবারিক আর্কাইভে সংরক্ষিত' : 'Saved to Family Archive from member profile',
        uploader: isBn ? 'সদস্য প্রোফাইল' : 'Member Profile',
        tags: ['member-profile-upload', ...(items.length > 1 ? ['multi-file-ocr-session'] : [])],
        accessPermission: 'family',
        historyNote: isBn ? 'সদস্য প্রোফাইল থেকে আপলোড করা নথি; একাধিক ফাইল হলে একই OCR session-এ একত্রে বিশ্লেষণ করা হয়েছে।' : 'Uploaded from member profile; multiple files are analyzed as one OCR session when applicable.'
      });

      let extracted = undefined as any;
      if (isOcrCapable) {
        try {
          const ocr = await runDocumentOcrBatch(
            items.filter(({ file }) => file.type.startsWith('image/') || file.type === 'application/pdf' || /\.pdf$/i.test(file.name)).map(({ file, dataUrl }) => ({ source: dataUrl, mimeType: file.type || undefined, name: file.name })),
            'ben+eng'
          );
          extracted = ocr.extractedFields;
          record = { ...record, ocrText: ocr.text || undefined, ocrConfidence: ocr.confidence, extractedFields: ocr.extractedFields, ocrVerification: 'unverified', history: [...(record.history || []), { id: `hist-${Date.now()}-ocr`, action: 'ocr_performed', timestamp: new Date().toISOString(), user: 'সিস্টেম OCR', details: `Profile OCR session completed (${ocr.confidence}%). User review required.` }] };
          await updateArchiveRecord(record, isBn ? `OCR সম্পন্ন (${ocr.confidence}%). এখন কোন তথ্য Profile-এ নেবেন নির্বাচন করুন।` : `OCR completed (${ocr.confidence}%). Choose which information to add to the Profile.`);
          const selectable = buildExtractedFieldCandidates(ocr.extractedFields).map(x => x.key);
          if (selectable.length) { setPendingProfileOcr({ fields: ocr.extractedFields, archiveRecordId: record.id }); setSelectedProfileOcrFields(selectable); }
        } catch (ocrError) {
          console.warn('Member profile OCR unavailable; document remains safely archived.', ocrError);
        }
      }

      const legacyDoc: MemberDocument = {
        id: `doc-${record.id}`,
        title: record.title,
        documentType: first.file.type.startsWith('image/') ? 'photo' : 'other',
        fileName: items.map(x => x.file.name).join(' + '),
        mimeType: first.file.type || 'application/octet-stream',
        uploadedAt: record.createdAt,
        archiveRecordId: record.id,
        ocrText: record.ocrText,
        ocrConfidence: record.ocrConfidence,
        extractedFields: extracted || record.extractedFields,
        ocrVerification: record.ocrVerification
      };
      const latest = members.find(m => m.id === currentMember.id) || currentMember;
      await updateMember({ ...latest, memberDocuments: [...(latest.memberDocuments || []), legacyDoc] });
    }).catch(() => alert(isBn ? 'ডকুমেন্ট যোগ করা যায়নি।' : 'Document upload failed.'));
    e.currentTarget.value = '';
  };

  const applyPendingProfileOcr = async () => {
    if (!member || !pendingProfileOcr) return;
    const fields = pendingProfileOcr.fields;
    const selected = new Set(selectedProfileOcrFields);
    const next: Member = { ...member, identityDocs: { ...(member.identityDocs || {}) } };
    let changed = false;
    const normalize = (v: string) => v.toLowerCase().replace(/[।,:;|()\-]/g, ' ').replace(/\s+/g, ' ').trim();
    const exactMatch = (v?: string) => {
      if (!v) return undefined;
      const q = normalize(v);
      return members.find(m => [m.banglaName, m.englishName, m.fullName, m.nickname].filter(Boolean).some(n => normalize(String(n)) === q));
    };
    const parseDate = (v?: string) => parseDocumentDate(v);
    if (selected.has('fullNameBn') && fields.fullNameBn && !member.banglaName) { next.banglaName = fields.fullNameBn; changed = true; }
    if (selected.has('fullNameEn') && fields.fullNameEn && !member.englishName) { next.englishName = fields.fullNameEn; if (!next.fullName || next.fullName === member.banglaName) next.fullName = fields.fullNameEn; changed = true; }
    if (selected.has('fullNameBn') && fields.fullNameBn && !fields.fullNameEn && !member.fullName) { next.fullName = fields.fullNameBn; changed = true; }
    // Explicitly selected OCR values must be applied even when the profile already
    // contains a value. Preserve the previous value in review notes before replacing it.
    if (selected.has('nidNumber') && fields.nidNumber && member.identityDocs?.nidNumber !== fields.nidNumber) {
      if (member.identityDocs?.nidNumber) next.researchNotes = [next.researchNotes, `আগের NID: ${member.identityDocs.nidNumber} | OCR থেকে পাওয়া NID: ${fields.nidNumber} — যাচাই করুন`].filter(Boolean).join('\n');
      next.identityDocs.nidNumber = fields.nidNumber; changed = true;
    }
    if (selected.has('brnNumber') && fields.brnNumber && member.identityDocs?.birthRegistrationNumber !== fields.brnNumber) { next.identityDocs.birthRegistrationNumber = fields.brnNumber; changed = true; }
    if (selected.has('passportNumber') && fields.passportNumber && !member.identityDocs?.passportNumber) { next.identityDocs.passportNumber = fields.passportNumber; changed = true; }
    if (selected.has('passportPersonalNumber') && fields.passportPersonalNumber) { next.identityDocs.passportPersonalNumber = fields.passportPersonalNumber; changed = true; }
    if (selected.has('passportIssueDate') && fields.passportIssueDate) { next.identityDocs.passportIssueDate = fields.passportIssueDate; changed = true; }
    if (selected.has('passportExpiryDate') && fields.passportExpiryDate) { next.identityDocs.passportExpiryDate = fields.passportExpiryDate; changed = true; }
    if (selected.has('passportIssuingAuthority') && fields.passportIssuingAuthority) { next.identityDocs.passportIssuingAuthority = fields.passportIssuingAuthority; changed = true; }
    if (selected.has('previousPassportNumber') && fields.previousPassportNumber) { next.identityDocs.previousPassportNumber = fields.previousPassportNumber; changed = true; }
    if (selected.has('dateOfBirth')) { const d = parseDate(fields.dateOfBirth); if (d && !member.birth?.date?.year) { next.birth = { ...next.birth, date: { ...(next.birth?.date || { precision: 'unknown' }), ...d } }; changed = true; } }
    if (selected.has('placeOfBirth') && fields.placeOfBirth && !member.birth?.place?.fullAddress) { next.birth = { ...next.birth, place: { ...(next.birth?.place || {}), fullAddress: fields.placeOfBirth } }; changed = true; }
    if (selected.has('address') && fields.address && member.currentAddress?.fullAddress !== fields.address) { next.currentAddress = { ...(next.currentAddress || {}), fullAddress: fields.address }; changed = true; }
    const structuredAddress = Object.fromEntries(Object.entries({ holding: fields.holding, road: fields.road, village: fields.village, union: fields.union, ward: fields.ward, postOffice: fields.postOffice, postalCode: fields.postalCode, upazila: fields.upazila, district: fields.district, division: fields.division, country: fields.country }).filter(([,v]) => v));
    if (Object.keys(structuredAddress).length && selected.has('address')) { next.currentAddress = { ...(next.currentAddress || {}), ...structuredAddress, ...(fields.address ? { fullAddress: fields.address } : {}) }; changed = true; }
    if (selected.has('presentAddress') && fields.presentAddress) { next.currentAddress = { ...(next.currentAddress || {}), ...fields.presentAddress }; changed = true; }
    if (selected.has('permanentAddress') && fields.permanentAddress) { next.permanentAddress = { ...(next.permanentAddress || {}), ...fields.permanentAddress }; changed = true; }
    // When the OCR parser only finds address components (rather than a structured
    // presentAddress object), retain those components on the profile as well.
    const addressParts = Object.fromEntries(Object.entries({ holding: fields.holding, road: fields.road, village: fields.village, union: fields.union, ward: fields.ward, postOffice: fields.postOffice, postalCode: fields.postalCode, upazila: fields.upazila, district: fields.district, division: fields.division, country: fields.country }).filter(([, value]) => Boolean(value)));
    if (selected.has('address') && Object.keys(addressParts).length) { next.currentAddress = { ...(next.currentAddress || {}), ...addressParts }; changed = true; }
    if (selected.has('occupation') && fields.occupation && !member.profession) { next.profession = fields.occupation; changed = true; }
    if (selected.has('mobileNumber') && fields.mobileNumber && !member.mobileNumber) { next.mobileNumber = fields.mobileNumber; changed = true; }
    if (selected.has('email') && fields.email && !member.email) { next.email = fields.email; changed = true; }
    if (selected.has('religion') && fields.religion && !member.religion) { next.religion = fields.religion; changed = true; }
    if (selected.has('nationality') && fields.nationality && !member.nationality) { next.nationality = fields.nationality; changed = true; }
    if (selected.has('gender') && fields.gender && (!member.gender || member.gender === 'unknown')) { next.gender = fields.gender; changed = true; }
    if (selected.has('bloodGroup') && fields.bloodGroup && (!member.bloodGroup || member.bloodGroup === 'unknown')) { next.bloodGroup = fields.bloodGroup; changed = true; }
    const isMarriageOrigin = member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin === true;
    // A married-in person's NID records their own biological parents. Never turn
    // those names into canonical links to same-name people in the husband's family.
    // Married-in spouse parent links are explicitly separated: do not automatically make them birth-line members.
    const father = !isMarriageOrigin && selected.has('fatherName') ? exactMatch(fields.fatherName) : undefined;
    const mother = !isMarriageOrigin && selected.has('motherName') ? exactMatch(fields.motherName) : undefined;
    if (father && father.id !== member.id && !member.fatherId) { next.fatherId = father.id; changed = true; }
    if (mother && mother.id !== member.id && !member.motherId) { next.motherId = mother.id; changed = true; }
    if (selected.has('fatherName') && fields.fatherName && member.fatherNameBn !== fields.fatherName) { next.fatherNameBn = fields.fatherName; changed = true; }
    if (selected.has('motherName') && fields.motherName && member.motherNameBn !== fields.motherName) { next.motherNameBn = fields.motherName; changed = true; }
    const evidence = [
      selected.has('fatherName') && fields.fatherName ? `OCR পিতা: ${fields.fatherName}${father ? ' → সদস্য মিলেছে' : ' → যাচাই প্রয়োজন'}` : '',
      selected.has('motherName') && fields.motherName ? `OCR মাতা: ${fields.motherName}${mother ? ' → সদস্য মিলেছে' : ' → যাচাই প্রয়োজন'}` : '',
      selected.has('spouseName') && fields.spouseName ? `OCR স্বামী/স্ত্রী: ${fields.spouseName} → সম্পর্ক তৈরির আগে যাচাই প্রয়োজন` : '',
      selected.has('childrenNames') && fields.childrenNames?.length ? `OCR সন্তান: ${fields.childrenNames.join(', ')} → বিদ্যমান সদস্যের সঙ্গে মিল/সম্পর্ক যাচাই প্রয়োজন` : ''
    ].filter(Boolean).join(' | ');
    if (evidence) { next.researchNotes = [next.researchNotes, evidence].filter(Boolean).join('\n'); changed = true; }
    if (selected.has('dateOfDeath') && fields.dateOfDeath) {
      const d = parseDate(fields.dateOfDeath);
      if (d) { next.death = { ...next.death, isDeceased: true, date: d }; next.isLiving = false; changed = true; }
    }
    const evidenceOnly = buildExtractedFieldCandidates(fields).filter(f => selected.has(f.key) && f.profileWritable === false);
    if (evidenceOnly.length) {
      const extra = evidenceOnly.map(f => `${f.labelBn || f.labelEn}: ${f.value}`).join(' | ');
      next.researchNotes = [next.researchNotes, isBn ? `OCR Evidence-only তথ্য: ${extra}` : `OCR evidence-only information: ${extra}`].filter(Boolean).join('\n');
      changed = true;
    }
    if (fields.conflicts?.length) {
      const conflictText = fields.conflicts.map(c => `${c.labelBn || c.labelEn}: ${c.values.join(' / ')}`).join(' | ');
      next.researchNotes = [next.researchNotes, isBn ? `OCR conflict — যাচাই প্রয়োজন: ${conflictText}` : `OCR conflict requiring review: ${conflictText}`].filter(Boolean).join('\n');
      changed = true;
    }
    const conflicting = [
      selected.has('fullNameBn') && fields.fullNameBn && member.banglaName && member.banglaName !== fields.fullNameBn ? `OCR বাংলা নাম: ${fields.fullNameBn}` : '',
      selected.has('fullNameEn') && fields.fullNameEn && member.englishName && member.englishName !== fields.fullNameEn ? `OCR English name: ${fields.fullNameEn}` : '',
      selected.has('nidNumber') && fields.nidNumber && member.identityDocs?.nidNumber && member.identityDocs.nidNumber !== fields.nidNumber ? `OCR NID: ${fields.nidNumber}` : '',
      selected.has('brnNumber') && fields.brnNumber && member.identityDocs?.birthRegistrationNumber && member.identityDocs.birthRegistrationNumber !== fields.brnNumber ? `OCR BRN: ${fields.brnNumber}` : '',
      selected.has('mobileNumber') && fields.mobileNumber && member.mobileNumber && member.mobileNumber !== fields.mobileNumber ? `OCR mobile: ${fields.mobileNumber}` : '',
      selected.has('address') && fields.address && member.currentAddress?.fullAddress && member.currentAddress.fullAddress !== fields.address ? `OCR address: ${fields.address}` : ''
    ].filter(Boolean);
    if (conflicting.length) {
      next.researchNotes = [next.researchNotes, 'OCR conflict/review: ' + conflicting.join(' | ')].filter(Boolean).join('\n');
      changed = true;
    }
    if (!changed) {
      alert(isBn ? 'নির্বাচিত OCR তথ্য প্রোফাইলে যোগ করার মতো নতুন পরিবর্তন পাওয়া যায়নি। NID/ঠিকানা/পিতা-মাতার নাম আগেই একই থাকলে তা অপরিবর্তিত আছে। OCR ফলাফল যাচাই করে অন্য ফিল্ড নির্বাচন করুন।' : 'No new changes were found in the selected OCR fields. If the NID/address/parent names already match, they were left unchanged. Review the OCR results and select other fields if needed.');
      return;
    }
    if (selected.has('nidNumber') && fields.nidNumber) {
      const normalizeNid = (value?: string) => (value || '').trim().replace(/[০-৯]/g, digit => String('০১২৩৪৫৬৭৮৯'.indexOf(digit))).replace(/[\s-]+/g, '');
      const submittedNid = normalizeNid(fields.nidNumber);
      const duplicate = members.find(candidate => candidate.id !== member.id && normalizeNid(candidate.identityDocs?.nidNumber) === submittedNid && submittedNid);
      if (duplicate) {
        const duplicateName = duplicate.banglaName || duplicate.englishName || duplicate.fullName || duplicate.id;
        alert(isBn ? `এই NID অন্য সদস্য “${duplicateName}”-এর প্রোফাইলে আছে। ডুপ্লিকেট NID সংরক্ষণ ঠেকাতে OCR তথ্য প্রয়োগ বন্ধ করা হয়েছে।` : `This NID is already assigned to “${duplicateName}”. OCR changes were not applied to prevent a duplicate NID.`);
        return;
      }
    }
    await updateMember(next);
    const archive = archiveRecords.find(r => r.id === pendingProfileOcr.archiveRecordId);
    if (archive) {
      await updateArchiveRecord({
        ...archive,
        extractedFields: fields,
        ocrVerification: 'verified',
        updatedAt: new Date().toISOString(),
        history: [...(archive.history || []), { id: `hist-${Date.now()}-ocr-verify`, action: 'ocr_verified', timestamp: new Date().toISOString(), user: isBn ? 'ব্যবহারকারী' : 'User', details: 'Selected OCR fields reviewed and applied to member profile.' }]
      }, isBn ? 'OCR তথ্য মানব যাচাইয়ের পর Profile-এ প্রয়োগ হয়েছে।' : 'OCR fields were reviewed and applied to the profile.');
    }
    setPendingProfileOcr(null);
    setSelectedProfileOcrFields([]);
  };

  if (!memberId || !member) return null;

  const memberArchiveRecords = archiveRecords.filter(r => (r.relatedMemberIds || []).includes(member.id));

  const memberMap = new Map(members.map(m => [m.id, m]));
  const branch = branches.find(b => b.id === member.branchId);
  const gen = generations.get(member.id) || 1;
  const birthYear = member.birth?.date?.year == null ? undefined : Number(member.birth.date.year);
  const deathYear = member.death?.date?.year;
  const today = new Date();
  const preciseAge = (startYear?: number, startMonth?: number, startDay?: number, endDate: Date = today) => {
    if (!startYear) return undefined;
    let age = endDate.getFullYear() - startYear;
    const month = Number(startMonth || 1);
    const day = Number(startDay || 1);
    if (endDate.getMonth() + 1 < month || (endDate.getMonth() + 1 === month && endDate.getDate() < day)) age -= 1;
    return Math.max(0, age);
  };
  const birthMonth = member.birth?.date?.month == null ? undefined : Number(member.birth.date.month);
  const birthDay = member.birth?.date?.day == null ? undefined : Number(member.birth.date.day);
  const deathDate = member.death?.date?.year ? new Date(member.death.date.year, Number(member.death.date.month || 12) - 1, Number(member.death.date.day || 31)) : today;
  const derivedAge = preciseAge(birthYear, birthMonth, birthDay, member.isLiving ? today : deathDate);

  const father = member.fatherId ? memberMap.get(member.fatherId) : null;
  const mother = member.motherId ? memberMap.get(member.motherId) : null;
  const recordedFatherName = father ? (isBn ? father.banglaName || father.fullName : father.englishName || father.fullName) : ((isBn ? member.fatherNameBn : member.fatherNameEn) || member.fatherNameBn);
  const recordedMotherName = mother ? (isBn ? mother.banglaName || mother.fullName : mother.englishName || mother.fullName) : ((isBn ? member.motherNameBn : member.motherNameEn) || member.motherNameBn);
  const adoptiveFatherName = (isBn ? member.adoptiveFatherNameBn : member.adoptiveFatherNameEn) || member.adoptiveFatherNameBn || member.adoptiveFatherNameEn;
  const adoptiveMotherName = (isBn ? member.adoptiveMotherNameBn : member.adoptiveMotherNameEn) || member.adoptiveMotherNameBn || member.adoptiveMotherNameEn;
  const grandparents = getGrandparents(member.id, memberMap);
  // A married-in mother may have biological parents recorded as OCR/external names
  // without creating family-member records. Surface those names as the child's
  // maternal grandparents, but keep them non-clickable and do not invent links.
  const maternalGrandfatherExternalName = mother
    ? ((isBn ? mother.fatherNameBn : mother.fatherNameEn || mother.fatherNameBn) || mother.fatherNameBn || mother.fatherNameEn)
    : undefined;
  const maternalGrandmotherExternalName = mother
    ? ((isBn ? mother.motherNameBn : mother.motherNameEn || mother.motherNameBn) || mother.motherNameBn || mother.motherNameEn)
    : undefined;

  // Marriages
  const memberMarriages = marriages.filter(
    m => m.husbandId === member.id || m.wifeId === member.id
  );
  const headerSpouses = memberMarriages
    .slice()
    .sort((a, b) => Number(b.status === 'current') - Number(a.status === 'current') || String(b.updatedAt).localeCompare(String(a.updatedAt)))
    .map(mar => memberMap.get(mar.husbandId === member.id ? mar.wifeId : mar.husbandId))
    .filter(Boolean) as Member[];

  // Children and siblings are derived from the same canonical relationship engine
  // used by the genealogy core. A parent's other marriages cannot leak children
  // into the current union.
  const biologicalChildren = getCanonicalChildren(member.id, members, marriages)
    .sort((a, b) => (a.birth?.date?.year ?? 9999) - (b.birth?.date?.year ?? 9999) || (a.birth?.date?.month ?? 99) - (b.birth?.date?.month ?? 99) || (a.birth?.date?.day ?? 99) - (b.birth?.date?.day ?? 99) || (a.birthOrder ?? 999999) - (b.birthOrder ?? 999999) || a.id.localeCompare(b.id));
  const siblingSets = getCanonicalSiblings(member.id, members, marriages);
  const siblings = [...siblingSets.fullSiblings, ...siblingSets.halfSiblings];

  const memberColor = getMemberColor(member);

  const lifespan = calculateLifespan(
    member.birth?.date,
    member.death?.date,
    member.isLiving,
    language
  );

  // Bangla Calendar calculation
  const banglaBirth = member.birth?.date?.year && member.birth?.date?.month && member.birth?.date?.day
    ? gregorianToBangla(member.birth.date.year, member.birth.date.month, member.birth.date.day)
    : null;

  const formatLocation = (location?: Member['currentAddress']) => {
    if (!location) return '';
    return [
      location.holding,
      location.road,
      location.fullAddress,
      location.village,
      location.union,
      location.ward,
      location.postOffice,
      location.postalCode,
      location.upazila,
      location.district,
      location.division,
      location.country
    ].filter(Boolean).join(', ');
  };

  const hasContact = Boolean(member.mobileNumber || member.email);
  const hasAddresses = Boolean(member.currentAddress || member.permanentAddress);
  const hasEducation = Boolean(member.education || member.educationHistory?.length);
  const hasCareer = Boolean(member.profession || member.professionHistory?.length);
  const hasHistory = Boolean(member.lifeEvents?.length || member.residenceHistory?.length || member.evidenceReferences?.length);
  const hasHeritageNotes = Boolean(member.importantInformation || member.familyOriginStory || member.memorialStory || member.notes);

  // A compact, non-destructive completeness summary helps families see which
  // profile areas still need information without changing any genealogy data.
  const profileChecks = [
    Boolean(member.banglaName || member.englishName || member.fullName),
    Boolean(member.gender),
    Boolean(member.birth?.date?.year || member.birth?.place),
    Boolean(member.isLiving === false ? member.death?.date?.year || member.death?.burialPlace : member.isLiving),
    Boolean(member.fatherId || member.motherId),
    Boolean(headerSpouses.length),
    Boolean(biologicalChildren.length),
    Boolean(hasContact),
    Boolean(hasAddresses),
    Boolean(hasCareer || hasEducation),
    Boolean(member.bloodGroup || member.identityDocs?.nidNumber || member.identityDocs?.birthRegistrationNumber),
    Boolean(member.memberDocuments?.length || memberArchiveRecords.length),
    Boolean(hasHistory || hasHeritageNotes || member.biography)
  ];
  const profileCompletion = Math.round((profileChecks.filter(Boolean).length / profileChecks.length) * 100);
  const completionLabel = profileCompletion >= 85 ? (isBn ? 'প্রায় সম্পূর্ণ' : 'Nearly complete') : profileCompletion >= 60 ? (isBn ? 'ভালোভাবে পূর্ণ' : 'Well documented') : (isBn ? 'আরও তথ্য যোগ করা যায়' : 'More information can be added');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-2xl border border-amber-900/15 bg-white shadow-2xl dark:border-stone-800 dark:bg-stone-900 my-8">
        {/* Header Hero */}
        <div className="relative overflow-hidden rounded-t-2xl border-b border-amber-900/10 bg-gradient-to-r from-amber-100/70 via-amber-50 to-stone-100 p-6 dark:border-stone-800 dark:from-stone-900 dark:via-stone-900 dark:to-stone-950">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              {/* Avatar with edit button */}
              <div className="relative group shrink-0">
                <div className="h-20 w-20 rounded-2xl border-2 border-amber-800/30 overflow-hidden bg-amber-50 shadow-md flex items-center justify-center dark:bg-stone-800">
                  {member.profilePhoto ? (
                    <img src={member.profilePhoto} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <span className="font-serif text-3xl font-bold text-amber-900 dark:text-amber-300">
                      {(member.banglaName || member.fullName)[0]}
                    </span>
                  )}
                </div>

                {onOpenAvatarModal && (
                  <button
                    onClick={() => onOpenAvatarModal(member.id)}
                    className="absolute -bottom-1 -right-1 rounded-full bg-amber-800 p-1.5 text-white shadow-md hover:bg-amber-900 transition"
                    title={isBn ? 'ছবি পরিবর্তন' : 'Change photo'}
                  >
                    <Camera className="h-3 w-3" />
                  </button>
                )}
              </div>

              {/* Name and Basic Identifiers */}
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold text-stone-600 dark:text-stone-400">
                    {isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Generation ${gen}`}
                  </span>
                  {branch && (
                    <span
                      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold"
                      style={{ backgroundColor: `${branch.color}15`, color: branch.color }}
                    >
                      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: branch.color }} />
                      {isBn ? branch.banglaName || branch.name : branch.name}
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap gap-1.5 text-[10px] font-semibold text-stone-600 dark:text-stone-400">
                  <span className="rounded-full bg-stone-100 px-2 py-0.5 dark:bg-stone-800">{isBn ? `জন্মক্রম: ${toBanglaDigits(member.birthOrder || 1)}` : `Birth Order: ${member.birthOrder || 1}`}</span>
                  <span className="rounded-full bg-stone-100 px-2 py-0.5 dark:bg-stone-800">{isBn ? (member.generationMode === 'manual' ? 'ম্যানুয়াল প্রজন্ম' : 'স্বয়ংক্রিয় প্রজন্ম') : (member.generationMode === 'manual' ? 'Manual generation' : 'Automatic generation')}</span>
                  <span className="rounded-full bg-stone-100 px-2 py-0.5 dark:bg-stone-800">{isBn ? (member.gender === 'male' ? 'পুরুষ' : member.gender === 'female' ? 'মহিলা' : 'অন্যান্য') : member.gender}</span>
                  <span className="rounded-full bg-stone-100 px-2 py-0.5 dark:bg-stone-800">{isBn ? ((member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin) ? 'বিবাহসূত্রে' : member.birthOrigin === 'born_in_family' ? 'জন্মসূত্রে' : member.birthOrigin === 'adopted' ? 'দত্তক' : 'অজানা') : ((member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin) ? 'joined_by_marriage' : member.birthOrigin)}</span>
                  {member.maritalStatus && <span className="rounded-full bg-stone-100 px-2 py-0.5 dark:bg-stone-800">{member.maritalStatus}</span>}
                </div>

                <h2 className="font-serif text-xl sm:text-2xl font-bold" style={{color:memberColor.text}}>
                  {isBn ? member.banglaName || member.fullName : member.englishName || member.fullName}
                </h2>

                {member.birthOrigin === 'born_in_family' && headerSpouses.length > 0 && (
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm font-semibold text-rose-700 dark:text-rose-300">
                    <span>{isBn ? (member.gender === 'male' ? 'স্ত্রী: ' : member.gender === 'female' ? 'স্বামী: ' : 'সঙ্গী: ') : 'Spouse: '}</span>
                    {headerSpouses.map((spouse, index) => (
                      <React.Fragment key={spouse.id}>
                        {index > 0 && <span className="text-stone-400">•</span>}
                        <button onClick={() => onNavigateToMember(spouse.id)} className="hover:underline">
                          {isBn ? spouse.banglaName || spouse.fullName : spouse.englishName || spouse.fullName}
                        </button>
                      </React.Fragment>
                    ))}
                  </div>
                )}

                {member.banglaName && member.englishName && (
                  <p className="text-xs text-stone-600 dark:text-stone-400">
                    {isBn ? member.englishName : member.banglaName}
                    {member.nickname && ` (${isBn ? 'ডাকনাম:' : 'Nick:'} ${member.nickname})`}
                  </p>
                )}
              </div>
            </div>

            {/* QR Code and Close */}
            <div className="flex flex-col items-end gap-2 shrink-0">
              <button
                onClick={onClose}
                className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-200/50 hover:text-stone-700 dark:hover:bg-stone-800 dark:hover:text-stone-200"
              >
                <X className="h-5 w-5" />
              </button>

              {qrCodeDataUrl && (
                <div className="hidden sm:flex flex-col items-center bg-amber-50 p-1 rounded-lg border border-amber-900/10 shadow-2xs dark:bg-stone-800" title="Stable Member QR">
                  <img src={qrCodeDataUrl} alt="QR" className="h-14 w-14 rounded-xs" />
                  <span className="text-[8px] font-mono text-amber-950 dark:text-amber-300 font-bold">VERIFIED</span>
                </div>
              )}
            </div>
          </div>

          {/* Lifespan & Origin Badge */}
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
            <span className="rounded-full px-2.5 py-0.5 font-medium border" style={{ backgroundColor: memberColor.soft, color: memberColor.text, borderColor: memberColor.border }}>
              {member.isLiving ? (isBn ? 'বর্তমানে জীবিত' : 'Living') : (isBn ? 'মরহুম/মরহুমা (প্রয়াত)' : 'Deceased')}
            </span>

            {lifespan && (
              <span className="text-stone-600 dark:text-stone-400">
                • {lifespan}
              </span>
            )}

            {member.birthOrigin === 'joined_by_marriage' && (
              <span className="rounded-full bg-fuchsia-100 text-fuchsia-800 px-2.5 py-0.5 text-xs font-medium dark:bg-fuchsia-950 dark:text-fuchsia-300">
                {isBn ? 'বৈবাহিক সূত্রে যুক্ত' : 'Joined by Marriage'}
              </span>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 flex flex-col gap-6 max-h-[72vh] overflow-y-auto">
          <div className="sticky top-0 z-10 -mx-2 rounded-2xl border border-stone-200 bg-white/95 p-2 shadow-sm backdrop-blur dark:border-stone-800 dark:bg-stone-900/95">
            <div className="flex gap-1.5 overflow-x-auto">
              {[
                { id: 'profile-lineage', bn: 'বংশপরিচয়', en: 'Lineage Overview' },
                { id: 'profile-parents', bn: 'পিতা-মাতা', en: 'Biological Parents' },
                { id: 'profile-grandparents', bn: 'দাদা-দাদি / নানা-নানি', en: 'Grandparents' },
                { id: 'profile-siblings', bn: 'ভাই-বোন', en: 'Siblings' },
                { id: 'profile-marriages', bn: 'বিবাহ ও স্বামী/স্ত্রী', en: 'Marriages & Spouses' },
                { id: 'profile-children', bn: 'সন্তান ও নাতি-নাতনি', en: 'Children & Descendants' },
                { id: 'profile-inlaws', bn: 'শ্বশুর-শাশুড়ী', en: 'Parents-in-law' },
                { id: 'profile-documents', bn: 'নথি, পরিচয়পত্র ও OCR', en: 'Documents, IDs & OCR' },
                { id: 'profile-history', bn: 'জীবনঘটনা ও প্রমাণ', en: 'Life Events & Evidence' },
                { id: 'profile-biography', bn: 'জীবনী ও পারিবারিক ইতিহাস', en: 'Biography & Family History' }
              ].map(({ id, bn, en }) => <button key={id} type="button" onClick={() => document.getElementById(id)?.scrollIntoView({behavior:'smooth', block:'start'})} className="shrink-0 rounded-xl bg-stone-100 px-3 py-1.5 text-[10px] font-bold text-stone-700 hover:bg-amber-100 hover:text-amber-900 dark:bg-stone-800 dark:text-stone-300 dark:hover:bg-amber-950 dark:hover:text-amber-300">{isBn ? bn : en}</button>)}
            </div>
          </div>
          {/* Profile completeness / quick status — informational only. */}
          <section className="rounded-2xl border border-emerald-200 bg-emerald-50/50 p-4 dark:border-emerald-900/40 dark:bg-emerald-950/15">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-900 dark:text-emerald-200">{isBn ? 'প্রোফাইল তথ্যের সারাংশ' : 'Profile Information Summary'}</h4>
                <p className="mt-1 text-[10px] text-stone-500">{isBn ? `${completionLabel} — প্রয়োজনীয় তথ্যের কোন অংশ এখনো খালি আছে তা দ্রুত বোঝা যাবে।` : `${completionLabel} — quickly see whether important profile areas still need information.`}</p>
              </div>
              <div className="min-w-28 text-right">
                <div className="text-xl font-black text-emerald-800 dark:text-emerald-300">{toBanglaDigits(profileCompletion)}%</div>
                <div className="h-2 overflow-hidden rounded-full bg-emerald-100 dark:bg-emerald-950"><div className="h-full rounded-full bg-emerald-600 transition-all" style={{ width: `${profileCompletion}%` }} /></div>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
              {[
                [isBn ? 'পরিচয়' : 'Identity', profileChecks[0]],
                [isBn ? 'জন্ম/মৃত্যু' : 'Life dates', profileChecks[2] && profileChecks[3]],
                [isBn ? 'পিতা-মাতা' : 'Parents', profileChecks[4]],
                [isBn ? 'স্বামী/স্ত্রী' : 'Spouse', profileChecks[5]],
                [isBn ? 'সন্তান' : 'Children', profileChecks[6]],
                [isBn ? 'যোগাযোগ' : 'Contact', profileChecks[7]],
                [isBn ? 'ঠিকানা' : 'Address', profileChecks[8]],
                [isBn ? 'নথি/আর্কাইভ' : 'Documents', profileChecks[11]]
              ].map(([label, ok]) => (
                <div key={String(label)} className={`rounded-xl border px-2.5 py-2 ${ok ? 'border-emerald-200 bg-white/70 text-emerald-800 dark:border-emerald-900/50 dark:bg-stone-900/40 dark:text-emerald-300' : 'border-stone-200 bg-white/60 text-stone-500 dark:border-stone-800 dark:bg-stone-900/30'}`}>
                  <span className="font-semibold">{ok ? '✓' : '○'} {label}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Family Lineage Overview — the member's most important genealogy facts are visible together. */}
          <section id="profile-lineage" className="rounded-2xl border border-amber-200 bg-amber-50/50 p-4 dark:border-amber-900/40 dark:bg-amber-950/15 order-0">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-black text-amber-950 dark:text-amber-200">
                  {isBn ? 'সম্পূর্ণ বংশপরিচয় — এক নজরে' : 'Complete Family Lineage — At a Glance'}
                </h4>
                <p className="mt-0.5 text-[10px] text-stone-500">
                  {isBn ? 'পিতা-মাতা, দাদা-দাদি, নানা-নানি, বিবাহ, সন্তান ও নথি একই প্রোফাইলে সংযুক্ত।' : 'Parents, grandparents, marriages, children and documents are connected from the canonical record.'}
                </p>
              </div>
              <span className="rounded-full bg-white/80 px-2 py-1 text-[10px] font-bold text-amber-900 dark:bg-stone-900/70 dark:text-amber-300">
                {isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Generation ${gen}`}
              </span>
            </div>

            <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                [isBn ? 'পিতা' : 'Father', father],
                [isBn ? 'মাতা' : 'Mother', mother],
                [isBn ? 'দাদা' : 'Paternal grandfather', grandparents.paternalGrandfather],
                [isBn ? 'দাদি' : 'Paternal grandmother', grandparents.paternalGrandmother],
                [isBn ? 'নানা' : 'Maternal grandfather', grandparents.maternalGrandfather, maternalGrandfatherExternalName],
                [isBn ? 'নানি' : 'Maternal grandmother', grandparents.maternalGrandmother, maternalGrandmotherExternalName],
              ].map(([label, person, externalName]) => {
                const p = person as Member | null | undefined;
                const external = typeof externalName === 'string' ? externalName : undefined;
                const displayName = p ? (isBn ? p.banglaName || p.fullName : p.englishName || p.fullName) : external;
                return (
                  <button
                    key={String(label)}
                    type="button"
                    disabled={!p}
                    className={`min-w-0 rounded-xl border bg-white/80 p-2 text-left dark:bg-stone-900/60 ${
                      p ? 'border-amber-200 hover:border-amber-400 hover:bg-white dark:border-stone-700 dark:hover:border-amber-700' : 'border-dashed border-stone-300 dark:border-stone-700'
                    }`}
                  >
                    <span className="block text-[9px] font-bold uppercase tracking-wide text-stone-400">{String(label)}</span>
                    <span className={`mt-0.5 block truncate text-[11px] font-semibold ${p || displayName ? 'text-stone-900 dark:text-stone-100' : 'text-stone-400'}`}>
                      {displayName || (isBn ? 'তথ্য অজানা' : 'Unknown')}
                    </span>
                    {!p && displayName && <span className="block text-[9px] text-amber-700 dark:text-amber-300">{isBn ? 'নথিতে সংরক্ষিত নাম' : 'Name from document'}</span>}
                  </button>
                );
              })}
            </div>

            <div className="mt-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div className="rounded-xl border border-white/80 bg-white/70 p-2 dark:border-stone-800 dark:bg-stone-900/50">
                <span className="block text-[9px] font-bold text-stone-400">{isBn ? 'স্বামী/স্ত্রী' : 'Spouse(s)'}</span>
                <span className="text-sm font-black text-stone-900 dark:text-stone-100">{toBanglaDigits(memberMarriages.length)}</span>
              </div>
              <div className="rounded-xl border border-white/80 bg-white/70 p-2 dark:border-stone-800 dark:bg-stone-900/50">
                <span className="block text-[9px] font-bold text-stone-400">{isBn ? 'পুত্র-কন্যা' : 'Children'}</span>
                <span className="text-sm font-black text-stone-900 dark:text-stone-100">{toBanglaDigits(biologicalChildren.length)}</span>
              </div>
              <div className="rounded-xl border border-white/80 bg-white/70 p-2 dark:border-stone-800 dark:bg-stone-900/50">
                <span className="block text-[9px] font-bold text-stone-400">{isBn ? 'ভাই-বোন' : 'Siblings'}</span>
                <span className="text-sm font-black text-stone-900 dark:text-stone-100">{toBanglaDigits(siblings.length)}</span>
              </div>
              <div className="rounded-xl border border-white/80 bg-white/70 p-2 dark:border-stone-800 dark:bg-stone-900/50">
                <span className="block text-[9px] font-bold text-stone-400">{isBn ? 'নথি/আর্কাইভ' : 'Documents / Archive'}</span>
                <span className="text-sm font-black text-stone-900 dark:text-stone-100">{toBanglaDigits((member.memberDocuments?.length || 0) + memberArchiveRecords.length)}</span>
              </div>
            </div>
          </section>

          {/* Birth & Death Details (with Bangla Era) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 rounded-xl border border-stone-200 bg-stone-50/60 p-4 dark:border-stone-800 dark:bg-stone-950/40 text-xs order-2">
            <div>
              <span className="font-bold text-stone-500 uppercase tracking-wider block mb-1">
                {isBn ? 'জন্ম তথ্য:' : 'Birth Information:'}
              </span>
              <div>{formatGenealogyDate(member.birth?.date, language)}</div>
              {banglaBirth && (
                <div className="text-amber-900 dark:text-amber-300 font-medium mt-0.5">
                  বঙ্গাব্দ: {toBanglaDigits(banglaBirth.day)} {banglaBirth.monthName}, {toBanglaDigits(banglaBirth.year)}
                </div>
              )}
              <div className="text-stone-600 dark:text-stone-400 mt-1">
                {[member.birth?.place?.village, member.birth?.place?.district, member.birth?.place?.country].filter(Boolean).join(', ')}
              </div>
            </div>

            <div>
              <span className="font-bold text-stone-500 uppercase tracking-wider block mb-1">
                {member.isLiving ? (isBn ? 'বর্তমান স্থিতি:' : 'Current Status:') : (isBn ? 'মৃত্যু ও সমাধিস্থল:' : 'Death & Resting Place:')}
              </span>
              {!member.isLiving ? (
                <>
                  <div>{formatGenealogyDate(member.death?.date, language)}</div>
                  <div className="text-stone-600 dark:text-stone-400 mt-1">
                    {member.death?.burialPlace || member.death?.notes || (isBn ? 'কবরস্থান / সমাধিস্থল অপ্রকাশিত' : 'Resting place unrecorded')}
                  </div>
                </>
              ) : (
                <div className="text-emerald-700 font-semibold">{isBn ? 'বর্তমানে জীবিত' : 'Currently living'}</div>
              )}
            </div>
          </div>

          {/* Canonical Member Identity — fixed, predictable profile order */}
          <section className="space-y-3 rounded-2xl border border-stone-200 p-4 dark:border-stone-800 order-1">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">{isBn ? 'সদস্য পরিচিতি ও মৌলিক তথ্য' : 'Member Identity & Core Information'}</h4>
              <p className="text-[10px] text-stone-400 mt-1">{isBn ? 'প্রোফাইলে মূল তথ্য একটি নির্দিষ্ট ও সহজ ক্রমে দেখানো হয়।' : 'Core information is shown in a fixed, predictable order.'}</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'বাংলা নাম' : 'Bangla Name'}</span><p className="text-sm font-semibold">{member.banglaName || member.fullName || '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'পূর্ণ নাম' : 'Full Name'}</span><p className="text-sm font-semibold">{member.fullName || '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'ইংরেজি নাম (ঐচ্ছিক)' : 'English Name (Optional)'}</span><p className="text-sm font-semibold">{member.englishName || (isBn ? 'দেওয়া হয়নি' : 'Not provided')}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'ডাকনাম' : 'Nickname'}</span><p className="text-sm font-semibold">{member.nickname || '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'লিঙ্গ' : 'Gender'}</span><p className="text-sm font-semibold">{isBn ? (member.gender === 'male' ? 'পুরুষ' : member.gender === 'female' ? 'মহিলা' : 'অন্যান্য') : member.gender}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'জন্মসূত্রে / বিবাহসূত্রে' : 'Origin'}</span><p className="text-sm font-semibold">{isBn ? ((member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin) ? 'বিবাহসূত্রে' : member.birthOrigin === 'born_in_family' ? 'জন্মসূত্রে' : member.birthOrigin === 'adopted' ? 'দত্তক' : 'অজানা') : member.birthOrigin}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'বৈবাহিক অবস্থা' : 'Marital Status'}</span><p className="text-sm font-semibold">{member.maritalStatus || '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'প্রজন্ম' : 'Generation'}</span><p className="text-sm font-semibold">{isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Generation ${gen}`}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? (member.isLiving ? 'বর্তমান বয়স' : 'মৃত্যুকালে বয়স') : (member.isLiving ? 'Current Age' : 'Age at Death')}</span><p className="text-sm font-semibold">{member.ageAtDeath ?? derivedAge ?? '—'}{(member.ageAtDeath ?? derivedAge) !== undefined ? (isBn ? ' বছর' : ' years') : ''}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'জন্মক্রম (Birth Order)' : 'Birth Order'}</span><p className="text-sm font-semibold">{member.birthOrder ? toBanglaDigits(member.birthOrder) : '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'বংশীয় শাখা (Family Branch)' : 'Family Branch'}</span><p className="text-sm font-semibold">{branch ? (isBn ? branch.banglaName || branch.name : branch.name) : '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'পেশা' : 'Profession'}</span><p className="text-sm font-semibold">{member.profession || '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'বিবাহ সংখ্যা' : 'Marriage Count'}</span><p className="text-sm font-semibold">{memberMarriages.length ? `${isBn ? toBanglaDigits(memberMarriages.length) : memberMarriages.length}${isBn ? 'টি' : ''}` : (isBn ? 'অবিবাহিত' : 'Unmarried')}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'ই-মেইল' : 'Email'}</span><p className="text-sm font-semibold break-all">{member.email || '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'মোবাইল' : 'Mobile'}</span><p className="text-sm font-semibold">{member.mobileNumber || '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'বর্তমান অবস্থান' : 'Current Location'}</span><p className="text-sm font-semibold">{formatLocation(member.currentAddress) || '—'}</p></div>
              <div><span className="text-[10px] font-bold text-stone-400">{isBn ? 'স্থায়ী অবস্থান' : 'Permanent Location'}</span><p className="text-sm font-semibold">{formatLocation(member.permanentAddress) || '—'}</p></div>
            </div>
          </section>

          {/* Preserved Biological Lineage Note */}
          {member.originalLineageNote && (
            <div className="rounded-xl border border-fuchsia-200 bg-fuchsia-50/60 p-3.5 text-xs space-y-1 dark:border-fuchsia-900/50 dark:bg-fuchsia-950/30 order-3">
              <span className="font-bold text-fuchsia-950 dark:text-fuchsia-300">
                {isBn ? 'জন্মসূত্রীয় বংশপরিচয় (Biological Lineage):' : 'Original Biological Lineage:'}
              </span>
              <p className="text-stone-700 dark:text-stone-300">
                {member.originalLineageNote}
              </p>
            </div>
          )}

          {/* Automatically derived grandparents */}
          <div id="profile-grandparents" className="space-y-2 order-5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">{isBn ? 'দাদা-দাদি ও নানা-নানি' : 'Grandparents'}</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {([
                { label: 'দাদা', person: grandparents.paternalGrandfather, en: 'Paternal grandfather' },
                { label: 'দাদি', person: grandparents.paternalGrandmother, en: 'Paternal grandmother' },
                { label: 'নানা', person: grandparents.maternalGrandfather, externalName: maternalGrandfatherExternalName, en: 'Maternal grandfather' },
                { label: 'নানি', person: grandparents.maternalGrandmother, externalName: maternalGrandmotherExternalName, en: 'Maternal grandmother' }
              ] as Array<{label: string; person?: Member; externalName?: string; en: string}>).map(({label, person, externalName, en}) => {
                const p = person;
                const displayName = p ? (isBn ? p.banglaName || p.fullName : p.englishName || p.fullName) : externalName;
                return <div key={label} onClick={() => p && onNavigateToMember(p.id)} className={`rounded-xl border p-2.5 text-xs ${p ? 'cursor-pointer hover:bg-amber-50 dark:hover:bg-stone-800' : displayName ? 'border-amber-200 bg-amber-50/40 dark:border-amber-900/50' : 'border-dashed text-stone-400'}`}>
                  <span className="block text-[10px] font-bold text-stone-400">{isBn ? label : en}</span>
                  <span className="font-semibold">{displayName || (isBn ? 'অনথিভুক্ত' : 'Unrecorded')}</span>
                  {!p && displayName && <span className="block text-[9px] text-amber-700 dark:text-amber-300">{isBn ? 'নথিতে সংরক্ষিত নাম' : 'Name from document'}</span>}
                </div>;
              })}
            </div>
          </div>

          {/* Biological Parents */}
          <div id="profile-parents" className="space-y-2 order-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
              {isBn ? 'পিতামাতা (অভিভাবক)' : 'Parents'}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div
                onClick={() => father && onNavigateToMember(father.id)}
                className={`flex items-center justify-between rounded-xl border p-2.5 transition ${
                  father ? 'cursor-pointer border-stone-200 hover:bg-amber-50 dark:border-stone-800' : 'border-dashed border-stone-300 text-stone-400'
                }`}
              >
                <div className="text-xs">
                  <span className="text-[10px] uppercase font-bold text-stone-400 block">{isBn ? 'পিতা' : 'Father'}</span>
                  <span className="font-semibold text-stone-900 dark:text-stone-100">
                    {recordedFatherName || (isBn ? 'অনথিভুক্ত' : 'Unrecorded')}
                  </span>
                </div>
                {father && <span className="text-xs font-mono text-amber-800 font-bold"></span>}
              </div>

              <div
                onClick={() => mother && onNavigateToMember(mother.id)}
                className={`flex items-center justify-between rounded-xl border p-2.5 transition ${
                  mother ? 'cursor-pointer border-stone-200 hover:bg-amber-50 dark:border-stone-800' : 'border-dashed border-stone-300 text-stone-400'
                }`}
              >
                <div className="text-xs">
                  <span className="text-[10px] uppercase font-bold text-stone-400 block">{isBn ? 'মাতা' : 'Mother'}</span>
                  <span className="font-semibold text-stone-900 dark:text-stone-100">
                    {recordedMotherName || (isBn ? 'অনথিভুক্ত' : 'Unrecorded')}
                  </span>
                </div>
                {mother && <span className="text-xs font-mono text-amber-800 font-bold"></span>}
              </div>
            </div>
            {(adoptiveFatherName || adoptiveMotherName) && <div className="mt-2 rounded-xl border border-violet-200 bg-violet-50/60 p-3 dark:border-violet-900/40 dark:bg-violet-950/20"><h5 className="mb-2 text-[10px] font-bold uppercase tracking-wide text-violet-700 dark:text-violet-300">{isBn ? 'পালক পিতা-মাতা (আলাদা সম্পর্ক)' : 'Adoptive parents (separate relationship)'}</h5><div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs"><div><span className="block text-[10px] text-stone-500">{isBn ? 'পালক পিতা' : 'Adoptive father'}</span><span className="font-semibold">{adoptiveFatherName || (isBn ? 'অনথিভুক্ত' : 'Unrecorded')}</span></div><div><span className="block text-[10px] text-stone-500">{isBn ? 'পালক মাতা' : 'Adoptive mother'}</span><span className="font-semibold">{adoptiveMotherName || (isBn ? 'অনথিভুক্ত' : 'Unrecorded')}</span></div></div></div>}
          </div>

          {/* Parents-in-law — derived per marriage from the spouse's canonical parents. */}
          <div id="profile-inlaws" className="rounded-2xl border border-rose-200 bg-rose-50/50 p-4 dark:border-rose-900/40 dark:bg-rose-950/20 order-9">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h4 className="font-bold text-sm text-stone-900 dark:text-white">{isBn ? 'শ্বশুর-শাশুড়ী — বিবাহভিত্তিক' : 'Parents-in-law — by marriage'}</h4>
                <p className="mt-1 text-[10px] text-stone-500">{isBn ? 'প্রতিটি স্বামী/স্ত্রীর পিতা-মাতা আলাদাভাবে দেখানো হয়; একাধিক বিবাহ হলে সম্পর্ক মিশে যাবে না।' : 'Each spouse’s parents are shown separately so multiple marriages never mix in-laws.'}</p>
              </div>
              <button type="button" onClick={() => onEdit(member)} className="rounded-lg border border-rose-200 bg-white px-2.5 py-1.5 text-[10px] font-bold text-rose-700 dark:border-rose-900/50 dark:bg-stone-900 dark:text-rose-300">{isBn ? 'শ্বশুর-শাশুড়ী সম্পাদনা' : 'Edit in-laws'}</button>
            </div>
            {inLawByMarriage.length === 0 && !fallbackFatherInLaw && !fallbackMotherInLaw && !savedFatherInLawName && !savedMotherInLawName ? (
              <div className="mt-3 rounded-xl border border-dashed border-rose-300 bg-white/60 p-3 text-xs text-stone-500 dark:border-rose-900/50 dark:bg-stone-900/40">
                {isBn ? 'এই সদস্যের জন্য এখনো শ্বশুর/শাশুড়ীর তথ্য সংরক্ষিত নেই। সদস্য সম্পাদনা করে স্বামী/স্ত্রীর পিতা-মাতা নির্বাচন করুন।' : 'No parents-in-law are recorded yet. Edit the member and select the spouse’s parents.'}
              </div>
            ) : (
              <div className="mt-3 space-y-2">
                {inLawByMarriage.map(({ marriage, spouse, father, mother, fatherExternalName, motherExternalName }) => (
                  <div key={marriage.id} className="rounded-xl border border-rose-100 bg-white/70 p-3 dark:border-rose-900/30 dark:bg-stone-900/50">
                    <div className="text-[10px] font-bold text-rose-700 dark:text-rose-300">{isBn ? 'স্বামী/স্ত্রী: ' : 'Spouse: '}{spouse ? (isBn ? spouse.banglaName || spouse.fullName : spouse.englishName || spouse.fullName) : '—'}</div>
                    <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button type="button" disabled={!father} onClick={() => father && onNavigateToMember(father.id)} className={`text-left rounded-xl border p-2 text-xs ${father ? 'hover:border-rose-300' : 'border-dashed text-stone-400'}`}>
                        <span className="block text-[9px] font-bold text-stone-400">{isBn ? 'শ্বশুর' : 'Father-in-law'}</span>
                        <span className="font-semibold">{father ? (isBn ? father.banglaName || father.fullName : father.englishName || father.fullName) : (fatherExternalName ? `${fatherExternalName} (${isBn ? 'বহিরাগত তথ্য' : 'external record'})` : (isBn ? 'তথ্য অজানা' : 'Unknown'))}</span>
                      </button>
                      <button type="button" disabled={!mother} onClick={() => mother && onNavigateToMember(mother.id)} className={`text-left rounded-xl border p-2 text-xs ${mother ? 'hover:border-rose-300' : 'border-dashed text-stone-400'}`}>
                        <span className="block text-[9px] font-bold text-stone-400">{isBn ? 'শাশুড়ী' : 'Mother-in-law'}</span>
                        <span className="font-semibold">{mother ? (isBn ? mother.banglaName || mother.fullName : mother.englishName || mother.fullName) : (motherExternalName ? `${motherExternalName} (${isBn ? 'বহিরাগত তথ্য' : 'external record'})` : (isBn ? 'তথ্য অজানা' : 'Unknown'))}</span>
                      </button>
                    </div>
                  </div>
                ))}
                {(fallbackFatherInLaw || fallbackMotherInLaw || savedFatherInLawName || savedMotherInLawName) && (
                  <div className="rounded-xl border border-dashed border-amber-300 bg-amber-50/60 p-3 dark:border-amber-900/50 dark:bg-amber-950/10">
                    <div className="text-[10px] font-bold text-amber-900 dark:text-amber-200">{isBn ? 'ঐতিহাসিক/ম্যানুয়াল fallback' : 'Historical/manual fallback'}</div>
                    <div className="mt-1 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <span>{isBn ? 'শ্বশুর: ' : 'Father-in-law: '}{fallbackFatherInLaw ? (fallbackFatherInLaw.banglaName || fallbackFatherInLaw.fullName) : (savedFatherInLawName || '—')}</span>
                      <span>{isBn ? 'শাশুড়ী: ' : 'Mother-in-law: '}{fallbackMotherInLaw ? (fallbackMotherInLaw.banglaName || fallbackMotherInLaw.fullName) : (savedMotherInLawName || '—')}</span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Marriages & Spouses */}
          <div id="profile-marriages" className="space-y-2 order-7">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 flex items-center gap-1.5">
              <Heart className="h-3.5 w-3.5 text-rose-600" />
              <span>{isBn ? `বিবাহ: ${memberMarriages.length}টি • দাম্পত্য সঙ্গী ও বৈবাহিক ইতিহাস` : `Marriages: ${memberMarriages.length} • Spouse(s) & Marriage History`}</span>
            </h4>

            {memberMarriages.length === 0 ? (
              <p className="text-xs text-stone-400 italic">
                {isBn ? 'কোনো বৈবাহিক রেকর্ড সংরক্ষিত নেই।' : 'No marriage records recorded.'}
              </p>
            ) : (
              memberMarriages.map(mar => {
                const spouseId = mar.husbandId === member.id ? mar.wifeId : mar.husbandId;
                const spouse = memberMap.get(spouseId);

                return (
                  <div key={mar.id} className="rounded-xl border border-stone-200 p-3 text-xs space-y-1 dark:border-stone-800">
                    <div className="flex items-center justify-between">
                      <span
                        onClick={() => spouse && onNavigateToMember(spouse.id)}
                        className="font-bold text-amber-950 dark:text-amber-200 hover:underline cursor-pointer"
                      >
                        {spouse ? (isBn ? spouse.banglaName || spouse.fullName : spouse.englishName || spouse.fullName) : spouseId}
                      </span>
                      <span className="rounded-full bg-rose-100 text-rose-800 px-2 py-0.5 text-[10px] font-medium dark:bg-rose-950 dark:text-rose-300">
                        {isBn ? ({current:'বর্তমান',separated:'পৃথক / আলাদা বসবাস',divorce_pending:'বিচ্ছেদ প্রক্রিয়াধীন',divorced:'বিবাহবিচ্ছেদ সম্পন্ন',talaq:'তালাকপ্রাপ্ত',widowed:'বিধবা/বিপত্নীক',annulled:'বিবাহ বাতিল'} as Record<string,string>)[mar.status] : mar.status}
                      </span>
                    </div>
                    {mar.marriageDate && (
                      <div className="text-[11px] text-stone-500">
                        {isBn ? 'তারিখ: ' : 'Date: '} {formatGenealogyDate(mar.marriageDate, language)}
                      </div>
                    )}
                    {mar.marriagePlace?.fullAddress && <div className="text-[11px] text-stone-500">{isBn ? 'স্থান: ' : 'Place: '}{mar.marriagePlace.fullAddress}</div>}
                    {(mar.husbandAddress?.fullAddress || mar.wifeAddress?.fullAddress) && <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 rounded-lg bg-stone-50 p-2 dark:bg-stone-900">
                      {mar.husbandAddress?.fullAddress && <div><div className="text-[10px] font-bold text-stone-400">{isBn ? 'স্বামীর ঠিকানা' : 'Husband address'}</div><div className="text-[11px]">{mar.husbandAddress.fullAddress}</div></div>}
                      {mar.wifeAddress?.fullAddress && <div><div className="text-[10px] font-bold text-stone-400">{isBn ? 'স্ত্রীর ঠিকানা' : 'Wife address'}</div><div className="text-[11px]">{mar.wifeAddress.fullAddress}</div></div>}
                    </div>}
                    {(mar.husbandFatherName || mar.husbandMotherName || mar.wifeFatherName || mar.wifeMotherName) && <div className="mt-2 rounded-lg border border-rose-100 p-2 dark:border-rose-900/40"><div className="mb-1 text-[10px] font-bold text-rose-700 dark:text-rose-300">{isBn ? 'এই বিবাহের শ্বশুর-শাশুড়ি / দুই পক্ষের পিতা-মাতা' : 'Parents-in-law for this marriage'}</div><div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-[11px]">{mar.husbandFatherName && <div>{isBn ? 'স্বামীর পিতা: ' : 'Husband father: '}{mar.husbandFatherName}</div>}{mar.husbandMotherName && <div>{isBn ? 'স্বামীর মাতা: ' : 'Husband mother: '}{mar.husbandMotherName}</div>}{mar.wifeFatherName && <div>{isBn ? 'স্ত্রীর পিতা: ' : 'Wife father: '}{mar.wifeFatherName}</div>}{mar.wifeMotherName && <div>{isBn ? 'স্ত্রীর মাতা: ' : 'Wife mother: '}{mar.wifeMotherName}</div>}</div></div>}
                    {mar.divorceInfo?.date && <div className="text-[11px] text-rose-600">{isBn ? 'বিচ্ছেদ: ' : 'Divorce: '}{formatGenealogyDate(mar.divorceInfo.date, language)}</div>}
                    <div className="text-[10px] text-stone-400">{getCanonicalChildrenForMarriage(mar, members).length} {isBn ? 'সন্তান' : 'children'}</div>
                  </div>
                );
              })
            )}
          </div>

          {/* Children grouped by the exact marriage/union; direct children without a marriage record remain visible. */}
          <div id="profile-children" className="space-y-3 order-8">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
              {isBn ? 'বিবাহভিত্তিক সন্তান (জন্মক্রম অনুসারে) — পুত্র-কন্যা' : 'Children — grouped by marriage and birth order'}
            </h4>
            {biologicalChildren.length === 0 ? (
              <p className="text-xs text-stone-400 italic">
                {isBn ? 'কোনো সন্তান তথ্য সংরক্ষিত নেই।' : 'No children are recorded.'}
              </p>
            ) : (
              <div className="space-y-3">
                {memberMarriages.map(mar => {
                  const spouseId = mar.husbandId === member.id ? mar.wifeId : mar.husbandId;
                  const spouse = memberMap.get(spouseId);
                  const unionChildren = getCanonicalChildrenForMarriage(mar, members)
                    .filter(child => biologicalChildren.some(c => c.id === child.id));
                  if (!unionChildren.length) return null;
                  return (
                    <div key={mar.id} className="rounded-xl border p-3" style={{ borderColor: memberColor.border, backgroundColor: memberColor.soft }}>
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div className="text-xs font-bold" style={{color:memberColor.text}}>
                          {isBn ? 'বিবাহ: ' : 'Marriage: '}
                          {spouse ? (isBn ? spouse.banglaName || spouse.fullName : spouse.englishName || spouse.fullName) : spouseId}
                        </div>
                        <span className="text-[10px] text-stone-500">{toBanglaDigits(unionChildren.length)} {isBn ? 'সন্তান' : 'children'}</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                        {unionChildren.map(child => {
                          const childColor = getMemberColor(child);
                          return (
                            <button key={child.id} type="button" onClick={() => onNavigateToMember(child.id)} className="cursor-pointer rounded-lg border p-2 text-left hover:shadow-sm" style={{borderColor:childColor.border,backgroundColor:childColor.soft}}>
                              <div className="flex items-center gap-2">
                                {child.profilePhoto ? <img src={child.profilePhoto} alt="" className="h-8 w-8 shrink-0 rounded-lg object-cover" /> : <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/70 text-xs font-bold dark:bg-stone-900/60">{(child.banglaName || child.fullName)[0]}</span>}
                                <span className="min-w-0 truncate text-xs font-semibold" style={{color:childColor.text}}>{isBn ? child.banglaName || child.fullName : child.englishName || child.fullName}</span>
                              </div>
                              <span className="mt-1 block text-[10px] text-stone-500">{child.gender === 'male' ? (isBn ? 'পুত্র' : 'Son') : child.gender === 'female' ? (isBn ? 'কন্যা' : 'Daughter') : (isBn ? 'লিঙ্গ: অজানা' : 'Gender: unknown')} {child.birthOrder ? ` • ${isBn ? 'জন্মক্রম ' : 'Birth order '}${child.birthOrder}` : ''} {child.birth?.date ? ` • ${formatGenealogyDate(child.birth.date, language)}` : ''}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}

                {(() => {
                  const groupedIds = new Set(memberMarriages.flatMap(mar => getCanonicalChildrenForMarriage(mar, members).map(child => child.id)));
                  const ungroupedChildren = biologicalChildren.filter(child => !groupedIds.has(child.id));
                  if (!ungroupedChildren.length) return null;
                  return (
                    <div className="rounded-xl border border-dashed border-amber-300 bg-amber-50/50 p-3 dark:border-amber-900/50 dark:bg-amber-950/10">
                      <div className="mb-2 text-xs font-bold text-amber-900 dark:text-amber-200">
                        {isBn ? 'বিবাহের সঙ্গে এখনো নির্দিষ্টভাবে যুক্ত নয়' : 'Direct children not yet assigned to a specific marriage'}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                        {ungroupedChildren.map(child => (
                          <button key={child.id} type="button" onClick={() => onNavigateToMember(child.id)} className="rounded-lg border bg-white/80 p-2 text-left hover:bg-white dark:border-stone-800 dark:bg-stone-900/60">
                            <span className="block truncate text-xs font-semibold">{isBn ? child.banglaName || child.fullName : child.englishName || child.fullName}</span>
                            <span className="mt-1 block text-[10px] text-stone-500">{child.gender === 'male' ? (isBn ? 'পুত্র' : 'Son') : child.gender === 'female' ? (isBn ? 'কন্যা' : 'Daughter') : (isBn ? 'লিঙ্গ: অজানা' : 'Gender: unknown')}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          {/* Siblings */}
          {siblings.length > 0 && (
            <div id="profile-siblings" className="space-y-2 order-6">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                {isBn ? 'সহোদর ভাই ও বোন (Siblings)' : 'Brothers & Sisters (Siblings)'}
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {siblings.map(sib => (
                  <button
                    key={sib.id}
                    onClick={() => onNavigateToMember(sib.id)}
                    className="inline-flex items-center gap-1 rounded-md bg-stone-100 px-2.5 py-1 text-xs font-medium text-stone-800 hover:bg-amber-100 hover:text-amber-950 transition dark:bg-stone-800 dark:text-stone-300"
                  >
                    <span>{isBn ? sib.banglaName || sib.fullName : sib.englishName || sib.fullName}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Personal, Contact & Identity Summary */}
          <div className="space-y-3 rounded-2xl border border-stone-200 p-4 bg-white dark:border-stone-800 dark:bg-stone-900/40 order-10">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
              <User className="h-3.5 w-3.5 text-amber-800 dark:text-amber-400" />
              <span>{isBn ? 'ব্যক্তিগত ও যোগাযোগের তথ্য' : 'Personal & Contact Information'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                <div className="text-[10px] font-semibold uppercase text-stone-400">{isBn ? 'লিঙ্গ' : 'Gender'}</div>
                <div className="mt-1 font-semibold text-stone-900 dark:text-stone-100">
                  {member.gender === 'male' ? (isBn ? 'পুরুষ' : 'Male') : member.gender === 'female' ? (isBn ? 'নারী' : 'Female') : (isBn ? 'অন্যান্য/অজানা' : 'Other/Unknown')}
                </div>
              </div>
              <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                <div className="text-[10px] font-semibold uppercase text-stone-400">{isBn ? 'বৈবাহিক অবস্থা' : 'Marital Status'}</div>
                <div className="mt-1 font-semibold text-stone-900 dark:text-stone-100">
                  {member.maritalStatus || (isBn ? 'তথ্য নেই' : 'Not recorded')}
                </div>
              </div>
              {member.profession && (
                <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                  <div className="flex items-center gap-1 text-[10px] font-semibold uppercase text-stone-400"><BriefcaseBusiness className="h-3 w-3" />{isBn ? 'পেশা' : 'Profession'}</div>
                  <div className="mt-1 font-semibold text-stone-900 dark:text-stone-100">{member.profession}</div>
                </div>
              )}
              {member.education && (
                <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                  <div className="flex items-center gap-1 text-[10px] font-semibold uppercase text-stone-400"><GraduationCap className="h-3 w-3" />{isBn ? 'শিক্ষাগত যোগ্যতা' : 'Education'}</div>
                  <div className="mt-1 font-semibold text-stone-900 dark:text-stone-100">{member.education}</div>
                </div>
              )}
              {member.mobileNumber && (
                <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                  <div className="flex items-center gap-1 text-[10px] font-semibold uppercase text-stone-400"><Phone className="h-3 w-3" />{isBn ? 'মোবাইল' : 'Mobile'}</div>
                  <div className="mt-1 font-semibold text-stone-900 dark:text-stone-100 break-all">{member.mobileNumber}</div>
                </div>
              )}
              {member.email && (
                <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                  <div className="flex items-center gap-1 text-[10px] font-semibold uppercase text-stone-400"><Mail className="h-3 w-3" />{isBn ? 'ই-মেইল' : 'Email'}</div>
                  <div className="mt-1 font-semibold text-stone-900 dark:text-stone-100 break-all">{member.email}</div>
                </div>
              )}
              {member.identityDocs?.passportNumber && (
                <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                  <div className="text-[10px] font-semibold uppercase text-stone-400">{isBn ? 'পাসপোর্ট' : 'Passport'}</div>
                  <div className="mt-1 font-mono font-semibold text-stone-900 dark:text-stone-100">{member.identityDocs.passportNumber}</div>
                </div>
              )}
            </div>

            {hasAddresses && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {member.currentAddress && (
                  <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                    <div className="flex items-center gap-1 text-[10px] font-semibold uppercase text-stone-400"><MapPinned className="h-3 w-3" />{isBn ? 'বর্তমান ঠিকানা' : 'Current Address'}</div>
                    <p className="mt-1 text-xs leading-relaxed text-stone-700 dark:text-stone-300">{formatLocation(member.currentAddress)}</p>
                  </div>
                )}
                {member.permanentAddress && (
                  <div className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                    <div className="flex items-center gap-1 text-[10px] font-semibold uppercase text-stone-400"><Home className="h-3 w-3" />{isBn ? 'স্থায়ী ঠিকানা' : 'Permanent Address'}</div>
                    <p className="mt-1 text-xs leading-relaxed text-stone-700 dark:text-stone-300">{formatLocation(member.permanentAddress)}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Extended Identity, Research & Background */}
          {(member.formerName || member.alternativeNames?.length || member.nationality || member.religion || member.bloodGroup || member.languages?.length || member.physicalDescription || member.militaryService || member.migrationHistory || member.researchNotes || member.researchStatus) && (
            <section className="space-y-3 rounded-2xl border border-violet-200 bg-violet-50/30 p-4 dark:border-violet-900/40 dark:bg-violet-950/10 order-10.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-violet-800 dark:text-violet-300">
                {isBn ? 'অতিরিক্ত পরিচয়, জীবনপট ও গবেষণা তথ্য' : 'Extended Identity, Background & Research'}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                {member.formerName && <div className="rounded-xl border border-violet-200 bg-white p-3 dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'পূর্বের নাম' : 'Former Name'}</div><div className="mt-1 font-semibold">{member.formerName}</div></div>}
                {(member.alternativeNames?.length || member.alternativeBanglaNames?.length || member.alternativeEnglishNames?.length) ? <div className="rounded-xl border border-violet-200 bg-white p-3 dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'বিভিন্ন দলিলে ব্যবহৃত নাম/বানান' : 'Names / spellings used on different documents'}</div><div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-2 text-sm"><div><div className="text-[10px] text-stone-400">{isBn?'বাংলা':'Bangla'}</div><div className="font-semibold">{(member.alternativeBanglaNames || member.alternativeNames || []).join(' • ') || '—'}</div></div><div><div className="text-[10px] text-stone-400">{isBn?'English (ঐচ্ছিক)':'English (optional)'}</div><div className="font-semibold">{(member.alternativeEnglishNames || []).join(' • ') || '—'}</div></div></div></div> : null}
                {(member.alternativeNameRecords?.length || 0) > 0 && <div className="rounded-xl border border-violet-200 p-3 dark:border-violet-900/40"><div className="mb-2 text-[10px] font-bold text-violet-700 dark:text-violet-300">{isBn ? 'নথি/উৎসভিত্তিক বিকল্প পরিচয়' : 'Alternative identities by source/document'}</div><div className="space-y-2">{member.alternativeNameRecords?.map((record, index) => <div key={record.id || `${record.name}-${index}`} className="rounded-lg bg-violet-50/70 p-2 text-xs dark:bg-violet-950/20"><div className="font-semibold">{record.name}</div><div className="mt-0.5 text-[10px] text-stone-500">{[record.sourceType, record.sourceReference, record.note].filter(Boolean).join(' • ') || (isBn ? 'উৎস উল্লেখ করা হয়নি' : 'No source specified')}</div></div>)}</div></div>}
                {member.nationality && <div className="rounded-xl border border-violet-200 bg-white p-3 dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'জাতীয়তা' : 'Nationality'}</div><div className="mt-1 font-semibold">{member.nationality}</div></div>}
                {member.religion && <div className="rounded-xl border border-violet-200 bg-white p-3 dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'ধর্মীয় পরিচয়' : 'Religion'}</div><div className="mt-1 font-semibold">{member.religion}</div></div>}
                {member.bloodGroup && <div className="rounded-xl border border-violet-200 bg-white p-3 dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'রক্তের গ্রুপ' : 'Blood Group'}</div><div className="mt-1 font-semibold">{member.bloodGroup === 'unknown' ? (isBn ? 'অজানা' : 'Unknown') : member.bloodGroup}</div></div>}
                {member.languages?.length ? <div className="rounded-xl border border-violet-200 bg-white p-3 dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'ভাষা' : 'Languages'}</div><div className="mt-1 font-semibold">{member.languages.join(', ')}</div></div> : null}
              </div>
              {member.physicalDescription && <div className="rounded-xl border border-violet-200 bg-white p-3 text-xs dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'শারীরিক পরিচিতি / বিশেষ চিহ্ন' : 'Physical Description / Identifying Marks'}</div><p className="mt-1 whitespace-pre-line leading-relaxed">{member.physicalDescription}</p></div>}
              {member.militaryService && <div className="rounded-xl border border-violet-200 bg-white p-3 text-xs dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'সামরিক/সরকারি/সেবামূলক ইতিহাস' : 'Military / Government / Service History'}</div><p className="mt-1 whitespace-pre-line leading-relaxed">{member.militaryService}</p></div>}
              {member.migrationHistory && <div className="rounded-xl border border-violet-200 bg-white p-3 text-xs dark:border-violet-900/40 dark:bg-stone-900"><div className="text-[10px] text-stone-400">{isBn ? 'অভিবাসন/দেশান্তর ইতিহাস' : 'Migration / Immigration History'}</div><p className="mt-1 whitespace-pre-line leading-relaxed">{member.migrationHistory}</p></div>}
              {(member.researchStatus || member.researchNotes) && <div className="rounded-xl border border-violet-300 bg-violet-100/50 p-3 text-xs dark:border-violet-900/50 dark:bg-violet-950/30"><div className="text-[10px] font-bold text-violet-800 dark:text-violet-300">{isBn ? 'গবেষণা অবস্থা' : 'Research Status'}: {member.researchStatus === 'verified' ? (isBn ? 'যাচাইকৃত' : 'Verified') : member.researchStatus === 'needs_research' ? (isBn ? 'আরও গবেষণা প্রয়োজন' : 'Needs research') : member.researchStatus}</div>{member.researchNotes && <p className="mt-1 whitespace-pre-line leading-relaxed text-stone-700 dark:text-stone-300">{member.researchNotes}</p>}</div>}
            </section>
          )}

          {/* Education & Career History */}
          {(hasEducation || hasCareer) && (
            <div className="space-y-4 rounded-2xl border border-stone-200 p-4 bg-stone-50/40 dark:border-stone-800 dark:bg-stone-900/30 order-11">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
                <BookOpen className="h-3.5 w-3.5 text-amber-800 dark:text-amber-400" />
                <span>{isBn ? 'শিক্ষা ও কর্মজীবনের ইতিহাস' : 'Education & Career History'}</span>
              </h4>

              {member.educationHistory?.length ? (
                <div className="space-y-2">
                  <div className="text-[10px] font-bold uppercase text-stone-400">{isBn ? 'শিক্ষা' : 'Education'}</div>
                  {member.educationHistory.map(record => (
                    <div key={record.id} className="rounded-xl border border-stone-200 bg-white p-3 dark:border-stone-800 dark:bg-stone-950/40">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="text-xs font-bold text-stone-900 dark:text-stone-100">{record.qualification || (isBn ? 'শিক্ষাগত তথ্য' : 'Education')}</div>
                          {record.institution && <div className="text-[11px] text-stone-600 dark:text-stone-400">{record.institution}</div>}
                          {record.subject && <div className="text-[11px] text-stone-500">{record.subject}</div>}
                        </div>
                        {record.year && <span className="text-[10px] font-mono text-stone-400">{record.year}</span>}
                      </div>
                      {record.result && <div className="mt-1 text-[11px] text-stone-500">{isBn ? 'ফলাফল: ' : 'Result: '}{record.result}</div>}
                    </div>
                  ))}
                </div>
              ) : null}

              {member.professionHistory?.length ? (
                <div className="space-y-2">
                  <div className="text-[10px] font-bold uppercase text-stone-400">{isBn ? 'পেশা ও কর্মসংস্থান' : 'Career'}</div>
                  {member.professionHistory.map(record => (
                    <div key={record.id} className="rounded-xl border border-stone-200 bg-white p-3 dark:border-stone-800 dark:bg-stone-950/40">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="text-xs font-bold text-stone-900 dark:text-stone-100">{record.designation || record.profession || (isBn ? 'কর্মজীবনের তথ্য' : 'Career')}</div>
                          {record.organization && <div className="text-[11px] text-stone-600 dark:text-stone-400">{record.organization}</div>}
                          {record.profession && record.designation && <div className="text-[11px] text-stone-500">{record.profession}</div>}
                        </div>
                      </div>
                      {record.location && <div className="mt-1 text-[11px] text-stone-500"><MapPin className="mr-1 inline h-3 w-3" />{formatLocation(record.location)}</div>}
                      {record.notes && <div className="mt-1 text-[11px] text-stone-500">{record.notes}</div>}
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          )}

          {/* Life, Residence & Evidence Timeline */}
          {hasHistory && (
            <div className="space-y-3 rounded-2xl border border-stone-200 p-4 dark:border-stone-800 order-12">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
                <Clock3 className="h-3.5 w-3.5 text-amber-800 dark:text-amber-400" />
                <span>{isBn ? 'জীবনঘটনা, বসবাস ও প্রমাণের সংক্ষিপ্ত ইতিহাস' : 'Life Events, Residence & Evidence'}</span>
              </h4>
              {member.lifeEvents?.length ? (
                <div className="space-y-2">
                  {member.lifeEvents.map(event => (
                    <div key={event.id} className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                      <div className="flex items-start justify-between gap-3">
                        <div className="text-xs font-semibold text-stone-900 dark:text-stone-100">{event.title}</div>
                        {event.date && <span className="text-[10px] font-mono text-stone-400">{formatGenealogyDate(event.date, language)}</span>}
                      </div>
                      {event.location && <div className="mt-1 text-[11px] text-stone-500"><MapPin className="mr-1 inline h-3 w-3" />{formatLocation(event.location)}</div>}
                      {event.description && <p className="mt-1 text-[11px] leading-relaxed text-stone-600 dark:text-stone-400">{event.description}</p>}
                    </div>
                  ))}
                </div>
              ) : null}
              {member.residenceHistory?.length ? (
                <div className="space-y-2">
                  <div className="text-[10px] font-bold uppercase text-stone-400">{isBn ? 'বসবাসের ইতিহাস' : 'Residence History'}</div>
                  {member.residenceHistory.map(record => (
                    <div key={record.id} className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                      <div className="text-xs font-semibold text-stone-900 dark:text-stone-100">{record.label}</div>
                      <div className="mt-1 text-[11px] text-stone-600 dark:text-stone-400">{formatLocation(record.address)}</div>
                      {record.notes && <div className="mt-1 text-[11px] text-stone-500">{record.notes}</div>}
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          )}

          <div className="space-y-3 rounded-2xl border border-stone-200 p-4 dark:border-stone-800 order-13">
              {pendingProfileOcr && (
                <div className="mb-3 rounded-xl border border-emerald-300 bg-emerald-50/70 p-3 dark:border-emerald-900/60 dark:bg-emerald-950/20">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <div>
                      <div className="text-xs font-bold text-emerald-900 dark:text-emerald-200">{isBn ? 'OCR থেকে Profile-এ তথ্য নিন' : 'Apply OCR information to Profile'}</div>
                      <div className="text-[10px] text-emerald-800/80 dark:text-emerald-300/80">{isBn ? 'যে তথ্যগুলো সত্য/সঠিক বলে যাচাই করেছেন শুধু সেগুলো নির্বাচন করুন। সম্পর্কের তথ্য আলাদা যাচাই হবে।' : 'Select only information you have verified. Relationship names remain evidence until confirmed.'}</div>
                    </div>
                    <button type="button" className="text-[10px] font-bold underline" onClick={() => setSelectedProfileOcrFields(buildExtractedFieldCandidates(pendingProfileOcr.fields).map(x => x.key))}>{isBn ? 'সব নির্বাচন' : 'Select all'}</button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5 max-h-56 overflow-auto">
                    {buildExtractedFieldCandidates(pendingProfileOcr.fields).map(field => (
                      <label key={field.key} className="flex items-start gap-2 rounded-lg border border-emerald-200 bg-white/80 p-2 text-[10px] dark:border-emerald-900/50 dark:bg-stone-900/60">
                        <input type="checkbox" checked={selectedProfileOcrFields.includes(field.key)} onChange={e => setSelectedProfileOcrFields(prev => e.target.checked ? [...new Set([...prev,field.key])] : prev.filter(x => x !== field.key))} />
                        <span className="min-w-0"><b>{isBn ? field.labelBn || field.labelEn : field.labelEn || field.labelBn}</b><span className="block break-words text-stone-600 dark:text-stone-400">{field.value}</span><small className="text-[9px] text-stone-400">{field.profileWritable ? (isBn ? 'Profile-এ নেওয়া যাবে' : 'Profile-writable') : (isBn ? 'Evidence/Review' : 'Evidence / review')}</small></span>
                      </label>
                    ))}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <button type="button" onClick={() => void applyPendingProfileOcr()} disabled={!selectedProfileOcrFields.length} className="rounded-lg bg-emerald-700 px-3 py-1.5 text-[10px] font-bold text-white disabled:opacity-40">{isBn ? 'নির্বাচিত তথ্য Profile-এ নিন' : 'Apply selected fields'}</button>
                    <button type="button" onClick={() => { setPendingProfileOcr(null); setSelectedProfileOcrFields([]); }} className="rounded-lg border border-stone-300 px-3 py-1.5 text-[10px] font-bold dark:border-stone-700">{isBn ? 'এখন নয়' : 'Not now'}</button>
                  </div>
                </div>
              )}
              <div className="flex items-center justify-between gap-2"><h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">{isBn ? 'সদস্যের ছবি ও ডকুমেন্ট' : 'Member Photos & Documents'}</h4><div className="flex flex-wrap justify-end gap-1.5"><input ref={photoInputRef} type="file" accept="image/*" className="hidden" onChange={handleProfilePhotoUpload}/><input ref={documentInputRef} type="file" accept="image/*,.pdf,.doc,.docx" multiple className="hidden" onChange={handleProfileDocumentUpload}/><button type="button" onClick={()=>photoInputRef.current?.click()} className="rounded-lg bg-amber-700 px-2 py-1 text-[10px] font-bold text-white">{isBn ? 'ছবি যোগ' : 'Add Photo'}</button><button type="button" onClick={()=>setIsScannerOpen(true)} className="rounded-lg bg-emerald-700 px-2 py-1 text-[10px] font-bold text-white">{isBn ? 'স্ক্যান + তথ্য নিন' : 'Scan + Extract'}</button><button type="button" onClick={()=>documentInputRef.current?.click()} className="rounded-lg border border-stone-300 px-2 py-1 text-[10px] font-bold dark:border-stone-700">{isBn ? 'ফাইল যোগ' : 'Add File'}</button></div></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(!member.memberDocuments || member.memberDocuments.length === 0) && (
                  <p className="col-span-full text-xs text-stone-400 italic">{isBn ? 'এখনো কোনো ছবি বা ডকুমেন্ট যোগ করা হয়নি। উপরের বোতাম থেকে যোগ করুন।' : 'No member photo or document has been added yet.'}</p>
                )}
                {(member.memberDocuments || []).map(doc => {
                  const canonical = doc.archiveRecordId ? archiveRecords.find(r => r.id === doc.archiveRecordId) : undefined;
                  const href = canonical?.mediaUrl || doc.dataUrl;
                  return (
                    <a key={doc.id} href={href || '#'} download={doc.fileName} target="_blank" rel="noreferrer" className="rounded-xl border p-3 hover:bg-stone-50 dark:border-stone-800">
                      <div className="flex items-center justify-between gap-2"><div className="text-xs font-semibold truncate">{doc.title}</div><div className="flex items-center gap-1">{canonical && <span className="text-[9px] rounded-full bg-emerald-100 px-1.5 py-0.5 font-bold text-emerald-700">{isBn ? 'আর্কাইভ' : 'Archive'}</span>}{(doc.ocrConfidence || canonical?.ocrConfidence) ? <span className="text-[9px] rounded-full bg-sky-100 px-1.5 py-0.5 font-bold text-sky-700">OCR {doc.ocrConfidence || canonical?.ocrConfidence}%</span> : null}</div></div>
                      <div className="text-[10px] text-stone-500">{doc.fileName}</div>
                      {doc.extractedFields && <div className="mt-1 text-[10px] text-stone-500">{[doc.extractedFields.fullNameBn, doc.extractedFields.fatherName, doc.extractedFields.motherName, doc.extractedFields.nidNumber, doc.extractedFields.brnNumber].filter(Boolean).slice(0,3).join(' • ')}</div>}
                    </a>
                  );
                })}
              </div>
            </div>

          {/* Identity Documents & Connected Archive Records (Rule 6: Profile -> Archive) */}
          <div id="profile-documents" className="space-y-3 rounded-2xl border border-stone-200 p-4 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/40 order-14">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
                <FileText className="h-3.5 w-3.5 text-amber-800 dark:text-amber-400" />
                <span>{isBn ? 'আইনগত পরিচয়পত্র ও ডিজিটাল মহাফেজখানা' : 'Identity Documents & Archive Records'}</span>
              </h4>

              <div className="flex items-center gap-2">
                {(member.identityDocs?.nidNumber || member.identityDocs?.birthRegistrationNumber) && (
                  <button
                    type="button"
                    onClick={() => setRevealNid(!revealNid)}
                    className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-800 hover:underline dark:text-amber-400"
                  >
                    {revealNid ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                    <span>{revealNid ? (isBn ? 'নম্বর লুকান' : 'Mask') : (isBn ? 'প্রদর্শন' : 'Reveal')}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setIsScannerOpen(true)}
                  className="inline-flex items-center gap-1 rounded-lg bg-amber-900 px-2 py-1 text-[11px] font-bold text-white shadow-xs hover:bg-amber-950 transition dark:bg-amber-800"
                >
                  <Plus className="h-3 w-3" />
                  <span>{isBn ? 'দলিল স্ক্যান' : 'Scan Doc'}</span>
                </button>
              </div>
            </div>

            {/* Official NID / BRN numbers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 text-xs font-mono">
              <div className="rounded-xl bg-white p-2.5 border border-stone-200/80 shadow-2xs dark:bg-stone-950/60 dark:border-stone-800">
                <div className="text-[10px] font-sans font-semibold text-stone-500 uppercase">{isBn ? 'জাতীয় পরিচয়পত্র (NID)' : 'National ID (NID)'}</div>
                <div className="font-bold text-stone-900 dark:text-stone-100 mt-0.5 flex items-center justify-between">
                  <span>
                    {member.identityDocs?.nidNumber
                      ? (revealNid ? member.identityDocs.nidNumber : `••••••${member.identityDocs.nidNumber.slice(-4)}`)
                      : (isBn ? 'অনথিভুক্ত' : 'Not recorded')}
                  </span>
                  {member.identityDocs?.verificationStatus === 'verified' && (
                    <span className="text-[10px] font-sans font-bold text-emerald-700 dark:text-emerald-400">✓ {isBn ? 'যাচাইকৃত' : 'Verified'}</span>
                  )}
                </div>
              </div>

              <div className="rounded-xl bg-white p-2.5 border border-stone-200/80 shadow-2xs dark:bg-stone-950/60 dark:border-stone-800">
                <div className="text-[10px] font-sans font-semibold text-stone-500 uppercase">{isBn ? 'জন্ম নিবন্ধন সনদ (Birth Reg)' : 'Birth Registration (BRN)'}</div>
                <div className="font-bold text-stone-900 dark:text-stone-100 mt-0.5 flex items-center justify-between">
                  <span>
                    {member.identityDocs?.birthRegistrationNumber
                      ? (revealNid ? member.identityDocs.birthRegistrationNumber : `••••••${member.identityDocs.birthRegistrationNumber.slice(-4)}`)
                      : (isBn ? 'অনথিভুক্ত' : 'Not recorded')}
                  </span>
                  {member.identityDocs?.verificationStatus === 'verified' && (
                    <span className="text-[10px] font-sans font-bold text-emerald-700 dark:text-emerald-400">✓ {isBn ? 'যাচাইকৃত' : 'Verified'}</span>
                  )}
                </div>
              </div>
            </div>

            {/* Linked Archive Records List (Rule 6) */}
            <div className="pt-2 border-t border-stone-200 dark:border-stone-800 space-y-2">
              <div className="text-[11px] font-semibold text-stone-600 dark:text-stone-400 flex items-center justify-between">
                <span>{isBn ? `সংযুক্ত মহাফেজখানা রেকর্ড (${memberArchiveRecords.length}):` : `Linked Vault Records (${memberArchiveRecords.length}):`}</span>
                <span className="text-[10px] text-stone-400">{isBn ? 'ক্লিক করে আসল প্রমাণ খুলুন' : 'Click to inspect original'}</span>
              </div>

              {memberArchiveRecords.length === 0 ? (
                <p className="text-xs text-stone-400 italic">
                  {isBn ? 'এই সদস্যের কোনো স্ক্যানকৃত দলিল বা অডিও সংযুক্ত নেই।' : 'No scanned documents or voice memos linked yet.'}
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {memberArchiveRecords.map(doc => (
                    <div
                      key={doc.id}
                      onClick={() => setSelectedArchiveDoc(doc)}
                      className="cursor-pointer group flex items-center justify-between rounded-xl border border-stone-200 bg-white p-2.5 hover:border-amber-800/40 hover:shadow-2xs transition dark:border-stone-800 dark:bg-stone-950/60"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="h-8 w-8 rounded-lg bg-stone-100 overflow-hidden flex items-center justify-center shrink-0 border border-stone-200 dark:bg-stone-800 dark:border-stone-700">
                          {doc.mediaType === 'audio' ? (
                            <Radio className="h-4 w-4 text-rose-700" />
                          ) : (
                            <img src={doc.mediaUrl} alt="" className="h-full w-full object-cover" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <span className="font-semibold text-xs text-stone-900 group-hover:text-amber-900 truncate block dark:text-stone-100 dark:group-hover:text-amber-300">
                            {isBn ? doc.titleBn || doc.title : doc.title || doc.titleBn}
                          </span>
                          <span className="text-[10px] text-stone-400 capitalize">
                            {doc.category.replace('_', ' ')} • {doc.date}
                          </span>
                        </div>
                      </div>

                      <ExternalLink className="h-3.5 w-3.5 text-stone-400 group-hover:text-amber-900 shrink-0" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sources & Evidence — explicit genealogy provenance section */}
          {(member.evidenceReferences?.length || member.lifeEvents?.some(event => event.evidenceReferenceIds?.length)) ? (
            <section id="profile-history" className="order-15 space-y-3 rounded-2xl border border-sky-200 bg-sky-50/40 p-4 dark:border-sky-900/40 dark:bg-sky-950/20">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-sky-700 dark:text-sky-300" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                  {isBn ? 'উৎস ও প্রমাণ / Sources & Evidence' : 'Sources & Evidence'}
                </h4>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(member.evidenceReferences || []).map(ref => {
                  const archive = ref.archiveRecordId ? archiveRecords.find(r => r.id === ref.archiveRecordId) : undefined;
                  return (
                    <div key={ref.id} className="rounded-xl border border-sky-200 bg-white/80 p-3 text-xs dark:border-sky-900/50 dark:bg-stone-950/50">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-stone-800 dark:text-stone-100">{ref.sourceType.replaceAll('_', ' ')}</span>
                        <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${ref.status === 'verified' ? 'bg-emerald-100 text-emerald-700' : 'bg-stone-100 text-stone-600'}`}>
                          {ref.status === 'verified' ? (isBn ? 'যাচাইকৃত' : 'Verified') : (isBn ? 'অযাচাইকৃত' : 'Unverified')}
                        </span>
                      </div>
                      {archive && <div className="mt-1 text-[10px] text-sky-700 dark:text-sky-300">{isBn ? archive.titleBn || archive.title : archive.title || archive.titleBn}</div>}
                      {ref.note && <p className="mt-1 text-[11px] leading-relaxed text-stone-600 dark:text-stone-400">{ref.note}</p>}
                    </div>
                  );
                })}
              </div>
            </section>
          ) : null}

          {/* Profile History / Audit metadata */}
          <section id="profile-biography" className="order-17 space-y-3 rounded-2xl border border-stone-200 p-4 dark:border-stone-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
              {isBn ? 'ইতিহাস ও পরিবর্তন / Profile History' : 'Profile History & Audit'}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div className="rounded-xl bg-stone-50 p-2.5 dark:bg-stone-900"><span className="text-[10px] text-stone-400">{isBn ? 'তৈরি' : 'Created'}</span><div className="font-semibold mt-0.5">{member.createdAt || '—'}</div></div>
              <div className="rounded-xl bg-stone-50 p-2.5 dark:bg-stone-900"><span className="text-[10px] text-stone-400">{isBn ? 'সর্বশেষ পরিবর্তন' : 'Updated'}</span><div className="font-semibold mt-0.5">{member.updatedAt || '—'}</div></div>
              <div className="rounded-xl bg-stone-50 p-2.5 dark:bg-stone-900"><span className="text-[10px] text-stone-400">{isBn ? 'প্রমাণের সংখ্যা' : 'Evidence Count'}</span><div className="font-semibold mt-0.5">{member.evidenceReferences?.length || 0}</div></div>
            </div>
          </section>

          {/* Biography, Important Information & Heritage Notes */}
          {hasHeritageNotes && (
            <div className="space-y-3 rounded-2xl border border-amber-900/10 bg-amber-50/40 p-4 dark:border-stone-800 dark:bg-stone-950/30 order-16">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
                <Info className="h-3.5 w-3.5 text-amber-800 dark:text-amber-400" />
                <span>{isBn ? 'জীবনী, গুরুত্বপূর্ণ তথ্য ও পারিবারিক ইতিহাস' : 'Biography, Important Information & Heritage'}</span>
              </h4>
              {member.biography && (
                <div>
                  <div className="text-[10px] font-bold uppercase text-stone-400 mb-1">{isBn ? 'জীবনবৃত্তান্ত' : 'Biography'}</div>
                  <p className="text-xs leading-relaxed text-stone-700 dark:text-stone-300 whitespace-pre-line">{member.biography}</p>
                </div>
              )}
              {member.importantInformation && (
                <div className="rounded-xl border border-amber-900/10 bg-white/70 p-3 dark:border-stone-800 dark:bg-stone-900/50">
                  <div className="text-[10px] font-bold uppercase text-stone-400 mb-1">{isBn ? 'গুরুত্বপূর্ণ তথ্য' : 'Important Information'}</div>
                  <p className="text-xs leading-relaxed text-stone-700 dark:text-stone-300 whitespace-pre-line">{member.importantInformation}</p>
                </div>
              )}
              {member.familyOriginStory && (
                <div>
                  <div className="text-[10px] font-bold uppercase text-stone-400 mb-1">{isBn ? 'পারিবারিক উৎসের ইতিহাস' : 'Family Origin Story'}</div>
                  <p className="text-xs leading-relaxed text-stone-700 dark:text-stone-300 whitespace-pre-line">{member.familyOriginStory}</p>
                </div>
              )}
              {member.memorialStory && (
                <div>
                  <div className="text-[10px] font-bold uppercase text-stone-400 mb-1">{isBn ? 'স্মৃতিচারণ' : 'Memorial Story'}</div>
                  <p className="text-xs leading-relaxed text-stone-700 dark:text-stone-300 whitespace-pre-line">{member.memorialStory}</p>
                </div>
              )}
              {member.notes && (
                <div>
                  <div className="text-[10px] font-bold uppercase text-stone-400 mb-1">{isBn ? 'অতিরিক্ত নোট' : 'Additional Notes'}</div>
                  <p className="text-xs leading-relaxed text-stone-600 dark:text-stone-400 whitespace-pre-line">{member.notes}</p>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-stone-200 px-6 py-4 dark:border-stone-800">
          <button
            type="button"
            onClick={() => onTraceRelationship(member.id)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-amber-900/20 bg-amber-50 px-3.5 py-2 text-xs font-semibold text-amber-900 hover:bg-amber-100 transition dark:border-stone-700 dark:bg-stone-800 dark:text-amber-200"
          >
            <Compass className="h-4 w-4 text-amber-800 dark:text-amber-400" />
            <span>{isBn ? 'এর সাথে সম্পর্ক নির্ণয় করুন' : 'Trace Kinship'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsDeleteDialogOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100 hover:border-rose-300 transition dark:border-rose-900/40 dark:bg-rose-950/40 dark:text-rose-300"
            >
              <Trash2 className="h-4 w-4 text-rose-600 dark:text-rose-400" />
              <span>{isBn ? 'সদস্য মুছে ফেলুন' : 'Delete Member'}</span>
            </button>

            <button
              type="button"
              onClick={() => onEdit(member)}
              className="inline-flex items-center gap-1.5 rounded-xl bg-amber-800 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-amber-900 transition dark:bg-amber-700 dark:hover:bg-amber-600"
            >
              <Edit3 className="h-4 w-4" />
              <span>{isBn ? 'তথ্য সম্পাদনা' : 'Edit Member'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* In-UI Deletion Confirmation Modal */}
      {isDeleteDialogOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">
                  {isBn ? 'সদস্য স্থায়ীভাবে মুছে ফেলবেন?' : 'Delete Member Record?'}
                </h3>
                <p className="text-xs text-stone-500">
                  {member.banglaName || member.fullName} ()
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed bg-stone-50 dark:bg-stone-800/50 p-3.5 rounded-2xl border border-stone-200 dark:border-stone-700">
              {isBn
                ? 'ভুলে সংরক্ষিত এই সদস্যের রেকর্ড সম্পূর্ণভাবে মুছে ফেলা হবে। সংশ্লিষ্ট পিতা-মাতা, সন্তান ও বৈবাহিক সম্পর্ক থেকে এই সদস্যকে নিরাপদে বিচ্ছিন্ন করা হবে।'
                : 'This member record will be permanently deleted. Related parents, children, and marriages will be unlinked safely.'}
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsDeleteDialogOpen(false)}
                className="px-4 py-2 text-xs font-semibold rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={async () => {
                  await deleteMember(member.id);
                  setIsDeleteDialogOpen(false);
                  onClose();
                }}
                className="px-4 py-2 text-xs font-bold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-sm flex items-center gap-1.5 transition"
              >
                <Trash2 className="h-4 w-4" />
                <span>{isBn ? 'হ্যাঁ, স্থায়ীভাবে মুছুন' : 'Yes, Permanently Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Child Modal: Inspect archive record directly from profile */}
      {selectedArchiveDoc && (
        <ArchiveRecordDetailModal
          isOpen={!!selectedArchiveDoc}
          onClose={() => setSelectedArchiveDoc(null)}
          record={selectedArchiveDoc}
          onOpenMemberProfile={(targetId) => {
            setSelectedArchiveDoc(null);
            onNavigateToMember(targetId);
          }}
          isBn={isBn}
        />
      )}

      {/* Child Modal: Scan new document directly for this member */}
      {isScannerOpen && (
        <DocumentScannerModal
          isOpen={isScannerOpen}
          onClose={() => setIsScannerOpen(false)}
          initialMemberId={member.id}
          onSaved={(newRec) => setSelectedArchiveDoc(newRec)}
          isBn={isBn}
        />
      )}
    </div>
  );
};
