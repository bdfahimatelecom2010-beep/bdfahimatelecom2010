/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Advanced Import & Export Hub (আমদানি ও রপ্তানি কেন্দ্র)
 * 
 * User Requirement:
 * "'Import And Export' বা 'আমদানি ও রপ্তানি' নামে একটি মেনু তৈরি করেন, আর সমস্ত উন্নত প্রয়োজনীয় সুবিধা যোগ করেন।"
 * 
 * Facilities Provided:
 * 1. Native Bongshokotha Backup Archive (.bkf / .json) - Export & Import with Diff Inspector & Strategy (Smart Merge, Keep Existing, Clean Restore)
 * 2. International GEDCOM 5.5.1 (.ged) - Full standard export & multi-mode import (file or paste text)
 * 3. Excel & CSV Spreadsheets - UTF-8 BOM exports for members & marriages; CSV parser with live validation preview & batch import
 * 4. Blank Spreadsheet Templates - Bilingual templates for field research and data gathering
 * 5. Structured Lineage Text Dossier (.txt / Markdown) - Instant hierarchical generational tree file
 * 6. Standalone Portable Offline HTML Archive (.html) - Single self-contained interactive file that opens in any browser without internet
 * 7. Verified Historical Datasets - One-click historical dataset loader
 * 8. Complete Safety & Audit Metrics - Records count, integrity check, checksum information
 */

import React, { useState, useRef, useMemo } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { toBanglaDigits, formatGenealogyDate } from '../engine/banglaCalendar';
import { SafeRestoreDiffModal } from './archive/SafeRestoreDiffModal';
import { BongshokothaArchive } from '../services/storage';
import {
  exportMembersToCSV,
  exportMarriagesToCSV,
  generateMembersCsvTemplate,
  parseMembersFromCSV,
  autoDetectAndParseUniversalImport,
  exportLineageToText,
  exportStandaloneHTMLArchive,
  ParsedCsvMemberResult,
  UniversalImportResult
} from '../engine/csvEngine';
import {
  ArrowDownUp,
  Download,
  Upload,
  FileSpreadsheet,
  FileCode,
  FileText,
  Globe,
  HardDrive,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Info,
  Copy,
  Check,
  RotateCcw,
  Layers,
  Users,
  Heart,
  BookOpen,
  Eye,
  Trash2,
  Printer,
  Zap,
  RefreshCw
} from 'lucide-react';

interface ImportExportViewProps {
  onSelectMember?: (memberId: string) => void;
  onNavigateToTree?: () => void;
}

type TabMode = 'all' | 'export' | 'import' | 'excel' | 'gedcom' | 'backup';

export const ImportExportView: React.FC<ImportExportViewProps> = ({
  onSelectMember,
  onNavigateToTree
}) => {
  const {
    family,
    members,
    marriages,
    branches,
    generations,
    archiveRecords,
    exportArchiveJSON,
    importArchiveJSON,
    exportGedcomFile,
    importGedcomText,
    importUniversalDataset,
    loadSampleDataset,
    addMember,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const memberMap = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);

  // Tab state
  const [activeSubTab, setActiveSubTab] = useState<TabMode>('all');

  // Backup file inputs
  const archiveFileInputRef = useRef<HTMLInputElement>(null);
  const gedcomFileInputRef = useRef<HTMLInputElement>(null);
  const csvFileInputRef = useRef<HTMLInputElement>(null);
  const universalFileInputRef = useRef<HTMLInputElement>(null);

  // Modal & pending archive
  const [pendingArchive, setPendingArchive] = useState<BongshokothaArchive | null>(null);
  const [isDiffModalOpen, setIsDiffModalOpen] = useState(false);

  // Universal Auto-Import State
  const [universalResult, setUniversalResult] = useState<UniversalImportResult | null>(null);
  const [isProcessingUniversal, setIsProcessingUniversal] = useState(false);
  const [isUniversalPasteOpen, setIsUniversalPasteOpen] = useState(false);
  const [universalPasteText, setUniversalPasteText] = useState('');
  const [isAutoDirectImport, setIsAutoDirectImport] = useState(false);
  const [universalStrategy, setUniversalStrategy] = useState<'merge_preserve' | 'overwrite_all'>('merge_preserve');
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  // Status & notifications
  const [statusMessage, setStatusMessage] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Raw GEDCOM paste drawer
  const [isGedcomPasteOpen, setIsGedcomPasteOpen] = useState(false);
  const [gedcomPasteText, setGedcomPasteText] = useState('');
  const [isGedcomProcessing, setIsGedcomProcessing] = useState(false);

  // CSV Import preview state
  const [csvPreviewData, setCsvPreviewData] = useState<ParsedCsvMemberResult | null>(null);
  const [isImportingCsv, setIsImportingCsv] = useState(false);

  // Copy helper
  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // 1. Handle Archive JSON (.bkf) File Pick
  const handleArchiveFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (parsed.format === 'BONGSHOKOTHA_ARCHIVE' && parsed.family) {
          setPendingArchive(parsed);
          setIsDiffModalOpen(true);
        } else {
          setStatusMessage({
            success: false,
            message: isBn
              ? 'অকার্যকর ফাইল ফরম্যাট। এটি কোনো বৈধ বংশকথা ব্যাকআপ (.bkf) নয়।'
              : 'Invalid file format. Not a recognized Bongshokotha archive.'
          });
        }
      } catch (err) {
        setStatusMessage({
          success: false,
          message: isBn ? 'ফাইলটি পড়তে ত্রুটি হয়েছে। অনুগ্রহ করে সঠিক JSON ফাইল নির্বাচন করুন।' : 'Failed to parse JSON file.'
        });
      }
    };
    reader.readAsText(file);
    if (archiveFileInputRef.current) archiveFileInputRef.current.value = '';
  };

  // Confirm archive restore from Diff Modal
  const handleConfirmRestore = async (strategy: 'merge_preserve' | 'overwrite_all' | 'keep_existing') => {
    if (!pendingArchive) return;
    const res = await importArchiveJSON(JSON.stringify(pendingArchive), strategy);
    setStatusMessage(res);
    setIsDiffModalOpen(false);
    setPendingArchive(null);
  };

  // 2. Handle GEDCOM File Upload
  const handleGedcomFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const text = event.target?.result as string;
      const res = await importGedcomText(text);
      setStatusMessage(res);
    };
    reader.readAsText(file);
    if (gedcomFileInputRef.current) gedcomFileInputRef.current.value = '';
  };

  // Handle GEDCOM Paste Import
  const handleImportGedcomText = async () => {
    if (!gedcomPasteText.trim()) return;
    setIsGedcomProcessing(true);
    try {
      const res = await importGedcomText(gedcomPasteText);
      setStatusMessage(res);
      if (res.success) {
        setGedcomPasteText('');
        setIsGedcomPasteOpen(false);
      }
    } finally {
      setIsGedcomProcessing(false);
    }
  };

  // 3. Handle CSV File Pick & Parse
  const handleCsvFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const defaultBranchId = branches[0]?.id || 'branch-main';
      const parsed = parseMembersFromCSV(text, family.id, defaultBranchId);
      setCsvPreviewData(parsed);
      if (parsed.errors.length > 0) {
        setStatusMessage({
          success: false,
          message: parsed.errors.join(' ')
        });
      } else {
        setStatusMessage({
          success: true,
          message: isBn
            ? `সিএসভি সফলভাবে যাচাই করা হয়েছে! ${toBanglaDigits(parsed.members.length)} জন সদস্যের তথ্য পাওয়া গেছে।`
            : `CSV verified! ${parsed.members.length} members detected for import.`
        });
      }
    };
    reader.readAsText(file);
    if (csvFileInputRef.current) csvFileInputRef.current.value = '';
  };

  // Confirm CSV Batch Import
  const handleCommitCsvImport = async () => {
    if (!csvPreviewData || csvPreviewData.members.length === 0) return;
    setIsImportingCsv(true);
    try {
      let importedCount = 0;
      for (const m of csvPreviewData.members) {
        await addMember(m as any);
        importedCount++;
      }
      setStatusMessage({
        success: true,
        message: isBn
          ? `অভিনন্দন! মোট ${toBanglaDigits(importedCount)} জন সদস্য সফলভাবে বংশতালিকায় যুক্ত করা হয়েছে।`
          : `Success! ${importedCount} members successfully imported into the lineage.`
      });
      setCsvPreviewData(null);
    } catch (e) {
      setStatusMessage({
        success: false,
        message: isBn ? 'সদস্য তথ্য আমদানি করতে ত্রুটি হয়েছে।' : 'Error importing members from CSV.'
      });
    } finally {
      setIsImportingCsv(false);
    }
  };

  // 3.1 Universal Auto-Detect File Processor
  const processUniversalFile = async (file: File) => {
    setIsProcessingUniversal(true);
    const defaultBranchId = branches[0]?.id || 'branch-main';

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;

        // Check if it's a native Bongshokotha archive first
        if (text.trim().startsWith('{') && text.includes('BONGSHOKOTHA_ARCHIVE')) {
          try {
            const parsed = JSON.parse(text);
            if (parsed.format === 'BONGSHOKOTHA_ARCHIVE' && parsed.family) {
              setPendingArchive(parsed);
              setIsDiffModalOpen(true);
              setIsProcessingUniversal(false);
              return;
            }
          } catch {}
        }

        // Auto-detect and parse (GEDCOM, CSV, or Spreadsheet)
        const result = autoDetectAndParseUniversalImport(text, family.id, defaultBranchId);

        if (result.errors.length > 0 && result.members.length === 0) {
          setStatusMessage({
            success: false,
            message: isBn
              ? `ফাইলটি প্রক্রিয়াকরণ করা যায়নি: ${result.errors.join(', ')}`
              : `Could not parse file: ${result.errors.join(', ')}`
          });
          return;
        }

        if (isAutoDirectImport) {
          const res = await importUniversalDataset(
            { members: result.members, marriages: result.marriages, branches: result.branches },
            universalStrategy
          );
          setStatusMessage(res);
          setUniversalResult(null);
        } else {
          setUniversalResult(result);
        }
      } catch (err: unknown) {
        setStatusMessage({
          success: false,
          message: isBn ? 'ফাইলটি পড়তে সমস্যা হয়েছে।' : 'Failed to read file.'
        });
      } finally {
        setIsProcessingUniversal(false);
      }
    };
    reader.readAsText(file);
  };

  const handleUniversalFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processUniversalFile(file);
    if (universalFileInputRef.current) universalFileInputRef.current.value = '';
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processUniversalFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingOver(false);
  };

  const handleUniversalTextImport = async () => {
    if (!universalPasteText.trim()) return;
    setIsProcessingUniversal(true);
    const defaultBranchId = branches[0]?.id || 'branch-main';
    try {
      const result = autoDetectAndParseUniversalImport(universalPasteText, family.id, defaultBranchId);
      if (result.errors.length > 0 && result.members.length === 0) {
        setStatusMessage({
          success: false,
          message: isBn ? `টেক্সট পার্স করা যায়নি: ${result.errors.join(', ')}` : `Failed to parse text.`
        });
        return;
      }
      if (isAutoDirectImport) {
        const res = await importUniversalDataset(
          { members: result.members, marriages: result.marriages, branches: result.branches },
          universalStrategy
        );
        setStatusMessage(res);
        setUniversalResult(null);
        setUniversalPasteText('');
        setIsUniversalPasteOpen(false);
      } else {
        setUniversalResult(result);
        setIsUniversalPasteOpen(false);
      }
    } finally {
      setIsProcessingUniversal(false);
    }
  };

  const handleCommitUniversalImport = async () => {
    if (!universalResult || universalResult.members.length === 0) return;
    setIsProcessingUniversal(true);
    try {
      const res = await importUniversalDataset(
        {
          members: universalResult.members,
          marriages: universalResult.marriages,
          branches: universalResult.branches
        },
        universalStrategy
      );
      setStatusMessage(res);
      setUniversalResult(null);
    } finally {
      setIsProcessingUniversal(false);
    }
  };

  // 4. Download Handlers
  const handleDownloadMembersCSV = () => {
    const csv = exportMembersToCSV(members, branches, generations, memberMap);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = (family.banglaName || family.name).replace(/\s+/g, '_');
    link.href = url;
    link.download = `Bongshokotha_${safeName}_Members_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadMarriagesCSV = () => {
    const csv = exportMarriagesToCSV(marriages, memberMap);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = (family.banglaName || family.name).replace(/\s+/g, '_');
    link.href = url;
    link.download = `Bongshokotha_${safeName}_Marriages_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadCsvTemplate = () => {
    const csv = generateMembersCsvTemplate();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Bongshokotha_Members_Template_বাংলা_ইংরেজি.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadTextDossier = () => {
    const txt = exportLineageToText(family, members, marriages, generations);
    const blob = new Blob([txt], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = (family.banglaName || family.name).replace(/\s+/g, '_');
    link.href = url;
    link.download = `Bongshokotha_${safeName}_Dossier_${new Date().toISOString().slice(0, 10)}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadOfflineHTML = () => {
    const html = exportStandaloneHTMLArchive(family, members, marriages, branches, generations);
    const blob = new Blob([html], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = (family.banglaName || family.name).replace(/\s+/g, '_');
    link.href = url;
    link.download = `Bongshokotha_${safeName}_Offline_Archive.html`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleLoadSampleData = async () => {
    const ok = window.confirm(
      isBn
        ? 'আপনি কি "সিলেট চৌধুরী বংশ"-এর ৪ প্রজন্মের ঐতিহাসিক নমুনা ডেটাসেট লোড করতে চান? এটি আপনার বিদ্যমান বংশতালিকায় কোনো ক্ষতি করবে না।'
        : 'Do you want to load the 4-generation verified sample dataset of Chowdhury Bongsho?'
    );
    if (ok) {
      await loadSampleDataset();
      setStatusMessage({
        success: true,
        message: isBn
          ? 'সিলেট চৌধুরী বংশের ৪ প্রজন্মের প্রামাণ্য ডেটাসেট সফলভাবে লোড হয়েছে!'
          : 'Chowdhury Bongsho sample dataset loaded successfully!'
      });
    }
  };

  // Sub-navigation tabs
  const subTabs = [
    { id: 'all' as TabMode, labelBn: 'সকল সুবিধা', labelEn: 'Overview & Hub' },
    { id: 'import' as TabMode, labelBn: 'অটোমেটিক আমদানি (Auto Import)', labelEn: 'Smart Auto-Import' },
    { id: 'export' as TabMode, labelBn: 'রপ্তানি (Export)', labelEn: 'Export Data' },
    { id: 'excel' as TabMode, labelBn: 'এক্সেল ও সিএসভি', labelEn: 'Excel / CSV' },
    { id: 'gedcom' as TabMode, labelBn: 'আন্তর্জাতিক জিইডিকম', labelEn: 'GEDCOM 5.5.1' },
    { id: 'backup' as TabMode, labelBn: 'ব্যাকআপ ও রিস্টোর', labelEn: 'System Backup' }
  ];

  return (
    <div className="space-y-6 pb-16">
      {/* Hidden File Inputs */}
      <input
        type="file"
        ref={universalFileInputRef}
        onChange={handleUniversalFileChange}
        accept=".bkf,.json,.ged,.csv,.tsv,.txt,application/json,text/plain,text/csv"
        className="hidden"
      />
      <input
        type="file"
        ref={archiveFileInputRef}
        onChange={handleArchiveFileChange}
        accept=".bkf,.json,application/json"
        className="hidden"
      />
      <input
        type="file"
        ref={gedcomFileInputRef}
        onChange={handleGedcomFileChange}
        accept=".ged,text/plain"
        className="hidden"
      />
      <input
        type="file"
        ref={csvFileInputRef}
        onChange={handleCsvFileChange}
        accept=".csv,text/csv"
        className="hidden"
      />

      {/* Hero Header Card */}
      <div
        className="rounded-3xl p-6 sm:p-8 border shadow-xs transition-all relative overflow-hidden"
        style={{
          backgroundColor: 'var(--surface)',
          borderColor: 'var(--border)'
        }}
      >
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border"
              style={{
                backgroundColor: 'var(--card)',
                color: 'var(--primary)',
                borderColor: 'var(--border)'
              }}
            >
              <ArrowDownUp className="w-3.5 h-3.5" />
              <span>{isBn ? 'ডেটা বিনিময় ও স্থানান্তর কেন্দ্র' : 'Data Interchange Hub'}</span>
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight" style={{ color: 'var(--text)' }}>
              {isBn ? 'আমদানি ও রপ্তানি' : 'Import And Export Hub'}
            </h1>

            <p className="text-sm leading-relaxed" style={{ color: 'var(--text-muted)' }}>
              {isBn
                ? 'পারিবারিক ঐতিহ্য ও বংশবৃক্ষের তথ্য নিরাপদ রাখা, বিভিন্ন আন্তর্জাতিক সফটওয়্যারে আদান-প্রদান (GEDCOM), এক্সেল ও সিএসভি স্প্রেডশিট প্রসেসিং এবং অফলাইন পোর্টেবল ফাইল তৈরির সর্বাধুনিক ব্যবস্থা।'
                : 'Complete genealogical data interchange: International GEDCOM 5.5.1 standards, UTF-8 Excel & CSV spreadsheets, offline standalone HTML archives, and non-destructive backup restoration.'}
            </p>
          </div>

          {/* Quick Metrics Badge */}
          <div
            className="flex flex-wrap md:flex-col gap-2.5 p-4 rounded-2xl border shrink-0 min-w-[220px]"
            style={{
              backgroundColor: 'var(--card)',
              borderColor: 'var(--border)'
            }}
          >
            <div className="text-[11px] font-bold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>
              {isBn ? 'বর্তমান পরিবারের অবস্থা' : 'Active Family Status'}
            </div>
            <div className="font-serif text-base font-bold truncate" style={{ color: 'var(--text)' }}>
              {family.banglaName || family.name}
            </div>
            <div className="grid grid-cols-2 gap-2 pt-2 border-t text-xs" style={{ borderColor: 'var(--border)' }}>
              <div>
                <span className="text-[11px]" style={{ color: 'var(--text-muted)' }}>{isBn ? 'সদস্য:' : 'Members:'}</span>{' '}
                <strong style={{ color: 'var(--text)' }}>{isBn ? toBanglaDigits(members.length) : members.length}</strong>
              </div>
              <div>
                <span className="text-[11px]" style={{ color: 'var(--text-muted)' }}>{isBn ? 'বন্ধন:' : 'Marriages:'}</span>{' '}
                <strong style={{ color: 'var(--text)' }}>{isBn ? toBanglaDigits(marriages.length) : marriages.length}</strong>
              </div>
              <div>
                <span className="text-[11px]" style={{ color: 'var(--text-muted)' }}>{isBn ? 'দলিল:' : 'Docs:'}</span>{' '}
                <strong style={{ color: 'var(--text)' }}>{isBn ? toBanglaDigits(archiveRecords.length) : archiveRecords.length}</strong>
              </div>
              <div>
                <span className="text-[11px]" style={{ color: 'var(--text-muted)' }}>{isBn ? 'শাখা:' : 'Branches:'}</span>{' '}
                <strong style={{ color: 'var(--text)' }}>{isBn ? toBanglaDigits(branches.length) : branches.length}</strong>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Notification Message */}
        {statusMessage && (
          <div
            className={`mt-4 p-4 rounded-2xl border flex items-start justify-between gap-3 text-sm ${
              statusMessage.success
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-200 dark:border-emerald-800'
                : 'bg-rose-50 text-rose-900 border-rose-200 dark:bg-rose-950/30 dark:text-rose-200 dark:border-rose-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {statusMessage.success ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              )}
              <span>{statusMessage.message}</span>
            </div>
            <button
              onClick={() => setStatusMessage(null)}
              className="text-xs opacity-70 hover:opacity-100 font-bold px-1"
            >
              ✕
            </button>
          </div>
        )}
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex overflow-x-auto no-scrollbar gap-2 pb-1 border-b" style={{ borderColor: 'var(--border)' }}>
        {subTabs.map(tab => {
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition shrink-0 border ${
                isActive ? 'shadow-xs' : 'hover:opacity-80'
              }`}
              style={{
                backgroundColor: isActive ? 'var(--primary)' : 'var(--card)',
                color: isActive ? '#ffffff' : 'var(--text)',
                borderColor: isActive ? 'var(--primary)' : 'var(--border)'
              }}
            >
              {isBn ? tab.labelBn : tab.labelEn}
            </button>
          );
        })}
      </div>

      {/* Universal Auto-Import Live Review & Commitment Modal */}
      {universalResult && (
        <div
          className="rounded-3xl p-5 sm:p-7 border shadow-xl space-y-5 animate-in fade-in"
          style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--primary)' }}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b" style={{ borderColor: 'var(--border)' }}>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wide text-white" style={{ backgroundColor: 'var(--primary)' }}>
                  {universalResult.formatLabel}
                </span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  {isBn ? 'স্বয়ংক্রিয় সনাক্তকরণ সফল' : 'Auto-Detected'}
                </span>
              </div>
              <h3 className="font-serif text-xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
                <Zap className="w-5 h-5 text-amber-500 fill-amber-500" />
                <span>{isBn ? 'সার্বজনীন অটোমেটিক আমদানি যাচাইকরণ' : 'Universal Auto-Import Preview'}</span>
              </h3>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {universalResult.summary.description}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setUniversalResult(null)}
                className="px-3 py-2 rounded-xl border text-xs font-semibold hover:opacity-80 transition"
                style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={handleCommitUniversalImport}
                disabled={isProcessingUniversal}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white shadow-md hover:opacity-90 transition flex items-center gap-2"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                {isProcessingUniversal ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-4 h-4" />
                )}
                <span>
                  {isProcessingUniversal
                    ? (isBn ? 'আমদানি হচ্ছে...' : 'Importing...')
                    : (isBn ? 'সবকিছু অটোমেটিকভাবে অন্তর্ভুক্ত করুন' : 'Auto-Import Everything Now')}
                </span>
              </button>
            </div>
          </div>

          {/* Quick Metrics from Auto-Detection */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl border flex flex-col" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
              <span className="text-[11px] font-semibold" style={{ color: 'var(--text-muted)' }}>{isBn ? 'মোট সদস্য' : 'Total Members'}</span>
              <strong className="text-xl font-bold font-serif" style={{ color: 'var(--primary)' }}>
                {isBn ? toBanglaDigits(universalResult.summary.totalMembers) : universalResult.summary.totalMembers}
              </strong>
            </div>
            <div className="p-3.5 rounded-2xl border flex flex-col" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
              <span className="text-[11px] font-semibold" style={{ color: 'var(--text-muted)' }}>{isBn ? 'বৈবাহিক বন্ধন' : 'Marriages'}</span>
              <strong className="text-xl font-bold font-serif text-rose-600">
                {isBn ? toBanglaDigits(universalResult.summary.totalMarriages) : universalResult.summary.totalMarriages}
              </strong>
            </div>
            <div className="p-3.5 rounded-2xl border flex flex-col" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
              <span className="text-[11px] font-semibold" style={{ color: 'var(--text-muted)' }}>{isBn ? 'প্রজন্ম বিস্তৃতি' : 'Generations'}</span>
              <strong className="text-xl font-bold font-serif text-indigo-600">
                {isBn ? toBanglaDigits(universalResult.summary.estimatedGenerations) : universalResult.summary.estimatedGenerations}
              </strong>
            </div>
            <div className="p-3.5 rounded-2xl border flex flex-col" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
              <span className="text-[11px] font-semibold" style={{ color: 'var(--text-muted)' }}>{isBn ? 'জীবিত / প্রয়াত' : 'Living / Deceased'}</span>
              <strong className="text-base font-bold font-mono mt-1" style={{ color: 'var(--text)' }}>
                {isBn ? toBanglaDigits(universalResult.summary.livingCount) : universalResult.summary.livingCount} / {isBn ? toBanglaDigits(universalResult.summary.deceasedCount) : universalResult.summary.deceasedCount}
              </strong>
            </div>
          </div>

          {/* Strategy Option Switcher */}
          <div className="p-4 rounded-2xl border space-y-2" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
            <span className="text-xs font-bold block" style={{ color: 'var(--text)' }}>
              {isBn ? 'আমদানি কৌশল নির্বাচন করুন:' : 'Select Import Strategy:'}
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <label
                onClick={() => setUniversalStrategy('merge_preserve')}
                className={`p-3 rounded-xl border cursor-pointer transition flex items-start gap-2.5 ${
                  universalStrategy === 'merge_preserve' ? 'ring-2' : 'hover:opacity-80'
                }`}
                style={{
                  backgroundColor: universalStrategy === 'merge_preserve' ? 'var(--surface)' : 'var(--card)',
                  borderColor: universalStrategy === 'merge_preserve' ? 'var(--primary)' : 'var(--border)',
                  color: 'var(--text)'
                }}
              >
                <input
                  type="radio"
                  name="universalStrategy"
                  checked={universalStrategy === 'merge_preserve'}
                  onChange={() => setUniversalStrategy('merge_preserve')}
                  className="mt-0.5 accent-amber-600"
                />
                <div>
                  <strong className="block font-semibold">
                    {isBn ? 'স্মার্ট মার্জ (প্রস্তাবিত ও সম্পূর্ণ নিরাপদ)' : 'Smart Safe Merge (Recommended)'}
                  </strong>
                  <span className="text-[11px] block mt-0.5" style={{ color: 'var(--text-muted)' }}>
                    {isBn
                      ? 'বিদ্যমান বংশতালিকা অক্ষুণ্ণ রেখে কেবল নতুন সদস্য ও অনুপস্থিত তথ্যসমূহ সমন্বিত করবে।'
                      : 'Preserves existing members; enriches missing details and auto-links relations.'}
                  </span>
                </div>
              </label>

              <label
                onClick={() => setUniversalStrategy('overwrite_all')}
                className={`p-3 rounded-xl border cursor-pointer transition flex items-start gap-2.5 ${
                  universalStrategy === 'overwrite_all' ? 'ring-2 ring-rose-500' : 'hover:opacity-80'
                }`}
                style={{
                  backgroundColor: universalStrategy === 'overwrite_all' ? 'var(--surface)' : 'var(--card)',
                  borderColor: universalStrategy === 'overwrite_all' ? '#e11d48' : 'var(--border)',
                  color: 'var(--text)'
                }}
              >
                <input
                  type="radio"
                  name="universalStrategy"
                  checked={universalStrategy === 'overwrite_all'}
                  onChange={() => setUniversalStrategy('overwrite_all')}
                  className="mt-0.5 accent-rose-600"
                />
                <div>
                  <strong className="block font-semibold text-rose-600">
                    {isBn ? 'সম্পূর্ণ প্রতিস্থাপন (ক্লিন রিস্টোর)' : 'Full Overwrite (Clean Replace)'}
                  </strong>
                  <span className="text-[11px] block mt-0.5" style={{ color: 'var(--text-muted)' }}>
                    {isBn
                      ? 'বর্তমান পরিবারের সদস্যদের প্রতিস্থাপন করে হুবহু এই নতুন ডেটাসেট স্থাপন করবে।'
                      : 'Replaces active members with this newly parsed dataset cleanly.'}
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* Table Preview */}
          <div className="overflow-x-auto rounded-2xl border max-h-72 overflow-y-auto" style={{ borderColor: 'var(--border)' }}>
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 z-10" style={{ backgroundColor: 'var(--card)', color: 'var(--text)' }}>
                <tr>
                  <th className="p-3">#</th>
                  <th className="p-3">{isBn ? 'বাংলা নাম' : 'Bangla Name'}</th>
                  <th className="p-3">{isBn ? 'ইংরেজি নাম' : 'English Name'}</th>
                  <th className="p-3">{isBn ? 'লিঙ্গ' : 'Gender'}</th>
                  <th className="p-3">{isBn ? 'জন্ম সাল' : 'Birth'}</th>
                  <th className="p-3">{isBn ? 'পিতা/মাতা লিঙ্ক' : 'Parent Link'}</th>
                  <th className="p-3">{isBn ? 'বৈবাহিক বন্ধন' : 'Marriages'}</th>
                  <th className="p-3">{isBn ? 'অবস্থা' : 'Status'}</th>
                </tr>
              </thead>
              <tbody className="divide-y" style={{ borderColor: 'var(--border)', color: 'var(--text)' }}>
                {universalResult.members.slice(0, 15).map((m, idx) => (
                  <tr key={idx} className="hover:bg-black/5 dark:hover:bg-white/5 transition">
                    <td className="p-3 font-mono font-bold" style={{ color: 'var(--primary)' }}>{idx + 1}</td>
                    <td className="p-3 font-semibold">{m.banglaName || m.fullName}</td>
                    <td className="p-3">{m.englishName || '—'}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold"
                        style={{ backgroundColor: m.gender === 'male' ? 'rgba(59, 130, 246, 0.15)' : 'rgba(236, 72, 153, 0.15)', color: m.gender === 'male' ? '#2563eb' : '#db2777' }}>
                        {m.gender === 'male' ? (isBn ? 'পুরুষ' : 'Male') : (isBn ? 'মহিলা' : 'Female')}
                      </span>
                    </td>
                    <td className="p-3 font-mono">{m.birth?.date?.year ? (isBn ? toBanglaDigits(m.birth.date.year) : m.birth.date.year) : '—'}</td>
                    <td className="p-3 font-mono text-[11px]">
                      {m.fatherId ? '✓ পিতা' : ''} {m.motherId ? '✓ মাতা' : ''} {!m.fatherId && !m.motherId ? '—' : ''}
                    </td>
                    <td className="p-3">
                      {m.marriageIds && m.marriageIds.length > 0 ? (
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                          {isBn ? `${toBanglaDigits(m.marriageIds.length)} টি বন্ধন` : `${m.marriageIds.length} marriages`}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="p-3">{m.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {universalResult.members.length > 15 && (
            <p className="text-[11px] text-center" style={{ color: 'var(--text-muted)' }}>
              {isBn
                ? `... এবং আরও ${toBanglaDigits(universalResult.members.length - 15)} জন সদস্যের রেকর্ড রয়েছে যা স্বয়ংক্রিয়ভাবে অন্তর্ভুক্ত হবে।`
                : `... and ${universalResult.members.length - 15} more members will be automatically imported.`}
            </p>
          )}
        </div>
      )}

      {/* Universal Text Paste Drawer */}
      {isUniversalPasteOpen && (
        <div
          className="rounded-3xl p-5 sm:p-6 border shadow-md space-y-4 animate-in fade-in"
          style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--primary)' }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500 fill-amber-500" />
              <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                {isBn ? 'যেকোনো বংশতালিকা টেক্সট বা কোড পেস্ট করুন' : 'Paste Any Genealogical Data or Text'}
              </h3>
            </div>
            <button
              onClick={() => setIsUniversalPasteOpen(false)}
              className="text-xs font-bold opacity-70 hover:opacity-100"
            >
              ✕
            </button>
          </div>

          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
            {isBn
              ? 'জিইডিকম, সিএসভি, এক্সেল থেকে কপি করা টেক্সট, বা বংশলতিকা ফরম্যাটের যেকোনো তথ্য নিচে পেস্ট করুন। ইঞ্জিন স্বয়ংক্রিয়ভাবে শনাক্ত ও পার্স করবে।'
              : 'Paste raw GEDCOM, CSV, TSV, or structured genealogical records here. The engine will automatically detect and parse it.'}
          </p>

          <textarea
            rows={7}
            value={universalPasteText}
            onChange={e => setUniversalPasteText(e.target.value)}
            placeholder={isBn ? 'এখানে টেক্সট বা কোড পেস্ট করুন...' : 'Paste text or table data here...'}
            className="w-full font-mono text-xs p-4 rounded-2xl border outline-none focus:ring-2 focus:ring-amber-500"
            style={{ backgroundColor: 'var(--card)', color: 'var(--text)', borderColor: 'var(--border)' }}
          />

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <label className="flex items-center gap-2 text-xs cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isAutoDirectImport}
                onChange={e => setIsAutoDirectImport(e.target.checked)}
                className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
              />
              <span style={{ color: 'var(--text)' }}>
                {isBn ? 'সরাসরি ১-ক্লিকে ডাটাবেজে অন্তর্ভুক্ত করুন' : 'Zero-click direct import into database'}
              </span>
            </label>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setIsUniversalPasteOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border hover:opacity-80"
                style={{ backgroundColor: 'var(--card)', color: 'var(--text)', borderColor: 'var(--border)' }}
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={handleUniversalTextImport}
                disabled={isProcessingUniversal || !universalPasteText.trim()}
                className="px-5 py-2 rounded-xl text-xs font-semibold text-white shadow-xs hover:opacity-90 flex items-center gap-1.5"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                {isProcessingUniversal ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Zap className="w-3.5 h-3.5" />
                )}
                <span>{isProcessingUniversal ? (isBn ? 'বিশ্লেষণ হচ্ছে...' : 'Processing...') : (isBn ? 'অটোমেটিক বিশ্লেষণ ও আমদানি' : 'Auto Detect & Import')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UNIVERSAL INTELLIGENT AUTO-IMPORT HERO CARD */}
      {(activeSubTab === 'all' || activeSubTab === 'import') && (
        <div
          className={`rounded-3xl p-6 sm:p-8 border-2 transition-all space-y-6 ${
            isDraggingOver
              ? 'border-amber-500 bg-amber-500/10 scale-[1.008]'
              : 'border-dashed shadow-xs hover:shadow-md'
          }`}
          style={{
            backgroundColor: isDraggingOver ? undefined : 'var(--surface)',
            borderColor: isDraggingOver ? '#f59e0b' : 'var(--primary)'
          }}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border"
                style={{
                  backgroundColor: 'var(--card)',
                  color: 'var(--primary)',
                  borderColor: 'var(--border)'
                }}
              >
                <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>{isBn ? 'স্মার্ট অটো-ইমপোর্ট ইঞ্জিন (Universal Auto-Import)' : 'Intelligent Auto-Import Engine'}</span>
              </div>

              <h2 className="font-serif text-xl sm:text-2xl font-bold tracking-tight" style={{ color: 'var(--text)' }}>
                {isBn ? 'অটোমেটিকভাবে যেকোনো বংশতালিকা ফাইল আমদানি করুন' : 'Universal Automatic Import'}
              </h2>

              <p className="text-xs sm:text-sm leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                {isBn
                  ? 'কোনো জটিল কনফিগারেশন ছাড়াই ফাইল এখানে ড্রপ করুন। ইঞ্জিন স্বয়ংক্রিয়ভাবে ফাইল ফরম্যাট (.bkf, .ged, .csv, .txt), কলাম হেডার, পিতামাতা ও বৈবাহিক সম্পর্ক শনাক্ত করে নির্ভুলভাবে ডাটাবেজে অন্তর্ভুক্ত করবে।'
                  : 'Drop any file here without manual configuration. The system automatically detects file types, maps bilingual columns, reconstructs parent-child trees, and links marriages safely.'}
              </p>

              {/* Feature Pills */}
              <div className="flex flex-wrap gap-2 pt-1">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-[11px] font-semibold bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isBn ? 'অটো-ফরম্যাট শনাক্তকরণ' : 'Auto Format Detection'}</span>
                </span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-[11px] font-semibold bg-amber-50 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  <Heart className="w-3.5 h-3.5 text-amber-600" />
                  <span>{isBn ? 'পিতামাতা ও বৈবাহিক অটো-লিঙ্ক' : 'Auto-Link Parents & Spouses'}</span>
                </span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-[11px] font-semibold bg-indigo-50 text-indigo-800 dark:bg-indigo-950/40 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{isBn ? 'নিরাপদ নন-ডিস্ট্রাক্টিভ মার্জ' : 'Safe Non-Destructive Merge'}</span>
                </span>
              </div>
            </div>

            {/* Direct Fast-Track Toggle */}
            <div className="flex flex-col gap-2 p-4 rounded-2xl border shrink-0 min-w-[220px]" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
              <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>
                {isBn ? 'আমদানি মোড' : 'Import Mode'}
              </span>
              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isAutoDirectImport}
                  onChange={e => setIsAutoDirectImport(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                />
                <span style={{ color: 'var(--text)' }}>
                  {isBn ? '১-ক্লিকে সরাসরি অটো-ইমপোর্ট' : 'Zero-Click Direct Import'}
                </span>
              </label>
              <p className="text-[10px] leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                {isBn
                  ? 'সক্রিয় থাকলে ফাইল ড্রপ বা নির্বাচনের সাথে সাথেই স্বয়ংক্রিয়ভাবে ডাটাবেজে যুক্ত হবে।'
                  : 'Instantly commits data into tree upon drop without extra confirmation screens.'}
              </p>
            </div>
          </div>

          {/* Interactive Drop Box Area */}
          <div
            onClick={() => universalFileInputRef.current?.click()}
            className="cursor-pointer border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center gap-3 transition hover:bg-black/5 dark:hover:bg-white/5"
            style={{ borderColor: 'var(--border)' }}
          >
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-xs" style={{ backgroundColor: 'var(--primary)', color: '#ffffff' }}>
              {isProcessingUniversal ? (
                <RefreshCw className="w-7 h-7 animate-spin" />
              ) : (
                <Upload className="w-7 h-7" />
              )}
            </div>

            <div className="space-y-1">
              <p className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                {isBn
                  ? 'যেকোনো ফাইল এখানে টেনে আনুন (Drag & Drop) অথবা ক্লিক করুন'
                  : 'Drag & Drop any genealogy file here, or click to browse'}
              </p>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {isBn
                  ? 'সমর্থিত: .bkf / .json (বংশকথা ব্যাকআপ), .ged (জিইডিকম), .csv / .tsv (স্প্রেডশিট), .txt (তালিকা)'
                  : 'Supported: .bkf, .json, .ged, .csv, .tsv, .txt'}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  universalFileInputRef.current?.click();
                }}
                className="px-5 py-2.5 rounded-xl text-xs font-bold text-white shadow-xs hover:opacity-90 transition flex items-center gap-2"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                <Upload className="w-4 h-4" />
                <span>{isBn ? 'ফাইল নির্বাচন করুন (অটোমেটিক)' : 'Choose File (Auto-Detect)'}</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsUniversalPasteOpen(prev => !prev);
                }}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center gap-2"
                style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>{isBn ? 'অথবা সরাসরি টেক্সট পেস্ট করুন' : 'Paste Raw Text'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CSV Preview Inspection Modal/Drawer */}
      {csvPreviewData && (
        <div
          className="rounded-3xl p-5 sm:p-6 border shadow-md space-y-4"
          style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--primary)' }}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b" style={{ borderColor: 'var(--border)' }}>
            <div>
              <h3 className="font-serif text-lg font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
                <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                <span>{isBn ? 'সিএসভি ফাইল যাচাইকরণ প্রিভিউ' : 'CSV Import Live Preview'}</span>
              </h3>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {isBn
                  ? `মোট ${toBanglaDigits(csvPreviewData.members.length)} জন সদস্যের রেকর্ড পাওয়া গেছে। ডাটাবেজে যুক্ত করার পূর্বে মিলিয়ে নিন:`
                  : `${csvPreviewData.members.length} member records parsed. Review before committing to lineage:`}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setCsvPreviewData(null)}
                className="px-3 py-1.5 rounded-xl border text-xs font-semibold hover:opacity-80 transition"
                style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                {isBn ? 'বাতিল করুন' : 'Cancel'}
              </button>
              <button
                onClick={handleCommitCsvImport}
                disabled={isImportingCsv}
                className="px-4 py-1.5 rounded-xl text-xs font-semibold text-white shadow-xs hover:opacity-90 transition flex items-center gap-1.5"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                <Check className="w-3.5 h-3.5" />
                <span>{isImportingCsv ? (isBn ? 'আমদানি হচ্ছে...' : 'Importing...') : (isBn ? 'বংশতালিকায় যুক্ত করুন' : 'Confirm Import')}</span>
              </button>
            </div>
          </div>

          {/* Table Preview */}
          <div className="overflow-x-auto rounded-2xl border" style={{ borderColor: 'var(--border)' }}>
            <table className="w-full text-left text-xs">
              <thead style={{ backgroundColor: 'var(--card)', color: 'var(--text)' }}>
                <tr>
                  <th className="p-3">#</th>
                  <th className="p-3">{isBn ? 'বাংলা নাম' : 'Bangla Name'}</th>
                  <th className="p-3">{isBn ? 'ইংরেজি নাম' : 'English Name'}</th>
                  <th className="p-3">{isBn ? 'লিঙ্গ' : 'Gender'}</th>
                  <th className="p-3">{isBn ? 'জন্ম সাল' : 'Birth Year'}</th>
                  <th className="p-3">{isBn ? 'অবস্থা' : 'Status'}</th>
                  <th className="p-3">{isBn ? 'পেশা' : 'Profession'}</th>
                  <th className="p-3">{isBn ? 'জাতীয় পরিচয়পত্র' : 'NID'}</th>
                </tr>
              </thead>
              <tbody className="divide-y" style={{ borderColor: 'var(--border)', color: 'var(--text)' }}>
                {csvPreviewData.members.slice(0, 10).map((m, idx) => (
                  <tr key={idx} className="hover:bg-black/5 dark:hover:bg-white/5 transition">
                    <td className="p-3 font-mono font-bold" style={{ color: 'var(--primary)' }}>{idx + 1}</td>
                    <td className="p-3 font-semibold">{m.banglaName || m.fullName}</td>
                    <td className="p-3">{m.englishName || '—'}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold"
                        style={{ backgroundColor: m.gender === 'male' ? 'rgba(59, 130, 246, 0.15)' : 'rgba(236, 72, 153, 0.15)', color: m.gender === 'male' ? '#2563eb' : '#db2777' }}>
                        {m.gender === 'male' ? (isBn ? 'পুরুষ' : 'Male') : (isBn ? 'মহিলা' : 'Female')}
                      </span>
                    </td>
                    <td className="p-3 font-mono">{m.birth?.date?.year ? (isBn ? toBanglaDigits(m.birth.date.year) : m.birth.date.year) : '—'}</td>
                    <td className="p-3">{m.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}</td>
                    <td className="p-3">{m.importantInformation || '—'}</td>
                    <td className="p-3 font-mono text-[11px]">{m.identityDocs?.nidNumber || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {csvPreviewData.members.length > 10 && (
            <p className="text-[11px] text-center" style={{ color: 'var(--text-muted)' }}>
              {isBn
                ? `... এবং আরও ${toBanglaDigits(csvPreviewData.members.length - 10)} জন সদস্য ডাটাবেজে যুক্ত হবে।`
                : `... and ${csvPreviewData.members.length - 10} more members will be imported.`}
            </p>
          )}
        </div>
      )}

      {/* Raw GEDCOM Text Paste Drawer */}
      {isGedcomPasteOpen && (
        <div
          className="rounded-3xl p-5 sm:p-6 border shadow-md space-y-4"
          style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode className="w-5 h-5 text-indigo-600" />
              <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                {isBn ? 'জিইডিকম কোড সরাসরি পেস্ট করুন' : 'Paste Raw GEDCOM Text'}
              </h3>
            </div>
            <button
              onClick={() => setIsGedcomPasteOpen(false)}
              className="text-xs font-bold opacity-70 hover:opacity-100"
            >
              ✕
            </button>
          </div>

          <textarea
            rows={8}
            value={gedcomPasteText}
            onChange={e => setGedcomPasteText(e.target.value)}
            placeholder="0 HEAD&#10;1 SOUR Ancestry / MyHeritage&#10;1 GEDC&#10;2 VERS 5.5.1&#10;0 @I1@ INDI&#10;1 NAME ..."
            className="w-full font-mono text-xs p-4 rounded-2xl border outline-none focus:ring-2 focus:ring-amber-500"
            style={{ backgroundColor: 'var(--card)', color: 'var(--text)', borderColor: 'var(--border)' }}
          />

          <div className="flex justify-end gap-2">
            <button
              onClick={() => setIsGedcomPasteOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold border hover:opacity-80"
              style={{ backgroundColor: 'var(--card)', color: 'var(--text)', borderColor: 'var(--border)' }}
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              onClick={handleImportGedcomText}
              disabled={isGedcomProcessing || !gedcomPasteText.trim()}
              className="px-5 py-2 rounded-xl text-xs font-semibold text-white shadow-xs hover:opacity-90 flex items-center gap-1.5"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>{isGedcomProcessing ? (isBn ? 'পার্সিং হচ্ছে...' : 'Processing...') : (isBn ? 'জিইডিকম আমদানি করুন' : 'Process GEDCOM')}</span>
            </button>
          </div>
        </div>
      )}

      {/* SECTION 1: EXPORT MODULES */}
      {(activeSubTab === 'all' || activeSubTab === 'export') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-serif text-lg sm:text-xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
              <Download className="w-5 h-5 text-emerald-600" />
              <span>{isBn ? 'উন্নত রপ্তানি সুবিধা (Export Facilities)' : 'Export Capabilities'}</span>
            </h2>
            <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
              {isBn ? 'সকল ফরম্যাটে ১০০% অফলাইন ও বিশ্বমানের ডেটা নিরাপত্তা' : '100% Offline & Universal Compatibility'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* 1. Full Backup Snapshot (.bkf) */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4 transition hover:shadow-md"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-amber-700 dark:text-amber-300 bg-amber-500/10">
                    <HardDrive className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border"
                    style={{ backgroundColor: 'var(--surface)', color: 'var(--primary)', borderColor: 'var(--border)' }}>
                    .BKF / JSON
                  </span>
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'পূর্ণাঙ্গ সিস্টেম ব্যাকআপ' : 'Full Native Archive'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'পরিবারের সকল সদস্য, সম্পর্ক, শাখা, বৈবাহিক তথ্য ও নথিপত্রের শতভাগ অক্ষুণ্ণ ব্যাকআপ স্ন্যাপশট।'
                    : 'Complete lossless archive with all member identities, marriage bonds, branches, and archival documents.'}
                </p>
              </div>

              <button
                onClick={exportArchiveJSON}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-white shadow-xs hover:opacity-90 transition flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                <Download className="w-4 h-4" />
                <span>{isBn ? 'ব্যাকআপ ফাইল ডাউনলোড করুন' : 'Download Backup (.bkf)'}</span>
              </button>
            </div>

            {/* 2. Standalone Portable HTML Archive */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4 transition hover:shadow-md"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-blue-700 dark:text-blue-300 bg-blue-500/10">
                    <Globe className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border"
                    style={{ backgroundColor: 'var(--surface)', color: '#2563eb', borderColor: 'var(--border)' }}>
                    .HTML (OFFLINE)
                  </span>
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'স্বয়ংসম্পূর্ণ অফলাইন এইচটিএমএল' : 'Standalone Offline Webpage'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'একটি মাত্র স্বতন্ত্র ফাইল যা কোনো ইন্টারনেট বা সফটওয়্যার ছাড়াই যেকোনো কম্পিউটার ও মোবাইলের ব্রাউজারে খোলে।'
                    : 'Single portable self-contained interactive file that opens in any browser without internet or software.'}
                </p>
              </div>

              <button
                onClick={handleDownloadOfflineHTML}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <Download className="w-4 h-4 text-blue-600" />
                <span>{isBn ? 'অফলাইন এইচটিএমএল সংগ্রহ করুন' : 'Download HTML (.html)'}</span>
              </button>
            </div>

            {/* 3. International GEDCOM 5.5.1 */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4 transition hover:shadow-md"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-indigo-700 dark:text-indigo-300 bg-indigo-500/10">
                    <FileCode className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border"
                    style={{ backgroundColor: 'var(--surface)', color: '#4f46e5', borderColor: 'var(--border)' }}>
                    GEDCOM 5.5.1
                  </span>
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'আন্তর্জাতিক জিইডিকম ফাইল' : 'Standard GEDCOM Export'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'Ancestry, MyHeritage, FamilySearch, Gramps এর সাথে ১০০% সামঞ্জস্যপূর্ণ স্ট্যান্ডার্ড বংশতালিকা ফরম্যাট।'
                    : 'Global genealogical standard for seamless transfer to Ancestry, MyHeritage, and FamilySearch.'}
                </p>
              </div>

              <button
                onClick={exportGedcomFile}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <Download className="w-4 h-4 text-indigo-600" />
                <span>{isBn ? 'জিইডিকম ফাইল ডাউনলোড (.ged)' : 'Download GEDCOM (.ged)'}</span>
              </button>
            </div>

            {/* 4. Members Excel/CSV with Bangla UTF-8 BOM */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4 transition hover:shadow-md"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-emerald-700 dark:text-emerald-300 bg-emerald-500/10">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border"
                    style={{ backgroundColor: 'var(--surface)', color: '#059669', borderColor: 'var(--border)' }}>
                    UTF-8 BOM (.CSV)
                  </span>
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'সদস্যদের এক্সেল / সিএসভি' : 'Members Spreadsheet'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'বাংলা হরফ নির্ভুলভাবে প্রদর্শনের জন্য UTF-8 BOM যুক্ত। মাইক্রোসফট এক্সেল ও গুগল শিটসে সরাসরি ওপেন হয়।'
                    : 'Bilingual headers and full biographical records formatted specifically for MS Excel & Google Sheets.'}
                </p>
              </div>

              <button
                onClick={handleDownloadMembersCSV}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <Download className="w-4 h-4 text-emerald-600" />
                <span>{isBn ? 'সদস্য তালিকা ডাউনলোড (.csv)' : 'Export Members (.csv)'}</span>
              </button>
            </div>

            {/* 5. Marriages Spreadsheet */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4 transition hover:shadow-md"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-rose-700 dark:text-rose-300 bg-rose-500/10">
                    <Heart className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border"
                    style={{ backgroundColor: 'var(--surface)', color: '#e11d48', borderColor: 'var(--border)' }}>
                    MARRIAGES (.CSV)
                  </span>
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'বৈবাহিক বন্ধন স্প্রেডশিট' : 'Marriages Spreadsheet'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'স্বামী, স্ত্রী, বিবাহের তারিখ, স্থান এবং সন্তানদের নামের সংযোগসহ পূর্ণাঙ্গ স্প্রেডশিট তালিকা।'
                    : 'Complete registry of husband, wife, marriage dates, and children linkages exported in CSV.'}
                </p>
              </div>

              <button
                onClick={handleDownloadMarriagesCSV}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <Download className="w-4 h-4 text-rose-600" />
                <span>{isBn ? 'বিবাহের তালিকা ডাউনলোড (.csv)' : 'Export Marriages (.csv)'}</span>
              </button>
            </div>

            {/* 6. Formatted Lineage Text Dossier */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4 transition hover:shadow-md"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-stone-700 dark:text-stone-300 bg-stone-500/10">
                    <FileText className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border"
                    style={{ backgroundColor: 'var(--surface)', color: 'var(--text)', borderColor: 'var(--border)' }}>
                    DOSSIER (.TXT)
                  </span>
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'কাঠামোগত টেক্সট ডসিয়ার' : 'Lineage Text Dossier'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'প্রজন্মভিত্তিক ক্রমানুসারে সাজানো টেক্সট ফাইল। হোয়াটসঅ্যাপ বা ইমেইলে সহজেই পরিবার সদস্যদের পাঠানো যায়।'
                    : 'Indented generation tree with birth, death, and spouse details, perfect for email and messaging.'}
                </p>
              </div>

              <button
                onClick={handleDownloadTextDossier}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <Download className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                <span>{isBn ? 'টেক্সট ফাইল সংগ্রহ করুন (.txt)' : 'Download Dossier (.txt)'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: IMPORT MODULES */}
      {(activeSubTab === 'all' || activeSubTab === 'import' || activeSubTab === 'backup') && (
        <div className="space-y-4 pt-4">
          <div className="flex items-center justify-between">
            <h2 className="font-serif text-lg sm:text-xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
              <Upload className="w-5 h-5 text-amber-700" />
              <span>{isBn ? 'উন্নত আমদানি সুবিধা (Import Facilities)' : 'Import Capabilities'}</span>
            </h2>
            <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
              {isBn ? 'স্মার্ট মার্জ ও যাচাইকরণ প্রোটোকল' : 'Non-Destructive Smart Merge & Safety'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 1. Import Native Backup (.bkf / .json) */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-amber-700 dark:text-amber-300 bg-amber-500/10">
                  <HardDrive className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'বংশকথা ব্যাকআপ রিস্টোর' : 'Restore Native Backup'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'পূর্বে ব্যাকআপ নেওয়া .bkf বা .json ফাইল আপলোড করুন। ফাইল যাচাইয়ের পর নিরাপদ ডিফারেন্সিয়াল তুলনা প্রদর্শিত হবে।'
                    : 'Upload previously saved .bkf snapshot with interactive diff inspection and conflict resolution.'}
                </p>
              </div>

              <button
                onClick={() => archiveFileInputRef.current?.click()}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-white shadow-xs hover:opacity-90 transition flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                <Upload className="w-4 h-4" />
                <span>{isBn ? 'ব্যাকআপ ফাইল বেছে নিন (.bkf)' : 'Select Backup File'}</span>
              </button>
            </div>

            {/* 2. Import GEDCOM 5.5.1 */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-indigo-700 dark:text-indigo-300 bg-indigo-500/10">
                  <FileCode className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'জিইডিকম ফাইল আমদানি' : 'Import GEDCOM 5.5.1'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'অন্যান্য বংশতালিকা সফটওয়্যার বা ওয়েবসাইট থেকে প্রাপ্ত .ged ফাইল আপলোড করুন অথবা কোড পেস্ট করুন।'
                    : 'Import standard .ged file exported from Ancestry, MyHeritage, or paste raw genealogical text.'}
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => gedcomFileInputRef.current?.click()}
                  className="flex-1 py-2.5 px-3 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center justify-center gap-1.5"
                  style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text)' }}
                >
                  <Upload className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{isBn ? 'ফাইল নির্বাচন' : 'File (.ged)'}</span>
                </button>
                <button
                  onClick={() => setIsGedcomPasteOpen(prev => !prev)}
                  className="py-2.5 px-3 rounded-xl text-xs font-semibold border hover:opacity-80 transition"
                  style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text)' }}
                  title="কোড পেস্ট করুন"
                >
                  {isBn ? 'পেস্ট' : 'Paste'}
                </button>
              </div>
            </div>

            {/* 3. Import CSV / Excel File */}
            <div
              className="rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4"
              style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <div className="space-y-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-emerald-700 dark:text-emerald-300 bg-emerald-500/10">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-base font-bold" style={{ color: 'var(--text)' }}>
                  {isBn ? 'স্প্রেডশিট থেকে সদস্য আমদানি' : 'Batch Import CSV'}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {isBn
                    ? 'এক্সেল বা গুগল শিটস থেকে সংরক্ষিত .csv ফাইল আপলোড করুন। স্বয়ংক্রিয়ভাবে নাম ও কলাম শনাক্ত করা হবে।'
                    : 'Upload spreadsheet with auto-detected columns for rapid onboarding of family members.'}
                </p>
              </div>

              <button
                onClick={() => csvFileInputRef.current?.click()}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <Upload className="w-4 h-4 text-emerald-600" />
                <span>{isBn ? 'সিএসভি ফাইল আপলোড করুন' : 'Upload CSV (.csv)'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: BLANK TEMPLATES & SAMPLE DATASET */}
      {(activeSubTab === 'all' || activeSubTab === 'excel') && (
        <div
          className="rounded-3xl p-6 border shadow-xs space-y-4"
          style={{ backgroundColor: 'var(--surface)', borderColor: 'var(--border)' }}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="font-serif text-base sm:text-lg font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
                <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                <span>{isBn ? 'তথ্য সংগ্রহের ফাঁকা এক্সেল টেমপ্লেট' : 'Offline Data Collection Templates'}</span>
              </h3>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {isBn
                  ? 'পরিবারের বয়োজ্যেষ্ঠদের কাছ থেকে তথ্য সংগ্রহ বা মাঠে তথ্য নেওয়ার জন্য আদর্শ বাংলা ও ইংরেজি কলামযুক্ত টেমপ্লেট।'
                  : 'Download pre-formatted bilingual spreadsheet template for collecting oral history from elders.'}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleDownloadCsvTemplate}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white shadow-xs hover:opacity-90 transition flex items-center gap-1.5"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isBn ? 'ফাঁকা সদস্য টেমপ্লেট ডাউনলোড' : 'Download Members Template'}</span>
              </button>

              <button
                onClick={handleLoadSampleData}
                className="px-4 py-2 rounded-xl text-xs font-semibold border hover:opacity-80 transition flex items-center gap-1.5"
                style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>{isBn ? 'সিলেট চৌধুরী বংশের নমুনা লোড' : 'Load Verified Sample Data'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: DATA INTEGRITY & ARCHIVAL SAFETY AUDIT */}
      <div
        className="rounded-2xl p-5 border text-xs space-y-3"
        style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', color: 'var(--text-muted)' }}
      >
        <div className="flex items-center gap-2 font-bold text-sm" style={{ color: 'var(--text)' }}>
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>{isBn ? 'নিরাপত্তা ও তথ্য সুরক্ষার নিশ্চয়তা' : 'Data Integrity & Privacy Guarantee'}</span>
        </div>
        <p className="leading-relaxed">
          {isBn
            ? 'বংশকথা একটি অফলাইন-ফার্স্ট অ্যাপ্লিকেশন। আপনার পরিবারের কোনো তথ্য কোনো বহিরাগত ক্লাউড সার্ভারে গোপনে প্রেরিত হয় না। সকল আমদানি ও রপ্তানি প্রক্রিয়া সরাসরি আপনার ডিভাইসের ব্রাউজারে প্রক্রিয়াভুক্ত হয়। নিয়মিত .bkf ব্যাকআপ সংগ্রহ করে গুগল ড্রাইভ বা পেনড্রাইভে সংরক্ষণ করার পরামর্শ দেওয়া হচ্ছে।'
            : 'Bongshokotha operates offline-first. All export, import, parsing, and restoration routines execute entirely within your local browser sandbox without unencrypted cloud transmission.'}
        </p>
      </div>

      {/* Safe Diff Inspection Modal */}
      {pendingArchive && (
        <SafeRestoreDiffModal
          isOpen={isDiffModalOpen}
          onClose={() => {
            setIsDiffModalOpen(false);
            setPendingArchive(null);
          }}
          incomingArchive={pendingArchive}
          currentMembers={members}
          currentMarriages={marriages}
          onConfirmRestore={handleConfirmRestore}
          isBn={isBn}
        />
      )}
    </div>
  );
};
