/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Oral History & Audio Recording Studio (Rule 18)
 * 
 * Records / uploads short audio narratives with speaker, date, transcript and member association.
 */

import React, { useState, useRef, useEffect } from 'react';
import { useGenealogy } from '../../context/GenealogyContext';
import { Member, ArchiveRecord } from '../../types/genealogy';
import {
  Mic,
  Square,
  Play,
  Pause,
  Upload,
  Radio,
  FileAudio,
  CheckCircle2,
  Calendar,
  User,
  X,
  Volume2
} from 'lucide-react';

interface OralHistoryRecorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (recordData: Omit<ArchiveRecord, 'id' | 'createdAt' | 'updatedAt' | 'history'>) => Promise<void>;
  preselectedMemberId?: string;
  isBn: boolean;
}

export const OralHistoryRecorderModal: React.FC<OralHistoryRecorderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  preselectedMemberId,
  isBn
}) => {
  const { members, family } = useGenealogy();

  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // Form Fields
  const [titleBn, setTitleBn] = useState('');
  const [titleEn, setTitleEn] = useState('');
  const [speaker, setSpeaker] = useState('');
  const [recordDate, setRecordDate] = useState(new Date().toISOString().slice(0, 10));
  const [selectedMemberId, setSelectedMemberId] = useState(preselectedMemberId || '');
  const [description, setDescription] = useState('');
  const [transcript, setTranscript] = useState('');
  const [permission, setPermission] = useState<'public' | 'family' | 'admin' | 'restricted'>('family');
  const [isSaving, setIsSaving] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  if (!isOpen) return null;

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = e => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setAudioBlob(blob);
        setAudioUrl(url);
        stream.getTracks().forEach(t => t.stop());
      };

      recorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);

      timerRef.current = window.setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Microphone access denied:', err);
      alert(isBn ? 'মাইক্রোফোন সংযোগ পাওয়া যায়নি বা অনুমতি মেলেনি।' : 'Microphone access denied or not available.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setIsRecording(false);
  };

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setAudioUrl(result);
      setAudioBlob(file);
      if (!titleBn) {
        setTitleBn(file.name.replace(/\.[^/.]+$/, ''));
      }
    };
    reader.readAsDataURL(file);
  };

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSave = async () => {
    if (!audioUrl) {
      alert(isBn ? 'অনুগ্রহ করে অডিও রেকর্ড বা আপলোড করুন।' : 'Please record or upload an audio clip.');
      return;
    }

    const title = titleEn.trim() || titleBn.trim() || (isBn ? 'পারিবারিক মৌখিক স্মৃতিচারণ' : 'Family Oral Memoir');
    setIsSaving(true);

    try {
      await onSave({
        title,
        titleBn: titleBn.trim() || title,
        category: 'audio',
        documentType: 'family_record',
        date: recordDate,
        description: description.trim(),
        descriptionBn: description.trim(),
        relatedMemberIds: selectedMemberId ? [selectedMemberId] : [],
        memberRoles: selectedMemberId ? { [selectedMemberId]: 'বক্তা / স্মৃতিচারণকারী' } : {},
        relatedFamilyId: family.id,
        mediaUrl: audioUrl,
        mediaType: 'audio',
        mimeType: 'audio/webm',
        fileSizeBytes: audioBlob?.size || 0,
        ocrVerification: 'verified',
        source: 'পারিবারিক মৌখিক ইতিহাস সংগ্রহশালা',
        provenance: `রেকর্ডকারী: ${speaker || 'পারিবারিক সদস্য'} (${recordDate})`,
        tags: ['মৌখিক ইতিহাস', 'অডিও', 'স্মৃতিচারণ'],
        accessPermission: permission,
        audioMetadata: {
          speaker: speaker.trim(),
          durationSeconds: recordingSeconds || 60,
          transcript: transcript.trim()
        }
      });
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl border border-amber-900/30 bg-[#fbf9f5] shadow-2xl dark:bg-stone-900 dark:border-stone-700">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-900/10 px-6 py-5 dark:border-stone-800">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">
              <Radio className="h-6 w-6" />
            </div>
            <div>
              <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100">
                {isBn ? 'মৌখিক ইতিহাস ও স্মৃতিচারণ রেকর্ডার' : 'Oral History & Voice Archive'}
              </h2>
              <p className="text-xs text-stone-600 dark:text-stone-400">
                {isBn
                  ? 'পূর্বপুরুষের কণ্ঠস্বর, প্রত্যক্ষ স্মৃতিকথা ও পারিভাষিক উপাখ্যান সংরক্ষণ'
                  : 'Preserve authentic ancestral voices, firsthand memories and oral narratives'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-stone-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Studio Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Recording / Player Deck */}
          <div className="rounded-3xl border border-rose-900/20 bg-rose-50/50 p-6 text-center dark:border-rose-950 dark:bg-rose-950/20 space-y-4">
            <div className="flex flex-col items-center justify-center">
              {isRecording ? (
                <div className="relative mb-2">
                  <div className="h-20 w-20 rounded-full bg-rose-600 animate-ping absolute inset-0 opacity-40" />
                  <button
                    type="button"
                    onClick={stopRecording}
                    className="relative flex h-20 w-20 items-center justify-center rounded-full bg-rose-600 text-white shadow-lg hover:bg-rose-700 transition"
                  >
                    <Square className="h-8 w-8 fill-current" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={startRecording}
                  className="flex h-20 w-20 items-center justify-center rounded-full bg-rose-700 text-white shadow-lg hover:bg-rose-800 hover:scale-105 transition"
                >
                  <Mic className="h-9 w-9" />
                </button>
              )}

              <div className="mt-3 font-mono text-2xl font-bold tracking-wider text-rose-950 dark:text-rose-200">
                {formatTimer(recordingSeconds)}
              </div>
              <p className="text-xs text-rose-800/80 dark:text-rose-300">
                {isRecording
                  ? (isBn ? 'রেকর্ডিং চলছে... সম্পন্ন হলে লাল বোতামে চাপুন' : 'Recording in progress... Click square to stop')
                  : audioUrl
                  ? (isBn ? 'রেকর্ড সংরক্ষিত হয়েছে। নিচে প্লে করে শুনুন।' : 'Recorded. Play preview below or re-record.')
                  : (isBn ? 'রেকর্ডিং শুরু করতে মাইক্রোফোনে চাপুন' : 'Click microphone to begin voice recording')}
              </p>
            </div>

            {/* Playback preview if audio ready */}
            {audioUrl && (
              <div className="pt-3 border-t border-rose-200 dark:border-rose-900/50">
                <audio
                  ref={audioPlayerRef}
                  src={audioUrl}
                  controls
                  className="w-full max-w-md mx-auto"
                />
              </div>
            )}

            {/* Alternative: Upload existing audio */}
            {!isRecording && (
              <div className="pt-2 text-xs text-stone-500 flex items-center justify-center gap-2">
                <span>{isBn ? 'অথবা বিদ্যমান অডিও ফাইল আপলোড করুন:' : 'Or upload existing audio file:'}</span>
                <label className="cursor-pointer font-semibold text-rose-800 hover:underline dark:text-rose-300 inline-flex items-center gap-1">
                  <Upload className="h-3.5 w-3.5" />
                  <span>{isBn ? 'ফাইল বাছুন' : 'Browse'}</span>
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={handleAudioUpload}
                    className="hidden"
                  />
                </label>
              </div>
            )}
          </div>

          {/* Metadata Fields */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  {isBn ? 'স্মৃতিচারণের শিরোনাম (বাংলা)' : 'Title (Bengali)'} *
                </label>
                <input
                  type="text"
                  value={titleBn}
                  onChange={e => setTitleBn(e.target.value)}
                  placeholder={isBn ? 'যেমন: ১৯৭১-এর যুদ্ধকালীন স্মৃতিচারণ' : 'e.g. Memories of 1971'}
                  className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-sm text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  {isBn ? 'শিরোনাম (English)' : 'Title (English)'}
                </label>
                <input
                  type="text"
                  value={titleEn}
                  onChange={e => setTitleEn(e.target.value)}
                  placeholder="e.g. Oral History: Memories of 1971"
                  className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-sm text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1 flex items-center gap-1">
                  <User className="h-3.5 w-3.5 text-stone-400" />
                  {isBn ? 'বক্তার নাম' : 'Speaker Name'}
                </label>
                <input
                  type="text"
                  value={speaker}
                  onChange={e => setSpeaker(e.target.value)}
                  placeholder={isBn ? 'যেমন: বেগম রাবেয়া খাতুন' : 'e.g. Rabeya Khatun'}
                  className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-sm text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1 flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5 text-stone-400" />
                  {isBn ? 'রেকর্ডের তারিখ' : 'Date Recorded'}
                </label>
                <input
                  type="date"
                  value={recordDate}
                  onChange={e => setRecordDate(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-sm text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  {isBn ? 'সম্পর্কিত পরিবার সদস্য' : 'Related Family Member'}
                </label>
                <select
                  value={selectedMemberId}
                  onChange={e => setSelectedMemberId(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-sm text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                >
                  <option value="">{isBn ? '-- নির্বাচন করুন --' : '-- Select Member --'}</option>
                  {members.map(m => (
                    <option key={m.id} value={m.id}>
                      {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName} ()
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                {isBn ? 'কথোপকথন ও অডিওর লিখিত রূপ (Transcript)' : 'Transcript / Spoken Content'}
              </label>
              <textarea
                value={transcript}
                onChange={e => setTranscript(e.target.value)}
                rows={3}
                placeholder={isBn ? 'বক্তার মুখের কথা হুবহু এখানে টাইপ করুন...' : 'Type or paste transcript of the spoken words here...'}
                className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-sm text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                {isBn ? 'সংক্ষিপ্ত প্রেক্ষাপট ও বর্ণনা' : 'Description & Context'}
              </label>
              <input
                type="text"
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder={isBn ? 'কোথায় এবং কোন উপলক্ষে এই স্মৃতি রেকর্ড করা হয়েছিল' : 'Context and occasion of this voice memo'}
                className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-sm text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
              />
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-amber-900/10 bg-stone-50/70 px-6 py-4 dark:border-stone-800 dark:bg-stone-900/90">
          <div className="text-xs text-stone-500">
            {isBn ? 'অডিও স্থায়ীভাবে ডিজিটাল আর্কাইভে নথিবদ্ধ হবে।' : 'Audio is permanently stored in the family archive.'}
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-stone-300 px-4 py-2.5 text-sm font-semibold text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300"
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={isSaving || !audioUrl}
              className="inline-flex items-center gap-2 rounded-xl bg-rose-800 px-5 py-2.5 text-sm font-semibold text-white shadow-md hover:bg-rose-900 disabled:opacity-50 transition"
            >
              <CheckCircle2 className="h-4 w-4" />
              {isSaving ? (isBn ? 'সংরক্ষণ হচ্ছে...' : 'Saving...') : (isBn ? 'আর্কাইভে সংরক্ষণ করুন' : 'Save to Archive')}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
