/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Archive Record Detail & Evidence Inspector (Part 3)
 * 
 * - Original Evidence vs Enhanced Copy Switch
 * - Audio Playback & Transcript Viewer
 * - Bidirectional Member Profile Navigation (Rule 6: Archive -> Member Profile)
 * - Member Link / Unlink with Roles
 * - Re-run OCR & Conflict Resolution Trigger
 * - Full Immutable Audit Trail (Rule 20)
 * - Provenance & Privacy Shield (Rule 21)
 */

import React, { useState } from 'react';
import { useGenealogy } from '../../context/GenealogyContext';
import { ArchiveRecord, Member } from '../../types/genealogy';
import { runDocumentOcr, detectConflicts } from '../../engine/ocrEngine';
import { DocumentConflictModal } from './DocumentConflictModal';
import {
  FileText,
  Image as ImageIcon,
  Radio,
  Calendar,
  Shield,
  Eye,
  CheckCircle2,
  AlertTriangle,
  User,
  Users,
  Copy,
  Check,
  RotateCw,
  Sparkles,
  History,
  Trash2,
  ExternalLink,
  Plus,
  X,
  Volume2
} from 'lucide-react';

interface ArchiveRecordDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: ArchiveRecord;
  onOpenMemberProfile: (memberId: string) => void;
  isBn: boolean;
}

export const ArchiveRecordDetailModal: React.FC<ArchiveRecordDetailModalProps> = ({
  isOpen,
  onClose,
  record,
  onOpenMemberProfile,
  isBn
}) => {
  const {
    members,
    updateArchiveRecord,
    deleteArchiveRecord,
    linkDocumentToMember,
    unlinkDocumentFromMember,
    updateMember
  } = useGenealogy();

  const [activeVersion, setActiveVersion] = useState<'original' | 'enhanced'>(
    record.enhancedMediaUrl ? 'enhanced' : 'original'
  );
  const [activeTab, setActiveTab] = useState<'preview' | 'ocr' | 'audit'>('preview');
  const [isCopied, setIsCopied] = useState(false);
  const [isOcrRunning, setIsOcrRunning] = useState(false);
  const [showAddMemberDropdown, setShowAddMemberDropdown] = useState(false);
  const [newMemberRole, setNewMemberRole] = useState('সংযুক্ত সদস্য');
  const [selectedAddMemberId, setSelectedAddMemberId] = useState('');

  // Conflict Modal
  const [showConflictModal, setShowConflictModal] = useState(false);
  const [detectedConflicts, setDetectedConflicts] = useState<any[]>([]);
  const [conflictMember, setConflictMember] = useState<Member | null>(null);

  if (!isOpen) return null;

  const currentMediaUrl =
    activeVersion === 'enhanced' && record.enhancedMediaUrl
      ? record.enhancedMediaUrl
      : record.mediaUrl;

  const relatedMembers = members.filter(m => (record.relatedMemberIds || []).includes(m.id));

  const handleCopyOcr = () => {
    if (record.ocrText) {
      navigator.clipboard.writeText(record.ocrText);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const handleReRunOcr = async () => {
    setIsOcrRunning(true);
    try {
      const res = await runDocumentOcr(record.mediaUrl, 'ben+eng');
      await updateArchiveRecord(
        {
          ...record,
          ocrText: res.text,
          ocrConfidence: res.confidence,
          ocrVerification: 'unverified',
          extractedFields: res.extractedFields
        },
        `ওসিআর পুনরায় বিশ্লেষণ সম্পন্ন (নির্ভুলতা: ${res.confidence}%)`
      );
    } catch (e) {
      console.error(e);
      alert(isBn ? 'ওসিআর বিশ্লেষণে ত্রুটি হয়েছে।' : 'OCR re-analysis failed.');
    } finally {
      setIsOcrRunning(false);
    }
  };

  const handleVerifyWithMember = async (member: Member) => {
    if (!record.extractedFields) {
      alert(isBn ? 'এই দলিলের কোনো ওসিআর নিষ্কাশিত তথ্য নেই।' : 'No extracted OCR fields found.');
      return;
    }
    const conflicts = detectConflicts(
      record.extractedFields,
      member,
      members,
      record.titleBn || record.title
    );
    if (conflicts.length === 0) {
      await updateArchiveRecord(
        {
          ...record,
          ocrVerification: 'verified',
          history: [
            ...(record.history || []),
            {
              id: `hist-${Date.now()}-ocr-verify`,
              action: 'ocr_verified',
              timestamp: new Date().toISOString(),
              user: isBn ? 'ব্যবহারকারী' : 'User',
              details: `OCR verified against member profile: ${member.banglaName || member.fullName || member.englishName || member.id}`
            }
          ]
        },
        isBn ? 'OCR তথ্য যাচাই সম্পন্ন হয়েছে। কোনো অমিল পাওয়া যায়নি।' : 'OCR verification completed. No conflicts were found.'
      );
      alert(
        isBn
          ? 'কোনো তথ্যের অমিল পাওয়া যায়নি। OCR যাচাই সম্পন্ন হিসেবে চিহ্নিত হয়েছে।'
          : 'No conflicts detected. The OCR record is now marked as verified.'
      );
      return;
    }
    setDetectedConflicts(conflicts);
    setConflictMember(member);
    setShowConflictModal(true);
  };

  const handleAddMemberLink = async () => {
    if (!selectedAddMemberId) return;
    await linkDocumentToMember(record.id, selectedAddMemberId, newMemberRole);
    setSelectedAddMemberId('');
    setShowAddMemberDropdown(false);
  };

  const handleDeleteRecord = async () => {
    const confirmMsg = isBn
      ? `আপনি কি নিশ্চিত যে "${record.titleBn || record.title}" দলিলটি মুছে ফেলতে চান?`
      : `Are you sure you want to delete "${record.title}"?`;
    if (window.confirm(confirmMsg)) {
      await deleteArchiveRecord(record.id);
      onClose();
    }
  };

  const handleConflictResolve = async (
    resolutions: Record<string, { decision: 'accept' | 'reject' | 'custom'; value: string }>
  ) => {
    if (!conflictMember) return;
    const updated = { ...conflictMember };
    let changed = false;

    Object.entries(resolutions).forEach(([fieldKey, res]) => {
      if (res.decision === 'accept' || res.decision === 'custom') {
        changed = true;
        if (fieldKey === 'banglaName') updated.banglaName = res.value;
        if (fieldKey === 'nidNumber') {
          updated.identityDocs = {
            ...updated.identityDocs,
            nidNumber: res.value,
            verificationStatus: 'verified'
          };
        }
        if (fieldKey === 'birthRegistrationNumber') {
          updated.identityDocs = {
            ...updated.identityDocs,
            birthRegistrationNumber: res.value,
            verificationStatus: 'verified'
          };
        }
      }
    });

    if (changed) {
      await updateMember(updated);
    }
    await updateArchiveRecord(
      {
        ...record,
        ocrVerification: 'verified',
        history: [
          ...(record.history || []),
          {
            id: `hist-${Date.now()}-ocr-verify`,
            action: 'ocr_verified',
            timestamp: new Date().toISOString(),
            user: isBn ? 'ব্যবহারকারী' : 'User',
            details: `OCR conflict review completed for ${conflictMember.banglaName || conflictMember.fullName || conflictMember.englishName || conflictMember.id}.`
          }
        ]
      },
      isBn ? `সদস্য ${conflictMember.banglaName || conflictMember.fullName}-এর সাথে OCR অমিল যাচাই সম্পন্ন।` : `OCR conflict review completed for ${conflictMember.banglaName || conflictMember.fullName}.`
    );
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-in fade-in duration-200">
        <div className="w-full max-w-5xl max-h-[92vh] flex flex-col rounded-3xl border border-amber-900/30 bg-[#fbf9f5] shadow-2xl dark:bg-stone-900 dark:border-stone-700">
          
          {/* Header */}
          <div className="flex items-center justify-between border-b border-amber-900/10 px-6 py-4 dark:border-stone-800">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300">
                {record.mediaType === 'audio' ? (
                  <Radio className="h-6 w-6" />
                ) : (
                  <FileText className="h-6 w-6" />
                )}
              </div>
              <div>
                <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100">
                  {isBn ? record.titleBn || record.title : record.title || record.titleBn}
                </h2>
                <div className="flex items-center gap-2 text-xs text-stone-500">
                  <span className="capitalize font-medium text-amber-900 dark:text-amber-300">
                    {record.category.replace('_', ' ')}
                  </span>
                  <span>•</span>
                  <span>{record.date}</span>
                  <span>•</span>
                  <span className="rounded bg-stone-100 px-1.5 py-0.5 text-[10px] uppercase dark:bg-stone-800">
                    {record.accessPermission}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDeleteRecord}
                className="rounded-full p-2 text-stone-400 hover:bg-rose-100 hover:text-rose-700 dark:hover:bg-rose-950/50"
                title={isBn ? 'দলিল মুছুন' : 'Delete Document'}
              >
                <Trash2 className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={onClose}
                className="rounded-full p-2 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-stone-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Provenance & Original Evidence Rule Banner */}
          <div className="bg-amber-500/10 border-b border-amber-500/20 px-6 py-2.5 flex flex-wrap items-center justify-between text-xs text-amber-900 dark:text-amber-200">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-amber-800 dark:text-amber-400 shrink-0" />
              <span>
                <strong>{isBn ? 'ঐতিহাসিক প্রমাণসূত্র:' : 'Provenance:'}</strong> {record.provenance || record.source || (isBn ? 'পারিবারিক সংগ্রহশালা' : 'Family Archive')}
              </span>
            </div>
            
            {record.enhancedMediaUrl && (
              <div className="flex items-center gap-1 bg-amber-200/60 rounded-xl p-1 dark:bg-amber-900/60">
                <button
                  type="button"
                  onClick={() => setActiveVersion('original')}
                  className={`rounded-lg px-2 py-0.5 font-bold transition text-[11px] ${
                    activeVersion === 'original'
                      ? 'bg-amber-900 text-white shadow-xs dark:bg-amber-800'
                      : 'text-amber-900 hover:bg-white/40 dark:text-amber-200'
                  }`}
                >
                  {isBn ? 'মূল অক্ষত প্রমাণ' : 'Original Evidence'}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveVersion('enhanced')}
                  className={`rounded-lg px-2 py-0.5 font-bold transition text-[11px] ${
                    activeVersion === 'enhanced'
                      ? 'bg-amber-900 text-white shadow-xs dark:bg-amber-800'
                      : 'text-amber-900 hover:bg-white/40 dark:text-amber-200'
                  }`}
                >
                  {isBn ? 'উন্নত ডিজিটাল কপি' : 'Enhanced Copy'}
                </button>
              </div>
            )}
          </div>

          {/* Sub Navigation Tabs */}
          <div className="flex border-b border-amber-900/10 bg-stone-50/50 px-6 pt-2 dark:border-stone-800 dark:bg-stone-950/40 gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-bold transition ${
                activeTab === 'preview'
                  ? 'border-amber-900 text-amber-900 dark:border-amber-400 dark:text-amber-300'
                  : 'border-transparent text-stone-600 hover:text-stone-900 dark:text-stone-400'
              }`}
            >
              <Eye className="h-4 w-4" />
              {isBn ? 'দলিল ও তথ্য' : 'Document & Data'}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('ocr')}
              className={`flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-bold transition ${
                activeTab === 'ocr'
                  ? 'border-amber-900 text-amber-900 dark:border-amber-400 dark:text-amber-300'
                  : 'border-transparent text-stone-600 hover:text-stone-900 dark:text-stone-400'
              }`}
            >
              <Sparkles className="h-4 w-4" />
              {isBn ? 'ওসিআর হরফ ও ক্ষেত্র' : 'OCR & Extracted Text'}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('audit')}
              className={`flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-bold transition ${
                activeTab === 'audit'
                  ? 'border-amber-900 text-amber-900 dark:border-amber-400 dark:text-amber-300'
                  : 'border-transparent text-stone-600 hover:text-stone-900 dark:text-stone-400'
              }`}
            >
              <History className="h-4 w-4" />
              {isBn ? `সম্পাদনা ইতিহাস (${record.history?.length || 1})` : `Audit Trail (${record.history?.length || 1})`}
            </button>
          </div>

          {/* Content Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {activeTab === 'preview' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left: Media Viewer */}
                <div className="lg:col-span-6 space-y-3">
                  <div className="relative overflow-hidden rounded-2xl border border-stone-300 bg-stone-950 flex items-center justify-center min-h-[300px] max-h-[460px]">
                    {record.mediaType === 'audio' ? (
                      <div className="p-8 text-center space-y-4 w-full">
                        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-rose-900/50 text-rose-300 border border-rose-500/30">
                          <Volume2 className="h-10 w-10" />
                        </div>
                        <div className="text-white font-serif font-bold text-lg">
                          {record.audioMetadata?.speaker || (isBn ? 'পারিবারিক স্মৃতিচারণ' : 'Family Voice')}
                        </div>
                        <audio src={record.mediaUrl} controls className="w-full max-w-sm mx-auto" />
                        {record.audioMetadata?.transcript && (
                          <div className="rounded-xl bg-stone-900/80 p-4 text-xs text-stone-300 text-left max-h-36 overflow-y-auto">
                            <strong>{isBn ? 'কথোপকথন (Transcript):' : 'Transcript:'}</strong>
                            <p className="mt-1 leading-relaxed">{record.audioMetadata.transcript}</p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <img
                        src={currentMediaUrl}
                        alt={record.title}
                        className="max-h-[460px] w-auto object-contain"
                      />
                    )}
                  </div>

                  {record.mediaType !== 'audio' && (
                    <div className="flex justify-between items-center text-xs text-stone-500">
                      <span>{record.originalFilename || 'document_scan.jpg'}</span>
                      <span>
                        {record.fileSizeBytes ? `${(record.fileSizeBytes / 1024).toFixed(0)} KB` : ''}
                      </span>
                    </div>
                  )}
                </div>

                {/* Right: Structured Metadata & Linked Members */}
                <div className="lg:col-span-6 space-y-5">
                  
                  {/* Document Numbers Badge Deck */}
                  {record.documentNumbers && Object.values(record.documentNumbers).some(Boolean) && (
                    <div className="rounded-2xl border border-amber-900/20 bg-amber-50/40 p-4 dark:border-stone-800 dark:bg-stone-950/60 space-y-2">
                      <div className="text-xs font-bold text-amber-950 dark:text-amber-200">
                        {isBn ? 'দালিলিক নম্বর ও সরকারি তথ্যসূত্র:' : 'Official Registry & Document Numbers:'}
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {record.documentNumbers.nid && (
                          <div className="rounded-lg bg-white p-2 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                            <span className="text-stone-500 block text-[10px]">NID Card No.</span>
                            <span className="font-mono font-bold text-stone-900 dark:text-stone-100">{record.documentNumbers.nid}</span>
                          </div>
                        )}
                        {record.documentNumbers.brn && (
                          <div className="rounded-lg bg-white p-2 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                            <span className="text-stone-500 block text-[10px]">Birth Reg No. (BRN)</span>
                            <span className="font-mono font-bold text-stone-900 dark:text-stone-100">{record.documentNumbers.brn}</span>
                          </div>
                        )}
                        {record.documentNumbers.khatian && (
                          <div className="rounded-lg bg-white p-2 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                            <span className="text-stone-500 block text-[10px]">{isBn ? 'খতিয়ান নং' : 'Khatian No.'}</span>
                            <span className="font-mono font-bold text-stone-900 dark:text-stone-100">{record.documentNumbers.khatian}</span>
                          </div>
                        )}
                        {record.documentNumbers.dag && (
                          <div className="rounded-lg bg-white p-2 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                            <span className="text-stone-500 block text-[10px]">{isBn ? 'দাগ নং' : 'Dag No.'}</span>
                            <span className="font-mono font-bold text-stone-900 dark:text-stone-100">{record.documentNumbers.dag}</span>
                          </div>
                        )}
                        {record.documentNumbers.deed && (
                          <div className="rounded-lg bg-white p-2 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                            <span className="text-stone-500 block text-[10px]">{isBn ? 'দলিল নম্বর' : 'Deed No.'}</span>
                            <span className="font-mono font-bold text-stone-900 dark:text-stone-100">{record.documentNumbers.deed}</span>
                          </div>
                        )}
                        {record.documentNumbers.mouza && (
                          <div className="rounded-lg bg-white p-2 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                            <span className="text-stone-500 block text-[10px]">{isBn ? 'মৌজা' : 'Mouza'}</span>
                            <span className="font-semibold text-stone-900 dark:text-stone-100">{record.documentNumbers.mouza}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Description */}
                  {record.description && (
                    <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-950 text-xs space-y-1">
                      <div className="font-bold text-stone-700 dark:text-stone-300">{isBn ? 'বিবরণ ও প্রসঙ্গ:' : 'Description & Context:'}</div>
                      <p className="text-stone-600 dark:text-stone-400 leading-relaxed">{record.description}</p>
                    </div>
                  )}

                  {/* Related Members Section (Rule 6: Bidirectional Jump) */}
                  <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-950 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-amber-800 dark:text-amber-400" />
                        <span className="text-xs font-bold text-stone-900 dark:text-stone-100">
                          {isBn ? `সম্পর্কিত পরিবার সদস্য (${relatedMembers.length})` : `Related Members (${relatedMembers.length})`}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowAddMemberDropdown(!showAddMemberDropdown)}
                        className="inline-flex items-center gap-1 rounded-lg border border-amber-800/30 bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-900 hover:bg-amber-100 dark:bg-amber-950/60 dark:text-amber-300"
                      >
                        <Plus className="h-3.5 w-3.5" />
                        <span>{isBn ? 'সদস্য যুক্ত করুন' : 'Link Member'}</span>
                      </button>
                    </div>

                    {/* Add member inline bar */}
                    {showAddMemberDropdown && (
                      <div className="flex flex-wrap gap-2 rounded-xl bg-amber-50/80 p-3 dark:bg-stone-900 border border-amber-900/20">
                        <select
                          value={selectedAddMemberId}
                          onChange={e => setSelectedAddMemberId(e.target.value)}
                          className="flex-1 rounded-lg border border-stone-300 bg-white px-2 py-1 text-xs dark:bg-stone-800 dark:text-white"
                        >
                          <option value="">{isBn ? '-- সদস্য নির্বাচন করুন --' : '-- Select Member --'}</option>
                          {members
                            .filter(m => !(record.relatedMemberIds || []).includes(m.id))
                            .map(m => (
                              <option key={m.id} value={m.id}>
                                {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName} ()
                              </option>
                            ))}
                        </select>
                        <input
                          type="text"
                          value={newMemberRole}
                          onChange={e => setNewMemberRole(e.target.value)}
                          placeholder={isBn ? 'ভূমিকা (যেমন: সহ-মালিক)' : 'Role'}
                          className="w-32 rounded-lg border border-stone-300 bg-white px-2 py-1 text-xs dark:bg-stone-800 dark:text-white"
                        />
                        <button
                          type="button"
                          onClick={handleAddMemberLink}
                          disabled={!selectedAddMemberId}
                          className="rounded-lg bg-amber-900 px-3 py-1 text-xs font-bold text-white hover:bg-amber-950 disabled:opacity-50"
                        >
                          {isBn ? 'সংযুক্ত করুন' : 'Attach'}
                        </button>
                      </div>
                    )}

                    {/* Members List with Jump Button & Conflict Verify Button */}
                    <div className="space-y-2">
                      {relatedMembers.length === 0 ? (
                        <p className="text-xs text-stone-400 italic">
                          {isBn ? 'কোনো সদস্য এখনো সংযুক্ত নেই।' : 'No members linked yet.'}
                        </p>
                      ) : (
                        relatedMembers.map(m => {
                          const role = record.memberRoles?.[m.id] || (isBn ? 'সংযুক্ত সদস্য' : 'Linked');
                          const name = isBn ? m.banglaName || m.fullName : m.englishName || m.fullName;

                          return (
                            <div
                              key={m.id}
                              className="flex items-center justify-between rounded-xl border border-stone-100 bg-stone-50/70 p-2.5 dark:border-stone-800/80 dark:bg-stone-900/50"
                            >
                              <div className="flex items-center gap-3">
                                <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center font-bold text-amber-900 text-xs dark:bg-amber-900/50 dark:text-amber-200">
                                  {name[0]}
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-semibold text-xs text-stone-900 dark:text-stone-100">
                                      {name}
                                    </span>
                                    <span className="rounded bg-stone-200/70 px-1.5 py-0.5 text-[10px] text-stone-700 dark:bg-stone-800 dark:text-stone-300">
                                      {role}
                                    </span>
                                  </div>
                                  <span className="text-[11px] text-stone-400 font-mono">
                                    
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5">
                                {/* Verify extracted data with member */}
                                {record.extractedFields && (
                                  <button
                                    type="button"
                                    onClick={() => handleVerifyWithMember(m)}
                                    className="inline-flex items-center gap-1 rounded-lg border border-amber-800/30 bg-amber-50/80 px-2 py-1 text-[11px] font-semibold text-amber-900 hover:bg-amber-100 dark:bg-stone-800 dark:text-amber-300"
                                    title={isBn ? 'দলিলের সাথে প্রোফাইল তথ্যের অমিল যাচাই করুন' : 'Verify Profile vs Document'}
                                  >
                                    <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                                    <span>{isBn ? 'তথ্য যাচাই' : 'Verify'}</span>
                                  </button>
                                )}

                                {/* Jump to Profile (Rule 6) */}
                                <button
                                  type="button"
                                  onClick={() => {
                                    onClose();
                                    onOpenMemberProfile(m.id);
                                  }}
                                  className="inline-flex items-center gap-1 rounded-lg bg-amber-900 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-amber-950 transition dark:bg-amber-800"
                                  title={isBn ? 'প্রোফাইল খুলুন' : 'Open Profile'}
                                >
                                  <span>{isBn ? 'প্রোফাইল' : 'Profile'}</span>
                                  <ExternalLink className="h-3 w-3" />
                                </button>

                                {/* Unlink */}
                                <button
                                  type="button"
                                  onClick={() => unlinkDocumentFromMember(record.id, m.id)}
                                  className="p-1 text-stone-400 hover:text-rose-600"
                                  title={isBn ? 'সংযোগ বিচ্ছিন্ন করুন' : 'Unlink'}
                                >
                                  <X className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                </div>
              </div>
            )}

            {/* OCR Extracted Text & Fields Tab */}
            {activeTab === 'ocr' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
                      {isBn ? 'ওসিআর পাঠোদ্ধার ও আত্মবিশ্বাস:' : 'OCR Text & Confidence:'}
                    </span>
                    <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-bold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      {record.ocrConfidence ? `${record.ocrConfidence}%` : (isBn ? 'বিশ্লেষিত নয়' : 'Not analyzed')}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleCopyOcr}
                      disabled={!record.ocrText}
                      className="inline-flex items-center gap-1 rounded-xl border border-stone-300 bg-white px-3 py-1.5 text-xs font-semibold text-stone-700 hover:bg-stone-50 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200"
                    >
                      {isCopied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                      <span>{isCopied ? (isBn ? 'কপি হয়েছে!' : 'Copied!') : (isBn ? 'টেক্সট কপি' : 'Copy Text')}</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleReRunOcr}
                      disabled={isOcrRunning}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-amber-900 px-3.5 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-amber-950 disabled:opacity-50 transition dark:bg-amber-800"
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      <span>{isOcrRunning ? (isBn ? 'বিশ্লেষণ চলছে...' : 'Analyzing...') : (isBn ? 'পুনরায় OCR চালান' : 'Re-run OCR')}</span>
                    </button>
                  </div>
                </div>

                {/* Raw text container */}
                <div className="rounded-2xl border border-stone-200 bg-white p-5 font-mono text-xs leading-relaxed text-stone-800 shadow-inner dark:border-stone-800 dark:bg-stone-950 dark:text-stone-200 max-h-96 overflow-y-auto whitespace-pre-wrap">
                  {record.ocrText || (
                    <span className="text-stone-400 font-sans italic">
                      {isBn
                        ? 'এই দলিলের জন্য এখনো কোনো টেক্সট নিষ্কাশন করা হয়নি। উপরের বোতাম চেপে OCR চালান।'
                        : 'No OCR text extracted yet. Click the button above to run OCR.'}
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Audit Trail Tab (Rule 20) */}
            {activeTab === 'audit' && (
              <div className="space-y-3">
                <div className="text-xs text-stone-500">
                  {isBn
                    ? 'দলিলটির সকল সংযোজন, পরিবর্তন, সম্পর্ক স্থাপন ও ওসিআর কর্মকাণ্ডের অপরিবর্তনীয় অডিট লগ:'
                    : 'Immutable chronological audit record of all upload, linkage and verification actions:'}
                </div>

                <div className="relative border-l-2 border-amber-900/20 ml-3 space-y-4 pl-4 py-2">
                  {(record.history || []).map((h, idx) => (
                    <div key={h.id || idx} className="relative space-y-1">
                      <div className="absolute -left-[23px] top-1 h-3 w-3 rounded-full bg-amber-800 ring-4 ring-[#fbf9f5] dark:ring-stone-900" />
                      <div className="flex items-center gap-2">
                        <span className="rounded bg-amber-100 px-2 py-0.5 font-mono text-[10px] font-bold text-amber-900 uppercase dark:bg-amber-950 dark:text-amber-300">
                          {h.action}
                        </span>
                        <span className="text-[11px] text-stone-400">
                          {new Date(h.timestamp).toLocaleString()}
                        </span>
                        <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                          • {h.user}
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 dark:text-stone-400">
                        {h.details}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* Footer */}
          <div className="flex items-center justify-between border-t border-amber-900/10 bg-stone-50/70 px-6 py-4 dark:border-stone-800 dark:bg-stone-900/90">
            <div className="text-xs text-stone-500">
              {isBn ? 'আইডি:' : 'ID:'} <span className="font-mono">{record.id}</span>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl bg-amber-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-amber-950 transition dark:bg-amber-800"
            >
              {isBn ? 'বন্ধ করুন' : 'Close'}
            </button>
          </div>

        </div>
      </div>

      {/* Conflict Resolution Modal if triggered */}
      {showConflictModal && conflictMember && (
        <DocumentConflictModal
          isOpen={showConflictModal}
          onClose={() => setShowConflictModal(false)}
          conflicts={detectedConflicts}
          member={conflictMember}
          sourceDocTitle={record.titleBn || record.title}
          onResolve={handleConflictResolve}
          isBn={isBn}
        />
      )}
    </>
  );
};
