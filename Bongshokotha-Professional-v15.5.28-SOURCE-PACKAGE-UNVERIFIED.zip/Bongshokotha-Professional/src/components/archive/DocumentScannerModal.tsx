/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Smart Document Scanner, Camera & OCR Extraction Studio
 * 
 * Implements:
 * - Camera Capture & Live Viewfinder
 * - File Upload & URL Reference
 * - Offline Image Enhancement (Canvas Binarization, Contrast, Rotation)
 * - Original Evidence Preservation Rule (Original vs Enhanced Copy)
 * - Offline OCR with Progress, Cancellation & Language Selection
 * - Smart Field Detection & Verification
 */

import React, { useState, useRef, useEffect } from 'react';
import { useGenealogy } from '../../context/GenealogyContext';
import {
  ArchiveRecord,
  ArchiveCategory,
  DocumentSubtype,
  ExtractedDocumentFields,
  Member
} from '../../types/genealogy';
import {
  enhanceDocumentImage,
  runDocumentOcr,
  runDocumentOcrBatch,
  cancelActiveOcr,
  findDuplicateCandidates,
  detectConflicts
} from '../../engine/ocrEngine';
import { buildExtractedFieldCandidates } from '../../engine/ocrFieldParser';
import { DuplicateDetectionModal } from './DuplicateDetectionModal';
import { ensureCameraPermission } from '../../services/devicePermissions';
import { DocumentConflictModal } from './DocumentConflictModal';
import {
  Camera,
  Upload,
  Link as LinkIcon,
  Sparkles,
  RotateCw,
  Sliders,
  CheckCircle2,
  AlertCircle,
  FileText,
  Shield,
  Eye,
  RefreshCw,
  X,
  Languages
} from 'lucide-react';

interface DocumentScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: (record: ArchiveRecord) => void;
  initialMemberId?: string;
  isBn: boolean;
}

export const DocumentScannerModal: React.FC<DocumentScannerModalProps> = ({
  isOpen,
  onClose,
  onSaved,
  initialMemberId,
  isBn
}) => {
  const { members, family, addArchiveRecord, updateMember } = useGenealogy();

  const [inputMode, setInputMode] = useState<'upload' | 'camera' | 'url'>('upload');

  // Images state (Original Evidence rule: never overwrite original)
  const [originalMediaUrl, setOriginalMediaUrl] = useState<string | null>(null);
  const [enhancedMediaUrl, setEnhancedMediaUrl] = useState<string | null>(null);
  const [viewingVersion, setViewingVersion] = useState<'original' | 'enhanced'>('original');
  const [filename, setFilename] = useState<string>('');
  const [fileSizeBytes, setFileSizeBytes] = useState<number>(0);
  const [sourceFiles, setSourceFiles] = useState<Array<{ fileName: string; mimeType?: string; dataUrl: string; fileSizeBytes?: number }>>([]);

  // Enhancement controls
  const [contrast, setContrast] = useState(25);
  const [brightness, setBrightness] = useState(10);
  const [binarize, setBinarize] = useState(false);
  const [rotation, setRotation] = useState(0);

  // Camera state
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);

  // OCR state
  const [ocrLanguage, setOcrLanguage] = useState<'ben+eng' | 'ben' | 'eng'>('ben+eng');
  const [isOcrRunning, setIsOcrRunning] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);
  const [ocrStatusText, setOcrStatusText] = useState('');
  const [ocrRawText, setOcrRawText] = useState('');
  const [ocrConfidence, setOcrConfidence] = useState(0);
  const [extractedFields, setExtractedFields] = useState<ExtractedDocumentFields | null>(null);
  const [selectedOcrFields, setSelectedOcrFields] = useState<string[]>([]);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Metadata Form state
  const [title, setTitle] = useState('');
  const [titleBn, setTitleBn] = useState('');
  const [category, setCategory] = useState<ArchiveCategory>('identity_document');
  const [documentType, setDocumentType] = useState<DocumentSubtype>('nid_card');
  const [recordDate, setRecordDate] = useState(new Date().toISOString().slice(0, 10));
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>(initialMemberId ? [initialMemberId] : []);
  const [memberRole, setMemberRole] = useState('মূল ধারক (Self)');
  const [source, setSource] = useState('পারিবারিক নথিপত্র');
  const [provenance, setProvenance] = useState('পারিবারিক ফাইল থেকে ডিজিটালাইজড');
  const [permission, setPermission] = useState<'public' | 'family' | 'admin' | 'restricted'>('family');
  const [description, setDescription] = useState('');

  // Conflict & Duplicate Modals
  const [duplicateCandidates, setDuplicateCandidates] = useState<any[]>([]);
  const [showDuplicateModal, setShowDuplicateModal] = useState(false);
  const [conflicts, setConflicts] = useState<any[]>([]);
  const [showConflictModal, setShowConflictModal] = useState(false);
  const [conflictTargetMember, setConflictTargetMember] = useState<Member | null>(null);

  // URL input
  const [urlInput, setUrlInput] = useState('');

  // Start/Stop Camera
  useEffect(() => {
    if (inputMode === 'camera' && isOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [inputMode, isOpen]);

  if (!isOpen) return null;

  async function startCamera() {
    try {
      const allowed = await ensureCameraPermission();
      if (!allowed) {
        alert(isBn ? 'ক্যামেরা ব্যবহারের অনুমতি প্রয়োজন। Settings → ক্যামেরা ও দলিল স্ক্যানার থেকে অনুমতি দিন।' : 'Camera permission is required. Open Settings → Camera & Scanner to allow it.');
        setInputMode('upload');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } }
      });
      cameraStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraActive(true);
    } catch (err) {
      console.error('Camera access failed:', err);
      alert(isBn ? 'ক্যামেরা চালু করা সম্ভব হয়নি।' : 'Could not start camera.');
      setInputMode('upload');
    }
  }

  function stopCamera() {
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach(t => t.stop());
      cameraStreamRef.current = null;
    }
    setIsCameraActive(false);
  }

  const captureCameraSnapshot = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
      setOriginalMediaUrl(dataUrl);
      const captureName = `scan_capture_${Date.now()}.jpg`;
      setFilename(captureName);
      const captureSize = Math.round((dataUrl.length * 3) / 4);
      setFileSizeBytes(captureSize);
      setSourceFiles([{ fileName: captureName, mimeType: 'image/jpeg', dataUrl, fileSizeBytes: captureSize }]);
      stopCamera();
      // Apply initial enhancement and immediately extract readable genealogy data.
      applyEnhancement(dataUrl, contrast, brightness, binarize, rotation);
      void runOcrImmediately(dataUrl, 'image/jpeg');
    }
  };

  const runOcrImmediately = async (source: string, mimeType?: string) => {
    if (!source) return;
    setIsOcrRunning(true);
    setOcrProgress(10);
    setOcrStatusText(isBn ? 'দলিল আপলোড হয়েছে — স্বয়ংক্রিয়ভাবে OCR শুরু হচ্ছে...' : 'Document uploaded — starting OCR automatically...');
    abortControllerRef.current = new AbortController();
    try {
      const res = await runDocumentOcr(source, ocrLanguage, (status, pct) => {
        setOcrStatusText(status);
        setOcrProgress(pct);
      }, abortControllerRef.current.signal, mimeType);
      setOcrRawText(res.text || '');
      setOcrConfidence(res.confidence || 0);
      setExtractedFields(res.extractedFields || null);
      const keys = Object.entries(res.extractedFields || {}).filter(([k,v]) => k !== 'documentKind' && k !== 'confidence' && Boolean(v)).map(([k]) => k);
      setSelectedOcrFields(keys);
    } catch (e) {
      console.warn('Automatic OCR failed:', e);
      setOcrStatusText(isBn ? 'স্বয়ংক্রিয় OCR সম্পন্ন হয়নি — পরে আবার চেষ্টা করুন।' : 'Automatic OCR could not complete — you can retry.');
    } finally {
      setIsOcrRunning(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    Promise.all(files.map(file => new Promise<{ file: File; dataUrl: string }>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve({ file, dataUrl: String(reader.result || '') });
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    }))).then(async items => {
      const sources = items.map(({ file, dataUrl }) => ({ fileName: file.name, mimeType: file.type || undefined, dataUrl, fileSizeBytes: file.size }));
      setSourceFiles(sources);
      setFilename(items.length === 1 ? items[0].file.name : items.map(x => x.file.name).join(' + '));
      setFileSizeBytes(items.reduce((sum, x) => sum + x.file.size, 0));
      setOriginalMediaUrl(items[0].dataUrl);
      if (!titleBn) setTitleBn(items.length > 1 ? (isBn ? 'একাধিক পৃষ্ঠার/দুই পাশের দলিল' : 'Multi-page / two-sided document') : items[0].file.name.replace(/\.[^/.]+$/, ''));
      applyEnhancement(items[0].dataUrl, contrast, brightness, binarize, rotation);
      const ocrItems = items.filter(({ file }) => file.type.startsWith('image/') || file.type === 'application/pdf' || /\.pdf$/i.test(file.name));
      if (ocrItems.length) {
        await runOcrBatchImmediately(ocrItems.map(({ file, dataUrl }) => ({ source: dataUrl, mimeType: file.type || undefined, name: file.name })));
      }
    }).catch(err => {
      console.warn('Document upload failed:', err);
      setOcrStatusText(isBn ? 'ফাইল পড়া যায়নি।' : 'The selected file(s) could not be read.');
    }).finally(() => { e.currentTarget.value = ''; });
  };

  const runOcrBatchImmediately = async (sources: Array<{ source: string; mimeType?: string; name?: string }>) => {
    if (!sources.length) return;
    setIsOcrRunning(true);
    setOcrProgress(5);
    setOcrStatusText(isBn ? 'দলিল সেশন বিশ্লেষণ শুরু হচ্ছে...' : 'Starting document-session OCR...');
    abortControllerRef.current = new AbortController();
    try {
      const res = await runDocumentOcrBatch(sources, ocrLanguage, (status, pct) => {
        setOcrStatusText(status);
        setOcrProgress(pct);
      }, abortControllerRef.current.signal);
      setOcrRawText(res.text || '');
      setOcrConfidence(res.confidence || 0);
      setExtractedFields(res.extractedFields || null);
      const keys = buildExtractedFieldCandidates(res.extractedFields || { documentKind: 'general', confidence: 0 }).map(x => x.key);
      setSelectedOcrFields(keys);
      const kind = res.extractedFields.documentKind;
      if (kind === 'passport') { setCategory('identity_document'); setDocumentType('passport'); }
      else if (kind === 'nid') { setCategory('identity_document'); setDocumentType('nid_card'); }
      else if (kind === 'birth_registration') { setCategory('certificate'); setDocumentType('birth_registration'); }
      else if (kind === 'land_deed') { setCategory('land_document'); setDocumentType('khatian'); }
      const candidates = findDuplicateCandidates(res.extractedFields, members);
      if (candidates.length) { setDuplicateCandidates(candidates); setShowDuplicateModal(true); }
    } catch (e: any) {
      if (e?.message?.includes('cancelled')) setOcrStatusText(isBn ? 'বাতিল করা হয়েছে।' : 'Cancelled.');
      else setOcrStatusText(isBn ? 'স্বয়ংক্রিয় OCR সম্পন্ন হয়নি — আবার চেষ্টা করুন।' : 'Automatic OCR did not complete — please retry.');
    } finally {
      setIsOcrRunning(false);
    }
  };

  const handleUrlSubmit = () => {
    if (!urlInput.trim()) return;
    setOriginalMediaUrl(urlInput.trim());
    setFilename('remote_url_document');
    setTitleBn(isBn ? 'ওয়েব সংরক্ষিত দলিল' : 'Remote Web Document');
  };

  const applyEnhancement = async (
    source: string,
    c: number,
    b: number,
    bin: boolean,
    rot: number
  ) => {
    const enhanced = await enhanceDocumentImage(source, {
      contrast: c,
      brightness: b,
      binarize: bin,
      rotation: rot
    });
    setEnhancedMediaUrl(enhanced);
  };

  const handleRotate = () => {
    const nextRot = (rotation + 90) % 360;
    setRotation(nextRot);
    if (originalMediaUrl) {
      applyEnhancement(originalMediaUrl, contrast, brightness, binarize, nextRot);
    }
  };

  const handleRunOcr = async () => {
    const targetImg = enhancedMediaUrl || originalMediaUrl;
    if (!targetImg) return;

    setIsOcrRunning(true);
    setOcrProgress(10);
    setOcrStatusText(isBn ? 'হরফ বিশ্লেষণ শুরু হচ্ছে...' : 'Initializing OCR...');
    abortControllerRef.current = new AbortController();

    try {
      const res = sourceFiles.length > 1
        ? await runDocumentOcrBatch(sourceFiles.map(file => ({ source: file.dataUrl, mimeType: file.mimeType, name: file.fileName })), ocrLanguage, (status, pct) => {
            setOcrStatusText(status);
            setOcrProgress(pct);
          }, abortControllerRef.current.signal)
        : await runDocumentOcr(
            targetImg,
            ocrLanguage,
            (status, pct) => {
              setOcrStatusText(status);
              setOcrProgress(pct);
            },
            abortControllerRef.current.signal
          );

      setOcrRawText(res.text);
      setOcrConfidence(res.confidence);
      setExtractedFields(res.extractedFields);
      setSelectedOcrFields(buildExtractedFieldCandidates(res.extractedFields).map(x => x.key));

      // Auto adjust category and document type based on OCR kind
      if (res.extractedFields.documentKind === 'passport') {
        setCategory('identity_document');
        setDocumentType('passport');
        if (!titleBn) setTitleBn('পাসপোর্ট');
      } else if (res.extractedFields.documentKind === 'nid') {
        setCategory('identity_document');
        setDocumentType('nid_card');
        if (!titleBn) setTitleBn('জাতীয় পরিচয়পত্র (NID)');
      } else if (res.extractedFields.documentKind === 'birth_registration') {
        setCategory('certificate');
        setDocumentType('birth_registration');
        if (!titleBn) setTitleBn('জন্ম নিবন্ধন সনদ (BRN)');
      } else if (res.extractedFields.documentKind === 'land_deed') {
        setCategory('land_document');
        setDocumentType('khatian');
        if (!titleBn) setTitleBn('ভূমি রেকর্ড / খতিয়ান দলিল');
      }

      // Check for duplicate / matching member candidates
      const candidates = findDuplicateCandidates(res.extractedFields, members);
      if (candidates.length > 0) {
        setDuplicateCandidates(candidates);
        setShowDuplicateModal(true);
      }
    } catch (err: any) {
      if (err.message?.includes('cancelled')) {
        setOcrStatusText(isBn ? 'বাতিল করা হয়েছে।' : 'Cancelled.');
      } else {
        console.error('OCR run error:', err);
        setOcrStatusText(isBn ? 'ওসিআর বিশ্লেষণে সমস্যা হয়েছে।' : 'OCR analysis error.');
      }
    } finally {
      setIsOcrRunning(false);
    }
  };

  const handleCancelOcr = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    cancelActiveOcr();
    setIsOcrRunning(false);
  };

  // Duplicate Modal Callbacks
  const handleSelectExistingCandidate = (candMember: Member) => {
    setSelectedMemberIds([candMember.id]);
    setShowDuplicateModal(false);

    // Now check if extracted fields conflict with this member
    if (extractedFields) {
      const detectedConflicts = detectConflicts(
        extractedFields,
        candMember,
        members,
        titleBn || title || 'স্ক্যানকৃত দলিল'
      );
      if (detectedConflicts.length > 0) {
        setConflicts(detectedConflicts);
        setConflictTargetMember(candMember);
        setShowConflictModal(true);
      }
    }
  };

  const handleConflictResolutions = async (
    resolutions: Record<string, { decision: 'accept' | 'reject' | 'custom'; value: string }>
  ) => {
    if (!conflictTargetMember) return;
    const updatedMember = { ...conflictTargetMember };
    let hasChanges = false;

    Object.entries(resolutions).forEach(([key, res]) => {
      if (res.decision === 'accept' || res.decision === 'custom') {
        hasChanges = true;
        if (key === 'banglaName') updatedMember.banglaName = res.value;
        if (key === 'nidNumber') {
          updatedMember.identityDocs = {
            ...updatedMember.identityDocs,
            nidNumber: res.value,
            verificationStatus: 'verified'
          };
        }
        if (key === 'birthRegistrationNumber') {
          updatedMember.identityDocs = {
            ...updatedMember.identityDocs,
            birthRegistrationNumber: res.value,
            verificationStatus: 'verified'
          };
        }
      }
    });

    if (hasChanges) {
      await updateMember(updatedMember);
    }
  };

  const applyOcrToSelectedMember = async () => {
    if (!extractedFields || !selectedMemberIds.length) return;
    const target = members.find(m => m.id === selectedMemberIds[0]);
    if (!target) return;

    const bnDigits = (value: string) => value.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
    const normalizeName = (value: string) => value.toLowerCase().replace(/[।,:;|()\-]/g, ' ').replace(/\s+/g, ' ').trim();
    const findByName = (value?: string) => {
      if (!value) return undefined;
      const q = normalizeName(value);
      return members.find(m => [m.banglaName, m.englishName, m.fullName, m.nickname]
        .filter(Boolean).some(n => normalizeName(String(n)) === q));
    };
    const parseOcrDate = (value?: string) => {
      if (!value) return undefined;
      const normalized = bnDigits(value).trim();
      const m = normalized.match(/(\d{1,2})[-/\s]+(\d{1,2})[-/\s]+(\d{4})/);
      if (!m) {
        const y = normalized.match(/(18|19|20)\d{2}/)?.[0];
        return y ? { year: Number(y), precision: 'approximate' as const } : undefined;
      }
      return { day: Number(m[1]), month: Number(m[2]), year: Number(m[3]), precision: 'exact' as const };
    };

    const labels: Record<string,string> = { fullNameBn:'বাংলা নাম', fullNameEn:'English Name', nidNumber:'NID', brnNumber:'জন্ম নিবন্ধন', passportNumber:'Passport', passportPersonalNumber:'Passport Personal No.', passportIssueDate:'Passport Issue Date', passportExpiryDate:'Passport Expiry Date', passportIssuingAuthority:'Passport Issuing Authority', previousPassportNumber:'Previous Passport', documentNumber:'দলিল নম্বর', documentIssueDate:'দলিল ইস্যু তারিখ', documentDate:'দলিলের তারিখ', dateOfBirth:'জন্মতারিখ', address:'ঠিকানা', presentAddress:'বর্তমান ঠিকানা', permanentAddress:'স্থায়ী ঠিকানা', holding:'বাসা/হোল্ডিং', road:'গ্রাম/রাস্তা', village:'গ্রাম', union:'ইউনিয়ন/পৌরসভা', ward:'ওয়ার্ড', postOffice:'ডাকঘর', postalCode:'পোস্ট কোড', upazila:'উপজেলা/থানা', district:'জেলা', division:'বিভাগ', country:'দেশ', placeOfBirth:'জন্মস্থান', fatherName:'পিতা', motherName:'মাতা', spouseName:'স্বামী/স্ত্রী', childrenNames:'সন্তান', occupation:'পেশা', mobileNumber:'মোবাইল', email:'ই-মেইল', religion:'ধর্ম', nationality:'জাতীয়তা', gender:'লিঙ্গ', bloodGroup:'রক্তের গ্রুপ', dateOfDeath:'মৃত্যু তারিখ', issuingAuthority:'ইস্যুকারী কর্তৃপক্ষ', mouza:'মৌজা', khatianNumber:'খতিয়ান', dagNumber:'দাগ', deedNumber:'দলিল নম্বর', deedYear:'দলিল সাল', landAmount:'জমির পরিমাণ', restingPlace:'কবর/শেষ ঠিকানা' };
    const available = selectedOcrFields.filter(key => Boolean((extractedFields as any)[key])).map(key => labels[key] || key);
    if (!available.length) {
      alert(isBn ? 'প্রোফাইলে নেওয়ার জন্য অন্তত একটি OCR তথ্য নির্বাচন করুন।' : 'Select at least one OCR field to apply.');
      return;
    }
    const confirmed = window.confirm(
      (isBn ? 'নির্বাচিত OCR তথ্য সদস্যের Profile-এ নিতে চান?\n\n' : 'Apply the selected OCR fields to the member Profile?\n\n') +
      available.join(' • ') +
      (isBn ? '\n\nশুধু নির্বাচিত তথ্যই Profile-এ লেখা হবে।' : '\n\nOnly selected fields will be written to the Profile.')
    );
    if (!confirmed) return;

    const next: Member = { ...target, identityDocs: { ...(target.identityDocs || {}) } };
    let changed = false;
    if (selectedOcrFields.includes('fullNameBn') && extractedFields.fullNameBn) { next.banglaName = extractedFields.fullNameBn; changed = true; }
    if (selectedOcrFields.includes('fullNameEn') && extractedFields.fullNameEn) { next.englishName = extractedFields.fullNameEn; changed = true; }
    if (!next.fullName && selectedOcrFields.some(k => k === 'fullNameBn' || k === 'fullNameEn') && (extractedFields.fullNameBn || extractedFields.fullNameEn)) { next.fullName = extractedFields.fullNameBn || extractedFields.fullNameEn || target.fullName; changed = true; }
    if (selectedOcrFields.includes('nidNumber') && extractedFields.nidNumber) { next.identityDocs.nidNumber = extractedFields.nidNumber; changed = true; }
    if (selectedOcrFields.includes('brnNumber') && extractedFields.brnNumber) { next.identityDocs.birthRegistrationNumber = extractedFields.brnNumber; changed = true; }
    if (selectedOcrFields.includes('passportNumber') && extractedFields.passportNumber) { next.identityDocs.passportNumber = extractedFields.passportNumber; changed = true; }
    if (selectedOcrFields.includes('passportPersonalNumber') && extractedFields.passportPersonalNumber) { next.identityDocs.passportPersonalNumber = extractedFields.passportPersonalNumber; changed = true; }
    if (selectedOcrFields.includes('passportIssueDate') && extractedFields.passportIssueDate) { next.identityDocs.passportIssueDate = extractedFields.passportIssueDate; changed = true; }
    if (selectedOcrFields.includes('passportExpiryDate') && extractedFields.passportExpiryDate) { next.identityDocs.passportExpiryDate = extractedFields.passportExpiryDate; changed = true; }
    if (selectedOcrFields.includes('passportIssuingAuthority') && extractedFields.passportIssuingAuthority) { next.identityDocs.passportIssuingAuthority = extractedFields.passportIssuingAuthority; changed = true; }
    if (selectedOcrFields.includes('previousPassportNumber') && extractedFields.previousPassportNumber) { next.identityDocs.previousPassportNumber = extractedFields.previousPassportNumber; changed = true; }

    const ocrDate = selectedOcrFields.includes('dateOfBirth') ? parseOcrDate(extractedFields.dateOfBirth) : undefined;
    if (ocrDate) { next.birth = { ...next.birth, date: { ...(next.birth?.date || { precision: 'unknown' }), ...ocrDate } }; changed = true; }
    if (selectedOcrFields.includes('address') && extractedFields.address) { next.currentAddress = { ...(next.currentAddress || {}), fullAddress: extractedFields.address }; changed = true; }
    const structuredAddress = {
      ...(extractedFields.holding ? { holding: extractedFields.holding } : {}),
      ...(extractedFields.road ? { road: extractedFields.road } : {}),
      ...(extractedFields.village ? { village: extractedFields.village } : {}),
      ...(extractedFields.union ? { union: extractedFields.union } : {}),
      ...(extractedFields.ward ? { ward: extractedFields.ward } : {}),
      ...(extractedFields.postOffice ? { postOffice: extractedFields.postOffice } : {}),
      ...(extractedFields.postalCode ? { postalCode: extractedFields.postalCode } : {}),
      ...(extractedFields.upazila ? { upazila: extractedFields.upazila } : {}),
      ...(extractedFields.district ? { district: extractedFields.district } : {}),
      ...(extractedFields.division ? { division: extractedFields.division } : {}),
      ...(extractedFields.country ? { country: extractedFields.country } : {})
    };
    if (selectedOcrFields.some(k => ['presentAddress','address','holding','road','village','union','ward','postOffice','postalCode','upazila','district','division','country'].includes(k)) && (Object.keys(structuredAddress).length || extractedFields.address)) {
      const targetAddress = extractedFields.permanentAddress && selectedOcrFields.includes('permanentAddress') ? 'permanentAddress' : 'currentAddress';
      next[targetAddress] = { ...(next[targetAddress] || {}), ...structuredAddress, ...(extractedFields.address ? { fullAddress: extractedFields.address } : {}) };
      changed = true;
    }
    if (selectedOcrFields.includes('permanentAddress') && extractedFields.permanentAddress) { next.permanentAddress = { ...(next.permanentAddress || {}), ...extractedFields.permanentAddress }; changed = true; }
    if (selectedOcrFields.includes('presentAddress') && extractedFields.presentAddress) { next.currentAddress = { ...(next.currentAddress || {}), ...extractedFields.presentAddress }; changed = true; }
    if (selectedOcrFields.includes('placeOfBirth') && extractedFields.placeOfBirth) { next.birth = { ...next.birth, place: { ...(next.birth?.place || {}), fullAddress: extractedFields.placeOfBirth } }; changed = true; }
    if (selectedOcrFields.includes('documentNumber') && extractedFields.documentNumber) { next.identityDocs.documentReference = extractedFields.documentNumber; changed = true; }
    if (selectedOcrFields.includes('occupation') && extractedFields.occupation) { next.profession = extractedFields.occupation; changed = true; }
    if (selectedOcrFields.includes('mobileNumber') && extractedFields.mobileNumber) { next.mobileNumber = extractedFields.mobileNumber; changed = true; }
    if (selectedOcrFields.includes('email') && extractedFields.email) { next.email = extractedFields.email; changed = true; }
    if (selectedOcrFields.includes('religion') && extractedFields.religion) { next.religion = extractedFields.religion; changed = true; }
    if (selectedOcrFields.includes('nationality') && extractedFields.nationality) { next.nationality = extractedFields.nationality; changed = true; }
    if (selectedOcrFields.includes('gender') && extractedFields.gender) { next.gender = extractedFields.gender; changed = true; }
    if (selectedOcrFields.includes('bloodGroup') && extractedFields.bloodGroup) { next.bloodGroup = extractedFields.bloodGroup; changed = true; }
    if (selectedOcrFields.includes('dateOfDeath') && extractedFields.dateOfDeath) { const d = parseOcrDate(extractedFields.dateOfDeath); if (d) { next.death = { ...next.death, isDeceased: true, date: d }; next.isLiving = false; changed = true; } }

    const father = selectedOcrFields.includes('fatherName') ? findByName(extractedFields.fatherName) : undefined;
    const mother = selectedOcrFields.includes('motherName') ? findByName(extractedFields.motherName) : undefined;
    const spouse = selectedOcrFields.includes('spouseName') ? findByName(extractedFields.spouseName) : undefined;
    if (father && father.id !== target.id) { next.fatherId = father.id; changed = true; }
    if (mother && mother.id !== target.id) { next.motherId = mother.id; changed = true; }
    if (father || mother || (selectedOcrFields.includes('fatherName') && extractedFields.fatherName) || (selectedOcrFields.includes('motherName') && extractedFields.motherName) || (selectedOcrFields.includes('spouseName') && extractedFields.spouseName)) {
      const evidence = [
        selectedOcrFields.includes('fatherName') && extractedFields.fatherName ? `OCR পিতা: ${extractedFields.fatherName}${father ? ' → সদস্য মিলেছে' : ' → তালিকায় সঠিক সদস্য মেলেনি'}` : '',
        selectedOcrFields.includes('motherName') && extractedFields.motherName ? `OCR মাতা: ${extractedFields.motherName}${mother ? ' → সদস্য মিলেছে' : ' → তালিকায় সঠিক সদস্য মেলেনি'}` : '',
        selectedOcrFields.includes('spouseName') && extractedFields.spouseName ? `OCR spouse: ${extractedFields.spouseName}${spouse ? ' → সদস্য মিলেছে' : ' → তালিকায় সঠিক সদস্য মেলেনি'}` : ''
      ].filter(Boolean).join(' | ');
      next.researchNotes = [next.researchNotes, evidence].filter(Boolean).join('\n');
      changed = true;
    }

    const evidenceOnly = buildExtractedFieldCandidates(extractedFields).filter(f => selectedOcrFields.includes(f.key) && f.profileWritable === false);
    if (evidenceOnly.length) {
      const extra = evidenceOnly.map(f => `${f.labelBn || f.labelEn}: ${f.value}`).join(' | ');
      next.researchNotes = [next.researchNotes, isBn ? `OCR থেকে Evidence-only তথ্য: ${extra}` : `OCR evidence-only information: ${extra}`].filter(Boolean).join('\n');
      changed = true;
    }
    if (extractedFields.conflicts?.length) {
      const conflictText = extractedFields.conflicts.map(c => `${c.labelBn || c.labelEn}: ${c.values.join(' / ')}`).join(' | ');
      next.researchNotes = [next.researchNotes, isBn ? `OCR conflict — সিদ্ধান্ত প্রয়োজন: ${conflictText}` : `OCR conflicts requiring decision: ${conflictText}`].filter(Boolean).join('\n');
      changed = true;
    }

    if (selectedOcrFields.includes('nidNumber') && extractedFields.nidNumber) {
      const normalizeNid = (value?: string) => (value || '').trim().replace(/[০-৯]/g, digit => String('০১২৩৪৫৬৭৮৯'.indexOf(digit))).replace(/[\s-]+/g, '');
      const submittedNid = normalizeNid(extractedFields.nidNumber);
      const duplicate = members.find(candidate => candidate.id !== target.id && normalizeNid(candidate.identityDocs?.nidNumber) === submittedNid && submittedNid);
      if (duplicate) {
        const duplicateName = duplicate.banglaName || duplicate.englishName || duplicate.fullName || duplicate.id;
        alert(isBn ? `এই NID অন্য সদস্য “${duplicateName}”-এর প্রোফাইলে আছে। ডুপ্লিকেট NID সংরক্ষণ ঠেকাতে OCR তথ্য প্রয়োগ বন্ধ করা হয়েছে।` : `This NID is already assigned to “${duplicateName}”. OCR changes were not applied to prevent a duplicate NID.`);
        return;
      }
    }
    if (changed) await updateMember(next);
    alert(isBn
      ? 'OCR তথ্য Profile-এ প্রয়োগ করা হয়েছে। সম্পর্কের ক্ষেত্রে শুধু বিদ্যমান সদস্যের সঙ্গে নিশ্চিত নাম-মিল পাওয়া গেলে পিতা/মাতা লিংক করা হয়েছে; বাকি OCR তথ্য Research Note-এ প্রমাণ হিসেবে রাখা হয়েছে।'
      : 'OCR data was applied. Parent links were created only when an existing member matched exactly; other OCR relationship facts remain as evidence in Research Notes.');
  };

  const handleFinalSave = async () => {
    if (!originalMediaUrl) {
      alert(isBn ? 'অনুগ্রহ করে একটি দলিল আপলোড বা স্ক্যান করুন।' : 'Please upload or scan a document.');
      return;
    }

    const docTitle = titleBn.trim() || title.trim() || (isBn ? 'নতুন মহাফেজখানা রেকর্ড' : 'New Archive Record');

    const newRecord = await addArchiveRecord({
      title: title.trim() || docTitle,
      titleBn: docTitle,
      category,
      documentType,
      date: recordDate,
      description: description.trim(),
      descriptionBn: description.trim(),
      relatedMemberIds: selectedMemberIds,
      memberRoles: selectedMemberIds.reduce((acc, id) => {
        acc[id] = memberRole;
        return acc;
      }, {} as Record<string, string>),
      relatedFamilyId: family.id,
      mediaUrl: originalMediaUrl, // Pristine original
      sourceFiles: sourceFiles.length > 1 ? sourceFiles : undefined,
      enhancedMediaUrl: enhancedMediaUrl || undefined, // Separate enhanced copy
      mediaType: (filename.toLowerCase().endsWith('.pdf') || filename.toLowerCase().endsWith('.doc') || filename.toLowerCase().endsWith('.docx')) ? 'document' : 'image',
      originalFilename: filename,
      mimeType: (filename.toLowerCase().endsWith('.pdf') ? 'application/pdf' : filename.toLowerCase().endsWith('.docx') ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : filename.toLowerCase().endsWith('.doc') ? 'application/msword' : 'image/jpeg'),
      fileSizeBytes,
      ocrText: ocrRawText || undefined,
      ocrConfidence: ocrConfidence || undefined,
      ocrVerification: 'unverified',
      extractedFields: extractedFields || undefined,
      source: source.trim(),
      provenance: provenance.trim(),
      uploader: 'ডিজিটাল আর্কাইভ স্ক্যানার',
      tags: [category, documentType].filter(Boolean),
      accessPermission: permission,
      documentNumbers: {
        nid: extractedFields?.nidNumber,
        brn: extractedFields?.brnNumber,
        khatian: extractedFields?.khatianNumber,
        dag: extractedFields?.dagNumber,
        deed: extractedFields?.deedNumber,
        mouza: extractedFields?.mouza
      },
      historyNote: `মূল প্রমাণ ও উন্নত কপি পৃথকভাবে ডিজিটাল মহাফেজখানায় সংরক্ষণ। (${ocrConfidence ? `OCR: ${ocrConfidence}%` : 'ম্যানুয়াল'})`
    });

    onSaved(newRecord);
    onClose();
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-in fade-in duration-200">
        <div className="w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl border border-amber-900/30 bg-[#fbf9f5] shadow-2xl dark:bg-stone-900 dark:border-stone-700">
          
          {/* Header */}
          <div className="flex items-center justify-between border-b border-amber-900/10 px-6 py-4 dark:border-stone-800">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300">
                <Sparkles className="h-6 w-6" />
              </div>
              <div>
                <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100">
                  {isBn ? 'দলিল স্ক্যানার ও বুদ্ধিবৃত্তিক ওসিআর' : 'Document Scanner & Intelligent OCR'}
                </h2>
                <p className="text-xs text-stone-600 dark:text-stone-400">
                  {isBn
                    ? 'মূল প্রমাণের পবিত্রতা রক্ষা ও স্বয়ংক্রিয় বাংলা ক্ষেত্র শনাক্তকরণ'
                    : 'Pristine original evidence preservation with Bengali field extraction'}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="rounded-full p-2 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-stone-800"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Workflow Tabs */}
          <div className="flex border-b border-amber-900/10 bg-amber-50/50 px-6 pt-2 dark:border-stone-800 dark:bg-stone-950/40">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setInputMode('upload')}
                className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs font-bold transition ${
                  inputMode === 'upload'
                    ? 'border-amber-900 text-amber-900 dark:border-amber-400 dark:text-amber-300'
                    : 'border-transparent text-stone-600 hover:text-stone-900 dark:text-stone-400'
                }`}
              >
                <Upload className="h-4 w-4" />
                {isBn ? 'ফাইল আপলোড' : 'File Upload'}
              </button>

              <button
                type="button"
                onClick={() => setInputMode('camera')}
                className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs font-bold transition ${
                  inputMode === 'camera'
                    ? 'border-amber-900 text-amber-900 dark:border-amber-400 dark:text-amber-300'
                    : 'border-transparent text-stone-600 hover:text-stone-900 dark:text-stone-400'
                }`}
              >
                <Camera className="h-4 w-4" />
                {isBn ? 'ক্যামেরা স্ক্যানার' : 'Live Camera'}
              </button>

              <button
                type="button"
                onClick={() => setInputMode('url')}
                className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs font-bold transition ${
                  inputMode === 'url'
                    ? 'border-amber-900 text-amber-900 dark:border-amber-400 dark:text-amber-300'
                    : 'border-transparent text-stone-600 hover:text-stone-900 dark:text-stone-400'
                }`}
              >
                <LinkIcon className="h-4 w-4" />
                {isBn ? 'ইউআরএল লিংক' : 'URL Reference'}
              </button>
            </div>
          </div>

          {/* Main Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {/* Capture / Input Section */}
            {inputMode === 'camera' && !originalMediaUrl && (
              <div className="relative overflow-hidden rounded-3xl border-2 border-dashed border-amber-900/30 bg-black aspect-4/3 max-h-80 flex items-center justify-center">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-x-0 bottom-4 flex items-center justify-center">
                  <button
                    type="button"
                    onClick={captureCameraSnapshot}
                    className="flex h-16 w-16 items-center justify-center rounded-full bg-amber-600 text-white shadow-xl hover:bg-amber-700 ring-4 ring-white/50"
                  >
                    <Camera className="h-8 w-8" />
                  </button>
                </div>
              </div>
            )}

            {inputMode === 'upload' && !originalMediaUrl && (
              <div className="rounded-3xl border-2 border-dashed border-amber-900/30 bg-amber-50/30 p-8 text-center hover:bg-amber-50/60 transition dark:border-stone-700 dark:bg-stone-950/40">
                <Upload className="mx-auto h-12 w-12 text-amber-800 dark:text-amber-400" />
                <h3 className="mt-3 font-serif font-bold text-stone-800 dark:text-stone-200">
                  {isBn ? 'দলিল বা ছবির ফাইল টানুন অথবা নির্বাচন করুন' : 'Drop document or image here'}
                </h3>
                <p className="mt-1 text-xs text-stone-500">
                  {isBn ? 'এনআইডি, জন্ম নিবন্ধন সনদ, জমির খতিয়ান, পর্চা, ঐতিহাসিক চিঠি' : 'NID, Birth Certificate, Land Khatian, Porcha, Heirloom Letters'}
                </p>
                <label className="mt-4 inline-flex cursor-pointer items-center gap-2 rounded-xl bg-amber-900 px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-amber-950 transition dark:bg-amber-800">
                  <Upload className="h-4 w-4" />
                  <span>{isBn ? 'ফাইল বাছুন (Front + Back / JPG, PNG, PDF)' : 'Browse Files (Front + Back / JPG, PNG, PDF)'}</span>
                  <input
                    type="file"
                    accept="image/*,.pdf,.doc,.docx"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            )}

            {inputMode === 'url' && !originalMediaUrl && (
              <div className="rounded-3xl border border-stone-200 bg-white p-6 dark:border-stone-800 dark:bg-stone-950 space-y-3">
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300">
                  {isBn ? 'দলিলের অনলাইন সরাসরি লিঙ্ক (Direct Image/Doc URL)' : 'Direct Image or Document URL'}
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={urlInput}
                    onChange={e => setUrlInput(e.target.value)}
                    placeholder="https://..."
                    className="flex-1 rounded-xl border border-stone-300 px-3.5 py-2 text-sm text-stone-900 dark:border-stone-700 dark:bg-stone-900 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={handleUrlSubmit}
                    className="rounded-xl bg-amber-900 px-4 py-2 text-xs font-bold text-white hover:bg-amber-950"
                  >
                    {isBn ? 'যুক্ত করুন' : 'Attach'}
                  </button>
                </div>
              </div>
            )}

            {/* Document Preview & Enhancement Controls */}
            {originalMediaUrl && (
              <div className="space-y-4">
                {/* Evidence Rule Switcher */}
                <div className="flex items-center justify-between rounded-2xl bg-stone-100 p-2 dark:bg-stone-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-stone-700 dark:text-stone-300 px-2">
                      {isBn ? 'প্রদর্শন রূপ:' : 'Display View:'}
                    </span>
                    <button
                      type="button"
                      onClick={() => setViewingVersion('original')}
                      className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                        viewingVersion === 'original'
                          ? 'bg-white text-amber-900 shadow-xs dark:bg-stone-900 dark:text-amber-300'
                          : 'text-stone-600 hover:text-stone-900 dark:text-stone-400'
                      }`}
                    >
                      {isBn ? 'মূল আদি প্রমাণ (Original)' : 'Pristine Original'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setViewingVersion('enhanced')}
                      className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                        viewingVersion === 'enhanced'
                          ? 'bg-amber-900 text-white shadow-xs dark:bg-amber-800'
                          : 'text-stone-600 hover:text-stone-900 dark:text-stone-400'
                      }`}
                    >
                      {isBn ? 'উন্নত কপি (Enhanced Copy)' : 'Enhanced Copy'}
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleRotate}
                      className="inline-flex items-center gap-1 rounded-lg border border-stone-300 bg-white px-2.5 py-1 text-xs font-medium text-stone-700 hover:bg-stone-50 dark:border-stone-700 dark:bg-stone-900 dark:text-stone-300"
                    >
                      <RotateCw className="h-3.5 w-3.5" />
                      <span>{isBn ? 'ঘোরান (৯০°)' : 'Rotate'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setOriginalMediaUrl(null);
                        setEnhancedMediaUrl(null);
                        setExtractedFields(null);
                      }}
                      className="rounded-lg border border-stone-300 bg-white px-2.5 py-1 text-xs font-medium text-rose-700 hover:bg-rose-50 dark:border-stone-700 dark:bg-stone-900 dark:text-rose-400"
                    >
                      {isBn ? 'পুনরায় বাছুন' : 'Reset Image'}
                    </button>
                  </div>
                </div>

                {/* Image Display */}
                <div className="relative overflow-hidden rounded-2xl border border-stone-300 bg-stone-950 flex items-center justify-center max-h-72">
                  <img
                    src={viewingVersion === 'original' ? originalMediaUrl : enhancedMediaUrl || originalMediaUrl}
                    alt="Scanned Document"
                    className="max-h-72 w-auto object-contain transition duration-200"
                  />
                  <div className="absolute top-2 left-2 rounded-md bg-black/60 px-2 py-0.5 font-mono text-[10px] text-white">
                    {viewingVersion === 'original' ? 'ORIGINAL EVIDENCE' : 'ENHANCED (CANVAS)'}
                  </div>
                </div>

                {/* Enhancement Sliders Accordion */}
                <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-950 space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-stone-800 dark:text-stone-200">
                    <span className="flex items-center gap-1.5">
                      <Sliders className="h-4 w-4 text-amber-800" />
                      {isBn ? 'ছবির স্পষ্টতা ও দ্বৈত-রঙ সমন্বয় (Enhancement Filters)' : 'Image Enhancement Suite'}
                    </span>
                    <label className="flex items-center gap-2 cursor-pointer font-normal text-xs text-amber-900 dark:text-amber-400">
                      <input
                        type="checkbox"
                        checked={binarize}
                        onChange={e => {
                          setBinarize(e.target.checked);
                          if (originalMediaUrl) {
                            applyEnhancement(originalMediaUrl, contrast, brightness, e.target.checked, rotation);
                          }
                        }}
                        className="rounded text-amber-800"
                      />
                      <span>{isBn ? 'পুরাতন দলিলের কালো-সাদা বাইনারাইজেশন (Otsu)' : 'Binarize Aged Document'}</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <div className="flex justify-between text-stone-600 mb-1">
                        <span>{isBn ? 'কনট্রাস্ট (Contrast)' : 'Contrast'}</span>
                        <span className="font-mono">{contrast}</span>
                      </div>
                      <input
                        type="range"
                        min="-50"
                        max="100"
                        value={contrast}
                        onChange={e => {
                          const val = Number(e.target.value);
                          setContrast(val);
                          if (originalMediaUrl) applyEnhancement(originalMediaUrl, val, brightness, binarize, rotation);
                        }}
                        className="w-full accent-amber-800"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-stone-600 mb-1">
                        <span>{isBn ? 'উজ্জ্বলতা (Brightness)' : 'Brightness'}</span>
                        <span className="font-mono">{brightness}</span>
                      </div>
                      <input
                        type="range"
                        min="-50"
                        max="50"
                        value={brightness}
                        onChange={e => {
                          const val = Number(e.target.value);
                          setBrightness(val);
                          if (originalMediaUrl) applyEnhancement(originalMediaUrl, contrast, val, binarize, rotation);
                        }}
                        className="w-full accent-amber-800"
                      />
                    </div>
                  </div>
                </div>

                {/* OCR Control Center */}
                <div className="rounded-2xl border border-amber-900/20 bg-amber-50/60 p-4 dark:border-stone-800 dark:bg-stone-950 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Languages className="h-4 w-4 text-amber-800 dark:text-amber-400" />
                      <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
                        {isBn ? 'অপটিক্যাল ক্যারেক্টার রিকগনিশন (OCR):' : 'Optical Character Recognition:'}
                      </span>
                      <select
                        value={ocrLanguage}
                        onChange={e => setOcrLanguage(e.target.value as any)}
                        disabled={isOcrRunning}
                        className="rounded-lg border border-stone-300 bg-white px-2.5 py-1 text-xs text-stone-800 dark:bg-stone-900 dark:text-white"
                      >
                        <option value="ben+eng">{isBn ? 'বাংলা + English (দ্বিভাষিক)' : 'Bengali + English'}</option>
                        <option value="ben">{isBn ? 'শুধু বাংলা (Bengali Only)' : 'Bengali Only'}</option>
                        <option value="eng">English Only</option>
                      </select>
                    </div>

                    <div className="flex items-center gap-2">
                      {isOcrRunning ? (
                        <button
                          type="button"
                          onClick={handleCancelOcr}
                          className="rounded-xl border border-rose-300 bg-rose-50 px-3 py-1.5 text-xs font-bold text-rose-700 hover:bg-rose-100"
                        >
                          {isBn ? 'বাতিল করুন' : 'Cancel OCR'}
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={handleRunOcr}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-amber-900 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-amber-950 transition dark:bg-amber-800"
                        >
                          <Sparkles className="h-3.5 w-3.5" />
                          <span>{isBn ? 'ওসিআর চালান ও ক্ষেত্র শনাক্ত করুন' : 'Run OCR & Detect Fields'}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* OCR Progress bar */}
                  {isOcrRunning && (
                    <div className="space-y-1.5 pt-1">
                      <div className="flex justify-between text-xs text-amber-900 dark:text-amber-300 font-medium">
                        <span>{ocrStatusText}</span>
                        <span className="font-mono">{ocrProgress}%</span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-amber-200 dark:bg-stone-800">
                        <div
                          className="h-full bg-amber-800 transition-all duration-300 dark:bg-amber-500"
                          style={{ width: `${ocrProgress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Extracted Fields Summary Card */}
                  {extractedFields && !isOcrRunning && (
                    <div className="rounded-xl border border-emerald-300 bg-emerald-50/90 p-3.5 text-xs text-emerald-950 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200 space-y-2">
                      <div className="flex items-center justify-between font-bold">
                        <span className="flex items-center gap-1.5 text-emerald-800 dark:text-emerald-300">
                          <CheckCircle2 className="h-4 w-4" />
                          {isBn
                            ? `শনাক্তকৃত ক্ষেত্রসমূহ (নির্ভুলতা: ${ocrConfidence}%)`
                            : `Extracted Attributes (Confidence: ${ocrConfidence}%)`}
                        </span>
                        <span className="rounded bg-emerald-200/80 px-2 py-0.5 font-mono text-[11px] text-emerald-900 dark:bg-emerald-900 dark:text-emerald-200">
                          {extractedFields.documentKind.toUpperCase()}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-stone-700 dark:text-stone-300 max-h-64 overflow-auto pr-1">
                        {buildExtractedFieldCandidates(extractedFields).map(field => (
                          <div key={field.key} className="rounded-lg border border-emerald-200/70 bg-white/70 p-2 dark:border-emerald-900/40 dark:bg-stone-900/50">
                            <div className="flex items-center justify-between gap-2"><strong>{isBn ? field.labelBn || field.labelEn : field.labelEn || field.labelBn}</strong><span className="text-[9px] font-mono text-stone-400">{field.confidence}%</span></div>
                            <div className="break-words text-[11px]">{field.value}</div>
                            <div className="mt-0.5 text-[9px] text-stone-400">{field.profileWritable ? (isBn ? 'Profile-এ নেওয়া যাবে' : 'Profile-writable') : (isBn ? 'Evidence/Review' : 'Evidence / review')}</div>
                          </div>
                        ))}
                      </div>
                      {extractedFields.rawUnmappedLines?.length ? (
                        <details className="rounded-xl border border-stone-200 bg-white/60 p-2 dark:border-stone-800 dark:bg-stone-950/40">
                          <summary className="cursor-pointer text-[10px] font-bold">{isBn ? `অন্যান্য OCR লেখা দেখুন (${extractedFields.rawUnmappedLines.length})` : `Show other OCR text (${extractedFields.rawUnmappedLines.length})`}</summary>
                          <pre className="mt-2 max-h-44 overflow-auto whitespace-pre-wrap text-[10px] leading-relaxed text-stone-600 dark:text-stone-400">{extractedFields.rawUnmappedLines.join('\n')}</pre>
                        </details>
                      ) : null}
                      {extractedFields.conflicts?.length ? (
                        <div className="rounded-xl border border-rose-300 bg-rose-50 p-2 text-[10px] text-rose-900 dark:border-rose-900 dark:bg-rose-950/30 dark:text-rose-200">
                          <b>{isBn ? 'একাধিক মান পাওয়া গেছে — সিদ্ধান্ত প্রয়োজন:' : 'Conflicting extracted values — review required:'}</b>
                          {extractedFields.conflicts.map(c => <div key={c.fieldKey}>• {c.labelBn || c.labelEn}: {c.values.join(' / ')}</div>)}
                        </div>
                      ) : null}
                      {initialMemberId && (
                        <div className="mt-3 rounded-xl border border-emerald-200 bg-white/70 p-3 dark:border-emerald-900/50 dark:bg-stone-900/50">
                          <div className="mb-2 flex items-center justify-between">
                            <b className="text-[11px]">{isBn ? 'প্রোফাইলে নেওয়ার তথ্য বাছাই করুন' : 'Choose fields to apply to Profile'}</b>
                            <button type="button" className="text-[10px] font-bold underline" onClick={() => setSelectedOcrFields(buildExtractedFieldCandidates(extractedFields).map(x => x.key))}>{isBn ? 'সব নির্বাচন' : 'Select all'}</button>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                            {buildExtractedFieldCandidates(extractedFields).map(field => (
                              <label key={field.key} className="flex items-center gap-2 rounded-lg border p-2 text-[11px] cursor-pointer">
                                <input type="checkbox" checked={selectedOcrFields.includes(field.key)} onChange={e => setSelectedOcrFields(prev => e.target.checked ? [...new Set([...prev,field.key])] : prev.filter(x => x !== field.key))} />
                                <span className="min-w-0"><b>{isBn ? field.labelBn || field.labelEn : field.labelEn || field.labelBn}</b><span className="block truncate text-stone-500">{field.value}</span><small className="text-[9px] text-stone-400">{field.profileWritable ? (isBn ? 'Profile' : 'Profile') : (isBn ? 'Evidence only' : 'Evidence only')}</small></span>
                              </label>
                            ))}
                          </div>
                        </div>
                      )}
                      {initialMemberId && (
                        <button type="button" onClick={applyOcrToSelectedMember} disabled={!extractedFields} className="mt-3 rounded-xl bg-emerald-700 px-4 py-2 text-xs font-bold text-white disabled:opacity-40">
                          {isBn ? 'OCR-এর তথ্য Profile-এ নিন (যাচাই করে)' : 'Review & Apply OCR to Profile'}
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* Metadata Details Form */}
                <div className="rounded-2xl border border-stone-200 bg-white p-5 dark:border-stone-800 dark:bg-stone-950 space-y-4">
                  <h4 className="font-serif font-bold text-stone-900 dark:text-stone-100 text-sm">
                    {isBn ? 'দলিলের স্থায়ী মেটাডাটা ও পারিবারিক সংযোগ' : 'Document Metadata & Family Linkage'}
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                        {isBn ? 'দলিলের শিরোনাম (বাংলা)' : 'Title (Bengali)'} *
                      </label>
                      <input
                        type="text"
                        value={titleBn}
                        onChange={e => setTitleBn(e.target.value)}
                        placeholder={isBn ? 'যেমন: ১৯৬৫ সালের জমিদারি খতিয়ান' : 'Document title in Bengali'}
                        className="w-full rounded-xl border border-stone-300 px-3.5 py-2 text-sm text-stone-900 dark:border-stone-700 dark:bg-stone-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                        {isBn ? 'শিরোনাম (English)' : 'Title (English)'}
                      </label>
                      <input
                        type="text"
                        value={title}
                        onChange={e => setTitle(e.target.value)}
                        placeholder="e.g. 1965 Zamindari Land Deed"
                        className="w-full rounded-xl border border-stone-300 px-3.5 py-2 text-sm text-stone-900 dark:border-stone-700 dark:bg-stone-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                        {isBn ? 'ক্যাটাগরি' : 'Category'}
                      </label>
                      <select
                        value={category}
                        onChange={e => setCategory(e.target.value as ArchiveCategory)}
                        className="w-full rounded-xl border border-stone-300 px-3 py-2 text-sm dark:border-stone-700 dark:bg-stone-900 dark:text-white"
                      >
                        <option value="identity_document">{isBn ? 'পরিচয়পত্র (Identity)' : 'Identity Document'}</option>
                        <option value="land_document">{isBn ? 'ভূমির রেকর্ড (Land Deed/Khatian)' : 'Land Document'}</option>
                        <option value="certificate">{isBn ? 'সনদপত্র (Certificate)' : 'Certificate'}</option>
                        <option value="photo">{isBn ? 'ফটোগ্রাফ (Photo)' : 'Photo'}</option>
                        <option value="letter">{isBn ? 'পত্রাবলী (Letter)' : 'Letter'}</option>
                        <option value="document">{isBn ? 'অন্যান্য দলিল (General Document)' : 'Document'}</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                        {isBn ? 'দলিলের প্রকারভেদ' : 'Document Subtype'}
                      </label>
                      <select
                        value={documentType}
                        onChange={e => setDocumentType(e.target.value as DocumentSubtype)}
                        className="w-full rounded-xl border border-stone-300 px-3 py-2 text-sm dark:border-stone-700 dark:bg-stone-900 dark:text-white"
                      >
                        <option value="nid_card">জাতীয় পরিচয়পত্র (NID)</option>
                        <option value="birth_registration">জন্ম নিবন্ধন (BRN)</option>
                        <option value="passport">পাসপোর্ট (Passport)</option>
                        <option value="khatian">খতিয়ান (CS/SA/RS/BS)</option>
                        <option value="porcha">পর্চা (Porcha)</option>
                        <option value="deed">দলিল (Registered Deed)</option>
                        <option value="marriage_doc">নিকাহনামা (Marriage Doc)</option>
                        <option value="death_doc">মৃত্যু সনদ (Death Doc)</option>
                        <option value="historical_doc">ঐতিহাসিক দলিল (Historical)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                        {isBn ? 'দলিলের তারিখ' : 'Date'}
                      </label>
                      <input
                        type="date"
                        value={recordDate}
                        onChange={e => setRecordDate(e.target.value)}
                        className="w-full rounded-xl border border-stone-300 px-3 py-2 text-sm dark:border-stone-700 dark:bg-stone-900 dark:text-white"
                      />
                    </div>
                  </div>

                  {/* Multi-member Association */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-stone-100 dark:border-stone-900">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                        {isBn ? 'সম্পর্কিত পরিবারের সদস্য (একাধিক হতে পারে)' : 'Related Family Member(s)'}
                      </label>
                      <select
                        multiple
                        value={selectedMemberIds}
                        onChange={e => {
                          const options = Array.from(e.target.selectedOptions, opt => opt.value);
                          setSelectedMemberIds(options);
                        }}
                        className="w-full rounded-xl border border-stone-300 px-3 py-2 text-xs dark:border-stone-700 dark:bg-stone-900 dark:text-white h-24"
                      >
                        {members.map(m => (
                          <option key={m.id} value={m.id}>
                            {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName} ()
                          </option>
                        ))}
                      </select>
                      <p className="mt-1 text-[11px] text-stone-400">
                        {isBn ? 'কন্ট্রোল চেপে একাধিক সদস্য নির্বাচন করতে পারেন।' : 'Hold Ctrl / Cmd to select multiple members.'}
                      </p>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                          {isBn ? 'সদস্যের ভূমিকা (Member Role in Document)' : 'Role in Document'}
                        </label>
                        <input
                          type="text"
                          value={memberRole}
                          onChange={e => setMemberRole(e.target.value)}
                          placeholder={isBn ? 'যেমন: মূল ধারক / পিতা (পিং) / গ্রহীতা' : 'e.g. Primary Holder / Father / Co-owner'}
                          className="w-full rounded-xl border border-stone-300 px-3 py-2 text-sm dark:border-stone-700 dark:bg-stone-900 dark:text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                          {isBn ? 'গোপনীয়তা ও অনুমতি' : 'Access Permission'}
                        </label>
                        <select
                          value={permission}
                          onChange={e => setPermission(e.target.value as any)}
                          className="w-full rounded-xl border border-stone-300 px-3 py-2 text-sm dark:border-stone-700 dark:bg-stone-900 dark:text-white"
                        >
                          <option value="family">{isBn ? 'পারিবারিক (Family Access)' : 'Family'}</option>
                          <option value="public">{isBn ? 'সার্বজনীন (Public)' : 'Public'}</option>
                          <option value="restricted">{isBn ? 'সংবেদনশীল ও মাস্কযুক্ত (Restricted)' : 'Restricted (Sensitive)'}</option>
                          <option value="admin">{isBn ? 'শুধু প্রশাসক (Admin Only)' : 'Admin Only'}</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            )}

          </div>

          {/* Footer */}
          <div className="flex items-center justify-between border-t border-amber-900/10 bg-stone-50/70 px-6 py-4 dark:border-stone-800 dark:bg-stone-900/90">
            <div className="text-xs text-stone-500">
              {isBn
                ? 'আসল প্রমাণ চিরতরে সংরক্ষিত থাকবে; উন্নত কপি পৃথক ফিল্টার ফাইল হিসেবে থাকবে।'
                : 'Pristine original is preserved forever; enhanced copy stored separately.'}
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl border border-stone-300 px-4 py-2.5 text-sm font-semibold text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleFinalSave}
                disabled={!originalMediaUrl || isOcrRunning}
                className="inline-flex items-center gap-2 rounded-xl bg-amber-900 px-5 py-2.5 text-sm font-semibold text-white shadow-md hover:bg-amber-950 disabled:opacity-50 transition dark:bg-amber-800"
              >
                <CheckCircle2 className="h-4 w-4" />
                {isBn ? 'পারিবারিক আর্কাইভে সংরক্ষণ করুন' : 'Save to Archive'}
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Duplicate Detection Modal if triggered */}
      {showDuplicateModal && extractedFields && (
        <DuplicateDetectionModal
          isOpen={showDuplicateModal}
          onClose={() => setShowDuplicateModal(false)}
          extractedFields={extractedFields}
          candidates={duplicateCandidates}
          documentTitle={titleBn || title || 'স্ক্যানকৃত দলিল'}
          onSelectExisting={handleSelectExistingCandidate}
          onCreateNew={() => setShowDuplicateModal(false)}
          onKeepUnlinked={() => {
            setSelectedMemberIds([]);
            setShowDuplicateModal(false);
          }}
          isBn={isBn}
        />
      )}

      {/* Conflict Resolution Modal if triggered */}
      {showConflictModal && conflictTargetMember && (
        <DocumentConflictModal
          isOpen={showConflictModal}
          onClose={() => setShowConflictModal(false)}
          conflicts={conflicts}
          member={conflictTargetMember}
          sourceDocTitle={titleBn || title || 'স্ক্যানকৃত দলিল'}
          onResolve={handleConflictResolutions}
          isBn={isBn}
        />
      )}
    </>
  );
};
