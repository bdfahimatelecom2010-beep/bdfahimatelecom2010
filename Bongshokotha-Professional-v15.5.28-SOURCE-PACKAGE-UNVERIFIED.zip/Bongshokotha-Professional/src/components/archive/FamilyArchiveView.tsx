/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Family Archive & Historical Documents Vault (Part 3)
 * 
 * Digital repository of family identity records, land deeds, heirloom photos,
 * letters, and recorded oral histories.
 */

import React, { useState, useMemo } from 'react';
import { useGenealogy } from '../../context/GenealogyContext';
import { ArchiveRecord, ArchiveCategory } from '../../types/genealogy';
import { DocumentScannerModal } from './DocumentScannerModal';
import { OralHistoryRecorderModal } from './OralHistoryRecorderModal';
import { ArchiveBulkUploadModal } from './ArchiveBulkUploadModal';
import { ArchiveRecordDetailModal } from './ArchiveRecordDetailModal';
import {
  FolderArchive,
  Search,
  Filter,
  Camera,
  Mic,
  UploadCloud,
  FileText,
  Image as ImageIcon,
  Radio,
  FileCheck,
  ShieldCheck,
  Calendar,
  Users,
  Grid,
  List,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Landmark,
  ShieldAlert,
  CheckCircle2
} from 'lucide-react';

interface FamilyArchiveViewProps {
  onOpenMemberProfile: (memberId: string) => void;
  isBn: boolean;
}

export const FamilyArchiveView: React.FC<FamilyArchiveViewProps> = ({
  onOpenMemberProfile,
  isBn
}) => {
  const { archiveRecords, members, family, addArchiveRecord, userAccount, checkPermission } = useGenealogy();

  // Search and Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedMemberFilter, setSelectedMemberFilter] = useState<string>('all');
  const [selectedVerification, setSelectedVerification] = useState<string>('all');
  const [viewLayout, setViewLayout] = useState<'grid' | 'table'>('grid');

  // Modal State
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isRecorderOpen, setIsRecorderOpen] = useState(false);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  const [selectedRecordForDetail, setSelectedRecordForDetail] = useState<ArchiveRecord | null>(null);

  // Filtered Archive Records
  const filteredRecords = useMemo(() => {
    return archiveRecords.filter(record => {
      if (record.accessPermission === 'restricted' && !checkPermission('canViewSensitiveDocs')) return false;
      if (record.accessPermission === 'admin' && !['owner','super_admin','admin'].includes(userAccount.role)) return false;
      // Category filter
      if (selectedCategory !== 'all' && record.category !== selectedCategory) {
        return false;
      }

      // Member filter
      if (selectedMemberFilter !== 'all') {
        if (!record.relatedMemberIds?.includes(selectedMemberFilter)) {
          return false;
        }
      }

      // Verification filter
      if (selectedVerification !== 'all') {
        if (record.ocrVerification !== selectedVerification) {
          return false;
        }
      }

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const titleMatch = (record.title || '').toLowerCase().includes(q) ||
          (record.titleBn || '').toLowerCase().includes(q);
        const descMatch = (record.description || '').toLowerCase().includes(q) ||
          (record.descriptionBn || '').toLowerCase().includes(q);
        const ocrMatch = (record.ocrText || '').toLowerCase().includes(q);
        const docNoMatch = (record.documentNumbers?.nid || '').includes(q) ||
          (record.documentNumbers?.brn || '').includes(q) ||
          (record.documentNumbers?.khatian || '').includes(q) ||
          (record.documentNumbers?.dag || '').includes(q);
        const tagMatch = (record.tags || []).some(t => t.toLowerCase().includes(q));

        if (!titleMatch && !descMatch && !ocrMatch && !docNoMatch && !tagMatch) {
          return false;
        }
      }

      return true;
    });
  }, [archiveRecords, selectedCategory, selectedMemberFilter, selectedVerification, searchQuery, userAccount.role, checkPermission]);

  // Archive Statistics Summary
  const stats = useMemo(() => {
    const total = archiveRecords.length;
    const photos = archiveRecords.filter(r => r.category === 'photo').length;
    const land = archiveRecords.filter(r => r.category === 'land_document').length;
    const identity = archiveRecords.filter(r => r.category === 'identity_document').length;
    const certificates = archiveRecords.filter(r => r.category === 'certificate').length;
    const audio = archiveRecords.filter(r => r.category === 'audio').length;
    const verified = archiveRecords.filter(r => r.ocrVerification === 'verified').length;
    return { total, photos, land, identity, certificates, audio, verified };
  }, [archiveRecords]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Top Banner & Action Header */}
      <div className="relative overflow-hidden rounded-3xl border border-amber-900/20 bg-linear-to-br from-[#f8f5ee] via-[#fbf9f5] to-amber-50/50 p-6 shadow-sm dark:border-stone-800 dark:from-stone-900 dark:via-stone-900 dark:to-stone-950">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-900/20 bg-amber-100/60 px-3 py-1 text-xs font-bold text-amber-900 dark:border-amber-700/40 dark:bg-amber-950/60 dark:text-amber-300">
              <FolderArchive className="h-3.5 w-3.5" />
              <span>{isBn ? 'পারিবারিক আর্কাইভ' : 'Digital Family Archive & Vault'}</span>
            </div>
            <h1 className="font-serif text-2xl lg:text-3xl font-bold text-stone-900 dark:text-stone-100">
              {isBn ? `${family.banglaName || family.name} — পারিবারিক দলিল ও স্মৃতিভাণ্ডার` : `${family.name} Archive & Vault`}
            </h1>
            <p className="text-xs lg:text-sm text-stone-600 dark:text-stone-400 max-w-2xl">
              {isBn
                ? 'পূর্বপুরুষের জমিজমার খতিয়ান, এনআইডি, ঐতিহাসিক চিঠিপত্র এবং মৌখিক স্মৃতিকথার চিরস্থায়ী সংরক্ষণাগার। মূল প্রমাণের আদি বিশুদ্ধতা অক্ষুণ্ণ রাখা হয়েছে।'
                : 'Permanent preservation of ancestral land deeds, national IDs, heirloom letters, and oral histories. Original evidence is inviolable.'}
            </p>
          </div>

          {/* Quick Action Studio Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setIsScannerOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-amber-900 px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-amber-950 hover:shadow-md transition active:scale-95 dark:bg-amber-800"
            >
              <Camera className="h-4 w-4" />
              <span>{isBn ? 'দলিল স্ক্যান ও OCR' : 'Scan & OCR'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsRecorderOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-rose-800 px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-rose-900 hover:shadow-md transition active:scale-95"
            >
              <Mic className="h-4 w-4" />
              <span>{isBn ? 'কণ্ঠস্বর রেকর্ড' : 'Voice Memo'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsBulkUploadOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-xs font-bold text-stone-700 shadow-2xs hover:bg-stone-50 transition active:scale-95 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200"
            >
              <UploadCloud className="h-4 w-4 text-stone-500" />
              <span>{isBn ? 'বহু নথি আপলোড' : 'Bulk Ingest'}</span>
            </button>
          </div>
        </div>

        {/* Mini Stats Badges Strip */}
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 pt-5 border-t border-amber-900/10 dark:border-stone-800 text-xs">
          <div className="rounded-xl bg-white/70 p-2.5 border border-stone-200/80 dark:bg-stone-900/60 dark:border-stone-800">
            <span className="text-stone-500 block text-[11px]">{isBn ? 'মোট সংরক্ষিত' : 'Total Vault'}</span>
            <span className="font-bold text-stone-900 dark:text-stone-100 font-serif text-base">{stats.total}</span>
          </div>

          <div className="rounded-xl bg-white/70 p-2.5 border border-stone-200/80 dark:bg-stone-900/60 dark:border-stone-800">
            <span className="text-stone-500 block text-[11px]">{isBn ? 'ভূমি ও খতিয়ান' : 'Land Deeds'}</span>
            <span className="font-bold text-emerald-800 dark:text-emerald-400 font-serif text-base">{stats.land}</span>
          </div>

          <div className="rounded-xl bg-white/70 p-2.5 border border-stone-200/80 dark:bg-stone-900/60 dark:border-stone-800">
            <span className="text-stone-500 block text-[11px]">{isBn ? 'জাতীয় পরিচয়পত্র' : 'NID & ID'}</span>
            <span className="font-bold text-blue-800 dark:text-blue-400 font-serif text-base">{stats.identity}</span>
          </div>

          <div className="rounded-xl bg-white/70 p-2.5 border border-stone-200/80 dark:bg-stone-900/60 dark:border-stone-800">
            <span className="text-stone-500 block text-[11px]">{isBn ? 'সনদপত্র' : 'Certificates'}</span>
            <span className="font-bold text-amber-800 dark:text-amber-400 font-serif text-base">{stats.certificates}</span>
          </div>

          <div className="rounded-xl bg-white/70 p-2.5 border border-stone-200/80 dark:bg-stone-900/60 dark:border-stone-800">
            <span className="text-stone-500 block text-[11px]">{isBn ? 'ফটোগ্রাফ' : 'Photographs'}</span>
            <span className="font-bold text-purple-800 dark:text-purple-400 font-serif text-base">{stats.photos}</span>
          </div>

          <div className="rounded-xl bg-white/70 p-2.5 border border-stone-200/80 dark:bg-stone-900/60 dark:border-stone-800">
            <span className="text-stone-500 block text-[11px]">{isBn ? 'মৌখিক অডিও' : 'Oral Audio'}</span>
            <span className="font-bold text-rose-800 dark:text-rose-400 font-serif text-base">{stats.audio}</span>
          </div>

          <div className="rounded-xl bg-white/70 p-2.5 border border-stone-200/80 dark:bg-stone-900/60 dark:border-stone-800">
            <span className="text-stone-500 block text-[11px]">{isBn ? 'যাচাইকৃত নথি' : 'Verified OCR'}</span>
            <span className="font-bold text-emerald-700 dark:text-emerald-400 font-serif text-base">{stats.verified}</span>
          </div>
        </div>
      </div>

      {/* Category Tabs Strip */}
      <div className="flex flex-wrap items-center gap-1.5 border-b border-amber-900/10 pb-2 text-xs font-semibold dark:border-stone-800">
        {[
          { id: 'all', labelBn: 'সকল রেকর্ড', labelEn: 'All Records', count: stats.total },
          { id: 'land_document', labelBn: 'ভূমির রেকর্ড ও খতিয়ান', labelEn: 'Land Deeds & Porcha', count: stats.land },
          { id: 'identity_document', labelBn: 'জাতীয় পরিচয়পত্র (NID)', labelEn: 'Identity & NID', count: stats.identity },
          { id: 'certificate', labelBn: 'সনদপত্র (জন্ম/শিক্ষা)', labelEn: 'Certificates', count: stats.certificates },
          { id: 'photo', labelBn: 'আলোকচিত্র ও প্রতিকৃতি', labelEn: 'Photos', count: stats.photos },
          { id: 'audio', labelBn: 'মৌখিক ইতিহাস (অডিও)', labelEn: 'Oral History', count: stats.audio },
          { id: 'letter', labelBn: 'পত্রাবলী ও স্মৃতি', labelEn: 'Letters & Notes', count: archiveRecords.filter(r => r.category === 'letter').length }
        ].map(cat => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setSelectedCategory(cat.id)}
            className={`rounded-xl px-3.5 py-2 transition flex items-center gap-1.5 ${
              selectedCategory === cat.id
                ? 'bg-amber-900 text-white shadow-xs dark:bg-amber-800'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200 dark:bg-stone-800 dark:text-stone-300'
            }`}
          >
            <span>{isBn ? cat.labelBn : cat.labelEn}</span>
            <span className={`rounded-full px-1.5 py-0.2 font-mono text-[10px] ${
              selectedCategory === cat.id ? 'bg-white/20 text-white' : 'bg-stone-200 text-stone-600 dark:bg-stone-700 dark:text-stone-300'
            }`}>
              {cat.count}
            </span>
          </button>
        ))}
      </div>

      {/* Search & Secondary Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={
              isBn
                ? 'নথির শিরোনাম, NID, জন্ম নিবন্ধন, খতিয়ান নং, দাগ নং বা সদস্য দিয়ে অনুসন্ধান...'
                : 'Search by title, NID, BRN, Khatian, Dag or member...'
            }
            className="w-full rounded-2xl border border-stone-300 bg-white pl-10 pr-4 py-2.5 text-xs text-stone-900 shadow-2xs focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:border-stone-700 dark:bg-stone-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Member Filter */}
          <select
            value={selectedMemberFilter}
            onChange={e => setSelectedMemberFilter(e.target.value)}
            className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs text-stone-800 dark:border-stone-700 dark:bg-stone-900 dark:text-white"
          >
            <option value="all">{isBn ? 'সকল সদস্য' : 'All Members'}</option>
            {members.map(m => (
              <option key={m.id} value={m.id}>
                {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
              </option>
            ))}
          </select>

          {/* Verification Status */}
          <select
            value={selectedVerification}
            onChange={e => setSelectedVerification(e.target.value)}
            className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs text-stone-800 dark:border-stone-700 dark:bg-stone-900 dark:text-white"
          >
            <option value="all">{isBn ? 'সকল যাচাই অবস্থা' : 'All Verification'}</option>
            <option value="verified">{isBn ? 'যাচাইকৃত (Verified)' : 'Verified'}</option>
            <option value="unverified">{isBn ? 'অযাচাইকৃত (Unverified)' : 'Unverified'}</option>
          </select>

          {/* Layout Toggle */}
          <div className="flex rounded-xl border border-stone-300 bg-white p-1 dark:border-stone-700 dark:bg-stone-900">
            <button
              type="button"
              onClick={() => setViewLayout('grid')}
              className={`p-1.5 rounded-lg transition ${
                viewLayout === 'grid' ? 'bg-amber-900 text-white dark:bg-amber-800' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              <Grid className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewLayout('table')}
              className={`p-1.5 rounded-lg transition ${
                viewLayout === 'table' ? 'bg-amber-900 text-white dark:bg-amber-800' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Records Display */}
      {filteredRecords.length === 0 ? (
        <div className="rounded-3xl border-2 border-dashed border-stone-300 p-12 text-center dark:border-stone-800 space-y-3">
          <FolderArchive className="mx-auto h-12 w-12 text-stone-400" />
          <h3 className="font-serif text-lg font-bold text-stone-700 dark:text-stone-300">
            {isBn ? 'কোনো নথি বা দলিল পাওয়া যায়নি' : 'No archive records matched'}
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            {isBn
              ? 'অন্য কোনো শব্দ দিয়ে খুঁজুন অথবা উপরে বোতাম চেপে নতুন দলিল স্ক্যান বা যুক্ত করুন।'
              : 'Try adjusting your search criteria or use the buttons above to scan or upload.'}
          </p>
        </div>
      ) : viewLayout === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredRecords.map(record => {
            const related = members.filter(m => (record.relatedMemberIds || []).includes(m.id));
            const displayTitle = isBn ? record.titleBn || record.title : record.title || record.titleBn;

            return (
              <div
                key={record.id}
                onClick={() => setSelectedRecordForDetail(record)}
                className="group cursor-pointer rounded-3xl border border-stone-200 bg-white overflow-hidden shadow-2xs hover:shadow-md hover:border-amber-800/40 transition duration-200 flex flex-col dark:border-stone-800 dark:bg-stone-900"
              >
                {/* Media Thumbnail */}
                <div className="relative aspect-16/10 bg-stone-950 overflow-hidden flex items-center justify-center">
                  {record.mediaType === 'audio' ? (
                    <div className="flex flex-col items-center justify-center p-6 text-rose-300 space-y-2">
                      <Radio className="h-10 w-10 animate-pulse" />
                      <span className="font-serif text-xs font-bold text-white">
                        {record.audioMetadata?.speaker || (isBn ? 'মৌখিক রেকর্ড' : 'Voice Memo')}
                      </span>
                    </div>
                  ) : (
                    <img
                      src={record.mediaUrl}
                      alt={displayTitle}
                      className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
                    />
                  )}

                  {/* Verification Badge */}
                  <div className="absolute top-3 right-3">
                    {record.ocrVerification === 'verified' ? (
                      <span className="flex items-center gap-1 rounded-full bg-emerald-900/80 backdrop-blur-xs px-2.5 py-1 text-[11px] font-bold text-emerald-200 border border-emerald-500/40">
                        <CheckCircle2 className="h-3 w-3" />
                        {isBn ? 'যাচাইকৃত' : 'Verified'}
                      </span>
                    ) : (
                      <span className="rounded-full bg-stone-900/80 backdrop-blur-xs px-2.5 py-1 text-[11px] font-medium text-stone-300 border border-stone-700">
                        {isBn ? 'অযাচাইকৃত' : 'Pending'}
                      </span>
                    )}
                  </div>

                  {/* Category Pill */}
                  <div className="absolute bottom-3 left-3">
                    <span className="rounded-lg bg-black/60 backdrop-blur-xs px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-white">
                      {record.category.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                {/* Card Information */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div className="space-y-1.5">
                    <h3 className="font-serif font-bold text-base text-stone-900 group-hover:text-amber-900 dark:text-stone-100 dark:group-hover:text-amber-300 line-clamp-1 transition">
                      {displayTitle}
                    </h3>

                    {record.description && (
                      <p className="text-xs text-stone-500 dark:text-stone-400 line-clamp-2 leading-relaxed">
                        {record.description}
                      </p>
                    )}
                  </div>

                  {/* Document Numbers Mini Bar */}
                  {record.documentNumbers && (record.documentNumbers.nid || record.documentNumbers.khatian || record.documentNumbers.brn) && (
                    <div className="rounded-xl bg-stone-50 p-2 text-[11px] font-mono text-stone-700 dark:bg-stone-800 dark:text-stone-300 flex items-center justify-between">
                      {record.documentNumbers.nid && (
                        <span>NID: <strong>{record.documentNumbers.nid}</strong></span>
                      )}
                      {record.documentNumbers.brn && (
                        <span>BRN: <strong>{record.documentNumbers.brn}</strong></span>
                      )}
                      {record.documentNumbers.khatian && (
                        <span>{isBn ? 'খতিয়ান:' : 'Khatian:'} <strong>{record.documentNumbers.khatian}</strong></span>
                      )}
                    </div>
                  )}

                  {/* OCR extracted summary: visible directly on the archive card so the
                      user can see what the document yielded without opening a second modal. */}
                  {record.extractedFields && Object.entries(record.extractedFields).some(([k,v]) => k !== 'documentKind' && k !== 'confidence' && Boolean(v)) && (
                    <div className="rounded-xl border border-sky-100 bg-sky-50/70 p-2.5 text-[10px] leading-relaxed dark:border-sky-900/40 dark:bg-sky-950/20">
                      <div className="font-bold text-sky-800 dark:text-sky-300">{isBn ? 'ডকুমেন্ট থেকে পাওয়া তথ্য' : 'Extracted from document'} · OCR {record.ocrConfidence || 0}%</div>
                      <div className="mt-1 space-y-0.5 text-stone-700 dark:text-stone-300">
                        {[
                          ['নাম', record.extractedFields.fullNameBn || record.extractedFields.fullNameEn],
                          ['পিতা', record.extractedFields.fatherName],
                          ['মাতা', record.extractedFields.motherName],
                          ['NID', record.extractedFields.nidNumber],
                          ['জন্ম নিবন্ধন', record.extractedFields.brnNumber],
                          ['জন্মতারিখ', record.extractedFields.dateOfBirth],
                          ['ঠিকানা', record.extractedFields.address]
                        ].filter(([,v]) => Boolean(v)).slice(0, 4).map(([label,value]) => <div key={label}><b>{label}:</b> {String(value)}</div>)}
                      </div>
                    </div>
                  )}

                  {/* Linked Members Strip */}
                  <div className="pt-2 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <Users className="h-3.5 w-3.5 text-stone-400 shrink-0" />
                      {related.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {related.slice(0, 2).map(m => (
                            <button
                              key={m.id}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onOpenMemberProfile(m.id);
                              }}
                              className="font-medium text-amber-900 hover:underline dark:text-amber-300 truncate max-w-[110px]"
                            >
                              {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
                            </button>
                          ))}
                          {related.length > 2 && (
                            <span className="text-stone-400 font-mono">+{related.length - 2}</span>
                          )}
                        </div>
                      ) : (
                        <span className="text-stone-400 text-[11px]">{isBn ? 'অসংযুক্ত' : 'Unlinked'}</span>
                      )}
                    </div>

                    <span className="text-[11px] text-stone-400 font-mono shrink-0">
                      {record.date}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Ledger Table View */
        <div className="overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-2xs dark:border-stone-800 dark:bg-stone-900">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-stone-700 dark:text-stone-300">
              <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-bold text-stone-500 uppercase tracking-wider dark:bg-stone-950 dark:border-stone-800">
                <tr>
                  <th className="px-5 py-3.5">{isBn ? 'দলিল ও শিরোনাম' : 'Record & Title'}</th>
                  <th className="px-4 py-3.5">{isBn ? 'ক্যাটাগরি' : 'Category'}</th>
                  <th className="px-4 py-3.5">{isBn ? 'তারিখ' : 'Date'}</th>
                  <th className="px-4 py-3.5">{isBn ? 'দালিলিক নম্বর' : 'Registry / No.'}</th>
                  <th className="px-4 py-3.5">{isBn ? 'সম্পর্কিত সদস্য' : 'Linked Members'}</th>
                  <th className="px-4 py-3.5">{isBn ? 'যাচাই' : 'Status'}</th>
                  <th className="px-4 py-3.5 text-right">{isBn ? 'অ্যাকশন' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {filteredRecords.map(record => {
                  const related = members.filter(m => (record.relatedMemberIds || []).includes(m.id));
                  const displayTitle = isBn ? record.titleBn || record.title : record.title || record.titleBn;

                  return (
                    <tr
                      key={record.id}
                      onClick={() => setSelectedRecordForDetail(record)}
                      className="cursor-pointer hover:bg-amber-50/40 dark:hover:bg-stone-800/50 transition"
                    >
                      <td className="px-5 py-3.5 font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-3">
                        <div className="h-8 w-8 rounded-lg bg-stone-100 overflow-hidden flex items-center justify-center shrink-0 border border-stone-200 dark:bg-stone-800 dark:border-stone-700">
                          {record.mediaType === 'audio' ? (
                            <Radio className="h-4 w-4 text-rose-700" />
                          ) : (
                            <img src={record.mediaUrl} alt="" className="h-full w-full object-cover" />
                          )}
                        </div>
                        <span className="font-serif">{displayTitle}</span>
                      </td>

                      <td className="px-4 py-3.5 capitalize">
                        {record.category.replace('_', ' ')}
                      </td>

                      <td className="px-4 py-3.5 font-mono text-stone-500">
                        {record.date}
                      </td>

                      <td className="px-4 py-3.5 font-mono">
                        {record.documentNumbers?.nid ||
                          record.documentNumbers?.brn ||
                          record.documentNumbers?.khatian ||
                          '—'}
                      </td>

                      <td className="px-4 py-3.5">
                        {related.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {related.map(m => (
                              <span
                                key={m.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenMemberProfile(m.id);
                                }}
                                className="rounded bg-stone-100 px-2 py-0.5 text-[11px] font-medium text-amber-900 hover:underline dark:bg-stone-800 dark:text-amber-300"
                              >
                                {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-stone-400 italic">—</span>
                        )}
                      </td>

                      <td className="px-4 py-3.5">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          record.ocrVerification === 'verified'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-stone-100 text-stone-600 dark:bg-stone-800 dark:text-stone-400'
                        }`}>
                          {record.ocrVerification}
                        </span>
                      </td>

                      <td className="px-4 py-3.5 text-right">
                        <ChevronRight className="h-4 w-4 text-stone-400 inline" />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Scanner & OCR Modal */}
      {isScannerOpen && (
        <DocumentScannerModal
          isOpen={isScannerOpen}
          onClose={() => setIsScannerOpen(false)}
          onSaved={(newRec) => setSelectedRecordForDetail(newRec)}
          isBn={isBn}
        />
      )}

      {/* Oral History Voice Recorder Modal */}
      {isRecorderOpen && (
        <OralHistoryRecorderModal
          isOpen={isRecorderOpen}
          onClose={() => setIsRecorderOpen(false)}
          onSave={async (data) => {
            const saved = await addArchiveRecord({
              ...data,
              historyNote: 'মৌখিক ইতিহাস স্টুডিও থেকে সরাসরি রেকর্ড ও সংরক্ষণ।'
            });
            setSelectedRecordForDetail(saved);
          }}
          isBn={isBn}
        />
      )}

      {/* Bulk Upload Modal */}
      {isBulkUploadOpen && (
        <ArchiveBulkUploadModal
          isOpen={isBulkUploadOpen}
          onClose={() => setIsBulkUploadOpen(false)}
          isBn={isBn}
        />
      )}

      {/* Detailed Archive Record Inspector Modal */}
      {selectedRecordForDetail && (
        <ArchiveRecordDetailModal
          isOpen={!!selectedRecordForDetail}
          onClose={() => setSelectedRecordForDetail(null)}
          record={selectedRecordForDetail}
          onOpenMemberProfile={onOpenMemberProfile}
          isBn={isBn}
        />
      )}

    </div>
  );
};
