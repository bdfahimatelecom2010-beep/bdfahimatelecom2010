/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Bulk Archive Importer & Batch Ingestion Studio (Rule 19)
 * 
 * "Support bulk archive import/upload.
 *  Before final import: validate files, detect duplicates, preview,
 *  assign category, assign members, confirm."
 */

import React, { useState } from 'react';
import { useGenealogy } from '../../context/GenealogyContext';
import { ArchiveRecord, ArchiveCategory } from '../../types/genealogy';
import {
  UploadCloud,
  FileText,
  Image as ImageIcon,
  CheckCircle2,
  Trash2,
  Layers,
  Users,
  Calendar,
  X
} from 'lucide-react';

interface ArchiveBulkUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  isBn: boolean;
}

interface StagedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  dataUrl: string;
  category: ArchiveCategory;
  titleBn: string;
  date: string;
  selectedMemberIds: string[];
}

export const ArchiveBulkUploadModal: React.FC<ArchiveBulkUploadModalProps> = ({
  isOpen,
  onClose,
  isBn
}) => {
  const { members, batchAddArchiveRecords } = useGenealogy();

  const [stagedFiles, setStagedFiles] = useState<StagedFile[]>([]);
  const [batchCategory, setBatchCategory] = useState<ArchiveCategory>('document');
  const [batchMemberId, setBatchMemberId] = useState<string>('');
  const [batchDate, setBatchDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleFilesDrop = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = () => {
        const url = reader.result as string;
        let detectedCategory: ArchiveCategory = 'document';
        if (file.type.startsWith('image/')) detectedCategory = 'photo';
        if (file.type.startsWith('audio/')) detectedCategory = 'audio';

        const staged: StagedFile = {
          id: `stage-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          name: file.name,
          size: file.size,
          type: file.type,
          dataUrl: url,
          category: detectedCategory,
          titleBn: file.name.replace(/\.[^/.]+$/, ''),
          date: batchDate,
          selectedMemberIds: batchMemberId ? [batchMemberId] : []
        };
        setStagedFiles(prev => [...prev, staged]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeStaged = (id: string) => {
    setStagedFiles(prev => prev.filter(f => f.id !== id));
  };

  const applyBatchCategory = () => {
    setStagedFiles(prev => prev.map(f => ({ ...f, category: batchCategory })));
  };

  const applyBatchMember = () => {
    if (!batchMemberId) return;
    setStagedFiles(prev => prev.map(f => ({ ...f, selectedMemberIds: [batchMemberId] })));
  };

  const handleConfirmBatchImport = async () => {
    if (stagedFiles.length === 0) return;
    setIsProcessing(true);

    try {
      const recordsToCreate = stagedFiles.map(f => {
        const isAudio = f.type.startsWith('audio/');
        return {
          title: f.titleBn,
          titleBn: f.titleBn,
          category: f.category,
          documentType: isAudio ? 'family_record' : ('historical_doc' as any),
          date: f.date,
          relatedMemberIds: f.selectedMemberIds,
          memberRoles: f.selectedMemberIds.reduce((acc, id) => {
            acc[id] = 'সংযুক্ত সদস্য';
            return acc;
          }, {} as Record<string, string>),
          relatedFamilyId: '', // Filled by context
          mediaUrl: f.dataUrl,
          mediaType: isAudio ? 'audio' : ('image' as any),
          originalFilename: f.name,
          mimeType: f.type || 'image/jpeg',
          fileSizeBytes: f.size,
          ocrVerification: 'unverified' as const,
          source: 'ব্যাচ আপলোড প্যাকেজ',
          provenance: 'পারিবারিক ডিজিটাল প্যাকেজ থেকে আমদানি',
          uploader: 'বাল্ক আমদানিকারী',
          tags: [f.category, 'bulk_import'],
          accessPermission: 'family' as const,
          historyNote: 'একাধিক নথি ব্যাচ পদ্ধতিতে একসাথে মহাফেজখানায় অন্তর্ভুক্ত।'
        };
      });

      await batchAddArchiveRecords(recordsToCreate);
      onClose();
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl border border-amber-900/30 bg-[#fbf9f5] shadow-2xl dark:bg-stone-900 dark:border-stone-700">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-900/10 px-6 py-4 dark:border-stone-800">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300">
              <Layers className="h-6 w-6" />
            </div>
            <div>
              <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100">
                {isBn ? 'বহু নথি একত্রে আপলোড ও আমদানি' : 'Bulk Archive Ingestion Studio'}
              </h2>
              <p className="text-xs text-stone-600 dark:text-stone-400">
                {isBn
                  ? 'একত্রিত যাচাইকরণ, ক্যাটাগরি বণ্টন ও স্বয়ংক্রিয় সদস্য সংযুক্তি'
                  : 'Batch validation, group categorization and atomic family archive import'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-stone-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Global Batch Controls */}
        <div className="border-b border-amber-900/10 bg-amber-50/50 p-4 dark:border-stone-800 dark:bg-stone-950/40">
          <div className="text-xs font-bold text-amber-950 dark:text-amber-200 mb-2">
            {isBn ? 'সার্বজনীন ব্যাচ সেটিংস (সকল নথিতে প্রয়োগ করুন):' : 'Batch Controls (Apply to all files):'}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="flex items-center gap-2">
              <select
                value={batchCategory}
                onChange={e => setBatchCategory(e.target.value as ArchiveCategory)}
                className="flex-1 rounded-xl border border-stone-300 bg-white px-3 py-2 dark:border-stone-700 dark:bg-stone-900 dark:text-white"
              >
                <option value="photo">{isBn ? 'ছবি (Photo)' : 'Photo'}</option>
                <option value="document">{isBn ? 'দলিল (Document)' : 'Document'}</option>
                <option value="land_document">{isBn ? 'ভূমির রেকর্ড (Land)' : 'Land'}</option>
                <option value="certificate">{isBn ? 'সনদপত্র (Certificate)' : 'Certificate'}</option>
                <option value="letter">{isBn ? 'চিঠিপত্র (Letter)' : 'Letter'}</option>
              </select>
              <button
                type="button"
                onClick={applyBatchCategory}
                className="rounded-xl bg-amber-800 px-3 py-2 font-bold text-white hover:bg-amber-900"
              >
                {isBn ? 'প্রয়োগ' : 'Apply'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={batchMemberId}
                onChange={e => setBatchMemberId(e.target.value)}
                className="flex-1 rounded-xl border border-stone-300 bg-white px-3 py-2 dark:border-stone-700 dark:bg-stone-900 dark:text-white"
              >
                <option value="">{isBn ? '-- সদস্য বাছুন --' : '-- Choose Member --'}</option>
                {members.map(m => (
                  <option key={m.id} value={m.id}>
                    {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={applyBatchMember}
                className="rounded-xl bg-amber-800 px-3 py-2 font-bold text-white hover:bg-amber-900"
              >
                {isBn ? 'প্রয়োগ' : 'Apply'}
              </button>
            </div>

            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-amber-900 px-4 py-2 font-bold text-white hover:bg-amber-950 transition">
              <UploadCloud className="h-4 w-4" />
              <span>{isBn ? '+ ফাইলসমূহ যুক্ত করুন' : '+ Add Files'}</span>
              <input
                type="file"
                multiple
                accept="image/*,audio/*,application/pdf"
                onChange={handleFilesDrop}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* Files Grid Preview */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {stagedFiles.length === 0 ? (
            <div className="rounded-3xl border-2 border-dashed border-stone-300 p-12 text-center dark:border-stone-800 space-y-3">
              <UploadCloud className="mx-auto h-12 w-12 text-stone-400" />
              <div className="font-serif text-base font-bold text-stone-700 dark:text-stone-300">
                {isBn ? 'এখনো কোনো ফাইল নির্বাচন করা হয়নি' : 'No files staged yet'}
              </div>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                {isBn
                  ? 'একত্রে ১০০টি পর্যন্ত পুরাতন ছবি, জমির পর্চা বা চিঠি নির্বাচন করে মহাফেজখানায় নথিবদ্ধ করুন।'
                  : 'Select up to 100 historical photos, land deeds or letters for atomic ingestion.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {stagedFiles.map((file, idx) => (
                <div
                  key={file.id}
                  className="flex gap-3 rounded-2xl border border-stone-200 bg-white p-3.5 shadow-2xs dark:border-stone-800 dark:bg-stone-950/60"
                >
                  <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl border border-stone-200 bg-stone-100 flex items-center justify-center dark:border-stone-800 dark:bg-stone-900">
                    {file.type.startsWith('image/') ? (
                      <img src={file.dataUrl} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <FileText className="h-8 w-8 text-amber-800" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <input
                        type="text"
                        value={file.titleBn}
                        onChange={e => {
                          const val = e.target.value;
                          setStagedFiles(prev =>
                            prev.map(f => (f.id === file.id ? { ...f, titleBn: val } : f))
                          );
                        }}
                        className="font-semibold text-stone-900 border-b border-transparent hover:border-stone-300 focus:border-amber-800 focus:outline-hidden dark:text-stone-100 truncate w-44"
                      />
                      <button
                        type="button"
                        onClick={() => removeStaged(file.id)}
                        className="text-stone-400 hover:text-rose-600 p-1"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-stone-500">
                      <span>{(file.size / 1024).toFixed(0)} KB</span>
                      <span>•</span>
                      <span className="capitalize">{file.category}</span>
                    </div>

                    {/* Member Link in file */}
                    <div className="flex items-center gap-1.5 pt-1">
                      <Users className="h-3 w-3 text-stone-400" />
                      <select
                        value={file.selectedMemberIds[0] || ''}
                        onChange={e => {
                          const val = e.target.value;
                          setStagedFiles(prev =>
                            prev.map(f => (f.id === file.id ? { ...f, selectedMemberIds: val ? [val] : [] } : f))
                          );
                        }}
                        className="rounded-lg border border-stone-200 bg-stone-50 px-2 py-0.5 text-[11px] text-stone-700 dark:border-stone-800 dark:bg-stone-900 dark:text-stone-300"
                      >
                        <option value="">{isBn ? 'সদস্যহীন (সাধারণ নথি)' : 'No Member Linked'}</option>
                        {members.map(m => (
                          <option key={m.id} value={m.id}>
                            {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-amber-900/10 bg-stone-50/70 px-6 py-4 dark:border-stone-800 dark:bg-stone-900/90">
          <div className="text-xs text-stone-500">
            {isBn
              ? `মোট ${stagedFiles.length}টি ফাইল আমদানির জন্য অপেক্ষমান`
              : `${stagedFiles.length} files staged for atomic ingestion`}
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-stone-300 px-4 py-2.5 text-sm font-semibold text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300"
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="button"
              onClick={handleConfirmBatchImport}
              disabled={stagedFiles.length === 0 || isProcessing}
              className="inline-flex items-center gap-2 rounded-xl bg-amber-900 px-5 py-2.5 text-sm font-semibold text-white shadow-md hover:bg-amber-950 disabled:opacity-50 transition dark:bg-amber-800"
            >
              <CheckCircle2 className="h-4 w-4" />
              {isProcessing
                ? (isBn ? 'আমদানি হচ্ছে...' : 'Importing...')
                : (isBn ? `সকল ${stagedFiles.length}টি সংরক্ষণ করুন` : `Import All ${stagedFiles.length} Files`)}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
