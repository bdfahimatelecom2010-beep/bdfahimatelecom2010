/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Conflict Resolution Modal (Rule 15: Non-destructive Verification)
 * 
 * "If OCR finds: Existing Name: Rahim Ahmed, OCR Name: Rahim Uddin:
 *  Do not automatically replace the existing value.
 *  Show: Existing Value, Extracted Value, Source Document, Confidence, Accept / Reject / Edit"
 */

import React, { useState } from 'react';
import { FieldConflict, Member } from '../../types/genealogy';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Edit3,
  ShieldCheck,
  FileText,
  ArrowRight,
  Sparkles,
  X
} from 'lucide-react';

interface DocumentConflictModalProps {
  isOpen: boolean;
  onClose: () => void;
  conflicts: FieldConflict[];
  member: Member;
  sourceDocTitle: string;
  onResolve: (resolutions: Record<string, { decision: 'accept' | 'reject' | 'custom'; value: string }>) => Promise<void>;
  isBn: boolean;
}

export const DocumentConflictModal: React.FC<DocumentConflictModalProps> = ({
  isOpen,
  onClose,
  conflicts: initialConflicts,
  member,
  sourceDocTitle,
  onResolve,
  isBn
}) => {
  const [decisions, setDecisions] = useState<Record<string, { decision: 'accept' | 'reject' | 'custom'; value: string }>>(() => {
    const init: Record<string, { decision: 'accept' | 'reject' | 'custom'; value: string }> = {};
    initialConflicts.forEach(c => {
      // Default to reject to protect verified data unless user actively accepts
      init[c.fieldKey] = { decision: 'reject', value: c.existingValue };
    });
    return init;
  });

  const [customEdits, setCustomEdits] = useState<Record<string, string>>({});
  const [editingField, setEditingField] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleDecision = (fieldKey: string, decision: 'accept' | 'reject', val: string) => {
    setDecisions(prev => ({
      ...prev,
      [fieldKey]: { decision, value: val }
    }));
  };

  const handleCustomSave = (fieldKey: string) => {
    const customVal = customEdits[fieldKey]?.trim();
    if (customVal) {
      setDecisions(prev => ({
        ...prev,
        [fieldKey]: { decision: 'custom', value: customVal }
      }));
    }
    setEditingField(null);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await onResolve(decisions);
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  const memberName = isBn ? member.banglaName || member.fullName : member.englishName || member.fullName;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl border border-amber-900/30 bg-[#fbf9f5] shadow-2xl dark:bg-stone-900 dark:border-stone-700">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-900/10 px-6 py-5 dark:border-stone-800">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <div>
              <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100">
                {isBn ? 'তথ্যের অমিল ও দ্বন্দ্ব সমাধান' : 'Information Conflict Resolution'}
              </h2>
              <p className="text-xs text-stone-600 dark:text-stone-400">
                {isBn
                  ? `${memberName}-এর বর্তমান প্রোফাইল ও দলিলের তথ্যের মধ্যে অমিল পরিলক্ষিত হয়েছে`
                  : `Differences detected between ${memberName}'s profile and source document`}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-stone-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Source Document Provenance Banner */}
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-6 py-3 flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 shrink-0 text-amber-800 dark:text-amber-400" />
            <span>
              <strong>{isBn ? 'উৎস দলিল:' : 'Source Document:'}</strong> {sourceDocTitle}
            </span>
          </div>
          <span className="rounded-md bg-amber-200/60 px-2 py-0.5 text-[11px] font-semibold text-amber-900 dark:bg-amber-900/60 dark:text-amber-300">
            {isBn ? 'অপরিবর্তনীয় আদি তথ্য সুরক্ষা সক্রিয়' : 'Non-destructive Shield Active'}
          </span>
        </div>

        {/* Conflict Items List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {initialConflicts.map(c => {
            const currentChoice = decisions[c.fieldKey];
            const isEditing = editingField === c.fieldKey;

            return (
              <div
                key={c.fieldKey}
                className="rounded-2xl border border-stone-200 bg-white p-5 shadow-xs dark:border-stone-800 dark:bg-stone-950/60 space-y-4"
              >
                <div className="flex items-center justify-between border-b border-stone-100 pb-3 dark:border-stone-800">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-stone-800 dark:text-stone-200 text-sm">
                      {isBn ? c.fieldLabelBn : c.fieldLabelEn}
                    </span>
                    <span className="rounded-full bg-stone-100 px-2.5 py-0.5 text-[11px] text-stone-600 dark:bg-stone-800 dark:text-stone-300">
                      {isBn ? `নির্ভুলতা: ${c.confidence}%` : `Confidence: ${c.confidence}%`}
                    </span>
                  </div>
                  <div className="text-xs font-medium">
                    {currentChoice?.decision === 'accept' && (
                      <span className="text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        {isBn ? 'দলিলের তথ্য গৃহীত হবে' : 'Extracted will replace'}
                      </span>
                    )}
                    {currentChoice?.decision === 'reject' && (
                      <span className="text-stone-600 dark:text-stone-400 flex items-center gap-1">
                        <ShieldCheck className="h-3.5 w-3.5" />
                        {isBn ? 'বর্তমান তথ্য বহাল থাকবে' : 'Keeping existing value'}
                      </span>
                    )}
                    {currentChoice?.decision === 'custom' && (
                      <span className="text-amber-700 dark:text-amber-400 flex items-center gap-1">
                        <Edit3 className="h-3.5 w-3.5" />
                        {isBn ? 'সম্পাদিত কাস্টম মান' : 'Custom edited value'}
                      </span>
                    )}
                  </div>
                </div>

                {/* Side-by-side comparison */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                  {/* Existing */}
                  <div
                    onClick={() => handleDecision(c.fieldKey, 'reject', c.existingValue)}
                    className={`cursor-pointer rounded-xl border p-3 transition ${
                      currentChoice?.decision === 'reject'
                        ? 'border-stone-800 bg-stone-50 ring-2 ring-stone-800/10 dark:border-stone-500 dark:bg-stone-900'
                        : 'border-stone-200 bg-stone-50/50 hover:border-stone-300 dark:border-stone-800 dark:bg-stone-900/40'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400 mb-1">
                      <span>{isBn ? 'বর্তমান প্রোফাইল মান' : 'Existing Profile Value'}</span>
                      {currentChoice?.decision === 'reject' && (
                        <CheckCircle2 className="h-4 w-4 text-stone-700 dark:text-stone-300" />
                      )}
                    </div>
                    <div className="font-semibold text-stone-900 dark:text-stone-100 break-words">
                      {c.existingValue || (isBn ? '(অপ্রকাশিত / ফাঁকা)' : '(Empty)')}
                    </div>
                  </div>

                  {/* Extracted */}
                  <div
                    onClick={() => handleDecision(c.fieldKey, 'accept', c.extractedValue)}
                    className={`cursor-pointer rounded-xl border p-3 transition ${
                      currentChoice?.decision === 'accept'
                        ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-600/20 dark:border-emerald-500 dark:bg-emerald-950/40'
                        : 'border-stone-200 bg-stone-50/50 hover:border-stone-300 dark:border-stone-800 dark:bg-stone-900/40'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs text-emerald-800 dark:text-emerald-400 mb-1">
                      <span className="flex items-center gap-1 font-medium">
                        <Sparkles className="h-3 w-3" />
                        {isBn ? 'দলিল হতে প্রাপ্ত মান (OCR)' : 'Extracted from Document'}
                      </span>
                      {currentChoice?.decision === 'accept' && (
                        <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                      )}
                    </div>
                    <div className="font-semibold text-emerald-950 dark:text-emerald-200 break-words">
                      {c.extractedValue}
                    </div>
                  </div>
                </div>

                {/* Inline Edit Box */}
                {isEditing ? (
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      defaultValue={customEdits[c.fieldKey] || c.extractedValue}
                      onChange={e => setCustomEdits(prev => ({ ...prev, [c.fieldKey]: e.target.value }))}
                      className="flex-1 rounded-xl border border-amber-800/40 bg-white px-3 py-2 text-sm text-stone-900 shadow-inner focus:outline-hidden focus:ring-2 focus:ring-amber-800 dark:bg-stone-900 dark:text-white"
                      placeholder={isBn ? 'সঠিক মান লিখুন...' : 'Enter custom value...'}
                    />
                    <button
                      type="button"
                      onClick={() => handleCustomSave(c.fieldKey)}
                      className="rounded-xl bg-amber-800 px-3 py-2 text-xs font-semibold text-white hover:bg-amber-900"
                    >
                      {isBn ? 'সংরক্ষণ' : 'Save'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingField(null)}
                      className="rounded-xl border border-stone-300 px-3 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300"
                    >
                      {isBn ? 'বাতিল' : 'Cancel'}
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingField(c.fieldKey);
                        if (!customEdits[c.fieldKey]) {
                          setCustomEdits(prev => ({ ...prev, [c.fieldKey]: c.extractedValue }));
                        }
                      }}
                      className="inline-flex items-center gap-1.5 text-xs text-amber-900 hover:underline dark:text-amber-400"
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                      {isBn ? 'কাস্টম সম্পাদনা করুন (Edit)' : 'Edit Custom Value'}
                    </button>
                    <span className="text-[11px] text-stone-400">
                      {isBn ? 'একটি বিকল্পে ক্লিক করে নির্বাচন করুন' : 'Click on a card to select'}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-amber-900/10 bg-stone-50/70 px-6 py-4 dark:border-stone-800 dark:bg-stone-900/90">
          <div className="text-xs text-stone-500 dark:text-stone-400">
            {isBn
              ? 'যাচাই ছাড়া কোনো তথ্য প্রোফাইলে নীরবে প্রতিস্থাপিত হবে না।'
              : 'No profile data is silently overwritten without your explicit choice.'}
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="rounded-xl border border-stone-300 px-4 py-2.5 text-sm font-semibold text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300"
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 rounded-xl bg-amber-900 px-5 py-2.5 text-sm font-semibold text-amber-50 shadow-md hover:bg-amber-950 transition dark:bg-amber-800"
            >
              <CheckCircle2 className="h-4 w-4" />
              {isSubmitting ? (isBn ? 'সংরক্ষণ হচ্ছে...' : 'Saving...') : (isBn ? 'সিদ্ধান্ত নিশ্চিত করুন' : 'Confirm Decisions')}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
