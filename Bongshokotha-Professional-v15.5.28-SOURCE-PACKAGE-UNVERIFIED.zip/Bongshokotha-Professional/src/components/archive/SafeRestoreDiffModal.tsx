/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Safe Restore & Non-Destructive Diff Inspector (Part 4)
 * 
 * Master Rule: "Never silently overwrite verified information.
 *               Never break relationships during editing, import, restore or migration."
 */

import React, { useState, useMemo } from 'react';
import { Member, MarriageRecord, ArchiveRecord, Family } from '../../types/genealogy';
import { BongshokothaArchive } from '../../services/storage';
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  ArrowRight,
  GitMerge,
  RotateCcw,
  X
} from 'lucide-react';

interface SafeRestoreDiffModalProps {
  isOpen: boolean;
  onClose: () => void;
  incomingArchive: BongshokothaArchive;
  currentMembers: Member[];
  currentMarriages: MarriageRecord[];
  onConfirmRestore: (strategy: 'merge_preserve' | 'overwrite_all' | 'keep_existing') => Promise<void>;
  isBn: boolean;
}

export const SafeRestoreDiffModal: React.FC<SafeRestoreDiffModalProps> = ({
  isOpen,
  onClose,
  incomingArchive,
  currentMembers,
  currentMarriages,
  onConfirmRestore,
  isBn
}) => {
  const [strategy, setStrategy] = useState<'merge_preserve' | 'overwrite_all' | 'keep_existing'>('merge_preserve');
  const [isProcessing, setIsProcessing] = useState(false);

  // Analyze differences
  const diffAnalysis = useMemo(() => {
    const incomingMembers = incomingArchive.members || [];
    const currentMemberIds = new Set(currentMembers.map(m => m.id));

    let newCount = 0;
    let conflictCount = 0;
    let exactMatchCount = 0;

    incomingMembers.forEach(incoming => {
      const existing = currentMembers.find(m => m.id === incoming.id);
      if (!existing) {
        newCount++;
      } else {
        // Compare basic attributes
        const isDiff =
          existing.fullName !== incoming.fullName ||
          existing.banglaName !== incoming.banglaName ||
          existing.identityDocs?.nidNumber !== incoming.identityDocs?.nidNumber;

        if (isDiff) {
          conflictCount++;
        } else {
          exactMatchCount++;
        }
      }
    });

    return {
      totalIncoming: incomingMembers.length,
      newCount,
      conflictCount,
      exactMatchCount,
      incomingMarriages: (incomingArchive.marriages || []).length,
      incomingArchiveRecords: (incomingArchive.archiveRecords || []).length
    };
  }, [incomingArchive, currentMembers]);

  if (!isOpen) return null;

  const handleExecute = async () => {
    setIsProcessing(true);
    try {
      await onConfirmRestore(strategy);
      onClose();
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl rounded-3xl border border-amber-900/30 bg-[#fbf9f5] shadow-2xl dark:bg-stone-900 dark:border-stone-700 overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-900/10 px-6 py-4 dark:border-stone-800">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300">
              <GitMerge className="h-6 w-6" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-stone-900 dark:text-stone-100">
                {isBn ? 'নিরাপদ ডেটা পুনরুদ্ধার ও ডিআইএফএফ বিশ্লেষণ' : 'Safe Restore & Non-Destructive Diff'}
              </h2>
              <p className="text-xs text-stone-500">
                {isBn
                  ? 'পূর্বনির্ধারিত যাচাইকৃত তথ্যের সুরক্ষা নিশ্চিত করে আমদানি করুন।'
                  : 'Guard existing verified facts before committing external data.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-stone-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Diff Stats Deck */}
        <div className="p-6 space-y-5">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4 dark:border-emerald-900 dark:bg-emerald-950/30">
            <div className="flex items-start gap-3">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
              <div>
                <div className="text-xs font-bold text-emerald-900 dark:text-emerald-200">{isBn ? 'স্বয়ংক্রিয় Smart Restore সক্রিয়' : 'Automatic Smart Restore is active'}</div>
                <p className="mt-1 text-[11px] leading-relaxed text-emerald-800 dark:text-emerald-300">{isBn ? 'রিস্টোরের আগে ভাঙা parent/marriage/child link মেরামত হবে, তারপর প্রজন্ম পুনর্গণনা হবে। ব্যাকআপে থাকা পুরোনো generation/order value একা UI-এর অবস্থান নির্ধারণ করবে না।' : 'Broken parent/marriage/child links are repaired before generation recalculation, so stale generation/order values from an old backup cannot control the restored presentation.'}</p>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-amber-900/20 bg-amber-50/50 p-4 dark:border-stone-800 dark:bg-stone-950/60">
            <div className="text-xs font-bold text-amber-950 dark:text-amber-200 mb-3">
              {isBn ? 'ফাইল থেকে প্রাপ্ত তথ্যের বিশ্লেষণ বিবরণী:' : 'Incoming Archive Inspection Report:'}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center text-xs">
              <div className="rounded-xl bg-white p-2.5 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                <span className="text-stone-500 block text-[10px]">{isBn ? 'মোট সদস্য' : 'Total Members'}</span>
                <span className="font-serif text-base font-bold text-stone-900 dark:text-stone-100">{diffAnalysis.totalIncoming}</span>
              </div>
              <div className="rounded-xl bg-white p-2.5 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                <span className="text-stone-500 block text-[10px]">{isBn ? 'সম্পূর্ণ নতুন' : 'New Additions'}</span>
                <span className="font-serif text-base font-bold text-emerald-700 dark:text-emerald-400">+{diffAnalysis.newCount}</span>
              </div>
              <div className="rounded-xl bg-white p-2.5 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                <span className="text-stone-500 block text-[10px]">{isBn ? 'তথ্য ভিন্নতা' : 'Conflicts'}</span>
                <span className="font-serif text-base font-bold text-amber-700 dark:text-amber-400">{diffAnalysis.conflictCount}</span>
              </div>
              <div className="rounded-xl bg-white p-2.5 border border-stone-200 dark:bg-stone-900 dark:border-stone-800">
                <span className="text-stone-500 block text-[10px]">{isBn ? 'মহাফেজখানা দলিল' : 'Vault Docs'}</span>
                <span className="font-serif text-base font-bold text-stone-900 dark:text-stone-100">{diffAnalysis.incomingArchiveRecords}</span>
              </div>
            </div>
          </div>

          {/* Strategy Selection */}
          <div className="space-y-3 text-xs">
            <div className="font-bold text-stone-800 dark:text-stone-200">
              {isBn ? 'পুনরুদ্ধার পদ্ধতি নির্বাচন করুন:' : 'Select Ingestion Strategy:'}
            </div>

            <label
              onClick={() => setStrategy('merge_preserve')}
              className={`flex items-start gap-3 rounded-2xl border p-4 cursor-pointer transition ${
                strategy === 'merge_preserve'
                  ? 'border-amber-800 bg-amber-50/70 dark:border-amber-500 dark:bg-amber-950/40'
                  : 'border-stone-200 bg-white hover:bg-stone-50 dark:border-stone-800 dark:bg-stone-950'
              }`}
            >
              <input
                type="radio"
                name="strategy"
                checked={strategy === 'merge_preserve'}
                onChange={() => setStrategy('merge_preserve')}
                className="mt-1 text-amber-800 focus:ring-amber-800"
              />
              <div className="space-y-1">
                <div className="font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-emerald-600" />
                  <span>{isBn ? 'অক্ষুণ্ণ একত্রীকরণ (স্মার্ট মার্জ)' : 'Non-Destructive Smart Merge (Recommended)'}</span>
                </div>
                <p className="text-stone-600 dark:text-stone-400 leading-relaxed text-[11px]">
                  {isBn
                    ? 'নতুন সদস্যদের যুক্ত করবে এবং বিদ্যমান সদস্যদের কোনো শূন্য তথ্য থাকলে তা পূরণ করবে। কিন্তু কোনো যাচাইকৃত তথ্য বা নাম মুছে বা জোরপূর্বক পরিবর্তন করবে না।'
                    : 'Appends new members and fills in unsupplied fields without overwriting your verified facts or destroying IDs.'}
                </p>
              </div>
            </label>

            <label
              onClick={() => setStrategy('keep_existing')}
              className={`flex items-start gap-3 rounded-2xl border p-4 cursor-pointer transition ${
                strategy === 'keep_existing'
                  ? 'border-blue-800 bg-blue-50/70 dark:border-blue-500 dark:bg-blue-950/40'
                  : 'border-stone-200 bg-white hover:bg-stone-50 dark:border-stone-800 dark:bg-stone-950'
              }`}
            >
              <input
                type="radio"
                name="strategy"
                checked={strategy === 'keep_existing'}
                onChange={() => setStrategy('keep_existing')}
                className="mt-1 text-blue-800 focus:ring-blue-800"
              />
              <div className="space-y-1">
                <div className="font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                  <ShieldAlert className="h-4 w-4 text-blue-600" />
                  <span>{isBn ? 'বিদ্যমান তথ্য অগ্রাধিকার (Keep Existing)' : 'Keep Existing Data on Conflict'}</span>
                </div>
                <p className="text-stone-600 dark:text-stone-400 leading-relaxed text-[11px]">
                  {isBn
                    ? 'বিদ্যমান কোনো তথ্যে হাত দেবে না; শুধুমাত্র সম্পূর্ণ নতুন সদস্য ও দলিলগুলো বর্তমান ডাটাবেসে যোগ করবে।'
                    : 'Leaves any existing record untouched; only appends completely new members and documents.'}
                </p>
              </div>
            </label>

            <label
              onClick={() => setStrategy('overwrite_all')}
              className={`flex items-start gap-3 rounded-2xl border p-4 cursor-pointer transition ${
                strategy === 'overwrite_all'
                  ? 'border-rose-800 bg-rose-50/70 dark:border-rose-500 dark:bg-rose-950/40'
                  : 'border-stone-200 bg-white hover:bg-stone-50 dark:border-stone-800 dark:bg-stone-950'
              }`}
            >
              <input
                type="radio"
                name="strategy"
                checked={strategy === 'overwrite_all'}
                onChange={() => setStrategy('overwrite_all')}
                className="mt-1 text-rose-800 focus:ring-rose-800"
              />
              <div className="space-y-1">
                <div className="font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-rose-600" />
                  <span>{isBn ? 'সম্পূর্ণ ডেটাবেস প্রতিস্থাপন' : 'Full Overwrite Restore'}</span>
                </div>
                <p className="text-stone-600 dark:text-stone-400 leading-relaxed text-[11px]">
                  {isBn
                    ? 'বর্তমান ডেটাবেসকে এই ফাইলের হুবহু রূপান্তর করবে। কেবল তখনই ব্যবহার করুন যখন আপনি পুরো পারিবারিক অবস্থা একটি নির্দিষ্ট ব্যাকআপ বিন্দুতে ফিরিয়ে নিতে চান।'
                    : 'Replaces current dataset entirely with this backup snapshot. Use only when rolling back to an exact archive state.'}
                </p>
              </div>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-amber-900/10 bg-stone-50 px-6 py-4 dark:border-stone-800 dark:bg-stone-900/80">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-stone-300 px-4 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300"
          >
            {isBn ? 'বাতিল' : 'Cancel'}
          </button>
          <button
            type="button"
            onClick={handleExecute}
            disabled={isProcessing}
            className="inline-flex items-center gap-2 rounded-xl bg-amber-900 px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-amber-950 disabled:opacity-50 transition dark:bg-amber-800"
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>
              {isProcessing
                ? (isBn ? 'পুনরুদ্ধার হচ্ছে...' : 'Restoring...')
                : (isBn ? 'নিরাপদ পুনরুদ্ধার সম্পন্ন করুন' : 'Execute Safe Restore')}
            </span>
          </button>
        </div>

      </div>
    </div>
  );
};
