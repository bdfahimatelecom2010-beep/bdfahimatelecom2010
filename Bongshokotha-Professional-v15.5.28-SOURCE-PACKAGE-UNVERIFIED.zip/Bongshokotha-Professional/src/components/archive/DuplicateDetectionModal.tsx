/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Duplicate Detection & Verification Modal (Rule 16)
 * 
 * "Before creating a new person from a document, search for possible matches
 *  using combinations of: name, NID, BRN, birth date, parents, phone, address.
 *  User confirms whether: Existing Member, New Member, Not enough information."
 */

import React from 'react';
import { DuplicateCandidate, ExtractedDocumentFields, Member } from '../../types/genealogy';
import {
  Users,
  UserCheck,
  UserPlus,
  HelpCircle,
  ShieldAlert,
  ChevronRight,
  FileText,
  X
} from 'lucide-react';

interface DuplicateDetectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  extractedFields: ExtractedDocumentFields;
  candidates: DuplicateCandidate[];
  documentTitle: string;
  onSelectExisting: (member: Member) => void;
  onCreateNew: () => void;
  onKeepUnlinked: () => void;
  isBn: boolean;
}

export const DuplicateDetectionModal: React.FC<DuplicateDetectionModalProps> = ({
  isOpen,
  onClose,
  extractedFields,
  candidates,
  documentTitle,
  onSelectExisting,
  onCreateNew,
  onKeepUnlinked,
  isBn
}) => {
  if (!isOpen) return null;

  const extractedName = isBn
    ? extractedFields.fullNameBn || extractedFields.fullNameEn || 'অজ্ঞাত ব্যক্তি'
    : extractedFields.fullNameEn || extractedFields.fullNameBn || 'Unknown Person';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl border border-amber-900/30 bg-[#fbf9f5] shadow-2xl dark:bg-stone-900 dark:border-stone-700">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-900/10 px-6 py-5 dark:border-stone-800">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300">
              <Users className="h-6 w-6" />
            </div>
            <div>
              <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100">
                {isBn ? 'সদস্য সাদৃশ্য ও দ্বৈততা যাচাই' : 'Duplicate Detection & Identity Verification'}
              </h2>
              <p className="text-xs text-stone-600 dark:text-stone-400">
                {isBn
                  ? 'দলিল হতে নিষ্কাশিত তথ্যের সাথে পরিবারে বিদ্যমান সদস্যদের সাদৃশ্য শনাক্তকরণ'
                  : 'Matching extracted identity attributes with existing family members'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-stone-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Extracted Subject Preview */}
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-6 py-3 text-xs text-amber-950 dark:text-amber-200 space-y-1">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-sm">{extractedName}</span>
            <span className="rounded bg-amber-200/80 px-2 py-0.5 font-mono text-[11px] dark:bg-amber-900/80">
              {documentTitle}
            </span>
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-stone-600 dark:text-stone-300">
            {extractedFields.nidNumber && (
              <span><strong>NID:</strong> {extractedFields.nidNumber}</span>
            )}
            {extractedFields.brnNumber && (
              <span><strong>BRN:</strong> {extractedFields.brnNumber}</span>
            )}
            {extractedFields.fatherName && (
              <span><strong>{isBn ? 'পিতা:' : 'Father:'}</strong> {extractedFields.fatherName}</span>
            )}
            {extractedFields.dateOfBirth && (
              <span><strong>{isBn ? 'জন্ম তারিখ:' : 'DOB:'}</strong> {extractedFields.dateOfBirth}</span>
            )}
          </div>
        </div>

        {/* Candidate List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <div className="flex items-center justify-between text-xs font-semibold text-stone-700 dark:text-stone-300">
            <span>
              {isBn
                ? `সম্ভাব্য মিলে যাওয়া সদস্য (${candidates.length} জন):`
                : `Potential Matches (${candidates.length} found):`}
            </span>
            <span className="text-stone-400">
              {isBn ? 'সঠিক সদস্যে ক্লিক করে লিংক করুন' : 'Click to link with an existing member'}
            </span>
          </div>

          {candidates.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-stone-300 p-8 text-center dark:border-stone-800 space-y-2">
              <ShieldAlert className="mx-auto h-8 w-8 text-stone-400" />
              <p className="text-sm font-medium text-stone-700 dark:text-stone-300">
                {isBn ? 'কোনো সরাসরি সাদৃশ্য পাওয়া যায়নি।' : 'No direct member matches found.'}
              </p>
              <p className="text-xs text-stone-500">
                {isBn
                  ? 'এই নথি দিয়ে আপনি নতুন পরিবার সদস্য তৈরি করতে পারেন অথবা শুধুমাত্র আর্কাইভে সংরক্ষণ করতে পারেন।'
                  : 'You can create a new family member from this document or keep it unlinked in the archive.'}
              </p>
            </div>
          ) : (
            candidates.map(({ member, matchScore, matchedReasons }) => {
              const name = isBn ? member.banglaName || member.fullName : member.englishName || member.fullName;
              return (
                <div
                  key={member.id}
                  onClick={() => onSelectExisting(member)}
                  className="group cursor-pointer rounded-2xl border border-stone-200 bg-white p-4 hover:border-amber-800/40 hover:shadow-md transition dark:border-stone-800 dark:bg-stone-950/60"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-xl bg-amber-50 border border-amber-800/20 overflow-hidden flex items-center justify-center text-amber-900 font-bold dark:bg-stone-800 dark:text-amber-300">
                        {member.profilePhoto ? (
                          <img src={member.profilePhoto} alt="" className="h-full w-full object-cover" />
                        ) : (
                          name[0]
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-serif font-bold text-stone-900 dark:text-stone-100">
                            {name}
                          </span>
                          <span className="font-mono text-xs text-stone-500">
                            ()
                          </span>
                        </div>
                        <div className="text-xs text-stone-500 dark:text-stone-400">
                          {member.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}
                          {member.birth?.date?.year && ` • ${isBn ? 'জন্ম' : 'Born'} ${member.birth.date.year}`}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${
                          matchScore >= 80
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}>
                          {matchScore}% {isBn ? 'মিল' : 'Match'}
                        </span>
                      </div>
                      <ChevronRight className="h-5 w-5 text-stone-400 group-hover:text-amber-800 transition" />
                    </div>
                  </div>

                  {/* Matching criteria badges */}
                  <div className="mt-3 flex flex-wrap gap-1.5 pt-2 border-t border-stone-100 dark:border-stone-900">
                    {matchedReasons.map((reason, idx) => (
                      <span
                        key={idx}
                        className="rounded-md bg-stone-100 px-2 py-0.5 text-[11px] text-stone-700 dark:bg-stone-800 dark:text-stone-300"
                      >
                        ✓ {reason}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* 3 Explicit Resolution Choices */}
        <div className="border-t border-amber-900/10 bg-stone-50/80 p-6 dark:border-stone-800 dark:bg-stone-900/90 space-y-3">
          <div className="text-xs font-medium text-stone-600 dark:text-stone-400">
            {isBn ? 'আপনার সিদ্ধান্ত নিশ্চিত করুন:' : 'Confirm your decision:'}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={onCreateNew}
              className="flex items-center justify-center gap-2 rounded-xl bg-amber-900 px-4 py-3 text-sm font-semibold text-white shadow-xs hover:bg-amber-950 transition dark:bg-amber-800"
            >
              <UserPlus className="h-4 w-4" />
              {isBn ? 'নতুন সদস্য হিসেবে তৈরি করুন' : 'Create as New Member'}
            </button>

            <button
              type="button"
              onClick={onKeepUnlinked}
              className="flex items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm font-semibold text-stone-700 hover:bg-stone-100 transition dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200"
            >
              <HelpCircle className="h-4 w-4 text-stone-500" />
              {isBn ? 'পর্যাপ্ত তথ্য নেই (অসংযুক্ত রাখুন)' : 'Not Enough Info (Keep Unlinked)'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
