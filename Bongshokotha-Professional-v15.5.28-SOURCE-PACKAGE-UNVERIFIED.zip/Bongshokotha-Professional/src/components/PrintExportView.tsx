/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Dedicated Archival Print Layouts & Import / Export Center
 */

import React, { useState, useMemo } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { Member } from '../types/genealogy';
import { toBanglaDigits, formatGenealogyDate, calculateLifespan } from '../engine/banglaCalendar';
import {
  Printer,
  Download,
  Upload,
  Layers,
  Users,
  GitFork,
  BookOpen,
  FileText,
  ShieldCheck,
  Check
} from 'lucide-react';

interface PrintExportViewProps {
  onNavigateToBook: () => void;
  onSelectMember: (memberId: string) => void;
}

export const PrintExportView: React.FC<PrintExportViewProps> = ({
  onNavigateToBook,
  onSelectMember
}) => {
  const {
    family,
    members,
    marriages,
    branches,
    generations,
    generationSummary,
    exportArchiveJSON,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const [activePrintLayout, setActivePrintLayout] = useState<'roster' | 'tree' | 'branch' | 'archive' | 'dossier'>('roster');
  const [selectedMemberId, setSelectedMemberId] = useState<string>(members[0]?.id || '');
  const [selectedBranchId, setSelectedBranchId] = useState<string>(branches[0]?.id || '');

  const memberMap = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);
  const selectedMember = memberMap.get(selectedMemberId);
  const selectedBranch = branches.find(b => b.id === selectedBranchId);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Controls (Hidden in Print) */}
      <div className="no-print rounded-2xl border border-amber-900/10 bg-white p-6 shadow-xs dark:border-stone-800 dark:bg-stone-900 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
          <div>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-amber-950 dark:text-amber-100 flex items-center gap-2">
              <Printer className="h-6 w-6 text-amber-800 dark:text-amber-400" />
              <span>{isBn ? 'মুদ্রণ লেআউট ও ডেটা আদান-প্রদান' : 'Dedicated Print Layouts & Export'}</span>
            </h2>
            <p className="text-xs text-stone-500">
              {isBn
                ? 'ব্রাউজার উইন্ডোর পরিবর্তে উচ্চমানের প্রামাণ্য পারিবারিক ডকুমেন্টের প্রিন্ট লেআউট তৈরি করুন।'
                : 'Generate publication-grade print sheets formatted with archival borders and clean typographic margins.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportArchiveJSON}
              className="inline-flex items-center gap-1.5 rounded-xl border border-amber-900/20 bg-amber-50 px-3.5 py-2 text-xs font-semibold text-amber-900 hover:bg-amber-100 transition dark:border-stone-700 dark:bg-stone-800 dark:text-amber-200"
            >
              <Download className="h-4 w-4" />
              <span>{isBn ? 'ব্যাকআপ (.bkf)' : 'Backup .bkf'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 rounded-xl bg-amber-800 px-5 py-2 text-xs sm:text-sm font-semibold text-white shadow-md hover:bg-amber-900 transition dark:bg-amber-700"
            >
              <Printer className="h-4 w-4" />
              <span>{isBn ? 'বর্তমান পৃষ্ঠা প্রিন্ট করুন' : 'Print Document'}</span>
            </button>
          </div>
        </div>

        {/* Layout Selection Bar */}
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'roster', labelBn: 'সদস্য তালিকা ও রেজিস্ট্রি (Roster)', labelEn: 'Member Roster' },
            { id: 'tree', labelBn: 'প্রজন্মভিত্তিক চার্ট (Generation List)', labelEn: 'Generational Chart' },
            { id: 'branch', labelBn: 'শাখাভিত্তিক বংশধারা (Branch Document)', labelEn: 'Branch Lineage' },
            { id: 'archive', labelBn: 'দলিল ও খতিয়ান ইনডেক্স (Archive Index)', labelEn: 'Archive Index' },
            { id: 'dossier', labelBn: 'ব্যক্তিগত পারিবারিক সনদ (Individual Dossier)', labelEn: 'Member Dossier' }
          ].map(lay => (
            <button
              key={lay.id}
              onClick={() => setActivePrintLayout(lay.id as typeof activePrintLayout)}
              className={`rounded-xl px-3.5 py-2 text-xs font-semibold transition ${
                activePrintLayout === lay.id
                  ? 'bg-amber-800 text-white shadow-xs dark:bg-amber-700'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200 dark:bg-stone-800 dark:text-stone-300'
              }`}
            >
              {isBn ? lay.labelBn : lay.labelEn}
            </button>
          ))}
        </div>

        {/* Sub-selector for Dossier or Branch */}
        {activePrintLayout === 'dossier' && (
          <div className="flex items-center gap-2 pt-2 text-xs">
            <span className="font-semibold text-stone-700 dark:text-stone-300">{isBn ? 'সদস্য নির্বাচন:' : 'Select Member:'}</span>
            <select
              value={selectedMemberId}
              onChange={e => setSelectedMemberId(e.target.value)}
              className="rounded-lg border border-stone-200 bg-white p-1.5 text-xs text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
            >
              {members.map(m => (
                <option key={m.id} value={m.id}>
                   — {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
                </option>
              ))}
            </select>
          </div>
        )}

        {activePrintLayout === 'branch' && (
          <div className="flex items-center gap-2 pt-2 text-xs">
            <span className="font-semibold text-stone-700 dark:text-stone-300">{isBn ? 'শাখা নির্বাচন:' : 'Select Branch:'}</span>
            <select
              value={selectedBranchId}
              onChange={e => setSelectedBranchId(e.target.value)}
              className="rounded-lg border border-stone-200 bg-white p-1.5 text-xs text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
            >
              {branches.map(b => (
                <option key={b.id} value={b.id}>
                  {isBn ? b.banglaName || b.name : b.name}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* PRINT SHEET CONTAINER */}
      <div className="mx-auto max-w-4xl bg-white p-8 sm:p-12 shadow-xl border border-amber-900/15 print:p-0 print:border-0 print:shadow-none dark:bg-stone-900">
        {/* Document Official Header */}
        <div className="border-b-2 border-amber-900 pb-4 mb-6 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-widest text-amber-900">
              BONGSHOKOTHA OFFICIAL ARCHIVE • বংশকথা
            </div>
            <h1 className="font-serif text-2xl font-bold text-amber-950 dark:text-amber-100">
              {family.banglaName || family.name}
            </h1>
            <p className="text-xs text-stone-500">
              {isBn ? 'প্রামাণ্য পারিবারিক বংশলতিকা ও ঐতিহাসিক নথি' : 'Certified Lineage & Genealogical Records'}
            </p>
          </div>

          <div className="text-right text-[10px] text-stone-500 font-mono">
            <div>{isBn ? 'পরিবার আইডি:' : 'Family ID:'} {family.id}</div>
            <div>{new Date().toLocaleDateString(isBn ? 'bn-BD' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
            <div className="text-emerald-800 font-bold font-sans">✓ Verified Sound</div>
          </div>
        </div>

        {/* LAYOUT 1: MEMBER ROSTER */}
        {activePrintLayout === 'roster' && (
          <div className="space-y-4">
            <h2 className="font-serif font-bold text-lg text-amber-950 pb-2 border-b border-stone-200">
              {isBn ? 'সম্পূর্ণ সদস্য নিবন্ধন সূচি' : 'Official Member Registry Roster'}
            </h2>

            <table className="w-full text-left text-xs border border-stone-200">
              <thead className="bg-stone-100 border-b border-stone-200 font-bold">
                <tr>
                  <th className="p-2 border-r">{isBn ? 'ক্রমিক' : 'Serial'}</th>
                  <th className="p-2 border-r">{isBn ? 'নাম' : 'Name'}</th>
                  <th className="p-2 border-r">{isBn ? 'প্রজন্ম ও শাখা' : 'Gen & Branch'}</th>
                  <th className="p-2 border-r">{isBn ? 'জীবনকাল' : 'Lifespan'}</th>
                  <th className="p-2 border-r">{isBn ? 'এনআইডি / জন্ম সনদ' : 'NID / Reg'}</th>
                  <th className="p-2">{isBn ? 'পিতামাতা' : 'Parents'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {members.map(m => {
                  const gen = generations.get(m.id) || 1;
                  const branch = branches.find(b => b.id === m.branchId);
                  const father = m.fatherId ? memberMap.get(m.fatherId) : null;
                  const mother = m.motherId ? memberMap.get(m.motherId) : null;
                  const lifespan = calculateLifespan(m.birth?.date, m.death?.date, m.isLiving, language);

                  return (
                    <tr key={m.id} className="page-break-inside-avoid">
                      <td className="p-2 font-mono font-bold border-r"></td>
                      <td className="p-2 font-semibold border-r">
                        {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
                      </td>
                      <td className="p-2 border-r">
                        {isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Gen ${gen}`} • {branch ? (isBn ? branch.banglaName || branch.name : branch.name) : '—'}
                      </td>
                      <td className="p-2 border-r text-[11px]">{lifespan}</td>
                      <td className="p-2 border-r font-mono text-[10px]">
                        {m.identityDocs?.nidNumber && <div>NID: {m.identityDocs.nidNumber}</div>}
                        {m.identityDocs?.birthRegistrationNumber && <div>Reg: {m.identityDocs.birthRegistrationNumber}</div>}
                      </td>
                      <td className="p-2 text-[11px]">
                        {father && <div>{isBn ? 'পিতা: ' : 'F: '}</div>}
                        {mother && <div>{isBn ? 'মাতা: ' : 'M: '}</div>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* LAYOUT 2: GENERATION CHART */}
        {activePrintLayout === 'tree' && (
          <div className="space-y-6">
            <h2 className="font-serif font-bold text-lg text-amber-950 pb-2 border-b border-stone-200">
              {isBn ? 'প্রজন্মভিত্তিক বংশানুক্রমিক তালিকা' : 'Generational Lineage Chart'}
            </h2>

            {Array.from({ length: generationSummary.maxGeneration }, (_, i) => i + 1).map(gen => {
              const genMembers = members.filter(m => (generations.get(m.id) || 1) === gen);

              return (
                <div key={gen} className="page-break-inside-avoid space-y-2 border-b border-stone-200 pb-4">
                  <h3 className="font-serif font-bold text-sm bg-amber-50 p-1.5 rounded-md text-amber-900">
                    {isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম (${toBanglaDigits(genMembers.length)} জন সদস্য)` : `Generation ${gen} (${genMembers.length} Members)`}
                  </h3>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                    {genMembers.map(m => (
                      <div key={m.id} className="border border-stone-200 p-2 rounded-md">
                        <div className="font-mono text-[10px] text-amber-900 font-bold"></div>
                        <div className="font-bold">{isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}</div>
                        <div className="text-[10px] text-stone-500">
                          {formatGenealogyDate(m.birth?.date, language)} • {m.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* LAYOUT 3: BRANCH ROSTER */}
        {activePrintLayout === 'branch' && selectedBranch && (
          <div className="space-y-4">
            <div className="pb-2 border-b border-stone-200">
              <span className="text-xs font-bold uppercase text-amber-800">{isBn ? 'শাখাভিত্তিক বংশধারা' : 'Lineage Branch'}</span>
              <h2 className="font-serif font-bold text-xl text-amber-950">
                {isBn ? selectedBranch.banglaName || selectedBranch.name : selectedBranch.name}
              </h2>
              {selectedBranch.description && (
                <p className="text-xs text-stone-600 italic mt-1">{selectedBranch.description}</p>
              )}
            </div>

            <div className="space-y-3">
              {members
                .filter(m => m.branchId === selectedBranch.id)
                .map(m => {
                  const gen = generations.get(m.id) || 1;
                  return (
                    <div key={m.id} className="page-break-inside-avoid border border-stone-200 p-3 rounded-lg text-xs space-y-1">
                      <div className="flex justify-between font-bold">
                        <span> — {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}</span>
                        <span className="font-mono text-[11px]">{isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Gen ${gen}`}</span>
                      </div>
                      <div className="text-[11px] text-stone-500">
                        {m.birth?.place?.district && `${isBn ? 'নিবাস: ' : 'District: '}${m.birth.place.district}`}
                        {m.isLiving ? ` • ${isBn ? 'জীবিত' : 'Living'}` : ` • ${isBn ? 'প্রয়াত' : 'Deceased'}`}
                      </div>
                      {m.biography && <p className="text-[11px] text-stone-700 pt-1">{m.biography}</p>}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* LAYOUT 4: ARCHIVE INDEX */}
        {activePrintLayout === 'archive' && (
          <div className="space-y-4">
            <h2 className="font-serif font-bold text-lg text-amber-950 pb-2 border-b border-stone-200">
              {isBn ? 'সংরক্ষিত প্রামাণ্য দলিল ও খতিয়ান সূচিপত্র' : 'Archival Documents & Records Index'}
            </h2>

            <table className="w-full text-left text-xs border border-stone-200">
              <thead className="bg-stone-100 border-b border-stone-200 font-bold">
                <tr>
                  <th className="p-2 border-r">{isBn ? 'নথি প্রকার' : 'Type'}</th>
                  <th className="p-2 border-r">{isBn ? 'দলিল নম্বর / রেফারেন্স' : 'Document Ref'}</th>
                  <th className="p-2 border-r">{isBn ? 'সদস্যের নাম ও ক্রমিক' : 'Member'}</th>
                  <th className="p-2">{isBn ? 'যাচাইকরণ' : 'Status'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {members.map(m => (
                  <React.Fragment key={m.id}>
                    {m.identityDocs?.nidNumber && (
                      <tr className="page-break-inside-avoid">
                        <td className="p-2 border-r font-semibold">NID</td>
                        <td className="p-2 border-r font-mono">{m.identityDocs.nidNumber}</td>
                        <td className="p-2 border-r">{isBn ? m.banglaName || m.fullName : m.englishName || m.fullName} ()</td>
                        <td className="p-2 font-semibold text-emerald-800">Verified</td>
                      </tr>
                    )}
                    {m.identityDocs?.birthRegistrationNumber && (
                      <tr className="page-break-inside-avoid">
                        <td className="p-2 border-r font-semibold">Birth Reg</td>
                        <td className="p-2 border-r font-mono">{m.identityDocs.birthRegistrationNumber}</td>
                        <td className="p-2 border-r">{isBn ? m.banglaName || m.fullName : m.englishName || m.fullName} ()</td>
                        <td className="p-2 font-semibold text-emerald-800">Verified</td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* LAYOUT 5: INDIVIDUAL DOSSIER */}
        {activePrintLayout === 'dossier' && selectedMember && (
          <div className="page-break-inside-avoid space-y-6 border border-stone-300 p-6 rounded-2xl">
            <div className="flex justify-between border-b pb-4">
              <div>
                <span className="font-mono text-xs font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded-sm">
                </span>
                <h2 className="font-serif font-bold text-2xl text-amber-950 mt-1">
                  {isBn ? selectedMember.banglaName || selectedMember.fullName : selectedMember.englishName || selectedMember.fullName}
                </h2>
                <p className="text-xs text-stone-500 font-mono">ID: {selectedMember.id}</p>
              </div>

              <div className="text-right text-xs">
                <div className="font-bold">{isBn ? `${toBanglaDigits(generations.get(selectedMember.id) || 1)}ম প্রজন্ম` : `Generation ${generations.get(selectedMember.id) || 1}`}</div>
                <div>{selectedMember.isLiving ? (isBn ? 'বর্তমানে জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="font-bold block text-stone-500">{isBn ? 'জন্ম তারিখ ও স্থান:' : 'Birth:'}</span>
                <div>{formatGenealogyDate(selectedMember.birth?.date, language)}</div>
                <div>{[selectedMember.birth?.place?.village, selectedMember.birth?.place?.district].filter(Boolean).join(', ')}</div>
              </div>

              <div>
                <span className="font-bold block text-stone-500">{isBn ? 'পরিচয়পত্র নম্বর:' : 'Identity Docs:'}</span>
                <div>NID: {selectedMember.identityDocs?.nidNumber || 'Unrecorded'}</div>
                <div>Reg: {selectedMember.identityDocs?.birthRegistrationNumber || 'Unrecorded'}</div>
              </div>
            </div>

            {selectedMember.biography && (
              <div className="border-t pt-4 text-xs">
                <span className="font-bold block text-stone-500 mb-1">{isBn ? 'জীবনী ও পারিবারিক ইতিবৃত্ত:' : 'Biography:'}</span>
                <p className="leading-relaxed text-stone-700">{selectedMember.biography}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
