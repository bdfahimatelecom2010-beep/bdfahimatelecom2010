/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Interactive Relationship Calculator & Kinship Path Visualizer
 * 
 * Rule: "Relationship Finder must show the actual relationship path."
 * Example: Person A -> Father -> Father's Brother -> His Daughter
 */

import React, { useState, useMemo } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { Member } from '../types/genealogy';
import { toBanglaDigits } from '../engine/banglaCalendar';
import {
  Compass,
  ArrowRight,
  ArrowLeftRight,
  Users,
  Layers,
  Sparkles,
  GitCommit,
  Info
} from 'lucide-react';

interface RelationshipFinderViewProps {
  initialPersonAId?: string;
  initialPersonBId?: string;
  onSelectMember: (memberId: string) => void;
}

export const RelationshipFinderView: React.FC<RelationshipFinderViewProps> = ({
  initialPersonAId,
  initialPersonBId,
  onSelectMember
}) => {
  const {
    members,
    calculateRelationship,
    language
  } = useGenealogy();

  const isBn = language === 'bn';

  const [personAId, setPersonAId] = useState<string>(
    initialPersonAId || (members[0]?.id ?? '')
  );
  const [personBId, setPersonBId] = useState<string>(
    initialPersonBId || (members[1]?.id ?? '')
  );

  const memberMap = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);

  const personA = memberMap.get(personAId);
  const personB = memberMap.get(personBId);

  const result = useMemo(() => {
    if (!personAId || !personBId) return null;
    return calculateRelationship(personAId, personBId);
  }, [personAId, personBId, calculateRelationship]);

  const swapPersons = () => {
    const temp = personAId;
    setPersonAId(personBId);
    setPersonBId(temp);
  };

  const getGenDiffLabel = (diff: number) => {
    if (diff === 0) return isBn ? 'একই প্রজন্ম (সমসাময়িক)' : 'Same Generation (Peer)';
    if (diff === 1) return isBn ? '১ প্রজন্ম অধস্তন (পরবর্তী প্রজন্ম)' : '+1 Generation (Descendant)';
    if (diff === -1) return isBn ? '১ প্রজন্ম উর্ধ্বতন (পূর্বপুরুষ)' : '-1 Generation (Ancestor)';
    if (diff > 1) return isBn ? `${toBanglaDigits(diff)} প্রজন্ম অধস্তন` : `+${diff} Generations Descendant`;
    return isBn ? `${toBanglaDigits(Math.abs(diff))} প্রজন্ম উর্ধ্বতন` : `${Math.abs(diff)} Generations Ancestor`;
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Top Banner */}
      <div className="rounded-2xl border border-amber-900/10 bg-white p-5 shadow-xs dark:border-stone-800 dark:bg-stone-900">
        <h2 className="font-serif text-xl sm:text-2xl font-bold text-amber-950 dark:text-amber-100">
          {isBn ? 'সম্পর্ক নির্ণয়ক ও রক্তের পথ অনুসন্ধান' : 'Kinship Path Calculator'}
        </h2>
        <p className="text-xs text-stone-500">
          {isBn
            ? 'পারিবারিক রক্ত ও বৈবাহিক গ্রাফ থেকে যেকোনো দুইজন সদস্যের মধ্যকার সঠিক আত্মীয়তার পদবি ও সংযোগ পথ বের করুন।'
            : 'Find the authentic Bengali kinship term and step-by-step connection path between any two members.'}
        </p>
      </div>

      {/* Selectors Panel */}
      <div className="grid grid-cols-1 md:grid-cols-7 gap-4 items-center rounded-2xl border border-amber-900/10 bg-white p-5 shadow-xs dark:border-stone-800 dark:bg-stone-900">
        {/* Person A Selector */}
        <div className="md:col-span-3 space-y-1.5">
          <label className="text-xs font-semibold text-stone-600 dark:text-stone-300">
            {isBn ? '১ম ব্যক্তি (শুরুর সদস্য):' : 'Person A (Source Member):'}
          </label>
          <select
            value={personAId}
            onChange={e => setPersonAId(e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs sm:text-sm font-medium text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
          >
            {members.map(m => (
              <option key={m.id} value={m.id}>
                 — {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
              </option>
            ))}
          </select>
          {personA && (
            <div className="text-[11px] text-stone-500">
              {isBn ? 'শাখা:' : 'Branch:'} {personA.branchId} • {personA.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}
            </div>
          )}
        </div>

        {/* Swap Button */}
        <div className="md:col-span-1 flex justify-center">
          <button
            onClick={swapPersons}
            className="rounded-full border border-stone-200 bg-amber-50 p-2.5 text-amber-900 hover:bg-amber-100 hover:rotate-180 transition-all duration-300 dark:border-stone-700 dark:bg-stone-800 dark:text-amber-300"
            title={isBn ? 'স্থান অদলবদল' : 'Swap members'}
          >
            <ArrowLeftRight className="h-4 w-4" />
          </button>
        </div>

        {/* Person B Selector */}
        <div className="md:col-span-3 space-y-1.5">
          <label className="text-xs font-semibold text-stone-600 dark:text-stone-300">
            {isBn ? '২য় ব্যক্তি (লক্ষ্য সদস্য):' : 'Person B (Target Member):'}
          </label>
          <select
            value={personBId}
            onChange={e => setPersonBId(e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs sm:text-sm font-medium text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
          >
            {members.map(m => (
              <option key={m.id} value={m.id}>
                 — {isBn ? m.banglaName || m.fullName : m.englishName || m.fullName}
              </option>
            ))}
          </select>
          {personB && (
            <div className="text-[11px] text-stone-500">
              {isBn ? 'শাখা:' : 'Branch:'} {personB.branchId} • {personB.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}
            </div>
          )}
        </div>
      </div>

      {/* Result Display */}
      {result && (
        <div className="space-y-6">
          {/* Kinship Title Hero Card */}
          <div className="rounded-2xl border border-amber-900/15 bg-gradient-to-br from-amber-50 via-amber-100/40 to-stone-50 p-6 sm:p-8 shadow-sm dark:border-stone-800 dark:from-stone-900 dark:via-stone-900 dark:to-stone-950">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-amber-800 px-3 py-1 text-xs font-bold text-white shadow-xs dark:bg-amber-700">
                    {isBn ? 'আত্মীয়তার পদবি' : 'Calculated Kinship'}
                  </span>
                  <span className="rounded-full bg-stone-200/80 px-2.5 py-0.5 text-xs font-medium text-stone-700 dark:bg-stone-800 dark:text-stone-300">
                    {getGenDiffLabel(result.generationDifference)}
                  </span>
                </div>

                <div className="font-serif text-2xl sm:text-4xl font-bold tracking-tight text-amber-950 dark:text-amber-100">
                  {isBn ? result.relationshipNameBn : result.relationshipNameEn}
                </div>

                <div className="text-sm font-medium text-amber-900/80 dark:text-amber-300/80">
                  {isBn ? result.relationshipNameEn : result.relationshipNameBn}
                </div>
              </div>

              <div className="rounded-xl border border-amber-900/10 bg-white/80 p-4 text-xs text-stone-600 dark:border-stone-800 dark:bg-stone-800/80 dark:text-stone-300 max-w-sm space-y-1.5 shadow-xs">
                <div className="flex items-center gap-1.5 font-semibold text-amber-950 dark:text-amber-200">
                  <Info className="h-3.5 w-3.5" />
                  <span>{isBn ? 'সম্পর্কের ব্যাখ্যা:' : 'Kinship Context:'}</span>
                </div>
                <p className="leading-relaxed">
                  {isBn
                    ? `${personA?.banglaName || personA?.fullName}-এর সাপেক্ষে ${personB?.banglaName || personB?.fullName} হলেন: "${result.relationshipNameBn}"`
                    : `${personB?.englishName || personB?.fullName} is ${personA?.englishName || personA?.fullName}'s ${result.relationshipNameEn}.`}
                </p>
              </div>
            </div>
          </div>

          {/* Actual Relationship Path (Breadcrumb / Step-by-Step Chain) */}
          <div className="rounded-2xl border border-amber-900/10 bg-white p-6 shadow-xs dark:border-stone-800 dark:bg-stone-900 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-800">
              <GitCommit className="h-4 w-4 text-amber-800 dark:text-amber-400" />
              <h3 className="font-serif text-base font-bold text-amber-950 dark:text-amber-100">
                {isBn ? 'ধাপভিত্তিক সম্পর্কের সংযোগ পথ (Kinship Path)' : 'Actual Relationship Path'}
              </h3>
            </div>

            <p className="text-xs text-stone-500 italic">
              {isBn
                ? 'বংশকথা সম্পর্কের পথ অনুমান করে না; রক্ত ও বৈবাহিক গ্রাফ অতিক্রম করে প্রতিটি ধাপ প্রত্যক্ষভাবে প্রদর্শন করে:'
                : 'Bongshokotha does not guess kinship; it traverses exact biological parent-child and marriage links:'}
            </p>

            {/* Visual Node Flow */}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              {/* Person A Node */}
              <div
                onClick={() => personA && onSelectMember(personA.id)}
                className="cursor-pointer rounded-xl border border-amber-800/40 bg-amber-50 p-3 shadow-xs transition hover:bg-amber-100 dark:border-amber-700/50 dark:bg-amber-950/40"
              >
                <div className="text-[10px] font-mono font-bold text-amber-800 dark:text-amber-400">
                  
                </div>
                <div className="font-bold text-xs sm:text-sm text-amber-950 dark:text-amber-100">
                  {isBn ? personA?.banglaName || personA?.fullName : personA?.englishName || personA?.fullName}
                </div>
                <div className="text-[10px] text-stone-500">{isBn ? 'প্রারম্ভিক বিন্দু' : 'Origin'}</div>
              </div>

              {/* Intermediate Steps */}
              {result.path.map((step, idx) => {
                const targetMember = memberMap.get(step.toId);
                const isFinal = idx === result.path.length - 1;

                return (
                  <React.Fragment key={idx}>
                    {/* Direction Arrow with Relation Label */}
                    <div className="flex flex-col items-center px-1">
                      <span className="text-[10px] font-semibold text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded-full dark:bg-amber-950/70 dark:text-amber-300">
                        {isBn ? step.banglaLabel : step.englishLabel}
                      </span>
                      <ArrowRight className="h-4 w-4 text-amber-800 dark:text-amber-400 my-1" />
                    </div>

                    {/* Step Node */}
                    <div
                      onClick={() => targetMember && onSelectMember(targetMember.id)}
                      className={`cursor-pointer rounded-xl border p-3 shadow-xs transition ${
                        isFinal
                          ? 'border-emerald-600/40 bg-emerald-50 hover:bg-emerald-100 dark:border-emerald-500/40 dark:bg-emerald-950/40'
                          : 'border-stone-200 bg-stone-50 hover:bg-stone-100 dark:border-stone-700 dark:bg-stone-800'
                      }`}
                    >
                      <div className="text-[10px] font-mono font-bold text-stone-500">
                        
                      </div>
                      <div className={`font-bold text-xs sm:text-sm ${
                        isFinal
                          ? 'text-emerald-950 dark:text-emerald-100'
                          : 'text-stone-900 dark:text-stone-100'
                      }`}>
                        {isBn ? targetMember?.banglaName || targetMember?.fullName : targetMember?.englishName || targetMember?.fullName}
                      </div>
                      <div className="text-[10px] text-stone-500">
                        {isFinal ? (isBn ? 'লক্ষ্য সদস্য' : 'Target') : (isBn ? 'সংযোগকারী' : 'Link')}
                      </div>
                    </div>
                  </React.Fragment>
                );
              })}
            </div>

            {/* Path text summary */}
            <div className="mt-4 rounded-xl bg-stone-50 p-3 text-xs text-stone-700 dark:bg-stone-950/50 dark:text-stone-300 font-mono">
              {isBn ? result.pathDescriptionBn : result.pathDescriptionEn}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
