/**
 * BONGSHOKOTHA / বংশকথা — Persistent Dashboard Control Center
 * Dashboard visibility, order and density are stored in FamilySettings so the
 * same arrangement survives reload, backup/restore and family switching.
 */
import React, { useMemo, useState } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import {
  Users, Layers, GitFork, Heart, ShieldCheck, AlertTriangle, Plus, Compass,
  FileQuestion, Settings2, Cake, Flower2, MapPin, HardDrive, UserCheck,
  Archive, ChevronUp, ChevronDown, Eye, EyeOff, RotateCcw, BarChart3, Activity, Home,
  FileText, Database, CalendarDays, ScanText, Share2
} from 'lucide-react';
import { toBanglaDigits } from '../engine/banglaCalendar';

interface DashboardViewProps {
  onNavigate: (tab: string) => void;
  onOpenAddMember: () => void;
  onOpenAddMarriage: () => void;
  onSelectMember: (memberId: string) => void;
}

type WidgetId = 'metrics'|'alerts'|'generations'|'demographics'|'upcoming'|'completeness'|'branches'|'ageProfile'|'recent'|'quickTools'|'marriageStatus'|'documents'|'researchHealth'|'familyMilestones'|'topBranches'|'familyOverview'|'genealogyHealth'|'ocrReview'|'backupStatus'|'anniversaries'|'lineageMix'|'sharing';

const WIDGETS: Array<{id: WidgetId; bn: string; en: string}> = [
  {id:'metrics',bn:'মূল পরিসংখ্যান',en:'Key Metrics'},
  {id:'alerts',bn:'সতর্কতা ও ডেটা সমস্যা',en:'Alerts & Data Health'},
  {id:'generations',bn:'প্রজন্ম বিন্যাস',en:'Generation Distribution'},
  {id:'demographics',bn:'লিঙ্গ ও জেলা',en:'Demographics & Districts'},
  {id:'upcoming',bn:'আসন্ন গুরুত্বপূর্ণ দিন',en:'Upcoming Dates'},
  {id:'completeness',bn:'তথ্য পূর্ণতার অবস্থা',en:'Profile Completeness'},
  {id:'branches',bn:'শাখা ও বংশধারা',en:'Branches & Lineages'},
  {id:'ageProfile',bn:'বয়স ও জীবনচিত্র',en:'Age & Life Profile'},
  {id:'recent',bn:'সাম্প্রতিক সদস্য',en:'Recent Members'},
  {id:'quickTools',bn:'দ্রুত কাজ',en:'Quick Tools'},
  {id:'marriageStatus',bn:'বিবাহের অবস্থা',en:'Marriage Status'},
  {id:'documents',bn:'দলিল ও আর্কাইভ',en:'Documents & Archive'},
  {id:'researchHealth',bn:'গবেষণা ও যাচাই',en:'Research & Verification'},
  {id:'familyMilestones',bn:'পারিবারিক মাইলস্টোন',en:'Family Milestones'},
  {id:'topBranches',bn:'শাখাভিত্তিক শীর্ষ সদস্য',en:'Branch Highlights'},
  {id:'familyOverview',bn:'পরিবারের সারসংক্ষেপ',en:'Family Overview'},
  {id:'genealogyHealth',bn:'বংশতথ্য স্বাস্থ্য',en:'Genealogy Health'},
  {id:'ocrReview',bn:'OCR যাচাই',en:'OCR Review'},
  {id:'backupStatus',bn:'ব্যাকআপ অবস্থা',en:'Backup Status'},
  {id:'anniversaries',bn:'বিবাহবার্ষিকী',en:'Marriage Anniversaries'},
  {id:'lineageMix',bn:'রক্তের বংশ ও বিবাহসূত্র',en:'Lineage & In-Marriage'},
  {id:'sharing',bn:'বংশ শেয়ার ও আমন্ত্রণ',en:'Family Sharing & Invites'}
];
const DEFAULT_ORDER = WIDGETS.map(w => w.id);

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate, onOpenAddMember, onOpenAddMarriage, onSelectMember }) => {
  const { family, members, marriages, branches, archiveRecords, generations, generationSummary, validationReport, language, updateFamily } = useGenealogy();
  const isBn = language === 'bn';
  const [showConfig, setShowConfig] = useState(false);
  const [summary, setSummary] = useState<{title:string; lines:string[]; memberId?:string; memberIds?:string[]}|null>(null);
  const settings = family.settings || {} as any;
  const enabled = useMemo(() => new Set<WidgetId>(settings.dashboardWidgets?.length ? settings.dashboardWidgets as WidgetId[] : DEFAULT_ORDER), [settings.dashboardWidgets]);
  const order = useMemo(() => {
    const saved = (settings.dashboardWidgetOrder || []) as WidgetId[];
    return [...saved, ...DEFAULT_ORDER.filter(id => !saved.includes(id))].filter(id => DEFAULT_ORDER.includes(id));
  }, [settings.dashboardWidgetOrder]);
  const layout = settings.dashboardLayout || 'comfortable';
  const dashboardAccent = settings.dashboardAccent || 'amber';
  const dashboardCardStyle = settings.dashboardCardStyle || 'elevated';
  const accentStyles: Record<string, {border:string; icon:string; bar:string; button:string; header:string}> = {
    amber: {border:'border-amber-900/10',icon:'text-amber-700',bar:'bg-amber-700',button:'bg-amber-700',header:'from-amber-100 via-yellow-50 to-orange-100'},
    blue: {border:'border-blue-900/10',icon:'text-blue-700',bar:'bg-blue-700',button:'bg-blue-700',header:'from-blue-100 via-sky-50 to-indigo-100'},
    green: {border:'border-emerald-900/10',icon:'text-emerald-700',bar:'bg-emerald-700',button:'bg-emerald-700',header:'from-emerald-100 via-teal-50 to-green-100'},
    violet: {border:'border-violet-900/10',icon:'text-violet-700',bar:'bg-violet-700',button:'bg-violet-700',header:'from-violet-100 via-purple-50 to-fuchsia-100'},
    slate: {border:'border-slate-500/20',icon:'text-slate-700',bar:'bg-slate-700',button:'bg-slate-700',header:'from-slate-100 via-gray-50 to-zinc-200'}
  };
  const accent = accentStyles[dashboardAccent] || accentStyles.amber;
  const dashboardGap = layout === 'compact' ? 'gap-3' : layout === 'wide' ? 'gap-7' : 'gap-5';

  const setDashboard = (patch: Partial<typeof settings>) => updateFamily({ settings: { ...settings, ...patch } });
  const toggle = (id: WidgetId) => setDashboard({ dashboardWidgets: enabled.has(id) ? Array.from(enabled).filter(x => x !== id) : [...Array.from(enabled), id] });
  const move = (id: WidgetId, direction: -1|1) => {
    const next = [...order]; const i = next.indexOf(id); const j = i + direction;
    if (i < 0 || j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    setDashboard({ dashboardWidgetOrder: next });
  };
  const resetDashboard = () => setDashboard({ dashboardWidgets: DEFAULT_ORDER, dashboardWidgetOrder: DEFAULT_ORDER, dashboardLayout: 'comfortable', dashboardAccent: 'amber', dashboardCardStyle: 'elevated' });

  // Build parent membership once. This avoids a nested members.some() scan for every
  // member, which becomes noticeably expensive for large multi-generation families.
  const memberMetrics = useMemo(() => {
    const knownIds = new Set(members.map(m => m.id));
    let living = 0, male = 0, female = 0, sons = 0, daughters = 0;
    let adopted = 0, multiMarriage = 0, missingIdentity = 0, missingBirth = 0, missingParents = 0;
    for (const member of members) {
      if (member.isLiving) living++;
      if (member.gender === 'male') male++;
      if (member.gender === 'female') female++;
      const hasKnownParent = Boolean((member.fatherId && knownIds.has(member.fatherId)) || (member.motherId && knownIds.has(member.motherId)));
      if (hasKnownParent && member.gender === 'male') sons++;
      if (hasKnownParent && member.gender === 'female') daughters++;
      if (Boolean((member as any).adoptiveFatherId || (member as any).adoptiveMotherId || (member as any).adoptionStatus === 'adopted')) adopted++;
      if ((member.marriageIds || []).length > 1) multiMarriage++;
      if (!member.identityDocs?.nidNumber && !member.identityDocs?.birthRegistrationNumber) missingIdentity++;
      if (!member.birth?.date?.year) missingBirth++;
      if ((generations.get(member.id) || 1) > 1 && !member.fatherId && !member.motherId) missingParents++;
    }
    const deceased = members.length - living;
    const completeness = members.length ? Math.max(0, Math.min(100, Math.round(((members.length * 3 - missingIdentity - missingBirth - missingParents) / (members.length * 3)) * 100))) : 100;
    return { living, deceased, male, female, sons, daughters, adopted, multiMarriage, missingIdentity, missingBirth, missingParents, completeness };
  }, [members, generations]);
  const { living, deceased, male, female, sons, daughters, adopted, multiMarriage, missingIdentity, missingBirth, missingParents, completeness } = memberMetrics;
  const districtCounts = useMemo(() => {
    const map: Record<string,number> = {}; members.forEach(m => { const d = m.birth?.place?.district || (isBn?'অনুল্লিখিত':'Unspecified'); map[d]=(map[d]||0)+1; });
    return Object.entries(map).sort((a,b)=>b[1]-a[1]).slice(0,6);
  }, [members,isBn]);
  const branchCounts = useMemo(() => branches.map(b => [b, members.filter(m=>m.branchId===b.id).length] as const).sort((a,b)=>b[1]-a[1]), [branches,members]);
  const ageBuckets = useMemo(() => {
    const labels = isBn ? ['০–১৭','১৮–৩৯','৪০–৫৯','৬০–৭৯','৮০+','অজানা'] : ['0–17','18–39','40–59','60–79','80+','Unknown'];
    const buckets = labels.map(label => [label, 0] as [string, number]);
    const yearNow = new Date().getFullYear();
    members.forEach(m => {
      const birthYear = Number(m.birth?.date?.year);
      if (!Number.isFinite(birthYear) || birthYear <= 0 || birthYear > yearNow) { buckets[5][1]++; return; }
      const endYear = m.isLiving ? yearNow : Number(m.death?.date?.year) || yearNow;
      const age = Math.max(0, endYear - birthYear);
      const index = age < 18 ? 0 : age < 40 ? 1 : age < 60 ? 2 : age < 80 ? 3 : 4;
      buckets[index][1]++;
    });
    return buckets;
  }, [members, isBn]);
  const upcoming = useMemo(() => {
    const now=new Date(); const items:Array<{id:string;name:string;kind:string;days:number;memberId:string}> = [];
    members.forEach(m=>{
      const y=now.getFullYear();
      if(m.isLiving && m.birth?.date?.month && m.birth?.date?.day){const d=new Date(y,m.birth.date.month-1,m.birth.date.day); const t=new Date(y,now.getMonth(),now.getDate()); if(d<t)d.setFullYear(y+1); const days=Math.ceil((d.getTime()-t.getTime())/86400000); if(days<=45)items.push({id:'b'+m.id,name:m.banglaName||m.fullName,kind:isBn?'জন্মদিন':'Birthday',days,memberId:m.id});}
      if(!m.isLiving && m.death?.date?.month && m.death?.date?.day){const d=new Date(y,m.death.date.month-1,m.death.date.day); const t=new Date(y,now.getMonth(),now.getDate()); if(d<t)d.setFullYear(y+1); const days=Math.ceil((d.getTime()-t.getTime())/86400000); if(days<=45)items.push({id:'d'+m.id,name:m.banglaName||m.fullName,kind:isBn?'স্মরণ দিবস':'Memorial',days,memberId:m.id});}
    }); return items.sort((a,b)=>a.days-b.days).slice(0,6);
  },[members,isBn]);
  const recent = useMemo(() => [...members].sort((a,b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || ''))).slice(0,6), [members]);
  const marriageStatus = useMemo(() => { const map: Record<string,number>={}; marriages.forEach(m=>{const k=m.status||'unknown';map[k]=(map[k]||0)+1}); return Object.entries(map).sort((a,b)=>b[1]-a[1]); },[marriages]);
  const documentCount = useMemo(()=>members.reduce((n,m)=>n+(m.memberDocuments?.length||0),0),[members]);
  const evidenceCount = useMemo(()=>members.reduce((n,m)=>n+(m.evidenceReferences?.length||0),0),[members]);
  const unverified = members.filter(m=>m.identityDocs?.verificationStatus && m.identityDocs.verificationStatus !== 'verified').length;
  const milestoneMembers = useMemo(() => members.filter(m => Number(m.birth?.date?.year) > 0).sort((a,b)=>(a.birth?.date?.year||9999)-(b.birth?.date?.year||9999)).slice(0,5), [members]);
  const branchHighlights = useMemo(()=>branchCounts.slice(0,5).map(([b,c])=>({branch:b,count:c,member:members.filter(m=>m.branchId===b.id).sort((a,z)=>(generations.get(z.id)||z.computedGeneration||0)-(generations.get(a.id)||a.computedGeneration||0))[0]})),[branchCounts,members]);
  const familyOverview = useMemo(() => ({ branches: branches.length, archive: archiveRecords.length, marriages: marriages.length, roots: members.filter(m => !m.fatherId && !m.motherId && (generations.get(m.id) || m.computedGeneration || 1) === 1).length }), [branches, archiveRecords, marriages, members, generations]);
  const ocrReviewCount = useMemo(() => {
    const pending = new Set<string>();
    archiveRecords.forEach(r => {
      const hasOcr = Boolean(r.ocrText || r.extractedFields);
      const status = r.ocrVerification || 'unverified';
      if (hasOcr && (status === 'unverified' || status === 'disputed')) pending.add(r.id);
    });
    members.forEach(m => (m.memberDocuments || []).forEach(d => {
      const hasOcr = Boolean(d.ocrText || d.extractedFields);
      const status = d.ocrVerification || 'unverified';
      if (hasOcr && (status === 'unverified' || status === 'disputed')) pending.add(d.archiveRecordId || `member-doc:${m.id}:${d.id}`);
    }));
    return pending.size;
  }, [members, archiveRecords]);
  const lineageMix = useMemo(() => ({ blood: members.filter(m=>m.birthOrigin==='born_in_family' && !m.marriageOrigin).length, inMarriage: members.filter(m=>m.birthOrigin==='joined_by_marriage' || m.marriageOrigin).length }),[members]);
  const backupCount = Array.isArray(family.backupHistory) ? family.backupHistory.length : 0;
  const anniversaryItems = useMemo(() => { const now=new Date(); const out:Array<{id:string;name:string;days:number;marriageId:string}> = []; marriages.forEach(m=>{ const month=m.marriageDate?.month, day=m.marriageDate?.day; if(!month||!day)return; const d=new Date(now.getFullYear(),month-1,day); const t=new Date(now.getFullYear(),now.getMonth(),now.getDate()); if(d<t)d.setFullYear(now.getFullYear()+1); const days=Math.ceil((d.getTime()-t.getTime())/86400000); if(days<=60){ const h=members.find(x=>x.id===m.husbandId), w=members.find(x=>x.id===m.wifeId); out.push({id:m.id,name:`${h?.banglaName||h?.fullName||'—'} × ${w?.banglaName||w?.fullName||'—'}`,days,marriageId:m.id}); }}); return out.sort((a,b)=>a.days-b.days).slice(0,6); },[marriages,members]);
  const openSummary = (title:string, lines:string[], memberId?:string, memberIds?:string[]) => setSummary({title,lines,memberId,memberIds});
  const ageBucketLabelForMember = (m: (typeof members)[number]): string => {
    const yearNow = new Date().getFullYear(); const birthYear = Number(m.birth?.date?.year);
    if (!Number.isFinite(birthYear) || birthYear <= 0 || birthYear > yearNow) return isBn ? 'অজানা' : 'Unknown';
    const endYear = m.isLiving ? yearNow : Number(m.death?.date?.year) || yearNow; const age = Math.max(0, endYear - birthYear);
    const index = age < 18 ? 0 : age < 40 ? 1 : age < 60 ? 2 : age < 80 ? 3 : 4;
    return ageBuckets[index]?.[0] || (isBn ? 'অজানা' : 'Unknown');
  };
  const metricMemberIds = (label: unknown): string[] => {
    const text = String(label);
    if (['মোট সদস্য','Members'].includes(text)) return members.map(m=>m.id);
    if (['জীবিত','Living'].includes(text)) return members.filter(m=>m.isLiving).map(m=>m.id);
    if (['প্রয়াত','প্রয়াত','Deceased'].includes(text)) return members.filter(m=>!m.isLiving).map(m=>m.id);
    if (['পুত্র','Sons'].includes(text)) return members.filter(m=>Boolean((m.fatherId && members.some(x=>x.id===m.fatherId)) || (m.motherId && members.some(x=>x.id===m.motherId))) && m.gender==='male').map(m=>m.id);
    if (['কন্যা','Daughters'].includes(text)) return members.filter(m=>Boolean((m.fatherId && members.some(x=>x.id===m.fatherId)) || (m.motherId && members.some(x=>x.id===m.motherId))) && m.gender==='female').map(m=>m.id);
    if (['একাধিক বিবাহ','Multiple marriages'].includes(text)) return members.filter(m=>(m.marriageIds||[]).length>1).map(m=>m.id);
    if (['দত্তক সন্তান','Adopted children'].includes(text)) return members.filter(m=>Boolean((m as any).adoptiveFatherId || (m as any).adoptiveMotherId || (m as any).adoptionStatus==='adopted')).map(m=>m.id);
    if (['বিবাহ','Marriages'].includes(text)) return Array.from(new Set(marriages.flatMap(m=>[m.husbandId,m.wifeId])));
    if (['প্রজন্ম','Generations'].includes(text)) return members.filter(m=>(generations.get(m.id)||m.computedGeneration||1)===generationSummary.maxGeneration).map(m=>m.id);
    return [];
  };

  const Widget = ({id, children, className='' }: {id:WidgetId;children:React.ReactNode;className?:string}) => enabled.has(id) ? <section className={`${dashboardCardStyle==='square'?'rounded-lg':'rounded-2xl'} border ${accent.border} bg-white p-5 ${dashboardCardStyle==='flat'?'shadow-none':dashboardCardStyle==='outlined'?'shadow-none':'shadow-sm'} dark:border-stone-800 dark:bg-stone-900 ${className}`} style={{order: order.indexOf(id)}}>{children}</section> : null;
  const title=(bn:string,en:string)=><div className="mb-4"><h3 className="font-serif text-base sm:text-lg font-bold text-slate-950 dark:text-slate-100">{isBn?bn:en}</h3></div>;
  const bar=(value:number,total:number)=> <div className="h-2.5 rounded-full bg-stone-100 dark:bg-stone-800 overflow-hidden"><div className={`h-full rounded-full ${accent.bar}`} style={{width:`${Math.min(100,Math.max(0,total?value/total*100:0))}%`}}/></div>;

  return <div className="space-y-6 pb-16">
    <header className={`relative overflow-hidden rounded-3xl border ${accent.border} bg-gradient-to-br ${accent.header} p-6 sm:p-8 shadow-sm dark:border-stone-800 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950`}>
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div><div className="inline-flex items-center gap-2 rounded-full border border-sky-900/20 bg-white/60 px-3 py-1 text-xs font-semibold text-sky-900 dark:border-sky-700/50 dark:bg-sky-950/60 dark:text-sky-300"><AwardIcon/><span>{isBn?'ঐতিহাসিক বংশধারা সংরক্ষণাগার':'Family Lineage Registry'}</span></div><h2 className="mt-2 font-serif text-2xl sm:text-3xl font-bold text-amber-950 dark:text-amber-100">{isBn?family.banglaName||family.name:family.name}</h2><p className="mt-1 text-xs sm:text-sm text-stone-700 dark:text-stone-300">{family.description || (isBn?'সম্পূর্ণ পারিবারিক ইতিহাস, সম্পর্ক ও প্রমাণপত্রের কেন্দ্রীয় ড্যাশবোর্ড।':'Central dashboard for lineage, relationships and evidence.')}</p></div>
        <div className="flex flex-wrap gap-2"><button onClick={onOpenAddMember} className="inline-flex items-center gap-2 rounded-xl bg-sky-800 px-4 py-2.5 text-xs font-bold text-white"><Plus className="w-4 h-4"/>{isBn?'নতুন সদস্য':'Add Member'}</button><button onClick={onOpenAddMarriage} className="inline-flex items-center gap-2 rounded-xl border bg-white/80 px-4 py-2.5 text-xs font-bold text-amber-950 dark:bg-stone-800 dark:text-amber-200"><Heart className="w-4 h-4"/>{isBn?'বিবাহ':'Marriage'}</button><button onClick={()=>setShowConfig(v=>!v)} className="inline-flex items-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-bold"><Settings2 className="w-4 h-4"/>{isBn?'সাজসজ্জা':'Customize'}</button></div>
      </div>
    </header>

    {showConfig && <div className="rounded-2xl border border-amber-900/15 bg-white p-4 dark:border-stone-800 dark:bg-stone-900"><div className="flex items-center justify-between mb-3"><div><b className="text-sm">{isBn?'ড্যাশবোর্ড উইজেট সাজসজ্জা':'Dashboard Widget Layout'}</b><p className="text-[11px] text-stone-500">{isBn?'দৃশ্যমানতা, ক্রম ও ঘনত্ব সংরক্ষণ করুন।':'Visibility, order and density are saved per family.'}</p></div><button onClick={resetDashboard} className="inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-[11px] font-bold"><RotateCcw className="w-3 h-3"/>{isBn?'ডিফল্ট':'Reset'}</button></div><div className="grid grid-cols-1 md:grid-cols-2 gap-2">{order.map((id,i)=>{const w=WIDGETS.find(x=>x.id===id)!;return <div key={id} className="flex items-center gap-2 rounded-xl border p-2"><button onClick={()=>toggle(id)} className="p-1" title="visibility">{enabled.has(id)?<Eye className="w-4 h-4 text-emerald-600"/>:<EyeOff className="w-4 h-4 text-stone-400"/>}</button><span className="flex-1 text-xs font-semibold">{isBn?w.bn:w.en}</span><button disabled={i===0} onClick={()=>move(id,-1)} className="p-1 disabled:opacity-20"><ChevronUp className="w-4 h-4"/></button><button disabled={i===order.length-1} onClick={()=>move(id,1)} className="p-1 disabled:opacity-20"><ChevronDown className="w-4 h-4"/></button></div>})}</div><div className="mt-3 flex flex-wrap items-center gap-2"><span className="text-[11px] font-bold self-center">{isBn?'ঘনত্ব:':'Density:'}</span>{(['comfortable','compact','wide'] as const).map(x=><button key={x} onClick={()=>setDashboard({dashboardLayout:x})} className={`px-3 py-1.5 rounded-lg text-[11px] font-bold ${layout===x?`${accent.button} text-white`:'bg-stone-100 dark:bg-stone-800'}`}>{isBn?(x==='comfortable'?'আরামদায়ক':x==='compact'?'কমপ্যাক্ট':'প্রশস্ত'):x}</button>)}</div><div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4"><div><b className="block text-xs mb-2">{isBn?'রঙের থিম':'Accent color'}</b><div className="flex flex-wrap gap-2">{([{id:'amber',label:'সোনালি',en:'Amber',cls:'bg-amber-600'},{id:'blue',label:'নীল',en:'Blue',cls:'bg-blue-600'},{id:'green',label:'সবুজ',en:'Green',cls:'bg-emerald-600'},{id:'violet',label:'বেগুনি',en:'Violet',cls:'bg-violet-600'},{id:'slate',label:'ধূসর',en:'Slate',cls:'bg-slate-600'}] as const).map(c=><button type="button" key={c.id} onClick={()=>setDashboard({dashboardAccent:c.id})} aria-pressed={dashboardAccent===c.id} className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] ${dashboardAccent===c.id?'ring-2 ring-offset-1 ring-sky-500':'opacity-80'}`}><span className={`h-3 w-3 rounded-full ${c.cls}`}/>{isBn?c.label:c.en}</button>)}</div></div><div><b className="block text-xs mb-2">{isBn?'কার্ডের ধরন':'Card style'}</b><div className="flex flex-wrap gap-2">{([{id:'elevated',bn:'ছায়াযুক্ত',en:'Elevated'},{id:'outlined',bn:'সাধারণ বর্ডার',en:'Outlined'},{id:'flat',bn:'সমতল',en:'Flat'},{id:'square',bn:'কম গোলাকার',en:'Square'}] as const).map(c=><button type="button" key={c.id} onClick={()=>setDashboard({dashboardCardStyle:c.id})} aria-pressed={dashboardCardStyle===c.id} className={`rounded-lg border px-2.5 py-1.5 text-[11px] ${dashboardCardStyle===c.id?`${accent.button} text-white`:'bg-stone-100 dark:bg-stone-800'}`}>{isBn?c.bn:c.en}</button>)}</div></div></div></div>}

    <div className={`grid grid-cols-1 lg:grid-cols-12 ${dashboardGap}`} style={{gridAutoFlow:'row'}}>
      <Widget id="alerts" className="lg:col-span-12">{title('সতর্কতা ও ডেটা স্বাস্থ্য','Alerts & Data Health')}<div className="grid md:grid-cols-3 gap-3"><button type="button" onClick={()=>onNavigate('admin')} className={`rounded-xl p-3 border text-left hover:shadow-sm ${validationReport.isValid?'border-emerald-200 bg-emerald-50':'border-rose-200 bg-rose-50'}`}><ShieldCheck className="w-4 h-4 mb-1"/><b className="text-xs">{validationReport.isValid?(isBn?'সম্পর্কের শুদ্ধতা ঠিক আছে':'Relationship graph healthy'):(isBn?`${toBanglaDigits(validationReport.issues.length)}টি সমস্যা`:`${validationReport.issues.length} issues`)}</b><p className="text-[10px] text-stone-500 mt-1">{isBn?'বিস্তারিত পরীক্ষা ও নিরাপদ মেরামত খুলুন':'Open diagnostics and safe repair'}</p></button><div className="rounded-xl p-3 border border-amber-200 bg-amber-50"><FileQuestion className="w-4 h-4 mb-1"/><b className="text-xs">{isBn?`${toBanglaDigits(missingIdentity)} জনের পরিচয়পত্র নেই`:`${missingIdentity} missing identity docs`}</b></div><div className="rounded-xl p-3 border border-sky-200 bg-sky-50"><GitFork className="w-4 h-4 mb-1"/><b className="text-xs">{isBn?`${toBanglaDigits(missingParents)} জনের পিতামাতা অসম্পূর্ণ`:`${missingParents} missing parents`}</b></div></div></Widget>

      <Widget id="metrics" className="lg:col-span-12"><div className="grid grid-cols-2 md:grid-cols-5 gap-3">{[[Users,isBn?'মোট সদস্য':'Members',members.length,`${living} ${isBn?'জন জীবিত':'living'}, ${deceased} ${isBn?'জন প্রয়াত':'deceased'}`],[UserCheck,isBn?'জীবিত':'Living',living,`${male} ${isBn?'পুরুষ':'male'}, ${female} ${isBn?'নারী':'female'}`],[Flower2,isBn?'প্রয়াত':'Deceased',deceased,isBn?'মৃত সদস্যদের সংক্ষিপ্ত তালিকা':'Deceased members'],[Layers,isBn?'প্রজন্ম':'Generations',generationSummary.maxGeneration,isBn?'সর্বোচ্চ প্রজন্ম':'Maximum generation'],[Heart,isBn?'বিবাহ':'Marriages',marriages.length,isBn?`${marriages.filter(m=>m.status==='current').length}টি চলমান`:`${marriages.filter(m=>m.status==='current').length} current`],[UserCheck,isBn?'পুত্র':'Sons',sons,isBn?'সদস্য সম্পর্ক থেকে নির্ণয়':'Derived from parent links'],[UserCheck,isBn?'কন্যা':'Daughters',daughters,isBn?'সদস্য সম্পর্ক থেকে নির্ণয়':'Derived from parent links'],[Heart,isBn?'একাধিক বিবাহ':'Multiple marriages',multiMarriage,isBn?'একাধিক বিবাহের রেকর্ড আছে':'Members with more than one marriage'],[UserCheck,isBn?'দত্তক সন্তান':'Adopted children',adopted,isBn?'দত্তক সম্পর্কের চিহ্নিত সদস্য':'Members marked with adoption links']].map(([Icon,label,value,detail]:any)=><button type="button" key={label} onClick={()=>openSummary(String(label),[`${detail}`,isBn?`মোট সংখ্যা: ${toBanglaDigits(value)}`:`Total: ${value}`],undefined,metricMemberIds(label))} className="rounded-xl border p-4 text-left hover:bg-amber-50 dark:hover:bg-stone-800 transition"><Icon className="w-4 h-4 text-amber-700 mb-2"/><div className="text-[11px] text-stone-500">{label}</div><div className="text-2xl font-serif font-bold">{isBn?toBanglaDigits(value):value}</div><div className="text-[10px] text-stone-400 mt-1">{detail}</div></button>)}</div></Widget>

      <Widget id="generations" className="lg:col-span-7">{title('প্রজন্মভিত্তিক সদস্য বিন্যাস','Generation Distribution')}<div className="space-y-3">{Array.from({length:generationSummary.maxGeneration},(_,i)=>i+1).map(gen=>{const count=generationSummary.generationDistribution[gen]||0;return <button type="button" key={gen} onClick={()=>openSummary(isBn?`${toBanglaDigits(gen)}ম প্রজন্ম`:`Generation ${gen}`,[isBn?`মোট সদস্য: ${toBanglaDigits(count)} জন`:`Members: ${count}`,isBn?'এই প্রজন্মের সদস্যদের তালিকা নিচে':'Members in this generation are listed below'],undefined,members.filter(m=>(generations.get(m.id)||m.computedGeneration||1)===gen).map(m=>m.id))} className="w-full text-left rounded-xl p-2 hover:bg-amber-50 dark:hover:bg-stone-800"><div className="flex justify-between text-xs mb-1"><span className="font-semibold">{isBn?`${toBanglaDigits(gen)}ম প্রজন্ম`:`Generation ${gen}`}</span><span>{isBn?`${toBanglaDigits(count)} জন`:`${count}`}</span></div>{bar(count,members.length)}</button>})}</div></Widget>

      <Widget id="demographics" className="lg:col-span-5">{title('লিঙ্গ ও জন্মস্থান','Demographics & Districts')}<div className="space-y-3"><div className="flex justify-between text-xs"><span>♂ {isBn?toBanglaDigits(male):male}</span><span>♀ {isBn?toBanglaDigits(female):female}</span></div>{bar(male,members.length)}<div className="pt-3 border-t space-y-2">{districtCounts.map(([d,c])=><button type="button" key={d} onClick={()=>openSummary(d,[isBn?`সদস্য: ${toBanglaDigits(c)} জন`:`Members: ${c}`,isBn?'জন্মস্থানভিত্তিক সদস্য তালিকা':'Members grouped by birthplace'],undefined,members.filter(m=>(m.birth?.place?.district||(isBn?'অনুল্লিখিত':'Unspecified'))===d).map(m=>m.id))} className="w-full flex justify-between text-xs rounded-lg p-1.5 hover:bg-amber-50"><span className="flex items-center gap-1"><MapPin className="w-3 h-3"/>{d}</span><b>{isBn?toBanglaDigits(c):c}</b></button>)}</div></div></Widget>

      <Widget id="upcoming" className="lg:col-span-5">{title('আসন্ন গুরুত্বপূর্ণ দিন','Upcoming Dates')}<div className="space-y-2">{upcoming.length?upcoming.map(x=><button key={x.id} onClick={()=>onSelectMember(x.memberId)} className="w-full flex items-center justify-between rounded-xl border p-2.5 text-left hover:bg-amber-50"><span className="flex items-center gap-2 text-xs font-semibold"><Cake className="w-4 h-4 text-amber-700"/>{x.name}</span><span className="text-[10px] font-bold text-stone-500">{x.days===0?(isBn?'আজ':'Today'):`${x.days}${isBn?' দিন':'d'}`}</span></button>):<p className="text-xs text-stone-400">{isBn?'আগামী ৪৫ দিনে নেই':'No upcoming events in 45 days.'}</p>}</div></Widget>

      <Widget id="completeness" className="lg:col-span-7">{title('সদস্য তথ্যের পূর্ণতা','Profile Completeness')}<button type="button" onClick={()=>openSummary(isBn?'সদস্য তথ্যের পূর্ণতা':'Profile Completeness',[isBn?`পূর্ণতা: ${toBanglaDigits(completeness)}%`:`Completeness: ${completeness}%`,isBn?`জন্মের তথ্য ঘাটতি: ${toBanglaDigits(missingBirth)}`:`Birth gaps: ${missingBirth}`,isBn?`পরিচয়পত্র ঘাটতি: ${toBanglaDigits(missingIdentity)}`:`Identity gaps: ${missingIdentity}`,isBn?`পিতামাতার তথ্য ঘাটতি: ${toBanglaDigits(missingParents)}`:`Parent gaps: ${missingParents}`],undefined,members.filter(m=>!m.birth?.date?.year || (!m.identityDocs?.nidNumber&&!m.identityDocs?.birthRegistrationNumber) || ((generations.get(m.id)||1)>1&&!m.fatherId&&!m.motherId)).map(m=>m.id))} className="w-full flex items-center gap-5 text-left rounded-xl p-2 hover:bg-amber-50"><div className="text-4xl font-serif font-bold text-amber-800">{isBn?toBanglaDigits(completeness):completeness}%</div><div className="flex-1"><div className="h-4 rounded-full bg-stone-100 overflow-hidden"><div className="h-full rounded-full bg-emerald-600" style={{width:`${completeness}%`}}/></div><p className="text-[11px] text-stone-500 mt-2">{isBn?`জন্ম ${toBanglaDigits(missingBirth)}টি, পরিচয় ${toBanglaDigits(missingIdentity)}টি, পিতামাতা ${toBanglaDigits(missingParents)}টি ঘাটতি`:`Birth ${missingBirth}, identity ${missingIdentity}, parents ${missingParents} gaps`}</p></div></button></Widget>

      <Widget id="branches" className="lg:col-span-6">{title('শাখা ও বংশধারা','Branches & Lineages')}<div className="space-y-2">{branchCounts.map(([b,c])=><button type="button" key={b.id} onClick={()=>openSummary(isBn?b.banglaName||b.name:b.name,[isBn?`সদস্য: ${toBanglaDigits(c)} জন`:`Members: ${c}`,isBn?'এই শাখার সদস্য তালিকা':'Members in this branch'],undefined,members.filter(m=>m.branchId===b.id).map(m=>m.id))} className="w-full flex items-center gap-2 rounded-xl p-2 text-left hover:bg-amber-50"><span className="w-2.5 h-2.5 rounded-full" style={{backgroundColor:b.color}}/><span className="flex-1 text-xs font-semibold">{isBn?b.banglaName||b.name:b.name}</span><span className="text-xs font-mono">{c}</span></button>)}</div></Widget>

      <Widget id="ageProfile" className="lg:col-span-6">{title('বয়স ও জীবনচিত্র','Age & Life Profile')}<div className="space-y-2">{ageBuckets.map(([label,count])=><button type="button" key={label} onClick={()=>openSummary(isBn?`বয়স ${label}`:`Age ${label}`,[isBn?`সদস্য: ${toBanglaDigits(count)} জন`:`Members: ${count}`,isBn?'এই বয়স-শ্রেণির সদস্য তালিকা':'Members in this age group'],undefined,members.filter(m=>ageBucketLabelForMember(m)===label).map(m=>m.id))} className="w-full flex items-center gap-2 text-xs rounded-lg p-1.5 text-left hover:bg-amber-50"><span className="w-14">{label}</span><div className="flex-1">{bar(count,members.length)}</div><b>{count}</b></button>)}</div></Widget>

      <Widget id="recent" className="lg:col-span-7">{title('সাম্প্রতিক সদস্য পরিবর্তন','Recently Updated Members')}<div className="grid sm:grid-cols-2 gap-2">{recent.map(m=><button key={m.id} onClick={()=>onSelectMember(m.id)} className="rounded-xl border p-3 text-left hover:bg-amber-50"><div className="font-semibold text-xs truncate">{isBn?m.banglaName||m.fullName:m.englishName||m.fullName}</div><div className="text-[10px] text-stone-500">{isBn?`প্রজন্ম ${toBanglaDigits(generations.get(m.id)||1)}`:`Generation ${generations.get(m.id)||1}`}</div></button>)}</div></Widget>

      <Widget id="marriageStatus" className="lg:col-span-5">{title('বিবাহের অবস্থা','Marriage Status')}<div className="space-y-2">{marriageStatus.map(([status,count])=><button key={status} type="button" onClick={()=>openSummary(isBn?'বিবাহের অবস্থা':'Marriage Status',[`${status}: ${count}`,isBn?`মোট বিবাহ: ${toBanglaDigits(marriages.length)}`:`Total marriages: ${marriages.length}`],undefined,Array.from(new Set(marriages.filter(m=>(m.status||'unknown')===status).flatMap(m=>[m.husbandId,m.wifeId]))))} className="w-full flex justify-between rounded-xl border p-2.5 text-xs hover:bg-amber-50"><span>{status}</span><b>{isBn?toBanglaDigits(count):count}</b></button>)}</div></Widget>
      <Widget id="documents" className="lg:col-span-4">{title('দলিল ও আর্কাইভ','Documents & Archive')}<div className="space-y-2"><button type="button" onClick={()=>onNavigate('archive')} className="w-full flex justify-between rounded-xl border p-3 text-xs hover:bg-amber-50"><span>{isBn?'সদস্যের দলিল':'Member documents'}</span><b>{isBn?toBanglaDigits(documentCount):documentCount}</b></button><button type="button" onClick={()=>onNavigate('archive')} className="w-full flex justify-between rounded-xl border p-3 text-xs hover:bg-amber-50"><span>{isBn?'আর্কাইভ খুলুন':'Open archive'}</span><Archive className="w-4 h-4"/></button></div></Widget>
      <Widget id="researchHealth" className="lg:col-span-3">{title('গবেষণা ও যাচাই','Research & Verification')}<div className="space-y-2"><button type="button" onClick={()=>openSummary(isBn?'গবেষণা ও যাচাই':'Research & Verification',[isBn?`প্রমাণ/Source: ${toBanglaDigits(evidenceCount)}`:`Evidence references: ${evidenceCount}`,isBn?`যাচাই বাকি: ${toBanglaDigits(unverified)}`:`Not fully verified: ${unverified}`],undefined,members.filter(m=>(m.evidenceReferences||[]).length>0 || Boolean(m.identityDocs?.verificationStatus && m.identityDocs.verificationStatus!=='verified')).map(m=>m.id))} className="w-full rounded-xl border p-3 text-left text-xs hover:bg-amber-50"><div>{isBn?'প্রমাণসূত্র':'Evidence references'}</div><b className="text-xl">{isBn?toBanglaDigits(evidenceCount):evidenceCount}</b><div className="text-[10px] text-stone-500">{isBn?`${toBanglaDigits(unverified)} জনের যাচাই বাকি`:`${unverified} need verification`}</div></button></div></Widget>
      <Widget id="familyMilestones" className="lg:col-span-7">{title('পারিবারিক মাইলস্টোন','Family Milestones')}<div className="grid sm:grid-cols-2 gap-2">{milestoneMembers.map(m=><button key={m.id} type="button" onClick={()=>{onSelectMember(m.id);openSummary(isBn?'সদস্য':'Member',[m.banglaName||m.fullName,isBn?`জন্মসন: ${toBanglaDigits(m.birth?.date?.year||0)}`:`Birth year: ${m.birth?.date?.year||'—'}`],m.id)}} className="rounded-xl border p-3 text-left hover:bg-amber-50"><div className="text-xs font-semibold">{isBn?m.banglaName||m.fullName:m.englishName||m.fullName}</div><div className="text-[10px] text-stone-500">{isBn?`জন্ম ${toBanglaDigits(m.birth?.date?.year||0)}`:`Born ${m.birth?.date?.year||'—'}`}</div></button>)}</div></Widget>
      <Widget id="topBranches" className="lg:col-span-5">{title('শাখাভিত্তিক শীর্ষ সদস্য','Branch Highlights')}<div className="space-y-2">{branchHighlights.map(x=><button key={x.branch.id} type="button" onClick={()=>openSummary(isBn?x.branch.banglaName||x.branch.name:x.branch.name,[isBn?`সদস্য: ${toBanglaDigits(x.count)} জন`:`Members: ${x.count}`,isBn?'শাখার সদস্যদের তালিকা':'Members in this branch'],undefined,members.filter(m=>m.branchId===x.branch.id).map(m=>m.id))} className="w-full flex items-center gap-2 rounded-xl border p-2.5 text-left hover:bg-amber-50"><span className="w-2.5 h-2.5 rounded-full" style={{backgroundColor:x.branch.color}}/><span className="flex-1 text-xs font-semibold">{isBn?x.branch.banglaName||x.branch.name:x.branch.name}</span><b className="text-xs">{x.count}</b></button>)}</div></Widget>
      <Widget id="familyOverview" className="lg:col-span-7">{title('পরিবারের সারসংক্ষেপ','Family Overview')}<div className="grid grid-cols-2 sm:grid-cols-4 gap-2"><button type="button" onClick={()=>openSummary(isBn?'সকল সদস্য':'All Members',[isBn?`মোট সদস্য: ${toBanglaDigits(members.length)} জন`:`Total members: ${members.length}`],undefined,members.map(m=>m.id))} className="rounded-xl border p-3 text-left hover:bg-amber-50"><Users className="w-4 h-4 text-amber-700 mb-1"/><div className="text-[10px] text-stone-500">{isBn?'সদস্য':'Members'}</div><b className="text-lg">{isBn?toBanglaDigits(members.length):members.length}</b></button><button type="button" onClick={()=>openSummary(isBn?'মূল প্রজন্ম':'Root Generation',[isBn?`মূল সদস্য: ${toBanglaDigits(familyOverview.roots)} জন`:`Root members: ${familyOverview.roots}`],undefined,members.filter(m=>!m.fatherId&&!m.motherId).map(m=>m.id))} className="rounded-xl border p-3 text-left hover:bg-amber-50"><GitFork className="w-4 h-4 text-emerald-700 mb-1"/><div className="text-[10px] text-stone-500">{isBn?'মূল প্রজন্ম':'Root Generation'}</div><b className="text-lg">{isBn?toBanglaDigits(familyOverview.roots):familyOverview.roots}</b></button><button type="button" onClick={()=>onNavigate('archive')} className="rounded-xl border p-3 text-left hover:bg-amber-50"><Archive className="w-4 h-4 text-sky-700 mb-1"/><div className="text-[10px] text-stone-500">{isBn?'আর্কাইভ রেকর্ড':'Archive Records'}</div><b className="text-lg">{isBn?toBanglaDigits(familyOverview.archive):familyOverview.archive}</b></button><button type="button" onClick={()=>openSummary(isBn?'বিবাহের সদস্য':'Marriage Members',[isBn?`মোট বিবাহ: ${toBanglaDigits(familyOverview.marriages)}`:`Total marriages: ${familyOverview.marriages}`],undefined,Array.from(new Set(marriages.flatMap(m=>[m.husbandId,m.wifeId]))))} className="rounded-xl border p-3 text-left hover:bg-amber-50"><Heart className="w-4 h-4 text-rose-700 mb-1"/><div className="text-[10px] text-stone-500">{isBn?'বিবাহ':'Marriages'}</div><b className="text-lg">{isBn?toBanglaDigits(familyOverview.marriages):familyOverview.marriages}</b></button></div><div className="mt-3 rounded-xl bg-stone-50 dark:bg-stone-800/60 p-3 text-xs text-stone-600 dark:text-stone-300"><div className="flex items-center gap-2 font-semibold"><Home className="w-4 h-4"/>{isBn?'সক্রিয় পরিবার: ':'Active family: '}{isBn?family.banglaName||family.name:family.name}</div><p className="mt-1 text-[10px]">{family.description || (isBn?'পরিবারের সদস্য, প্রজন্ম, বিবাহ ও মহাফেজখানার সমন্বিত সারসংক্ষেপ।':'Unified summary of members, generations, marriages and the family archive.')}</p></div></Widget>

      <Widget id="genealogyHealth" className="lg:col-span-7">{title('বংশতথ্য স্বাস্থ্য','Genealogy Health')}<div className="grid grid-cols-2 md:grid-cols-4 gap-2"><button type="button" onClick={()=>onNavigate('members')} className="rounded-xl border p-3 text-left"><Database className="w-4 h-4 mb-1"/><div className="text-[10px] text-stone-500">{isBn?'মূল বংশ সদস্য':'Birth-line members'}</div><b className="text-lg">{isBn?toBanglaDigits(lineageMix.blood):lineageMix.blood}</b></button><button type="button" onClick={()=>onNavigate('members')} className="rounded-xl border p-3 text-left"><Heart className="w-4 h-4 mb-1"/><div className="text-[10px] text-stone-500">{isBn?'বিবাহসূত্রে':'In-marriage'}</div><b className="text-lg">{isBn?toBanglaDigits(lineageMix.inMarriage):lineageMix.inMarriage}</b></button><button type="button" onClick={()=>onNavigate('members')} className="rounded-xl border p-3 text-left"><UserCheck className="w-4 h-4 mb-1"/><div className="text-[10px] text-stone-500">{isBn?'পিতামাতা পূর্ণ':'Parent-complete'}</div><b className="text-lg">{isBn?toBanglaDigits(members.length-missingParents):members.length-missingParents}</b></button><button type="button" onClick={()=>onNavigate('archive')} className="rounded-xl border p-3 text-left"><FileText className="w-4 h-4 mb-1"/><div className="text-[10px] text-stone-500">{isBn?'আর্কাইভ':'Archive'}</div><b className="text-lg">{isBn?toBanglaDigits(archiveRecords.length):archiveRecords.length}</b></button></div></Widget>
      <Widget id="ocrReview" className="lg:col-span-5">{title('OCR যাচাই','OCR Review')}<button type="button" onClick={()=>onNavigate('archive')} className="w-full rounded-xl border p-4 text-left hover:bg-amber-50"><ScanText className="w-5 h-5 mb-2 text-amber-700"/><b className="text-2xl">{isBn?toBanglaDigits(ocrReviewCount):ocrReviewCount}</b><div className="text-xs text-stone-500">{isBn?'ডকুমেন্টের OCR ফল যাচাই বাকি':'OCR results awaiting review'}</div></button></Widget>
      <Widget id="backupStatus" className="lg:col-span-4">{title('ব্যাকআপ অবস্থা','Backup Status')}<button type="button" onClick={()=>onNavigate('archive')} className="w-full rounded-xl border p-4 text-left hover:bg-amber-50"><HardDrive className="w-5 h-5 mb-2 text-sky-700"/><b className="text-lg">{isBn?`${toBanglaDigits(backupCount)}টি রেকর্ড`:`${backupCount} backup record(s)`}</b><div className="text-[10px] text-stone-500 mt-1">{isBn?(family.settings?.syncStatus||'স্থানীয় সংরক্ষণ'):(family.settings?.syncStatus||'Local storage')}</div></button></Widget>
      <Widget id="anniversaries" className="lg:col-span-4">{title('আসন্ন বিবাহবার্ষিকী','Marriage Anniversaries')}<div className="space-y-2">{anniversaryItems.length?anniversaryItems.map(x=><button key={x.id} type="button" onClick={()=>onNavigate('marriages')} className="w-full rounded-xl border p-2.5 text-left flex justify-between text-xs"><span className="flex items-center gap-2"><CalendarDays className="w-4 h-4 text-rose-700"/>{x.name}</span><b>{x.days===0?(isBn?'আজ':'Today'):`${x.days}${isBn?' দিন':'d'}`}</b></button>):<p className="text-xs text-stone-400">{isBn?'আগামী ৬০ দিনে নেই':'None in next 60 days.'}</p>}</div></Widget>
      <Widget id="lineageMix" className="lg:col-span-4">{title('বংশের ধরন','Lineage & In-Marriage')}<div className="space-y-2 text-xs"><div className="flex justify-between"><span>{isBn?'জন্মসূত্রে বংশ':'Birth-line'}</span><b>{isBn?toBanglaDigits(lineageMix.blood):lineageMix.blood}</b></div>{bar(lineageMix.blood,members.length)}<div className="flex justify-between"><span>{isBn?'বিবাহসূত্রে যুক্ত':'Joined by marriage'}</span><b>{isBn?toBanglaDigits(lineageMix.inMarriage):lineageMix.inMarriage}</b></div>{bar(lineageMix.inMarriage,members.length)}</div></Widget>
      <Widget id="sharing" className="lg:col-span-4">{title('বংশ শেয়ার ও আমন্ত্রণ','Family Sharing & Invites')}<div className="space-y-3"><p className="text-xs text-stone-500">{isBn?'বংশের সংক্ষিপ্ত পরিচিতি শেয়ার করুন অথবা Admin Center থেকে নিরাপদ Join Code/QR তৈরি করুন।':'Share a short family introduction, or create a join code/QR from Admin Center.'}</p><button type="button" onClick={()=>onNavigate('share')} className="w-full rounded-xl border p-3 text-left hover:bg-indigo-50 dark:hover:bg-stone-800"><Share2 className="w-4 h-4 mb-1 text-indigo-700"/><b className="text-xs">{isBn?'বংশতালিকা শেয়ার':'Share family tree'}</b><span className="block text-[10px] text-stone-500 mt-1">{isBn?'পরিচিতির লেখা কপি ও শেয়ার করুন':'Copy and share a family introduction'}</span></button><button type="button" onClick={()=>onNavigate('admin')} className="w-full rounded-xl border p-3 text-left hover:bg-amber-50 dark:hover:bg-stone-800"><Users className="w-4 h-4 mb-1 text-amber-700"/><b className="text-xs">{isBn?'পারিবারিক আমন্ত্রণ ও অনুমতি':'Family invites & permissions'}</b><span className="block text-[10px] text-stone-500 mt-1">{isBn?'Admin Center → Share':'Admin Center → Share'}</span></button><p className="text-[10px] text-amber-800 dark:text-amber-300">{isBn?'গোপনীয়তা: Join Code শেয়ার করার আগে প্রাপক ও ডেটা প্যাকেজ যাচাই করুন।':'Privacy: verify recipients and exported data before sharing an invite/package.'}</p></div></Widget>

      <Widget id="quickTools" className="lg:col-span-5">{title('দ্রুত কাজ','Quick Actions')}<div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        <button type="button" onClick={onOpenAddMember} className="rounded-xl border p-3 text-xs font-bold hover:border-amber-500 hover:bg-amber-50 dark:hover:bg-stone-800"><Plus className="w-4 h-4 mx-auto mb-1 text-amber-700"/>{isBn?'নতুন সদস্য':'Add Member'}</button>
        <button type="button" onClick={onOpenAddMarriage} className="rounded-xl border p-3 text-xs font-bold hover:border-rose-400 hover:bg-rose-50 dark:hover:bg-stone-800"><Heart className="w-4 h-4 mx-auto mb-1 text-rose-700"/>{isBn?'বিবাহ যোগ':'Add Marriage'}</button>
        <button type="button" onClick={()=>onNavigate('members')} className="rounded-xl border p-3 text-xs font-bold hover:bg-amber-50 dark:hover:bg-stone-800"><Users className="w-4 h-4 mx-auto mb-1"/>{isBn?'সদস্য তালিকা':'Members'}</button>
        <button type="button" onClick={()=>onNavigate('tree')} className="rounded-xl border p-3 text-xs font-bold hover:bg-amber-50 dark:hover:bg-stone-800"><GitFork className="w-4 h-4 mx-auto mb-1"/>{isBn?'বংশবৃক্ষ':'Family Tree'}</button>
        <button type="button" onClick={()=>onNavigate('relations')} className="rounded-xl border p-3 text-xs font-bold hover:bg-amber-50 dark:hover:bg-stone-800"><Compass className="w-4 h-4 mx-auto mb-1"/>{isBn?'আত্মীয়তা খুঁজুন':'Find Relation'}</button>
        <button type="button" onClick={()=>onNavigate('archive')} className="rounded-xl border p-3 text-xs font-bold hover:bg-amber-50 dark:hover:bg-stone-800"><Archive className="w-4 h-4 mx-auto mb-1"/>{isBn?'পারিবারিক আর্কাইভ':'Family Archive'}</button>
        <button type="button" onClick={()=>onNavigate('import-export')} className="rounded-xl border p-3 text-xs font-bold hover:bg-amber-50 dark:hover:bg-stone-800"><FileText className="w-4 h-4 mx-auto mb-1"/>{isBn?'আমদানি / রপ্তানি':'Import / Export'}</button>
        <button type="button" onClick={()=>onNavigate('calendar')} className="rounded-xl border p-3 text-xs font-bold hover:bg-amber-50 dark:hover:bg-stone-800"><CalendarDays className="w-4 h-4 mx-auto mb-1"/>{isBn?'পারিবারিক বর্ষপঞ্জি':'Family Calendar'}</button>
        <button type="button" onClick={()=>onNavigate('map')} className="rounded-xl border p-3 text-xs font-bold hover:bg-sky-50 dark:hover:bg-stone-800"><MapPin className="w-4 h-4 mx-auto mb-1 text-sky-700"/>{isBn?'পারিবারিক মানচিত্র':'Family Map'}</button>
        <button type="button" onClick={()=>onNavigate('share')} className="rounded-xl border p-3 text-xs font-bold hover:bg-indigo-50 dark:hover:bg-stone-800"><Share2 className="w-4 h-4 mx-auto mb-1 text-indigo-700"/>{isBn?'বংশ শেয়ার':'Family Sharing'}</button>
        <button type="button" onClick={()=>onNavigate('settings')} className="rounded-xl border p-3 text-xs font-bold hover:bg-amber-50 dark:hover:bg-stone-800"><Settings2 className="w-4 h-4 mx-auto mb-1"/>{isBn?'সেটিংস':'Settings'}</button>
      </div></Widget>
    </div>
    {summary && <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/40 p-4" onClick={()=>setSummary(null)}><div className="w-full max-w-md rounded-2xl bg-white dark:bg-stone-900 border border-amber-900/15 p-5 shadow-2xl" onClick={e=>e.stopPropagation()}><div className="flex items-center justify-between mb-3"><h3 className="font-serif text-lg font-bold text-amber-950 dark:text-amber-100">{summary.title}</h3><button type="button" onClick={()=>setSummary(null)} className="rounded-lg border px-2 py-1 text-xs">×</button></div><div className="space-y-2 max-h-[65vh] overflow-y-auto">{summary.lines.map((line,i)=><div key={i} className="rounded-xl bg-stone-50 dark:bg-stone-800 p-3 text-sm">{line}</div>)}{(summary.memberIds||[]).length>0 && <div className="pt-2"><div className="text-xs font-bold text-stone-500 mb-2">{isBn?`সম্পর্কিত সদস্য (${toBanglaDigits(summary.memberIds!.length)} জন)`:`Related members (${summary.memberIds!.length})`}</div>{summary.memberIds!.map(id=>members.find(m=>m.id===id)).filter(Boolean).map(m=><button key={m!.id} type="button" onClick={()=>{onSelectMember(m!.id);setSummary(null)}} className="w-full rounded-xl border p-3 mb-2 text-left hover:bg-amber-50 dark:hover:bg-stone-800 flex items-center gap-3">{m!.profilePhoto?<img src={m!.profilePhoto} alt="" className="h-10 w-10 rounded-full object-cover"/>:<div className="h-10 w-10 rounded-full bg-amber-100 dark:bg-stone-700 flex items-center justify-center font-bold">{(m!.banglaName||m!.fullName||'?').slice(0,1)}</div>}<span className="min-w-0 flex-1"><span className="block text-sm font-semibold truncate">{isBn?m!.banglaName||m!.fullName:m!.englishName||m!.fullName}</span><span className="block text-[10px] text-stone-500">{isBn?`প্রজন্ম: ${toBanglaDigits(generations.get(m!.id)||m!.computedGeneration||1)}`:`Generation: ${generations.get(m!.id)||m!.computedGeneration||1}`}</span></span><span className="text-xs text-amber-700">{isBn?'বিস্তারিত ↗':'Open ↗'}</span></button>)}</div>}{summary.memberId && <button type="button" onClick={()=>{onSelectMember(summary.memberId!);setSummary(null)}} className="mt-4 w-full rounded-xl bg-sky-800 px-4 py-2.5 text-xs font-bold text-white">{isBn?'সদস্যের বিস্তারিত খুলুন':'Open member details'}</button>}</div></div></div>}
  </div>;
};

const AwardIcon = () => <BarChart3 className="h-3.5 w-3.5"/>;
