import React, { useMemo, useState } from 'react';
import { KeyRound, Mail, Smartphone, UserCircle, Save, ShieldCheck, Camera } from 'lucide-react';
import { useGenealogy } from '../context/GenealogyContext';
import { hashPassword, verifyPassword } from '../services/security';
import { listStoredAccounts, saveStoredAccounts, type StoredAccount, type UserRole } from '../services/authRbac';

const roleLabel: Record<UserRole,string> = {
  owner:'বংশমালিক', super_admin:'সুপার অ্যাডমিন', admin:'অ্যাডমিন', co_admin:'Co-Admin', tester:'টেস্টার',
  editor:'এডিটর', contributor:'কন্ট্রিবিউটর', viewer:'সাধারণ ব্যবহারকারী'
};
const normalizeMobile = (v:string) => v.replace(/[\s-]/g,'');

export const MyAccountView: React.FC = () => {
  const { userAccount, setUserAccount, language } = useGenealogy();
  const isBn = language === 'bn';
  const [name,setName] = useState(userAccount.name || userAccount.nameBn || '');
  const [username,setUsername] = useState(userAccount.username || '');
  const [avatarUrl,setAvatarUrl] = useState(userAccount.avatarUrl || '');
  const [mobile,setMobile] = useState((userAccount as StoredAccount).mobile || (userAccount.loginMethod==='mobile' ? userAccount.contact : ''));
  const [email,setEmail] = useState((userAccount as StoredAccount).email || (userAccount.loginMethod==='email' ? userAccount.contact : ''));
  const [currentPassword,setCurrentPassword] = useState('');
  const [newPassword,setNewPassword] = useState('');
  const [confirmPassword,setConfirmPassword] = useState('');
  const [message,setMessage] = useState('');
  const [error,setError] = useState('');

  const stored = useMemo(() => listStoredAccounts().find(a=>a.id===userAccount.id), [userAccount.id, message]);

  const saveProfile = async () => {
    setError(''); setMessage('');
    const nextMobile = mobile.trim() ? normalizeMobile(mobile.trim()) : '';
    const nextEmail = email.trim().toLowerCase();
    if (!name.trim() || !username.trim() || (!nextMobile && !nextEmail)) { setError(isBn?'নাম, Username এবং মোবাইল/ইমেইলের অন্তত একটি দিন।':'Name, username and at least one mobile/email are required.'); return; }
    if (!/^[a-zA-Z0-9._-]{3,32}$/.test(username.trim())) { setError(isBn?'Username ৩–৩২ অক্ষরের হতে হবে।':'Username must be 3–32 characters.'); return; }
    if (nextMobile && !/^\+?[0-9]{10,15}$/.test(nextMobile)) { setError(isBn?'মোবাইল নম্বর সঠিক নয়।':'Invalid mobile number.'); return; }
    if (nextEmail && !/^\S+@\S+\.\S+$/.test(nextEmail)) { setError(isBn?'ইমেইল সঠিক নয়।':'Invalid email address.'); return; }
    const accounts = listStoredAccounts();
    const duplicate = accounts.find(a=>a.id!==userAccount.id && ((a.username && a.username.toLowerCase()===username.trim().toLowerCase()) || (nextMobile && a.mobile===nextMobile) || (nextEmail && a.email?.toLowerCase()===nextEmail)));
    if (duplicate) { setError(isBn?'এই মোবাইল বা ইমেইল অন্য একাউন্টে ব্যবহার হচ্ছে।':'This mobile or email is already used by another account.'); return; }
    const target = accounts.find(a=>a.id===userAccount.id);
    if (!target) { setError(isBn?'একাউন্ট পাওয়া যায়নি। আবার লগইন করুন।':'Account not found. Please sign in again.'); return; }
    target.name = name.trim(); target.nameBn = name.trim(); target.username = username.trim(); target.mobile = nextMobile || undefined; target.email = nextEmail || undefined; target.avatarUrl = avatarUrl || undefined;
    target.contact = nextMobile || nextEmail;
    target.loginMethod = nextMobile ? 'mobile' : 'email';
    saveStoredAccounts(accounts);
    setUserAccount({ ...target, sessionToken:userAccount.sessionToken });
    setMessage(isBn?'নিজের Account তথ্য সংরক্ষণ হয়েছে। বংশতালিকার Member তথ্য পরিবর্তন হয়নি।':'Your account information was saved. Genealogy member data was not changed.');
  };

  const changePassword = async () => {
    setError(''); setMessage('');
    if (!stored?.passwordDigest) { setError(isBn?'বর্তমান পাসওয়ার্ড যাচাই করা যাচ্ছে না।':'Current password record is unavailable.'); return; }
    if (!(await verifyPassword(currentPassword, stored.passwordDigest))) { setError(isBn?'বর্তমান পাসওয়ার্ড সঠিক নয়।':'Current password is incorrect.'); return; }
    if (newPassword.length < 10 || newPassword !== confirmPassword) { setError(isBn?'নতুন পাসওয়ার্ড কমপক্ষে ১০ অক্ষরের এবং দুইবার একই হতে হবে।':'New password must be at least 10 characters and match confirmation.'); return; }
    const accounts = listStoredAccounts(); const target=accounts.find(a=>a.id===userAccount.id); if(!target){setError('Account not found.');return;}
    target.passwordDigest = await hashPassword(newPassword); saveStoredAccounts(accounts); setCurrentPassword('');setNewPassword('');setConfirmPassword('');setMessage(isBn?'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে।':'Password changed successfully.');
  };

  return <div className="space-y-5">
    <div className="rounded-3xl border border-stone-200 bg-white dark:border-stone-800 dark:bg-stone-900 p-6 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-4"><div><h1 className="text-2xl font-black flex items-center gap-2"><UserCircle className="w-7 h-7 text-amber-700"/>{isBn?'আমার অ্যাকাউন্ট':'My Account'}</h1><p className="text-sm text-stone-500 mt-1">{isBn?'এখানকার পরিবর্তন শুধু Login Account-এ প্রযোজ্য হবে; বংশতালিকার Member Profile অপরিবর্তিত থাকবে।':'Changes here affect only the login account, never the genealogy member profile.'}</p></div><div className="rounded-2xl bg-amber-50 dark:bg-amber-950/20 px-4 py-3 text-sm font-bold text-amber-800 dark:text-amber-200"><ShieldCheck className="inline w-4 h-4 mr-1"/>{roleLabel[userAccount.role] || userAccount.role}</div></div>
      <div className="grid md:grid-cols-2 gap-4 mt-6">
        <label className="text-xs font-bold">{isBn?'অ্যাকাউন্টের নাম':'Account Name'}<input value={name} onChange={e=>setName(e.target.value)} className="mt-1 w-full rounded-xl border p-3 text-sm bg-white dark:bg-stone-800"/></label>
        <label className="text-xs font-bold">{isBn?'Username (লগইন নাম)':'Username'}<input value={username} onChange={e=>setUsername(e.target.value)} autoComplete="username" className="mt-1 w-full rounded-xl border p-3 text-sm bg-white dark:bg-stone-800"/></label>
        <label className="text-xs font-bold"><Smartphone className="inline w-3.5 h-3.5 mr-1"/>{isBn?'লগইন মোবাইল':'Login Mobile'}<input value={mobile} onChange={e=>setMobile(e.target.value)} className="mt-1 w-full rounded-xl border p-3 text-sm bg-white dark:bg-stone-800"/></label>
        <label className="text-xs font-bold"><Mail className="inline w-3.5 h-3.5 mr-1"/>{isBn?'Gmail / Email':'Gmail / Email'}<input value={email} onChange={e=>setEmail(e.target.value)} className="mt-1 w-full rounded-xl border p-3 text-sm bg-white dark:bg-stone-800"/></label>
        <div className="rounded-xl border border-stone-200 dark:border-stone-700 p-3 text-xs"><b>{isBn?'Genealogy Member Link':'Genealogy Member Link'}</b><p className="mt-1 text-stone-500">{userAccount.linkedMemberId || (isBn?'কোনো Member Link নির্ধারিত নেই।':'No member link is assigned.')}</p><p className="mt-1 text-emerald-700">{isBn?'এই Account পরিবর্তন Member-এর বংশতথ্য পরিবর্তন করে না।':'Account changes never mutate genealogy data.'}</p></div>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-4 rounded-2xl border border-stone-200 dark:border-stone-700 p-4">
        <div className="w-20 h-20 rounded-full overflow-hidden border bg-stone-100 dark:bg-stone-800 flex items-center justify-center">
          {avatarUrl ? <img src={avatarUrl} alt="Account profile" className="w-full h-full object-cover"/> : <UserCircle className="w-12 h-12 text-stone-400"/>}
        </div>
        <div>
          <div className="text-sm font-bold">{isBn ? 'অ্যাকাউন্ট প্রোফাইল ছবি' : 'Account Profile Photo'}</div>
          <p className="text-xs text-stone-500 mt-1">{isBn ? 'এটি Login Account-এর ছবি; Genealogy Member-এর ছবি নয়।' : 'This is the Login Account photo, separate from the genealogy member photo.'}</p>
          <label className="mt-2 inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-bold cursor-pointer"><Camera className="w-4 h-4"/>{isBn ? 'ছবি নির্বাচন করুন' : 'Choose Photo'}<input type="file" accept="image/*" className="hidden" onChange={e=>{ const f=e.target.files?.[0]; if(!f)return; const r=new FileReader(); r.onload=()=>setAvatarUrl(String(r.result||'')); r.readAsDataURL(f); }}/></label>
        </div>
      </div>
      <button onClick={saveProfile} className="mt-5 rounded-xl bg-amber-700 text-white px-5 py-3 text-sm font-bold"><Save className="inline w-4 h-4 mr-1.5"/>{isBn?'অ্যাকাউন্ট তথ্য সংরক্ষণ':'Save Account Information'}</button>
    </div>
    <div className="rounded-3xl border border-stone-200 bg-white dark:border-stone-800 dark:bg-stone-900 p-6 shadow-sm"><h2 className="text-lg font-black"><KeyRound className="inline w-5 h-5 mr-2 text-amber-700"/>{isBn?'পাসওয়ার্ড পরিবর্তন':'Change Password'}</h2><div className="grid md:grid-cols-3 gap-3 mt-4"><input type="password" value={currentPassword} onChange={e=>setCurrentPassword(e.target.value)} placeholder={isBn?'বর্তমান পাসওয়ার্ড':'Current password'} className="rounded-xl border p-3 text-sm dark:bg-stone-800"/><input type="password" value={newPassword} onChange={e=>setNewPassword(e.target.value)} placeholder={isBn?'নতুন পাসওয়ার্ড':'New password'} className="rounded-xl border p-3 text-sm dark:bg-stone-800"/><input type="password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} placeholder={isBn?'আবার নতুন পাসওয়ার্ড':'Confirm password'} className="rounded-xl border p-3 text-sm dark:bg-stone-800"/></div><button onClick={changePassword} className="mt-4 rounded-xl border border-stone-300 dark:border-stone-700 px-5 py-3 text-sm font-bold"><KeyRound className="inline w-4 h-4 mr-1.5"/>{isBn?'পাসওয়ার্ড পরিবর্তন':'Change Password'}</button></div>
    {(error||message) && <div className={`rounded-2xl p-4 text-sm font-semibold ${error?'border border-red-200 bg-red-50 text-red-700':'border border-emerald-200 bg-emerald-50 text-emerald-700'}`}>{error||message}</div>}
  </div>;
};
