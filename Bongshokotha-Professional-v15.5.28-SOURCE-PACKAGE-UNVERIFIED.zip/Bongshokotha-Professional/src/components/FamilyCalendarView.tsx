/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Family Heritage Calendar & Commemorative Chronology
 * 
 * Views: Month, List, Upcoming
 * Events: Birthday, Marriage Anniversary, Death Anniversary, Family Heritage Event
 */

import React, { useState, useMemo } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { Member, MarriageRecord } from '../types/genealogy';
import { toBanglaDigits, BANGLA_MONTHS } from '../engine/banglaCalendar';
import {
  Calendar as CalendarIcon,
  Cake,
  Heart,
  Flower2,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Filter,
  List,
  Clock,
  CalendarDays
} from 'lucide-react';

interface FamilyCalendarViewProps {
  onSelectMember: (memberId: string) => void;
}

interface CalendarEvent {
  id: string;
  type: 'birthday' | 'anniversary' | 'death_anniversary' | 'historical';
  titleBn: string;
  titleEn: string;
  month: number; // 1-12
  day: number; // 1-31
  originalYear?: number | null;
  yearsCount?: number;
  memberId?: string;
  memberIds?: string[];
  branchId?: string;
  subtitle?: string;
}

export const FamilyCalendarView: React.FC<FamilyCalendarViewProps> = ({
  onSelectMember
}) => {
  const {
    members,
    marriages,
    branches,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const currentYear = new Date().getFullYear();

  const [viewMode, setViewMode] = useState<'upcoming' | 'month' | 'list'>('upcoming');
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1); // 1-12
  const [filterType, setFilterType] = useState<string>('all');
  const [filterBranch, setFilterBranch] = useState<string>('all');

  const memberMap = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);

  // Aggregate all events from members & marriages
  const allEvents = useMemo(() => {
    const events: CalendarEvent[] = [];

    // 1. Birthdays (Only for living members)
    members.forEach(m => {
      if (m.birth?.date?.month && m.birth?.date?.day) {
        if (m.isLiving) {
          const age = m.birth.date.year ? currentYear - m.birth.date.year : undefined;
          events.push({
            id: `birth-${m.id}`,
            type: 'birthday',
            titleBn: `${m.banglaName || m.fullName}-এর জন্মদিন`,
            titleEn: `${m.englishName || m.fullName}'s Birthday`,
            month: m.birth.date.month,
            day: m.birth.date.day,
            originalYear: m.birth.date.year,
            yearsCount: age,
            memberId: m.id,
            branchId: m.branchId,
            subtitle: age !== undefined ? (isBn ? `${toBanglaDigits(age)}তম জন্মদিন` : `Turns ${age}`) : undefined
          });
        } else {
          // 2. Death Anniversaries (For deceased members)
          if (m.death?.date?.month && m.death?.date?.day) {
            const yearsSince = m.death.date.year ? currentYear - m.death.date.year : undefined;
            events.push({
              id: `death-${m.id}`,
              type: 'death_anniversary',
              titleBn: `মরহুম ${m.banglaName || m.fullName}-এর মৃত্যুবার্ষিকী`,
              titleEn: `Memorial: ${m.englishName || m.fullName}`,
              month: m.death.date.month,
              day: m.death.date.day,
              originalYear: m.death.date.year,
              yearsCount: yearsSince,
              memberId: m.id,
              branchId: m.branchId,
              subtitle: yearsSince !== undefined ? (isBn ? `${toBanglaDigits(yearsSince)} বছর স্মারক` : `${yearsSince} years since passing`) : undefined
            });
          }
        }
      }
    });

    // 3. Marriage Anniversaries
    marriages.forEach(mar => {
      if (mar.marriageDate?.month && mar.marriageDate?.day && mar.status === 'current') {
        const husband = memberMap.get(mar.husbandId);
        const wife = memberMap.get(mar.wifeId);
        const years = mar.marriageDate.year ? currentYear - mar.marriageDate.year : undefined;

        events.push({
          id: `anniv-${mar.id}`,
          type: 'anniversary',
          titleBn: `${husband?.banglaName || 'স্বামী'} ও ${wife?.banglaName || 'স্ত্রী'}-এর বিবাহবার্ষিকী`,
          titleEn: `${husband?.englishName || 'Husband'} & ${wife?.englishName || 'Wife'} Anniversary`,
          month: mar.marriageDate.month,
          day: mar.marriageDate.day,
          originalYear: mar.marriageDate.year,
          yearsCount: years,
          memberId: mar.husbandId,
          memberIds: [mar.husbandId, mar.wifeId],
          branchId: husband?.branchId || wife?.branchId,
          subtitle: years !== undefined ? (isBn ? `${toBanglaDigits(years)}তম বিবাহবার্ষিকী` : `${years}th Anniversary`) : undefined
        });
      }
    });

    // Sort by month, then day
    events.sort((a, b) => {
      if (a.month !== b.month) return a.month - b.month;
      return a.day - b.day;
    });

    return events;
  }, [members, marriages, currentYear, memberMap, isBn]);

  // Filtered events
  const filteredEvents = useMemo(() => {
    return allEvents.filter(ev => {
      if (filterType !== 'all' && ev.type !== filterType) return false;
      if (filterBranch !== 'all' && ev.branchId !== filterBranch) return false;
      if (viewMode === 'month' && ev.month !== selectedMonth) return false;
      return true;
    });
  }, [allEvents, filterType, filterBranch, viewMode, selectedMonth]);

  // Upcoming 30 days events calculation
  const upcomingEvents = useMemo(() => {
    const today = new Date();
    const curMonth = today.getMonth() + 1;
    const curDay = today.getDate();

    return allEvents
      .map(ev => {
        let diffDays = 0;
        // Calculate day distance in circular calendar
        const eventDateThisYear = new Date(currentYear, ev.month - 1, ev.day);
        const todayDate = new Date(currentYear, today.getMonth(), today.getDate());
        let timeDiff = eventDateThisYear.getTime() - todayDate.getTime();

        if (timeDiff < 0) {
          // Event already passed this year, next occurrence is next year
          const nextYearDate = new Date(currentYear + 1, ev.month - 1, ev.day);
          timeDiff = nextYearDate.getTime() - todayDate.getTime();
        }

        diffDays = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
        return { ...ev, diffDays };
      })
      .sort((a, b) => a.diffDays - b.diffDays)
      .slice(0, 15);
  }, [allEvents, currentYear]);

  const monthNamesEn = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const monthNamesBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];

  const getEventIcon = (type: CalendarEvent['type']) => {
    switch (type) {
      case 'birthday':
        return <Cake className="h-4 w-4 text-amber-600 dark:text-amber-400" />;
      case 'anniversary':
        return <Heart className="h-4 w-4 text-rose-600 dark:text-rose-400" />;
      case 'death_anniversary':
        return <Flower2 className="h-4 w-4 text-stone-500 dark:text-stone-400" />;
      default:
        return <Bookmark className="h-4 w-4 text-blue-600 dark:text-blue-400" />;
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Top Banner & View Switcher */}
      <div className="flex flex-col gap-4 rounded-2xl border border-amber-900/10 bg-white p-5 shadow-xs dark:border-stone-800 dark:bg-stone-900 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-amber-950 dark:text-amber-100 flex items-center gap-2">
            <CalendarIcon className="h-6 w-6 text-amber-800 dark:text-amber-400" />
            <span>{isBn ? 'পারিবারিক বর্ষপঞ্জি ও স্মারক দিন' : 'Family Calendar & Memorials'}</span>
          </h2>
          <p className="text-xs text-stone-500">
            {isBn
              ? 'বংশের সকল জীবিত ও মরহুম সদস্যদের জন্মদিন, বিবাহবার্ষিকী এবং ইন্তেকাল স্মরণোৎসব।'
              : 'Birthdays, wedding anniversaries, and memorial dates across generations.'}
          </p>
        </div>

        {/* View Mode Buttons */}
        <div className="flex rounded-xl bg-stone-100 p-1 dark:bg-stone-800">
          <button
            onClick={() => setViewMode('upcoming')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              viewMode === 'upcoming'
                ? 'bg-white text-amber-950 shadow-xs dark:bg-stone-900 dark:text-amber-200'
                : 'text-stone-600 hover:text-stone-900 dark:text-stone-400'
            }`}
          >
            <Clock className="h-3.5 w-3.5" />
            <span>{isBn ? 'আসন্ন দিন' : 'Upcoming'}</span>
          </button>

          <button
            onClick={() => setViewMode('month')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              viewMode === 'month'
                ? 'bg-white text-amber-950 shadow-xs dark:bg-stone-900 dark:text-amber-200'
                : 'text-stone-600 hover:text-stone-900 dark:text-stone-400'
            }`}
          >
            <CalendarDays className="h-3.5 w-3.5" />
            <span>{isBn ? 'মাসভিত্তিক' : 'Month'}</span>
          </button>

          <button
            onClick={() => setViewMode('list')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              viewMode === 'list'
                ? 'bg-white text-amber-950 shadow-xs dark:bg-stone-900 dark:text-amber-200'
                : 'text-stone-600 hover:text-stone-900 dark:text-stone-400'
            }`}
          >
            <List className="h-3.5 w-3.5" />
            <span>{isBn ? 'সম্পূর্ণ তালিকা' : 'All List'}</span>
          </button>
        </div>
      </div>

      {/* Filter and Month Navigation Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-900/10 bg-white p-4 shadow-xs dark:border-stone-800 dark:bg-stone-900">
        {/* Month Selector (if in month mode) */}
        {viewMode === 'month' ? (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedMonth(prev => (prev === 1 ? 12 : prev - 1))}
              className="rounded-lg p-1.5 text-stone-600 hover:bg-stone-100 dark:hover:bg-stone-800"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="font-serif font-bold text-sm text-amber-950 dark:text-amber-100 min-w-[120px] text-center">
              {isBn ? monthNamesBn[selectedMonth - 1] : monthNamesEn[selectedMonth - 1]}
            </span>
            <button
              onClick={() => setSelectedMonth(prev => (prev === 12 ? 1 : prev + 1))}
              className="rounded-lg p-1.5 text-stone-600 hover:bg-stone-100 dark:hover:bg-stone-800"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="text-xs font-semibold text-stone-600 dark:text-stone-400">
            {isBn ? 'পারিবারিক স্মরণীয় দিনপঞ্জি' : 'Commemorative Lineage Events'}
          </div>
        )}

        {/* Filters: Type & Branch */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-stone-600 dark:text-stone-300">
            <Filter className="h-3.5 w-3.5 text-amber-800 dark:text-amber-400" />
            <span>{isBn ? 'ইভেন্ট ধরন:' : 'Type:'}</span>
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="rounded-lg border border-stone-200 bg-white px-2.5 py-1 text-xs dark:border-stone-700 dark:bg-stone-800"
            >
              <option value="all">{isBn ? 'সকল ইভেন্ট' : 'All Events'}</option>
              <option value="birthday">{isBn ? 'জন্মদিন' : 'Birthdays'}</option>
              <option value="anniversary">{isBn ? 'বিবাহবার্ষিকী' : 'Anniversaries'}</option>
              <option value="death_anniversary">{isBn ? 'মৃত্যুবার্ষিকী / স্মারক' : 'Memorials'}</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-stone-600 dark:text-stone-300">
            <span>{isBn ? 'শাখা:' : 'Branch:'}</span>
            <select
              value={filterBranch}
              onChange={e => setFilterBranch(e.target.value)}
              className="rounded-lg border border-stone-200 bg-white px-2.5 py-1 text-xs dark:border-stone-700 dark:bg-stone-800"
            >
              <option value="all">{isBn ? 'সকল শাখা' : 'All Branches'}</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>
                  {isBn ? b.banglaName || b.name : b.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* VIEW 1: UPCOMING DAYS */}
      {viewMode === 'upcoming' && (
        <div className="space-y-4">
          <h3 className="font-serif text-base font-bold text-amber-950 dark:text-amber-100">
            {isBn ? 'আসন্ন পারিবারিক দিনসমূহ (পরবর্তী ৩০ দিন)' : 'Upcoming Family Days'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingEvents.length === 0 ? (
              <div className="col-span-full rounded-2xl border border-dashed border-stone-300 p-8 text-center text-xs text-stone-400">
                {isBn ? 'কোনো আসন্ন স্মরণীয় দিন নেই।' : 'No upcoming events.'}
              </div>
            ) : (
              upcomingEvents.map(ev => (
                <div
                  key={ev.id}
                  onClick={() => ev.memberId && onSelectMember(ev.memberId)}
                  className="cursor-pointer rounded-2xl border border-stone-200/90 bg-white p-4 shadow-xs transition hover:border-amber-800/40 hover:shadow-md dark:border-stone-800 dark:bg-stone-900"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-800 dark:bg-stone-800">
                        {getEventIcon(ev.type)}
                      </div>
                      <div>
                        <div className="font-serif font-bold text-sm text-amber-950 dark:text-amber-100">
                          {isBn ? ev.titleBn : ev.titleEn}
                        </div>
                        {ev.subtitle && (
                          <div className="text-[11px] font-semibold text-amber-800 dark:text-amber-400">
                            {ev.subtitle}
                          </div>
                        )}
                      </div>
                    </div>

                    <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-[10px] font-bold text-amber-900 dark:bg-amber-950 dark:text-amber-300 whitespace-nowrap">
                      {ev.diffDays === 0
                        ? (isBn ? 'আজ!' : 'Today!')
                        : ev.diffDays === 1
                        ? (isBn ? 'আগামীকাল' : 'Tomorrow')
                        : (isBn ? `${toBanglaDigits(ev.diffDays)} দিন বাকি` : `In ${ev.diffDays} days`)}
                    </span>
                  </div>

                  <div className="mt-3 pt-2 border-t border-stone-100 text-xs text-stone-500 dark:border-stone-800 flex items-center justify-between">
                    <span>
                      {isBn ? `${toBanglaDigits(ev.day)} ${monthNamesBn[ev.month - 1]}` : `${ev.day} ${monthNamesEn[ev.month - 1]}`}
                      {ev.originalYear && ` (${isBn ? toBanglaDigits(ev.originalYear) : ev.originalYear})`}
                    </span>
                    <span className="text-[10px] text-amber-800 underline dark:text-amber-400">
                      {isBn ? 'প্রোফাইল দর্শন →' : 'View Profile →'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* VIEW 2 & 3: MONTH OR FULL LIST */}
      {(viewMode === 'month' || viewMode === 'list') && (
        <div className="rounded-2xl border border-amber-900/10 bg-white shadow-xs dark:border-stone-800 dark:bg-stone-900 overflow-hidden">
          <div className="divide-y divide-stone-100 dark:divide-stone-800">
            {filteredEvents.length === 0 ? (
              <div className="p-8 text-center text-xs text-stone-400">
                {isBn ? 'নির্বাচিত ফিল্টার বা মাসে কোনো ইভেন্ট নেই।' : 'No events in selected period.'}
              </div>
            ) : (
              filteredEvents.map(ev => (
                <div
                  key={ev.id}
                  onClick={() => ev.memberId && onSelectMember(ev.memberId)}
                  className="flex items-center justify-between p-4 hover:bg-amber-50/50 cursor-pointer transition dark:hover:bg-stone-800"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-stone-100 dark:bg-stone-800">
                      {getEventIcon(ev.type)}
                    </div>

                    <div>
                      <div className="font-serif font-bold text-sm text-stone-900 dark:text-stone-100">
                        {isBn ? ev.titleBn : ev.titleEn}
                      </div>
                      <div className="text-xs text-stone-500">
                        {isBn ? `${toBanglaDigits(ev.day)} ${monthNamesBn[ev.month - 1]}` : `${ev.day} ${monthNamesEn[ev.month - 1]}`}
                        {ev.subtitle && ` • ${ev.subtitle}`}
                      </div>
                    </div>
                  </div>

                  <span className="text-xs font-semibold text-amber-800 underline dark:text-amber-400">
                    {isBn ? 'বিস্তারিত' : 'View'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
