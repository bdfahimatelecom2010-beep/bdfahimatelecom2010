import React, { useMemo, useState } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { ROLE_PERMISSIONS, UserRole, listStoredAccounts, saveStoredAccounts, assignStoredAccountRole, type StoredAccount } from '../services/authRbac';
import { hashPassword } from '../services/security';
import { ShieldCheck, Users, UserCog, KeyRound, Menu, Database, RefreshCw, ClipboardCheck, Activity, Cloud, UserPlus, CheckCircle2, XCircle, Save, Share2, Download, QrCode, Copy } from 'lucide-react';
import QRCode from 'qrcode';
import { publishInvite } from '../services/syncClient';
import { getActiveServerProfile, getServerProfiles, saveServerProfiles, setActiveServerId, testServer, getServerLoginUrl, type ServerProfile } from '../services/serverRegistry';
import { backupFamilyToGoogleDrive, connectGoogleDrive, disconnectGoogleDrive, isGoogleDriveConfigured } from '../services/googleDriveBackup';
import type { SuccessionCandidate } from '../types/genealogy';
import { MyAccountView } from './MyAccountView';
import { IntegrityRepairView } from './IntegrityRepairView';
import { logAuditEvent } from '../services/auditLogger';

type AdminSection = 'overview' | 'users' | 'roles' | 'menus' | 'permissions' | 'backup' | 'sync' | 'succession' | 'proposals' | 'integrity' | 'audit' | 'my-account';

const ROLE_LABELS: Record<UserRole, string> = {
  owner: 'বংশমালিক (Owner)',
  super_admin: 'সুপার অ্যাডমিন',
  admin: 'অ্যাডমিন',
  co_admin: 'Co-Admin',
  tester: 'টেস্টার (Tester)',
  editor: 'এডিটর',
  contributor: 'কন্ট্রিবিউটর',
  viewer: 'ভিউয়ার'
};

const MODULES = [
  ['dashboard', 'ড্যাশবোর্ড'], ['members', 'সকল সদস্য'], ['tree', 'বংশলতিকা বৃক্ষ'],
  ['relations', 'আত্মীয়তা নির্ণয়'], ['marriages', 'বৈবাহিক বন্ধন'], ['archive', 'পারিবারিক আর্কাইভ'],
  ['book', 'বংশপুস্তক ও ইতিহাস'], ['calendar', 'ঐতিহাসিক বর্ষপঞ্জি'], ['import-export', 'আমদানি ও রপ্তানি'],
  ['print-export', 'মুদ্রণ ও প্রকাশ'], ['map', 'পারিবারিক মানচিত্র'], ['share', 'বংশতালিকা শেয়ার'],
  ['recycle-bin', 'রিসাইকেল বিন'], ['settings', 'সেটিংস ও নিরাপত্তা']
] as const;

const ACTIONS = [
  'দেখা', 'যোগ', 'সম্পাদনা', 'মুছে ফেলা', 'পুনরুদ্ধার', 'স্থায়ী মুছে ফেলা',
  'আপলোড', 'ডাউনলোড', 'প্রিন্ট', 'আমদানি', 'রপ্তানি', 'অনুমোদন', 'প্রত্যাখ্যান', 'শেয়ার'
];

const ROLE_MENU_KEY = 'bongshokotha_role_menus_v1';

export const AdminCenterView: React.FC = () => {
  const { language, userAccount, members, marriages, archiveRecords, family, updateFamily, checkPermission } = useGenealogy();
  const isBn = language === 'bn';
  const [section, setSection] = useState<AdminSection>('overview');
  const [selectedRole, setSelectedRole] = useState<UserRole>('editor');
  const [saved, setSaved] = useState(false);
  const [roleMenus, setRoleMenus] = useState<Record<string, string[]>>(() => {
    try { return JSON.parse(localStorage.getItem(ROLE_MENU_KEY) || '{}'); } catch { return {}; }
  });
  const [selectedModules, setSelectedModules] = useState<string[]>(roleMenus.editor || ['dashboard','members','tree','relations','marriages','archive','book','calendar']);
  const [shareCode, setShareCode] = useState('');
  const [shareQr, setShareQr] = useState('');
  const [cloudEmail, setCloudEmail] = useState('');
  const [cloudBusy, setCloudBusy] = useState(false);
  const [cloudMessage, setCloudMessage] = useState('');
  const [serverProfiles, setServerProfiles] = useState<ServerProfile[]>(() => getServerProfiles());
  const [activeServerId, setActiveServerIdState] = useState(() => getActiveServerProfile()?.id || 'local');
  const [serverBusyId, setServerBusyId] = useState<string | null>(null);
  const [serverLoginMessage, setServerLoginMessage] = useState('');
  const [gmailAddress, setGmailAddress] = useState(() => family.settings?.googleAccountEmail || '');
  const [accounts, setAccounts] = useState<StoredAccount[]>(() => listStoredAccounts());
  const [passwordResetInputs, setPasswordResetInputs] = useState<Record<string,string>>({});
  const [passwordResetMessage, setPasswordResetMessage] = useState('');
  const resetAccountPassword = async (accountId:string) => {
    setPasswordResetMessage('');
    const nextPassword = passwordResetInputs[accountId] || '';
    if (accountId === userAccount.id) { setPasswordResetMessage(isBn?'নিজের পাসওয়ার্ডের জন্য My Account ব্যবহার করুন।':'Use My Account to change your own password.'); return; }
    if (nextPassword.length < 10) { setPasswordResetMessage(isBn?'অস্থায়ী পাসওয়ার্ড কমপক্ষে ১০ অক্ষরের হতে হবে।':'Temporary password must be at least 10 characters.'); return; }
    const nextAccounts = listStoredAccounts(); const target = nextAccounts.find(a=>a.id===accountId);
    if (!target) { setPasswordResetMessage(isBn?'একাউন্ট পাওয়া যায়নি।':'Account not found.'); return; }
    target.passwordDigest = await hashPassword(nextPassword); saveStoredAccounts(nextAccounts); setAccounts(nextAccounts);
    setPasswordResetInputs(old=>({...old,[accountId]:''}));
    setPasswordResetMessage(isBn?'পাসওয়ার্ড রিসেট হয়েছে। নিরাপদ মাধ্যমে অস্থায়ী পাসওয়ার্ডটি সংশ্লিষ্ট ব্যবহারকারীকে জানান।':'Password reset. Communicate the temporary password to the user through a secure channel.');
    logAuditEvent({ eventType:'password_reset', actorId:userAccount.id, actorName:userAccount.name, actorRole:userAccount.role, targetEntity:accountId, details:'Account password reset by authorized administrator', detailsBn:'অনুমোদিত প্রশাসক ব্যবহারকারীর পাসওয়ার্ড রিসেট করেছেন।', severity:'warning' });
  };
  const [successors, setSuccessors] = useState<SuccessionCandidate[]>(() => (family.settings?.successionCandidates || []).slice().sort((a,b)=>a.priority-b.priority));

  const isOwner = userAccount?.role === 'owner';
  const canManageRoles = checkPermission('canManageRoles');
  const canGmailBackup = checkPermission('canGmailBackup');
  const canManageServers = checkPermission('canManageServers');
  const canDeleteEntireGenealogy = checkPermission('canDeleteEntireGenealogy');
  const permissions = ROLE_PERMISSIONS[selectedRole];
  const permissionList = useMemo(() => Object.entries(permissions), [permissions]);

  React.useEffect(() => {
    const onServerAuth = async (event: MessageEvent) => {
      const data = event.data || {};
      if (data?.type !== 'BKS_SERVER_AUTH' || !data.serverId || !data.token) return;
      const profile = serverProfiles.find(p => p.id === data.serverId);
      if (!profile) return;
      try { if (new URL(profile.endpoint).origin !== event.origin) return; } catch { return; }
      const next = serverProfiles.map(p => p.id === profile.id ? { ...p, token: String(data.token) } : p);
      setServerProfiles(next); saveServerProfiles(next);
      setServerLoginMessage(isBn ? 'সার্ভার লগইন সফল। সংযোগ যাচাই চলছে…' : 'Server login received. Verifying connection…');
      const result = await testServer({ ...profile, token: String(data.token) });
      const checked = new Date().toISOString();
      const finalProfiles = next.map(p => p.id === profile.id ? { ...p, status: (result.ok ? 'online' : 'offline') as ServerProfile['status'], lastCheckedAt: checked, version: result.version } : p);
      setServerProfiles(finalProfiles); saveServerProfiles(finalProfiles);
      if (result.ok) { setActiveServerId(profile.id); setActiveServerIdState(profile.id); await updateFamily({ settings: { ...family.settings, syncEndpoint: profile.endpoint, syncProvider: profile.provider === 'self_hosted' ? 'self_hosted' : 'self_hosted', syncStatus: 'synced', syncLastTimestamp: checked } }); setServerLoginMessage(isBn ? 'লগইন ও সার্ভার সংযোগ সফল। এখন পরের কাজগুলো এই সার্ভার ব্যবহার করবে।' : 'Login and server connection succeeded. The remaining workflows will use this server automatically.'); }
      else setServerLoginMessage(result.message);
    };
    window.addEventListener('message', onServerAuth);
    return () => window.removeEventListener('message', onServerAuth);
  }, [serverProfiles, family.settings, isBn, updateFamily]);

  const openServerLogin = (profile: ServerProfile) => {
    const url = getServerLoginUrl(profile);
    if (!url) { setServerLoginMessage(isBn ? 'এই সার্ভারের Login Page চালু করতে আগে endpoint দিন।' : 'Set the server endpoint before opening its Login Page.'); return; }
    setActiveServerId(profile.id); setActiveServerIdState(profile.id);
    window.open(url, `bongshokotha-server-login-${profile.id}`, 'popup,width=520,height=720,resizable=yes,scrollbars=yes');
  };

  if (!canManageRoles) {
    if (checkPermission('canRunIntegrityRepair')) return <IntegrityRepairView onSelectMember={() => {}} />;
    return (
      <div className="p-6 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-sm">
        <ShieldCheck className="w-10 h-10 text-amber-600 mb-3" />
        <h2 className="text-xl font-black">{isBn ? 'এ্যাডমিন মেনু সীমিত' : 'Admin Menu Restricted'}</h2>
        <p className="mt-2 text-sm text-stone-500">{isBn ? 'অনুমোদিত Owner/Super Admin এই মেনু ব্যবহার করতে পারবেন।' : 'Only an authorized Owner/Super Admin can use the Admin Center.'}</p>
      </div>
    );
  }

  const sections: [AdminSection, string, React.ElementType][] = [
    ['overview',isBn ? 'অ্যাডমিন ড্যাশবোর্ড' : 'Admin Dashboard',ShieldCheck], ['my-account',isBn ? 'আমার অ্যাকাউন্ট' : 'My Account',UserCog], ['users',isBn ? 'ইউজার ও সহযোগী' : 'Users & Collaborators',Users], ['roles',isBn ? 'রোল ব্যবস্থাপনা' : 'Role Management',UserCog],
    ['menus',isBn ? 'রোল মেনু ব্যবস্থাপনা' : 'Role Menu Management',Menu], ['permissions',isBn ? 'Permission Management' : 'Permission Management',KeyRound],
    ...(canGmailBackup ? [['backup','Gmail Backup ও Share',Cloud] as [AdminSection,string,React.ElementType]] : []),
    ...(canManageServers ? [['sync','Server ও Sync',RefreshCw] as [AdminSection,string,React.ElementType]] : []),
    ['succession',isBn ? 'পরবর্তী বংশমালিক' : 'Succession',Users], ['proposals',isBn ? 'Contributor Proposals' : 'Contributor Proposals',ClipboardCheck], ['integrity',isBn ? 'Data Integrity ও Repair' : 'Data Integrity & Repair',Database], ['audit',isBn ? 'Audit ও Activity Log' : 'Audit & Activity Log',Activity]
  ];

  const shareFamilyPackage = async () => {
    const confirmed = window.confirm(isBn
      ? 'এই প্যাকেজে পরিবারের সদস্যদের ব্যক্তিগত তথ্য ও আর্কাইভের তথ্য থাকতে পারে। যাকে পাঠাবেন তিনি এগুলো দেখতে পারবেন। আপনি কি নিশ্চিতভাবে প্যাকেজ তৈরি ও শেয়ার করতে চান?'
      : 'This package may contain personal member and archive data. Anyone receiving it may be able to read that information. Continue creating and sharing the package?');
    if (!confirmed) return;
    const payload = { format: 'BONGSHOKOTHA_SHARE_PACKAGE', version: '1.2', exportedAt: new Date().toISOString(), family, members, marriages, archiveRecords };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const file = new File([blob], `Bongshokotha_${(family.banglaName || family.name || 'Family').replace(/\s+/g,'_')}_Share.json`, { type: 'application/json' });
    try {
      if (navigator.share && navigator.canShare?.({ files: [file] })) await navigator.share({ title: 'বংশকথা Family Share', text: 'পরিবারের বংশতথ্য প্যাকেজ', files: [file] });
      else { const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = file.name; a.click(); URL.revokeObjectURL(url); alert(isBn ? 'শেয়ার প্যাকেজ ডাউনলোড হয়েছে।' : 'Share package downloaded.'); }
    } catch { /* user cancelled */ }
  };

  const generateShareInvite = async () => {
    const code = `BKS-${Math.random().toString(36).slice(2,6).toUpperCase()}-${Math.random().toString(36).slice(2,6).toUpperCase()}`;
    setShareCode(code);
    try {
      setShareQr(await QRCode.toDataURL(JSON.stringify({ type:'BONGSHOKOTHA_JOIN', familyId: family.id, code }), { width:320, margin:2 }));
      if (family.settings?.syncEndpoint) {
        const archive = { format:'BONGSHOKOTHA_ARCHIVE' as const, version:'1.2' as const, exportedAt:new Date().toISOString(), app:'Bongshokotha / বংশকথা' as const, family, members, marriages, branches:family.branches || [], archiveRecords };
        const published = await publishInvite(family.settings.syncEndpoint, code, family.id, archive, null, getActiveServerProfile()?.token);
        if (!published || typeof published.code !== 'string' || !published.code.trim()) throw new Error('Server did not return a valid join code.');
        setShareCode(published.code);
        setShareQr(await QRCode.toDataURL(JSON.stringify({ type:'BONGSHOKOTHA_JOIN', familyId: family.id, code: published.code }), { width:320, margin:2 }));
      } else {
        alert(isBn ? 'এটি শুধু এই ডিভাইসের স্থানীয় QR/Code। অন্য ডিভাইসে ব্যবহার করতে Settings → Server/Sync-এ সার্ভার সংযোগ করুন।' : 'This QR/code is local to this device. Connect a server in Settings → Server/Sync to use it on other devices.');
      }
    } catch (e) { setShareQr(''); setShareCode(''); alert(e instanceof Error ? e.message : 'Remote invite publish failed.'); }
  };

  const connectAndBackupGoogle = async () => {
    if (!canGmailBackup) { setCloudMessage('এই Role-এর Gmail Backup permission নেই।'); return; }
    if (!isGoogleDriveConfigured()) {
      setCloudMessage('VITE_GOOGLE_CLIENT_ID সেট করা নেই। .env.local-এ Google OAuth Client ID দিন।');
      return;
    }
    setCloudBusy(true); setCloudMessage('');
    try {
      const account = await connectGoogleDrive('consent', family.settings?.googleAccountEmail || undefined);
      setCloudEmail(account.email || 'Google account connected');
      await backupFamilyToGoogleDrive(family, members, marriages, archiveRecords, false, account.email || family.settings?.googleAccountEmail || undefined);
      setCloudMessage('Google Drive appDataFolder-এ সম্পূর্ণ family backup সফলভাবে সংরক্ষিত হয়েছে।');
    } catch (e) {
      setCloudMessage(e instanceof Error ? e.message : 'Google backup ব্যর্থ হয়েছে।');
    } finally { setCloudBusy(false); }
  };

  const saveGmailAddress = () => {
    if (!canGmailBackup) { setCloudMessage('এই Role-এর Gmail Backup permission নেই।'); return; }
    const value = gmailAddress.trim();
    if (value && !/^[^\s@]+@gmail\.com$/i.test(value)) { setCloudMessage('শুধু বৈধ Gmail ঠিকানা দিন, যেমন name@gmail.com'); return; }
    void (async () => { await updateFamily({ settings: { ...family.settings, googleAccountEmail: value } }); setCloudMessage(value ? 'Admin recovery Gmail ঠিকানা সংরক্ষিত হয়েছে।' : 'Gmail ঠিকানা মুছে দেওয়া হয়েছে।'); })();
  };

  const updateFamilySettings = async (patch: Record<string, any>) => {
    const current = family.settings || ({} as any);
    await updateFamily({ settings: { ...family.settings, ...patch } });
  };

  const persistSettings = async (patch: Record<string, any>) => {
    // The context setter is intentionally resolved from the same event-safe bridge used by the app shell.
    await updateFamily({ settings: { ...family.settings, ...patch } });
  };

  const saveSuccessors = async () => {
    const clean = successors.slice().sort((a,b)=>a.priority-b.priority).filter((x,i)=>x.memberId && i < 5);
    const seen = new Set<number>();
    const unique = clean.filter(x => !seen.has(x.priority) && (seen.add(x.priority), true));
    await persistSettings({ successionCandidates: unique, ownerSuccessionLastReviewed: new Date().toISOString(), successionFallback: family.settings?.successionFallback || 'applicable_law' });
    setSuccessors(unique);
  };

  const saveServer = (id: string, patch: Partial<ServerProfile>) => {
    const next = serverProfiles.map(p => p.id === id ? { ...p, ...patch } : p);
    setServerProfiles(next); saveServerProfiles(next);
  };

  const connectServerProfile = async (profile: ServerProfile) => {
    if (!canManageServers) { setServerLoginMessage('এই Role-এর Server permission নেই।'); return; }
    setServerBusyId(profile.id);
    const result = await testServer(profile);
    setServerBusyId(null);
    const next: ServerProfile[] = serverProfiles.map(p => p.id === profile.id ? { ...p, status: (result.ok ? 'online' : 'offline') as ServerProfile['status'], version: result.version, lastCheckedAt: new Date().toISOString() } : p);
    setServerProfiles(next); saveServerProfiles(next);
    if (result.ok) { setActiveServerId(profile.id); setActiveServerIdState(profile.id); setCloudMessage(`${profile.nameBn}: সংযোগ সফল।`); } else setCloudMessage(`${profile.nameBn}: ${result.message}`);
  };

  const saveRoleMenu = () => {
    const next = { ...roleMenus, [selectedRole]: selectedModules };
    setRoleMenus(next);
    localStorage.setItem(ROLE_MENU_KEY, JSON.stringify(next));
    setSaved(true); setTimeout(() => setSaved(false), 1800);
  };

  const selectRole = (role: UserRole) => {
    setSelectedRole(role);
    setSelectedModules(roleMenus[role] || (role === 'viewer' ? ['dashboard','members','tree','book'] : ['dashboard','members','tree','relations','marriages','archive','book','calendar']));
  };

  return (
    <div className="space-y-5">
      <div className="rounded-3xl p-5 bg-gradient-to-br from-stone-900 to-stone-800 text-white shadow-lg">
        <div className="flex items-start justify-between gap-4">
          <div><p className="text-xs uppercase tracking-widest text-stone-300">BONGSHOKOTHA • ADMIN CENTER</p><h1 className="text-2xl font-black mt-1">এ্যাডমিন ও রোলস</h1><p className="text-sm text-stone-300 mt-1">শুধু বংশমালিকের জন্য—ব্যবহারকারী, Role Menu, Permission, Backup, Sync, Proposal, Integrity ও Audit এক জায়গায়।</p></div>
          <ShieldCheck className="w-9 h-9 text-amber-400 shrink-0" />
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {sections.map(([id,label,Icon]) => <button key={id} onClick={() => setSection(id)} className={`shrink-0 px-3 py-2 rounded-xl text-xs font-bold border transition ${section===id?'bg-stone-900 text-white border-stone-900':'bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300'}`}><Icon className="w-3.5 h-3.5 inline mr-1.5" />{label}</button>)}
      </div>

      {section === 'my-account' && <MyAccountView />}
      {section === 'overview' && <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[['সদস্য',members.length,Users],['Role',6,UserCog],['Admin Sections',10,ShieldCheck],['Audit Ready','ON',Activity]].map(([label,value,Icon]: any)=><div key={label} className="rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-5"><Icon className="w-5 h-5 text-amber-600"/><p className="text-xs text-stone-500 mt-3">{label}</p><p className="text-2xl font-black mt-1">{value}</p></div>)}
        <div className="sm:col-span-2 lg:col-span-4 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-5"><h3 className="font-black">Owner-only নিরাপত্তা নীতি</h3><p className="text-sm text-stone-500 mt-2">Admin menu UI-এর পাশাপাশি RBAC permission layer ব্যবহার করা হবে। Role Menu কেবল অনুমোদিত module/action দেখাবে; Admin menu কোনো non-owner-এর জন্য প্রকাশ করা হবে না।</p></div>
      </div>}

      {section === 'users' && <Panel title="ইউজার ও সহযোগী"><div className="space-y-3">{accounts.length===0 ? <div className="p-4 rounded-2xl border border-dashed text-sm text-stone-500">এখনো কোনো নিবন্ধিত account পাওয়া যায়নি।</div> : accounts.map(acc => <div key={acc.id} className="p-4 rounded-2xl border border-stone-200 dark:border-stone-700 space-y-3"><div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:justify-between"><div><b>{acc.nameBn || acc.name}</b><p className="text-xs text-stone-500">Username: {acc.username || '—'} · {acc.contact} · বর্তমান: {ROLE_LABELS[acc.role]}</p></div><div className="flex items-center gap-2"><select value={acc.role} disabled={acc.id===userAccount.id} onChange={e=>{ try { const updated=assignStoredAccountRole(userAccount, acc.id, e.target.value as UserRole, family.id); setAccounts(listStoredAccounts()); logAuditEvent({ eventType:'role_change', actorId:userAccount.id, actorName:userAccount.name, actorRole:userAccount.role, targetEntity:updated.id, details:`Role changed to ${updated.role}`, detailsBn:`ব্যবহারকারীর Role ${updated.role} করা হয়েছে।`, severity:'warning' }); } catch(err){ setCloudMessage(err instanceof Error?err.message:'Role update denied.'); } }} className="rounded-xl border px-3 py-2 text-xs bg-white dark:bg-stone-800">{(Object.keys(ROLE_LABELS) as UserRole[]).map(r=><option key={r} value={r}>{ROLE_LABELS[r]}</option>)}</select></div></div>{acc.id!==userAccount.id && <div className="flex flex-col sm:flex-row gap-2"><input type="password" value={passwordResetInputs[acc.id]||''} onChange={e=>setPasswordResetInputs(old=>({...old,[acc.id]:e.target.value}))} autoComplete="new-password" placeholder="নতুন অস্থায়ী পাসওয়ার্ড (কমপক্ষে ১০ অক্ষর)" className="flex-1 rounded-xl border px-3 py-2 text-xs bg-white dark:bg-stone-800"/><button type="button" onClick={()=>void resetAccountPassword(acc.id)} className="rounded-xl bg-amber-700 text-white px-4 py-2 text-xs font-bold">পাসওয়ার্ড রিসেট</button></div>}</div>)}</div>{passwordResetMessage && <p className="mt-3 rounded-xl border border-amber-200 bg-amber-50 dark:bg-amber-950/20 p-3 text-xs">{passwordResetMessage}</p>}<p className="mt-4 text-xs text-stone-500">রোল পরিবর্তন FamilyMembership-এ সংরক্ষিত হয়। অনুমোদিত Owner/Admin/Co-Admin অন্য ব্যবহারকারীর পাসওয়ার্ড রিসেট করতে পারবেন; অস্থায়ী পাসওয়ার্ড আলাদা নিরাপদ মাধ্যমে দিতে হবে।</p></Panel>}

      {section === 'roles' && <Panel title="রোল ব্যবস্থাপনা"><div className="grid md:grid-cols-3 gap-3">{(Object.keys(ROLE_LABELS) as UserRole[]).map(r=><button key={r} onClick={()=>selectRole(r)} className={`text-left p-4 rounded-2xl border ${selectedRole===r?'border-amber-600 bg-amber-50 dark:bg-amber-950/20':'border-stone-200 dark:border-stone-700'}`}><b>{ROLE_LABELS[r]}</b><p className="text-xs text-stone-500 mt-1">{Object.values(ROLE_PERMISSIONS[r]).filter(Boolean).length} permissions enabled</p></button>)}</div></Panel>}

      {section === 'menus' && <Panel title="Role Menu Management"><div className="flex flex-wrap gap-2 mb-4">{(Object.keys(ROLE_LABELS) as UserRole[]).map(r=><button key={r} onClick={()=>selectRole(r)} className={`px-3 py-2 rounded-xl text-xs font-bold ${selectedRole===r?'bg-amber-700 text-white':'bg-stone-100 dark:bg-stone-800'}`}>{ROLE_LABELS[r]}</button>)}</div><p className="text-sm text-stone-500 mb-3">{ROLE_LABELS[selectedRole]} কোন কোন মূল menu দেখতে পারবে তা নির্বাচন করুন।</p><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">{MODULES.map(([id,label])=><label key={id} className="flex items-center gap-3 p-3 rounded-xl border border-stone-200 dark:border-stone-700"><input type="checkbox" checked={selectedModules.includes(id)} onChange={()=>setSelectedModules(v=>v.includes(id)?v.filter(x=>x!==id):[...v,id])}/><span className="text-sm font-semibold">{label}</span></label>)}</div><button onClick={saveRoleMenu} className="mt-4 px-4 py-2 rounded-xl bg-amber-700 text-white font-bold text-sm"><Save className="w-4 h-4 inline mr-1.5"/>{saved?'সংরক্ষিত':'Role Menu সংরক্ষণ'}</button></Panel>}

      {section === 'permissions' && <Panel title={`Permission Management — ${ROLE_LABELS[selectedRole]}`}><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">{permissionList.map(([key,value])=><div key={key} className="p-3 rounded-xl border border-stone-200 dark:border-stone-700 flex items-center justify-between"><span className="text-xs font-semibold">{key.replace(/^can/, '').replace(/([A-Z])/g,' $1')}</span>{value?<CheckCircle2 className="w-4 h-4 text-emerald-600"/>:<XCircle className="w-4 h-4 text-stone-300"/>}</div>)}</div><p className="text-xs text-stone-500 mt-4">Action-level permissions: {ACTIONS.join(' • ')}</p></Panel>}

      {section === 'backup' && <Panel title="Gmail Backup ও Share">
        <div className="rounded-2xl border border-amber-200 bg-amber-50 dark:bg-amber-950/20 p-4 mb-4">
          <div className="text-sm font-black">Admin Recovery Gmail</div>
          <p className="text-xs text-stone-600 dark:text-stone-400 mt-1">এই ঠিকানাটি শুধু Owner-এর recovery/backup account হিসেবে সংরক্ষিত হবে। Password কখনো সফটওয়্যারে রাখা হবে না; Google OAuth ব্যবহার হবে।</p>
          <div className="flex flex-col sm:flex-row gap-2 mt-3"><input value={gmailAddress} onChange={e=>setGmailAddress(e.target.value)} type="email" placeholder="name@gmail.com" className="flex-1 rounded-xl border px-3 py-2 text-sm bg-white dark:bg-stone-900"/><button onClick={saveGmailAddress} className="rounded-xl bg-amber-700 text-white px-4 py-2 text-sm font-bold">Gmail সংরক্ষণ</button></div>
          {family.settings?.googleAccountEmail && <div className="mt-2 text-xs text-emerald-700">Recovery account: {family.settings.googleAccountEmail}</div>}
        </div>
        <FeatureRow icon={Cloud} title="Gmail / Google Drive Backup" text="Gmail password নয়—Google OAuth ব্যবহার করে Drive-এর private appDataFolder-এ encrypted/portable family archive সংরক্ষণ করা হয়।"/><div className="rounded-2xl border border-stone-200 dark:border-stone-700 p-4"><div className="flex flex-wrap gap-2 items-center"><button disabled={cloudBusy} onClick={connectAndBackupGoogle} className="rounded-xl bg-amber-700 px-4 py-2.5 text-sm font-bold text-white disabled:opacity-50">{cloudBusy?'Backup চলছে…':'Google account connect + Backup'}</button><button disabled={cloudBusy} onClick={()=>{disconnectGoogleDrive();setCloudEmail('');setCloudMessage('Google session disconnected.');}} className="rounded-xl border border-stone-300 px-4 py-2.5 text-sm font-bold dark:border-stone-700">Disconnect</button></div>{cloudEmail&&<p className="mt-2 text-xs text-emerald-700 dark:text-emerald-400">Connected: {cloudEmail}</p>}{cloudMessage&&<p className="mt-2 text-xs text-stone-600 dark:text-stone-400">{cloudMessage}</p>}</div><FeatureRow icon={Database} title="Family Data Share" text="QR, সাধারণ Join Code এবং full family package export-এর workflow."/><div className="mt-4 flex flex-wrap gap-2"><button onClick={shareFamilyPackage} className="rounded-xl bg-amber-700 px-4 py-2.5 text-sm font-bold text-white"><Share2 className="inline h-4 w-4 mr-1.5"/>পরিবারের ডাটা শেয়ার</button><button onClick={generateShareInvite} className="rounded-xl border border-stone-300 px-4 py-2.5 text-sm font-bold dark:border-stone-700"><QrCode className="inline h-4 w-4 mr-1.5"/>QR + Join Code তৈরি</button><button onClick={shareFamilyPackage} className="rounded-xl border border-stone-300 px-4 py-2.5 text-sm font-bold dark:border-stone-700"><Download className="inline h-4 w-4 mr-1.5"/>Share Package Export</button></div>{shareCode&&<div className="mt-5 grid md:grid-cols-2 gap-5 items-center rounded-2xl bg-stone-50 dark:bg-stone-950 p-5"><div>{shareQr&&<img src={shareQr} alt="Family join QR" className="w-48 h-48 mx-auto rounded-xl bg-white p-2"/>}</div><div><div className="text-xs text-stone-500">Join Code</div><div className="mt-1 text-2xl font-black font-mono tracking-wider">{shareCode}</div><button onClick={()=>navigator.clipboard?.writeText(shareCode)} className="mt-3 rounded-xl bg-stone-900 text-white px-4 py-2 text-xs font-bold"><Copy className="inline h-4 w-4 mr-1"/>Code কপি</button><p className="mt-3 text-xs text-stone-500">বংশ ও ব্যবহারকারীর কোনো expiry নেই; এই invite code-এর default expiry নেই এবং Owner চাইলে revoke করতে পারবেন।</p></div></div>}</Panel>}
      {section === 'sync' && <Panel title={isBn ? 'Server List ও Automatic Login' : 'Server List & Automatic Login'}>
        <FeatureRow icon={RefreshCw} title={isBn ? 'Server নির্বাচন → Login Page → Automatic Connection' : 'Select Server → Login Page → Automatic Connection'} text={isBn ? 'ব্যবহারকারী তালিকা থেকে server নির্বাচন করে Login Page খুলবেন। BONGSHOKOTHA server-এর login সফল হলে token ফেরত এসে health check হবে, server active হবে এবং পরের Share/Join/Sync কাজ স্বয়ংক্রিয়ভাবে সেই server ব্যবহার করবে।' : 'Select a server, open its Login Page, receive the authentication token, run a health check, activate the server, and use it automatically for the next Share/Join/Sync workflows.'}/>
        <div className="space-y-3">{serverProfiles.map(profile=><div key={profile.id} className={`rounded-2xl border p-4 ${activeServerId===profile.id?'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/20':'border-stone-200 dark:border-stone-700'}`}><div className="flex flex-col lg:flex-row gap-3 lg:items-end"><div className="flex-1"><div className="flex gap-2 items-center flex-wrap"><b>{isBn?profile.nameBn:profile.nameEn}</b><span className="text-[10px] rounded-full px-2 py-0.5 bg-stone-100 dark:bg-stone-800">{profile.status||'unknown'}</span>{profile.provider && <span className="text-[10px] rounded-full px-2 py-0.5 bg-blue-50 text-blue-700">{profile.provider}</span>}</div><input value={profile.endpoint} onChange={e=>saveServer(profile.id,{endpoint:e.target.value})} placeholder="https://server.example.com" className="mt-2 w-full rounded-xl border px-3 py-2 text-xs bg-white dark:bg-stone-900"/></div><div className="flex flex-wrap gap-2"><button onClick={()=>openServerLogin(profile)} disabled={!getServerLoginUrl(profile)} className="rounded-xl bg-amber-700 text-white px-4 py-2.5 text-sm font-bold disabled:opacity-40">{isBn ? 'লগইন পেজ' : 'Login Page'}</button><button disabled={serverBusyId===profile.id || !profile.endpoint.trim()} onClick={()=>connectServerProfile(profile)} className="rounded-xl bg-emerald-600 text-white px-4 py-2.5 text-sm font-bold disabled:opacity-40">{serverBusyId===profile.id ? (isBn ? 'সংযোগ হচ্ছে…' : 'Connecting…') : (isBn ? 'সংযোগ যাচাই' : 'Test Connection')}</button></div></div></div>)}</div>
        <p className="mt-3 text-xs text-stone-500">{serverLoginMessage || cloudMessage || (isBn ? 'Server নির্বাচন করুন, Login Page-এ প্রবেশ করুন; login সফল হলে active server ও পরের sync workflow স্বয়ংক্রিয় হবে।' : 'Select a server and open its Login Page. After successful login, it becomes the active server for the next sync workflows.')}</p>
      </Panel>}
      {section === 'succession' && <Panel title="পরবর্তী বংশমালিক">
        <div className="rounded-2xl border border-blue-200 bg-blue-50 dark:bg-blue-950/20 p-4 mb-4 text-xs text-blue-900 dark:text-blue-200">Owner সর্বোচ্চ ৫ জন সদস্যকে 1–5 priority দিতে পারবেন। কোনো priority-র সদস্য আগে মারা গেলে তার slot সতর্কতা হিসেবে দেখানো হবে; কোনো successor নির্ধারিত না থাকলে software কোনো নিজস্ব ‘আইন’ বানাবে না—প্রযোজ্য পারিবারিক নীতি/আইন অনুসারে সিদ্ধান্ত নেওয়ার জন্য সতর্কতা দেখাবে।</div>
        <div className="space-y-2">{[1,2,3,4,5].map(priority=>{const current=successors.find(x=>x.priority===priority); return <div key={priority} className="grid sm:grid-cols-[60px_1fr_1fr] gap-2 items-center rounded-xl border p-3"><b>#{priority}</b><select value={current?.memberId||''} onChange={e=>{const rest=successors.filter(x=>x.priority!==priority); setSuccessors(e.target.value?[...rest,{memberId:e.target.value,priority:priority as 1|2|3|4|5}]:rest)}} className="rounded-xl border px-3 py-2 text-sm bg-white dark:bg-stone-900"><option value="">সদস্য নির্বাচন করুন</option>{members.map(m=><option key={m.id} value={m.id}>{m.banglaName||m.fullName}{m.isLiving===false?' — মৃত':''}</option>)}</select><input value={current?.note||''} onChange={e=>setSuccessors(v=>v.map(x=>x.priority===priority?{...x,note:e.target.value}:x))} placeholder="নোট (ঐচ্ছিক)" className="rounded-xl border px-3 py-2 text-sm bg-white dark:bg-stone-900"/></div>})}</div>
        <button onClick={saveSuccessors} className="mt-4 rounded-xl bg-amber-700 text-white px-4 py-2.5 text-sm font-bold">উত্তরাধিকার তালিকা সংরক্ষণ</button>
      </Panel>}
      {section === 'proposals' && <Panel title="Contributor Proposals"><FeatureRow icon={ClipboardCheck} title="Pending Proposals" text="Contributor-এর প্রস্তাবিত সদস্য/তথ্য পরিবর্তন review করে Approve বা Reject করার কেন্দ্র."/><FeatureRow icon={CheckCircle2} title="Approval Gate" text="Approval ছাড়া contributor-এর প্রস্তাবিত sensitive change সরাসরি master data overwrite করবে না."/></Panel>}
      {section === 'integrity' && (checkPermission('canRunIntegrityRepair') ? <IntegrityRepairView onSelectMember={() => { setSection('users'); }} /> : <Panel title="Data Integrity ও Repair"><p className="text-sm text-stone-500">এই কাজের জন্য আপনার অনুমতি নেই।</p></Panel>)}
      {section === 'audit' && <Panel title="Audit ও Activity Log"><FeatureRow icon={Activity} title="Immutable-style Activity View" text="Role change, delete/restore, import/export, backup, repair, approval এবং sensitive document access-এর history."/></Panel>}
    </div>
  );
};

const Panel: React.FC<{title:string;children:React.ReactNode}> = ({title,children}) => <section className="rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-5 shadow-sm"><h2 className="text-lg font-black mb-4">{title}</h2>{children}</section>;
const FeatureRow: React.FC<{icon:React.ElementType;title:string;text:string}> = ({icon:Icon,title,text}) => <div className="flex gap-4 p-4 rounded-2xl border border-stone-200 dark:border-stone-700 mb-3"><Icon className="w-5 h-5 text-amber-600 mt-0.5 shrink-0"/><div><b>{title}</b><p className="text-sm text-stone-500 mt-1">{text}</p></div></div>;
