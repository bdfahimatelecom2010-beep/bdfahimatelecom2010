/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * New Family Lineage Creation Modal
 */

import React, { useState } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { X, TreeDeciduous, Plus, Save } from 'lucide-react';

interface FamilyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FamilyModal: React.FC<FamilyModalProps> = ({
  isOpen,
  onClose
}) => {
  const { createNewFamily, language } = useGenealogy();
  const isBn = language === 'bn';

  const [name, setName] = useState('');
  const [banglaName, setBanglaName] = useState('');
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    await createNewFamily(
      name.trim(),
      banglaName.trim() || name.trim(),
      description.trim() || undefined
    );
    setName('');
    setBanglaName('');
    setDescription('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md rounded-2xl border border-amber-900/15 bg-white p-6 shadow-2xl dark:border-stone-800 dark:bg-stone-900">
        <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-800 text-white">
              <TreeDeciduous className="h-4 w-4" />
            </div>
            <h3 className="font-serif font-bold text-base text-amber-950 dark:text-amber-100">
              {isBn ? 'নতুন পারিবারিক স্পেস তৈরি' : 'Create New Family Lineage'}
            </h3>
          </div>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-700">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
              {isBn ? 'পরিবারের ইংরেজি নাম (Family Name) *' : 'Family Name (English) *'}
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Khan Bongsho"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
              {isBn ? 'পরিবারের বাংলা নাম (Bangla Name)' : 'Bangla Name'}
            </label>
            <input
              type="text"
              placeholder="যেমন: খান বংশ"
              value={banglaName}
              onChange={e => setBanglaName(e.target.value)}
              className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
              {isBn ? 'সংক্ষিপ্ত ইতিহাস বা পরিচিতি' : 'Description / Heritage Summary'}
            </label>
            <textarea
              rows={3}
              placeholder={isBn ? 'পরিবারের আদি নিবাস ও ইতিবৃত্ত...' : 'Origin location and heritage summary...'}
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200 dark:border-stone-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 dark:text-stone-400 dark:hover:bg-stone-800"
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 rounded-xl bg-amber-800 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-amber-900 transition dark:bg-amber-700"
            >
              <Plus className="h-4 w-4" />
              <span>{isBn ? 'পরিবার তৈরি করুন' : 'Create Space'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
