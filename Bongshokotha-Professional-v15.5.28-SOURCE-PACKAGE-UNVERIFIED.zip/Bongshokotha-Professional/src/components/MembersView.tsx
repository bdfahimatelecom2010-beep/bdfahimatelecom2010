/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Members Lineage Registry & Generational Directory
 * 
 * User Requirement:
 * "সকল সদস্য মেনুতে প্রজন্ম হিসাবে দেখাবে, সর্বদা প্রজন্মের বড় সন্তানের সন্তানদের আগে দেখাবে।"
 * (All members displayed grouped by GENERATION, and within each generation,
 * ALWAYS show the descendants/children of the eldest child first).
 */

import React, { useState, useMemo } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { useThemeRegistry } from '../context/ThemeRegistry';
import { Member } from '../types/genealogy';
import { getMemberColor, MEMBER_COLOR_LEGEND } from '../engine/memberColor';
import { getVisibleFamilyMembers } from '../engine/familyVisibility';
import { sortMembersByCanonicalGenealogyOrder } from '../engine/genealogyOrdering';
import { toBanglaDigits, formatGenealogyDate, calculateLifespan } from '../engine/banglaCalendar';
import {
  Users,
  Search,
  Filter,
  Plus,
  ShieldCheck,
  Calendar,
  MapPin,
  FileText,
  Trash2,
  Edit3,
  ExternalLink,
  Eye,
  EyeOff,
  LayoutGrid,
  List,
  Layers,
  Heart,
  GitFork,
  Image as ImageIcon,
  Crown,
  ChevronDown,
  ChevronUp,
  Sparkles,
  CheckSquare,
  Square,
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';

interface MembersViewProps {
  onOpenAddMember: () => void;
  onEditMember: (member: Member) => void;
  onSelectMember: (memberId: string) => void;
}

type CardStyle = 'classic' | 'compact' | 'detailed' | 'photo' | 'genealogy' | 'professional';

// Deterministic lineage ordering: for every member, follow both biological
// parent paths and choose the lexicographically earliest (eldest) family line.
function lineageCandidates(member: Member, memberMap: Map<string, Member>, visiting = new Set<string>()): number[][] {
  if (visiting.has(member.id)) return [[999999]];
  const nextVisited = new Set(visiting).add(member.id);
  const ownOrder = member.birthOrder ?? 999999;
  const parents = [member.fatherId, member.motherId].filter((id): id is string => Boolean(id && memberMap.has(id)));
  if (!parents.length) return [[ownOrder]];
  const paths: number[][] = [];
  for (const parentId of parents) {
    const parent = memberMap.get(parentId)!;
    for (const parentPath of lineageCandidates(parent, memberMap, nextVisited)) paths.push([...parentPath, ownOrder]);
  }
  return paths.length ? paths : [[ownOrder]];
}

function computeLineageSortPath(member: Member, memberMap: Map<string, Member>): number[] {
  const paths = lineageCandidates(member, memberMap);
  paths.sort((a, b) => {
    const len = Math.max(a.length, b.length);
    for (let i = 0; i < len; i++) {
      const av = a[i] ?? 0;
      const bv = b[i] ?? 0;
      if (av !== bv) return av - bv;
    }
    return a.length - b.length;
  });
  return paths[0] || [999999];
}

function compareLineagePaths(pathA: number[], pathB: number[]): number {
  const len = Math.max(pathA.length, pathB.length);
  for (let i = 0; i < len; i++) {
    const valA = i < pathA.length ? pathA[i] : 0;
    const valB = i < pathB.length ? pathB[i] : 0;
    if (valA !== valB) return valA - valB;
  }
  return pathA.length - pathB.length;
}

export const MembersView: React.FC<MembersViewProps> = ({
  onOpenAddMember,
  onEditMember,
  onSelectMember
}) => {
  const {
    members,
    marriages,
    branches,
    generations,
    generationSummary,
    deleteMember,
    deleteMultipleMembers,
    language,
    recalculateAndPersistGenerations
  } = useGenealogy();

  const themeRegistry = useThemeRegistry();
  const { colors, currentTheme } = themeRegistry;
  const isBn = language === 'bn';

  // Filters and States
  const [search, setSearch] = useState('');
  const [filterBranch, setFilterBranch] = useState('all');
  const [filterLiving, setFilterLiving] = useState('all');
  const [filterGender, setFilterGender] = useState('all');
  const [filterMissing, setFilterMissing] = useState('all');
  const [cardStyle, setCardStyle] = useState<CardStyle>('professional');
  const [revealedNids, setRevealedNids] = useState<Set<string>>(new Set());
  const [activeGenFilter, setActiveGenFilter] = useState<number | 'all'>('all');
  const [collapsedGens, setCollapsedGens] = useState<Set<number>>(new Set());
  const [sortMode, setSortMode] = useState<'lineage' | 'newest' | 'name' | 'birth'>('lineage');
  const [isRecalculating, setIsRecalculating] = useState(false);

  // Selection & Bulk Cleanup States
  const [memberToDelete, setMemberToDelete] = useState<Member | null>(null);
  const [selectedMemberIds, setSelectedMemberIds] = useState<Set<string>>(new Set());
  const [isBatchDeleteDialogOpen, setIsBatchDeleteDialogOpen] = useState(false);
  const [isSelectionMode, setIsSelectionMode] = useState(false);

  const memberMap = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);

  const toggleRevealNid = (memberId: string) => {
    setRevealedNids(prev => {
      const next = new Set(prev);
      if (next.has(memberId)) next.delete(memberId);
      else next.add(memberId);
      return next;
    });
  };

  const toggleCollapseGen = (gen: number) => {
    setCollapsedGens(prev => {
      const next = new Set(prev);
      if (next.has(gen)) next.delete(gen);
      else next.add(gen);
      return next;
    });
  };

  // Filter members first
  const visibleFamilyMembers = useMemo(() => getVisibleFamilyMembers(members, marriages), [members, marriages]);

  const filteredMembers = useMemo(() => {
    return visibleFamilyMembers.filter(m => {
      if (filterBranch !== 'all' && m.branchId !== filterBranch) return false;
      if (filterLiving === 'living' && !m.isLiving) return false;
      if (filterLiving === 'deceased' && m.isLiving) return false;
      if (filterGender !== 'all' && m.gender !== filterGender) return false;

      if (filterMissing === 'nid' && (m.identityDocs?.nidNumber || m.identityDocs?.birthRegistrationNumber)) return false;
      if (filterMissing === 'birth' && m.birth?.date?.year) return false;
      if (filterMissing === 'parents' && (m.fatherId || m.motherId || (generations.get(m.id) || 1) === 1)) return false;

      if (search.trim()) {
        const q = search.toLowerCase();
        const matches =
          m.fullName?.toLowerCase().includes(q) ||
          m.banglaName?.toLowerCase().includes(q) ||
          m.englishName?.toLowerCase().includes(q) ||
          m.nickname?.toLowerCase().includes(q) ||
          m.identityDocs?.nidNumber?.includes(q) ||
          m.identityDocs?.birthRegistrationNumber?.includes(q) ||
          m.birth?.place?.district?.toLowerCase().includes(q);
        if (!matches) return false;
      }

      return true;
    });
  }, [visibleFamilyMembers, filterBranch, filterLiving, filterGender, filterMissing, search, generations]);

  const effectiveGeneration = (m: Member) => m.generationMode === 'manual' && m.generationOverride ? m.generationOverride : (m.computedGeneration || generations.get(m.id) || 1);

  // Generation remains metadata/filtering; the actual "All Generations" display
  // uses the canonical recursive genealogy traversal so an elder sibling's
  // COMPLETE descendant branch finishes before the next sibling branch starts.
  const canonicalRank = useMemo(() => {
    const ordered = sortMembersByCanonicalGenealogyOrder(visibleFamilyMembers, marriages);
    return new Map(ordered.map((m, index) => [m.id, index]));
  }, [visibleFamilyMembers, marriages]);

  const groupedByGeneration = useMemo(() => {
    const map = new Map<number, Member[]>();
    const maxGen = Math.max(generationSummary.maxGeneration, 1);

    for (let i = 1; i <= maxGen; i++) map.set(i, []);

    if (sortMode === 'lineage' && activeGenFilter === 'all') {
      map.set(0, filteredMembers.slice().sort((a, b) =>
        (canonicalRank.get(a.id) ?? 999999) - (canonicalRank.get(b.id) ?? 999999)
      ));
      return map;
    }

    filteredMembers.forEach(m => {
      const gen = effectiveGeneration(m);
      if (!map.has(gen)) map.set(gen, []);
      map.get(gen)!.push(m);
    });

    // A marriage-origin member is a presentation companion, not a new branch root.
    // Its rank is always immediately after its birth-origin spouse. Never put
    // all in-married members at the beginning of a generation.
    const spouseAdjacentRank = (member: Member) => {
      const joined = member.birthOrigin === 'joined_by_marriage' || member.marriageOrigin === true;
      if (!joined) return (canonicalRank.get(member.id) ?? 999999) * 2;
      const links = marriages.filter(m => m.husbandId === member.id || m.wifeId === member.id);
      const birthLineSpouse = links
        .map(m => m.husbandId === member.id ? m.wifeId : m.husbandId)
        .map(id => filteredMembers.find(x => x.id === id))
        .find(Boolean);
      const spouseRank = birthLineSpouse ? (canonicalRank.get(birthLineSpouse.id) ?? 999999) : 999999;
      return spouseRank * 2 + 1;
    };

    map.forEach((genList, gen) => {
      if (gen === 0) return;
      genList.sort((a, b) => {
        if (sortMode === 'lineage') return spouseAdjacentRank(a) - spouseAdjacentRank(b);
        if (sortMode === 'newest') {
          const rankDiff = spouseAdjacentRank(a) - spouseAdjacentRank(b);
          return rankDiff !== 0 ? rankDiff : b.createdAt.localeCompare(a.createdAt);
        }
        if (sortMode === 'name') {
          const rankDiff = spouseAdjacentRank(a) - spouseAdjacentRank(b);
          return rankDiff !== 0 ? rankDiff : (a.banglaName || a.fullName).localeCompare(b.banglaName || b.fullName, 'bn');
        }
        if (sortMode === 'birth') {
          const ao = a.birthOrder ?? 999999;
          const bo = b.birthOrder ?? 999999;
          if (ao !== bo) return ao - bo;
          const ay = a.birth?.date?.year || 9999;
          const by = b.birth?.date?.year || 9999;
          if (ay !== by) return ay - by;
        }
        return spouseAdjacentRank(a) - spouseAdjacentRank(b);
      });
    });

    return map;
  }, [filteredMembers, generations, generationSummary.maxGeneration, memberMap, marriages, sortMode, activeGenFilter, canonicalRank]);

  const availableGenerations = useMemo(() => Array.from(new Set(filteredMembers.map(effectiveGeneration))).sort((a, b) => a - b), [filteredMembers, generations]);

  const toggleSelectMember = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedMemberIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAllFiltered = () => {
    setSelectedMemberIds(new Set(filteredMembers.map(m => m.id)));
  };

  const clearSelection = () => {
    setSelectedMemberIds(new Set());
  };

  const handleDelete = (member: Member, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setMemberToDelete(member);
  };

  const genTitlesBn = [
    '১ম প্রজন্ম — আদি মূল পূর্বপুরুষ (Roots)',
    '২য় প্রজন্ম — দ্বিতীয় স্তর',
    '৩য় প্রজন্ম — তৃতীয় স্তর (জ্যেষ্ঠ ধারা প্রথমে)',
    '৪র্থ প্রজন্ম — চতুর্থ স্তর',
    '৫ম প্রজন্ম — পঞ্চম স্তর',
    '৬ষ্ঠ প্রজন্ম — ষষ্ঠ স্তর',
    '৭ম প্রজন্ম — সপ্তম স্তর',
    '৮ম প্রজন্ম — অষ্টম স্তর',
    '৯ম প্রজন্ম — নবম স্তর',
    '১০ম প্রজন্ম — দশম স্তর'
  ];

  const genTitlesEn = [
    '1st Generation — Root Ancestors',
    '2nd Generation — Second Tier',
    '3rd Generation — Third Tier (Eldest Lineage First)',
    '4th Generation — Fourth Tier',
    '5th Generation — Fifth Tier',
    '6th Generation — Sixth Tier',
    '7th Generation — Seventh Tier',
    '8th Generation — Eighth Tier',
    '9th Generation — Ninth Tier',
    '10th Generation — Tenth Tier'
  ];

  return (
    <div className="space-y-6 pb-20 select-none">
      
      {/* Top Header & Quick Action */}
      <div
        className="flex flex-col gap-4 rounded-3xl p-5 sm:p-6 border shadow-xs transition-all md:flex-row md:items-center md:justify-between"
        style={{
          backgroundColor: colors.surface,
          borderColor: `${colors.primary}25`
        }}
      >
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span
              className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border shadow-2xs"
              style={{
                backgroundColor: `${colors.primary}18`,
                color: colors.primary,
                borderColor: `${colors.primary}35`
              }}
            >
              {isBn ? 'প্রজন্মভিত্তিক তালিকা' : 'Generational Directory'}
            </span>
            <span className="text-xs text-stone-500 font-sans">
              {isBn ? '• সর্বদা বড় সন্তানের বংশধর অগ্রাধিকার' : '• Eldest child lineage priority'}
            </span>
          </div>

          <h2 className="font-serif text-xl sm:text-2xl font-bold flex items-center gap-2" style={{ color: colors.text }}>
            <Users className="h-6 w-6" style={{ color: colors.primary }} />
            <span>{isBn ? 'সকল সদস্য ও বংশধর রেজিস্ট্রি' : 'All Clan Members & Lineage'}</span>
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            {isBn
              ? `মোট ${toBanglaDigits(filteredMembers.length)} জন সদস্য • প্রজন্ম ১ থেকে শুরু করে প্রতি স্তরে জ্যেষ্ঠ সন্তানের শাখা ক্রমানুসারে সজ্জিত।`
              : `Total ${filteredMembers.length} members grouped by generation with eldest sibling lineages first.`}
          </p>
        </div>

        {/* Card Style Selector and Add Button */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-2xl p-1 border shadow-xs" style={{ backgroundColor: colors.card, borderColor: colors.border }}>
            {[
              { id: 'classic', labelBn: 'ক্লাসিক', labelEn: 'Classic' },
              { id: 'compact', labelBn: 'কম্প্যাক্ট', labelEn: 'Compact' },
              { id: 'detailed', labelBn: 'বিস্তারিত', labelEn: 'Detailed' },
              { id: 'photo', labelBn: 'পোর্ট্রেট', labelEn: 'Photo' },
              { id: 'genealogy', labelBn: 'রক্তধারা', labelEn: 'Lineage' },
              { id: 'professional', labelBn: 'প্রফেশনাল', labelEn: 'Professional' }
            ].map(style => (
              <button
                key={style.id}
                onClick={() => setCardStyle(style.id as CardStyle)}
                className="px-2.5 py-1.5 rounded-xl text-xs font-bold transition"
                style={
                  cardStyle === style.id
                    ? { backgroundColor: colors.primary, color: '#ffffff' }
                    : { color: colors.text }
                }
              >
                {isBn ? style.labelBn : style.labelEn}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => {
              setIsSelectionMode(prev => !prev);
              if (isSelectionMode) clearSelection();
            }}
            className={`inline-flex items-center gap-1.5 rounded-2xl px-3.5 py-2 text-xs font-bold border transition ${
              isSelectionMode || selectedMemberIds.size > 0
                ? 'border-amber-500 bg-amber-50 text-amber-900 dark:bg-amber-950/60 dark:text-amber-200'
                : 'border-stone-300 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
          >
            <CheckSquare className="h-4 w-4" />
            <span>{isSelectionMode ? (isBn ? 'নির্বাচন সম্পন্ন' : 'Done') : (isBn ? 'একাধিক নির্বাচন / মুছুন' : 'Select Mode')}</span>
          </button>

          <button
            onClick={onOpenAddMember}
            className="inline-flex items-center gap-1.5 rounded-2xl px-4 py-2.5 text-xs font-bold text-white shadow-md active:scale-95 transition"
            style={{ backgroundColor: colors.primary }}
          >
            <Plus className="h-4 w-4" />
            <span>{isBn ? 'নতুন সদস্য' : 'Add Member'}</span>
          </button>
        </div>
      </div>

      {/* Generation Quick Jump Filter Bar */}
      <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none">
        <button
          onClick={() => setActiveGenFilter('all')}
          className="px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition border shadow-xs"
          style={
            activeGenFilter === 'all'
              ? { backgroundColor: colors.primary, color: '#ffffff', borderColor: colors.primary }
              : { backgroundColor: colors.card, color: colors.text, borderColor: colors.border }
          }
        >
          {isBn ? 'সকল প্রজন্ম' : 'All Generations'} ({filteredMembers.length})
        </button>

        {availableGenerations.map(gen => {
          const count = filteredMembers.filter(m => effectiveGeneration(m) === gen).length;
          if (count === 0 && search) return null;
          const isSelected = activeGenFilter === gen;

          return (
            <button
              key={gen}
              onClick={() => setActiveGenFilter(gen)}
              className="px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition border shadow-xs flex items-center gap-1.5"
              style={
                isSelected
                  ? { backgroundColor: colors.primary, color: '#ffffff', borderColor: colors.primary }
                  : { backgroundColor: colors.card, color: colors.text, borderColor: colors.border }
              }
            >
              <span>{isBn ? `${toBanglaDigits(gen)}ম প্রজন্ম` : `Gen ${gen}`}</span>
              <span
                className="px-1.5 py-0.2 rounded-md text-[10px] font-mono"
                style={{
                  backgroundColor: isSelected ? 'rgba(255,255,255,0.25)' : `${colors.primary}18`,
                  color: isSelected ? '#ffffff' : colors.primary
                }}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Search and Secondary Filter Controls Bar */}
      <div
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 rounded-2xl p-4 border shadow-xs"
        style={{ backgroundColor: colors.card, borderColor: colors.border }}
      >
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-stone-400" />
          <input
            type="text"
            placeholder={isBn ? 'নাম, ক্রমিক নম্বর, NID...' : 'Search name, serial, NID...'}
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full rounded-xl border pl-9 pr-3 py-2 text-xs focus:outline-none"
            style={{ backgroundColor: colors.surface, borderColor: colors.border, color: colors.text }}
          />
        </div>

        <select
          value={filterBranch}
          onChange={e => setFilterBranch(e.target.value)}
          className="rounded-xl border px-3 py-2 text-xs focus:outline-none"
          style={{ backgroundColor: colors.surface, borderColor: colors.border, color: colors.text }}
        >
          <option value="all">{isBn ? 'সকল শাখা' : 'All Branches'}</option>
          {branches.map(b => (
            <option key={b.id} value={b.id}>{isBn ? b.banglaName || b.name : b.name}</option>
          ))}
        </select>

        <select
          value={filterLiving}
          onChange={e => setFilterLiving(e.target.value)}
          className="rounded-xl border px-3 py-2 text-xs focus:outline-none"
          style={{ backgroundColor: colors.surface, borderColor: colors.border, color: colors.text }}
        >
          <option value="all">{isBn ? 'জীবিত ও প্রয়াত (সকল)' : 'Living & Deceased'}</option>
          <option value="living">{isBn ? 'শুধুমাত্র জীবিত' : 'Living only'}</option>
          <option value="deceased">{isBn ? 'প্রয়াত পূর্বপুরুষ' : 'Deceased only'}</option>
        </select>

        <select
          value={filterMissing}
          onChange={e => setFilterMissing(e.target.value)}
          className="rounded-xl border px-3 py-2 text-xs focus:outline-none"
          style={{ backgroundColor: colors.surface, borderColor: colors.border, color: colors.text }}
        >
          <option value="all">{isBn ? 'তথ্য সম্পূর্ণতা (সকল)' : 'Completeness (All)'}</option>
          <option value="nid">{isBn ? 'NID/জন্ম সনদ অনুপস্থিত' : 'Missing NID/BRN'}</option>
          <option value="birth">{isBn ? 'জন্ম সন অনুপস্থিত' : 'Missing Birth Year'}</option>
          <option value="parents">{isBn ? 'পিতামাতা অনুল্লিখিত' : 'Missing Parents'}</option>
        </select>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-3" style={{ borderColor: colors.border, backgroundColor: colors.surface }}>
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-stone-500">{isBn ? 'সাজানো:' : 'Sort:'}</span>
          {[['lineage', 'বংশধারা'], ['birth', 'জন্মক্রম'], ['newest', 'নতুন আগে'], ['name', 'নাম']].map(([id, label]) => (
            <button key={id} type="button" onClick={() => setSortMode(id as typeof sortMode)} className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold ${sortMode === id ? 'bg-amber-700 text-white' : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300'}`}>{isBn ? label : id}</button>
          ))}
        </div>
        <button type="button" disabled={isRecalculating} onClick={async () => { setIsRecalculating(true); try { await recalculateAndPersistGenerations(); } finally { setIsRecalculating(false); } }} className="inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[11px] font-bold hover:bg-stone-100 disabled:opacity-50" style={{ borderColor: colors.border, color: colors.primary }}>
          <GitFork className="w-3.5 h-3.5" /> {isRecalculating ? (isBn ? 'গণনা হচ্ছে…' : 'Calculating…') : (isBn ? 'প্রজন্ম পুনর্গণনা ও সাজান' : 'Recalculate & Arrange Generations')}
        </button>
      </div>

      {/* RENDER MEMBERS GROUPED BY GENERATION */}
      {filteredMembers.length === 0 ? (
        <div className="rounded-3xl border border-dashed p-12 text-center text-xs text-stone-400" style={{ borderColor: colors.border }}>
          {isBn ? 'কোনো সদস্য খুঁজে পাওয়া যায়নি।' : 'No members found matching filters.'}
        </div>
      ) : (
        <div>
          <div className="mb-4 rounded-2xl border p-3" style={{ borderColor: colors.border, backgroundColor: colors.surface }}>
            <div className="text-[11px] font-bold mb-2" style={{ color: colors.text }}>{isBn ? 'সদস্যের রঙের অর্থ' : 'Member color legend'}</div>
            <div className="flex flex-wrap gap-2">
              {MEMBER_COLOR_LEGEND.map(item => <span key={item.key} className="inline-flex items-center gap-1.5 rounded-full border px-2 py-1 text-[10px] font-semibold" style={{ borderColor:item.border, backgroundColor:item.soft, color:item.text }}><i className="h-2 w-2 rounded-full" style={{backgroundColor:item.accent}} />{isBn ? item.bn : item.en}</span>)}
            </div>
          </div>
          <div className="space-y-8">
          {Array.from(groupedByGeneration.keys())
            .filter(gen => (sortMode === 'lineage' && activeGenFilter === 'all' ? gen === 0 : (activeGenFilter === 'all' || activeGenFilter === gen)))
            .map(gen => {
              const genMembers = groupedByGeneration.get(gen) || [];
              if (genMembers.length === 0) return null;
              const isCollapsed = collapsedGens.has(gen);

              return (
                <div
                  key={gen}
                  className="rounded-3xl border shadow-xs overflow-hidden transition-all"
                  style={{
                    backgroundColor: colors.surface,
                    borderColor: `${colors.primary}25`
                  }}
                >
                  {/* Generation Tier Header */}
                  <div
                    onClick={() => toggleCollapseGen(gen)}
                    className="flex items-center justify-between p-4 sm:p-5 cursor-pointer border-b hover:bg-black/5 dark:hover:bg-white/5 transition"
                    style={{ borderColor: `${colors.primary}20` }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-2xl flex items-center justify-center font-serif text-base font-bold text-white shadow-sm shrink-0"
                        style={{ backgroundColor: colors.primary }}
                      >
                        {gen === 0 ? '↕' : (isBn ? toBanglaDigits(gen) : gen)}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-serif text-base sm:text-lg font-bold" style={{ color: colors.text }}>
                            {gen === 0 ? (isBn ? 'সম্পূর্ণ বংশানুক্রমিক তালিকা' : 'Complete Genealogical Branch Order') : (isBn ? genTitlesBn[gen - 1] || `${toBanglaDigits(gen)}ম প্রজন্ম` : genTitlesEn[gen - 1] || `Generation ${gen}`)}
                          </h3>
                          <span
                            className="px-2 py-0.5 rounded-md text-[10px] font-bold border"
                            style={{
                              backgroundColor: `${colors.primary}15`,
                              color: colors.primary,
                              borderColor: `${colors.primary}30`
                            }}
                          >
                            {genMembers.length} {isBn ? 'জন' : 'members'}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-500 mt-0.5">
                          {gen === 0
                            ? (isBn ? 'পিতা → বড় সন্তান → তার সম্পূর্ণ বংশ → পরের সন্তান; বিবাহসূত্রে সদস্য নিজের জন্মক্রম দিয়ে এই শাখার ক্রম বদলাবে না।' : 'Parent → eldest child → complete descendant branch → next sibling; a married-in member’s own birth order never changes this branch order.')
                            : (isBn ? 'এই প্রজন্মের সদস্যরা একই বংশগত শাখার ক্রম অনুসরণ করছে।' : 'Members in this generation follow the canonical family-branch order.')}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-stone-400">
                      <span className="hidden sm:inline-block text-[11px] font-mono text-stone-500">
                        {isCollapsed ? (isBn ? 'প্রদর্শন করুন' : 'Expand') : (isBn ? 'সংকোচন' : 'Collapse')}
                      </span>
                      {isCollapsed ? <ChevronDown className="w-5 h-5" /> : <ChevronUp className="w-5 h-5" />}
                    </div>
                  </div>

                  {/* Generation Members Grid */}
                  {!isCollapsed && (
                    <div className="p-4 sm:p-6">
                      <div className={`grid gap-4 ${
                        cardStyle === 'compact'
                          ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
                          : cardStyle === 'photo'
                          ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4'
                          : cardStyle === 'detailed'
                          ? 'grid-cols-1 md:grid-cols-2'
                          : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
                      }`}>
                        {genMembers.map(member => {
                          const branch = branches.find(b => b.id === member.branchId);
                          const father = member.fatherId ? memberMap.get(member.fatherId) : null;
                          const mother = member.motherId ? memberMap.get(member.motherId) : null;
                          const isRevealed = revealedNids.has(member.id);
                          const lifespan = calculateLifespan(member.birth?.date, member.death?.date, member.isLiving, language);
                          const isEldestChild = member.birthOrder === 1;
                          const isSelected = selectedMemberIds.has(member.id);
                          const memberColor = getMemberColor(member);
                          const linkedMarriages = marriages.filter(m => m.husbandId === member.id || m.wifeId === member.id);
                          const marriageCount = linkedMarriages.length;
                          const listSpouses = member.birthOrigin === 'born_in_family'
                            ? linkedMarriages
                                .sort((a, b) => Number(b.status === 'current') - Number(a.status === 'current') || String(b.updatedAt).localeCompare(String(a.updatedAt)))
                                .map(m => memberMap.get(m.husbandId === member.id ? m.wifeId : m.husbandId))
                                .filter(Boolean)
                            : [];

                          // STYLE 0: PROFESSIONAL — based on the legacy Windows EXE member-card
                          // layout, while retaining the current data model and relationship engine.
                          if (cardStyle === 'professional') {
                            const categoryLabel = isBn ? memberColor.bn : memberColor.en;
                            const displayName = isBn ? member.banglaName || member.fullName : member.englishName || member.fullName;
                            const fatherName = father ? (isBn ? father.banglaName || father.fullName : father.englishName || father.fullName) : undefined;
                            const motherName = mother ? (isBn ? mother.banglaName || mother.fullName : mother.englishName || mother.fullName) : undefined;
                            const address = member.currentAddress?.fullAddress
                              || member.currentAddress?.village
                              || member.currentAddress?.district;
                            return (
                              <div
                                key={member.id}
                                data-member-color={memberColor.key}
                                onClick={() => onSelectMember(member.id)}
                                className={`group relative flex flex-col justify-between rounded-2xl border-2 p-4 shadow-xs cursor-pointer transition-all hover:-translate-y-0.5 hover:shadow-md ${
                                  isSelected ? 'ring-2 ring-amber-500' : ''
                                }`}
                                style={{
                                  backgroundColor: memberColor.soft,
                                  borderColor: isSelected ? colors.primary : memberColor.accent
                                }}
                              >
                                <div className="space-y-3">
                                  <div
                                    className="flex items-center justify-between gap-2 border-b pb-2"
                                    style={{ borderColor: `${memberColor.border}80` }}
                                  >
                                    <div className="flex items-center gap-2 min-w-0">
                                      <button
                                        type="button"
                                        onClick={(e) => toggleSelectMember(member.id, e)}
                                        className={`p-0.5 rounded transition shrink-0 ${
                                          isSelected ? 'text-amber-600' : 'text-stone-500 hover:text-amber-600'
                                        }`}
                                        title={isSelected ? 'Deselect' : 'Select'}
                                      >
                                        {isSelected ? <CheckSquare className="w-4 h-4 text-amber-600" /> : <Square className="w-4 h-4" />}
                                      </button>
                                      <span
                                        className="px-2 py-0.5 rounded-lg text-[10px] font-bold text-white truncate"
                                        style={{ backgroundColor: memberColor.accent }}
                                      >
                                        {categoryLabel}
                                      </span>
                                    </div>
                                    <span
                                      className="px-2 py-0.5 rounded font-mono font-bold text-[10px] shrink-0"
                                      style={{ backgroundColor: `${colors.primary}18`, color: colors.primary }}
                                    >
                                      {isBn ? `${toBanglaDigits(effectiveGeneration(member))}ম প্রজন্ম` : `Gen ${effectiveGeneration(member)}`}
                                    </span>
                                  </div>

                                  <div className="flex items-start gap-3">
                                    <div className="relative shrink-0">
                                      {member.profilePhoto ? (
                                        <img
                                          src={member.profilePhoto}
                                          alt={displayName}
                                          referrerPolicy="no-referrer"
                                          onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.style.display = 'none'; }}
                                          className="w-14 h-14 rounded-2xl object-cover border-2 shadow-xs bg-stone-100"
                                          style={{ borderColor: memberColor.accent }}
                                        />
                                      ) : (
                                        <div
                                          className="w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-xl border-2 bg-stone-100"
                                          style={{ color: memberColor.text, borderColor: memberColor.accent, backgroundColor: memberColor.soft }}
                                        >
                                          {displayName?.charAt(0) || '?'}
                                        </div>
                                      )}
                                      <span
                                        className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center text-[8px] font-bold text-white ${
                                          member.isLiving ? 'bg-emerald-600' : 'bg-rose-600'
                                        }`}
                                      >
                                        {member.isLiving ? '✓' : '✝'}
                                      </span>
                                    </div>

                                    <div className="min-w-0 flex-1">
                                      <h3 className="font-serif text-sm font-bold truncate" style={{ color: memberColor.text }}>
                                        {displayName}
                                      </h3>
                                      {member.englishName && isBn && (
                                        <p className="text-[10px] truncate" style={{ color: colors.textMuted }}>
                                          {member.englishName}
                                        </p>
                                      )}
                                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                                        <span
                                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-xs font-semibold border ${
                                            member.isLiving
                                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                              : 'bg-rose-50 text-rose-800 border-rose-300'
                                          }`}
                                          title={lifespan || ''}
                                        >
                                          <span className="text-[11px]">{member.isLiving ? '🎂' : '🕯️'}</span>
                                          <span>{lifespan}</span>
                                        </span>
                                        {member.birth?.date?.isoString && (
                                          <span
                                            className="text-[10px] px-1.5 py-0.5 rounded border opacity-80"
                                            style={{ borderColor: colors.border, color: colors.textMuted }}
                                          >
                                            {isBn ? 'জন্ম: ' : 'Born: '}
                                            {member.birth.date.isoString}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  </div>

                                  <div
                                    className="space-y-1.5 text-[11px] pt-2 border-t"
                                    style={{ borderColor: `${memberColor.border}80`, color: colors.text }}
                                  >
                                    {fatherName && (
                                      <div className="truncate">
                                        <span className="font-semibold" style={{ color: colors.textMuted }}>{isBn ? 'পিতা:' : 'Father:'}</span>{' '}
                                        {fatherName}
                                      </div>
                                    )}
                                    {motherName && (
                                      <div className="truncate">
                                        <span className="font-semibold" style={{ color: colors.textMuted }}>{isBn ? 'মাতা:' : 'Mother:'}</span>{' '}
                                        {motherName}
                                      </div>
                                    )}
                                    {address && (
                                      <div className="flex items-center gap-1 truncate" style={{ color: colors.textMuted }}>
                                        <MapPin className="w-3 h-3 shrink-0 text-rose-500" />
                                        <span className="truncate">{address}</span>
                                      </div>
                                    )}
                                    {member.profession && (
                                      <div className="flex items-center gap-1 truncate" style={{ color: colors.textMuted }}>
                                        <FileText className="w-3 h-3 shrink-0 text-blue-500" />
                                        <span className="truncate">{member.profession}</span>
                                      </div>
                                    )}
                                    <div className="flex items-center gap-1.5 pt-0.5">
                                      <Heart className="w-3 h-3 shrink-0 text-rose-500" />
                                      <span className="font-semibold" style={{ color: colors.text }}>
                                        {isBn
                                          ? marriageCount > 0 ? `বিবাহ: ${toBanglaDigits(marriageCount)}টি` : 'বিবাহ: অবিবাহিত'
                                          : marriageCount > 0 ? `Marriages: ${marriageCount}` : 'Marital status: Unmarried'}
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                <div
                                  className="mt-3 flex items-center justify-between pt-2 border-t"
                                  style={{ borderColor: `${memberColor.border}80` }}
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <button
                                    type="button"
                                    onClick={() => onSelectMember(member.id)}
                                    className="text-xs font-semibold flex items-center gap-1 hover:opacity-80"
                                    style={{ color: colors.primary }}
                                  >
                                    <Eye className="w-3.5 h-3.5" />
                                    <span>{isBn ? 'প্রোফাইল' : 'Profile'}</span>
                                  </button>
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => onEditMember(member)}
                                      className="p-1.5 rounded-lg border hover:opacity-80"
                                      style={{ borderColor: colors.border, color: colors.text }}
                                      title={isBn ? 'সম্পাদনা' : 'Edit'}
                                    >
                                      <Edit3 className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={(e) => handleDelete(member, e)}
                                      className="p-1.5 rounded-lg border text-red-500 hover:bg-red-50"
                                      style={{ borderColor: colors.border }}
                                      title={isBn ? 'রিসাইকেল বিনে পাঠান' : 'Move to recycle bin'}
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            );
                          }

                          // STYLE 1: COMPACT
                          if (cardStyle === 'compact') {
                            return (
                              <div
                                key={member.id}
                                data-member-color={memberColor.key}
                                onClick={() => onSelectMember(member.id)}
                                className={`cursor-pointer flex items-center justify-between rounded-2xl border p-3 hover:shadow-md transition ${
                                  isSelected ? 'ring-2 ring-amber-500' : ''
                                }`}
                                style={{ backgroundColor: memberColor.soft, borderColor: isSelected ? colors.primary : memberColor.border }}
                              >
                                <div className="flex items-center gap-2.5 truncate">
                                  <button
                                    type="button"
                                    onClick={(e) => toggleSelectMember(member.id, e)}
                                    className="p-1 rounded-lg text-stone-400 hover:text-amber-600 transition shrink-0"
                                    title={isSelected ? 'Deselect' : 'Select'}
                                  >
                                    {isSelected ? <CheckSquare className="w-4 h-4 text-amber-600" /> : <Square className="w-4 h-4" />}
                                  </button>

                                  <div
                                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl font-bold font-serif text-xs shadow-xs"
                                    style={{ backgroundColor: `${memberColor.accent}18`, color: memberColor.text }}
                                  >
                                    {(member.banglaName || member.fullName)[0]}
                                  </div>
                                  <div className="truncate">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-mono text-[10px] font-bold text-stone-400">
                                        
                                      </span>
                                      {isEldestChild && (
                                        <span className="text-[9px] px-1 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold flex items-center gap-0.5">
                                          <Crown className="w-2.5 h-2.5" />
                                          <span>{isBn ? 'বড়' : '1st'}</span>
                                        </span>
                                      )}
                                      <span className="font-serif font-bold text-xs truncate" style={{ color: colors.text }}>
                                        {isBn ? member.banglaName || member.fullName : member.englishName || member.fullName}
                                      </span>
                                      {listSpouses.length > 0 && <span className="text-[10px] font-semibold text-rose-700 dark:text-rose-300 truncate">{isBn ? (member.gender === 'male' ? 'স্ত্রী: ' : 'স্বামী: ') : 'Spouse: '}{listSpouses.map((sp:any) => isBn ? sp.banglaName || sp.fullName : sp.englishName || sp.fullName).join(' • ')}</span>}
                                    </div>
                                    <div className="text-[11px] text-stone-500 truncate">
                                      {lifespan} {father && `• পিতা: ${father.banglaName || father.fullName}`}
                                    </div>
                                  </div>
                                </div>

                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onEditMember(member);
                                    }}
                                    className="p-1.5 rounded-lg text-stone-400 hover:text-amber-600 transition"
                                  >
                                    <Edit3 className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    onClick={(e) => handleDelete(member, e)}
                                    className="p-1.5 rounded-lg text-stone-400 hover:text-rose-600 transition"
                                    title={isBn ? 'মুছুন' : 'Delete'}
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              </div>
                            );
                          }

                          // STYLE 2: PHOTO
                          if (cardStyle === 'photo') {
                            return (
                              <div
                                key={member.id}
                                data-member-color={memberColor.key}
                                onClick={() => onSelectMember(member.id)}
                                className={`group cursor-pointer rounded-2xl border overflow-hidden shadow-xs hover:shadow-md transition flex flex-col justify-between ${
                                  isSelected ? 'ring-2 ring-amber-500' : ''
                                }`}
                                style={{ backgroundColor: memberColor.soft, borderColor: isSelected ? colors.primary : memberColor.border }}
                              >
                                <div className="aspect-square bg-stone-100 dark:bg-stone-800 flex items-center justify-center overflow-hidden relative">
                                  {member.profilePhoto ? (
                                    <img src={member.profilePhoto} alt="" className="h-full w-full object-cover group-hover:scale-105 transition" />
                                  ) : (
                                    <span className="font-serif text-4xl font-bold" style={{ color: memberColor.accent }}>
                                      {(member.banglaName || member.fullName)[0]}
                                    </span>
                                  )}
                                  <div className="absolute top-2 left-2 flex gap-1">
                                    <span className="bg-black/60 backdrop-blur-xs text-white text-[9px] font-mono px-1.5 py-0.5 rounded">
                                      
                                    </span>
                                    {isEldestChild && (
                                      <span className="bg-amber-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5">
                                        <Crown className="w-2.5 h-2.5" />
                                      </span>
                                    )}
                                  </div>

                                  <button
                                    type="button"
                                    onClick={(e) => toggleSelectMember(member.id, e)}
                                    className="absolute top-2 right-2 p-1 rounded-lg bg-black/60 backdrop-blur-xs text-white hover:bg-black/80 transition"
                                    title={isSelected ? 'Deselect' : 'Select'}
                                  >
                                    {isSelected ? <CheckSquare className="w-4 h-4 text-amber-400" /> : <Square className="w-4 h-4 text-white" />}
                                  </button>
                                </div>

                                <div className="p-3 space-y-1">
                                  <h4 className="font-serif font-bold text-xs truncate" style={{ color: colors.text }}>
                                    {isBn ? member.banglaName || member.fullName : member.englishName || member.fullName}
                                  </h4>
                                  {listSpouses.length > 0 && <div className="text-[10px] font-semibold text-rose-700 dark:text-rose-300 truncate">{isBn ? (member.gender === 'male' ? 'স্ত্রী: ' : 'স্বামী: ') : 'Spouse: '}{listSpouses.map((sp:any) => isBn ? sp.banglaName || sp.fullName : sp.englishName || sp.fullName).join(' • ')}</div>}
                                  <p className="text-[10px] text-stone-500 truncate">{lifespan}</p>
                                </div>
                              </div>
                            );
                          }

                          // STYLE 3, 4, 5: CLASSIC, DETAILED & GENEALOGY CARDS
                          return (
                            <div
                              key={member.id}
                              data-member-color={memberColor.key}
                              className={`group relative flex flex-col justify-between rounded-2xl border p-4 shadow-xs transition hover:shadow-md ${
                                isSelected ? 'ring-2 ring-amber-500' : ''
                              }`}
                              style={{ backgroundColor: memberColor.soft, borderColor: isSelected ? colors.primary : memberColor.border }}
                            >
                              <div className="space-y-3">
                                {/* Card Header Badge Bar */}
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-1.5">
                                    <span
                                      className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md border"
                                      style={{
                                        backgroundColor: `${colors.primary}15`,
                                        color: colors.primary,
                                        borderColor: `${colors.primary}30`
                                      }}
                                    >
                                      
                                    </span>

                                    {member.birthOrder !== undefined && (
                                      <span
                                        className={`text-[10px] px-2 py-0.5 rounded-md font-bold flex items-center gap-0.5 ${
                                          isEldestChild
                                            ? 'bg-amber-100 text-amber-900 border border-amber-300 dark:bg-amber-950 dark:text-amber-200'
                                            : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400'
                                        }`}
                                      >
                                        {isEldestChild && <Crown className="w-2.5 h-2.5 text-amber-600" />}
                                        <span>#{isBn ? toBanglaDigits(member.birthOrder) : member.birthOrder}</span>
                                        {isEldestChild && <span className="text-[9px]">({isBn ? 'বড় সন্তান' : 'Eldest'})</span>}
                                      </span>
                                    )}

                                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-bold">{isBn ? `${toBanglaDigits(effectiveGeneration(member))}ম প্রজন্ম` : `Gen ${effectiveGeneration(member)}`}</span>

                                    {branch && (
                                      <span
                                        className="h-2 w-2 rounded-full ring-1 ring-black/10"
                                        style={{ backgroundColor: branch.color }}
                                        title={branch.name}
                                      />
                                    )}
                                  </div>

                                  <div className="flex items-center gap-1.5">
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                      member.isLiving
                                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                        : 'bg-stone-200 text-stone-700 dark:bg-stone-800 dark:text-stone-300'
                                    }`}>
                                      {member.isLiving ? (isBn ? 'জীবিত' : 'Living') : (isBn ? 'প্রয়াত' : 'Deceased')}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={(e) => toggleSelectMember(member.id, e)}
                                      className={`p-1 rounded-lg transition ${
                                        isSelected
                                          ? 'text-amber-600 bg-amber-100 dark:bg-amber-950/60'
                                          : 'text-stone-300 dark:text-stone-600 hover:text-stone-500'
                                      }`}
                                      title={isSelected ? 'Deselect' : 'Select'}
                                    >
                                      {isSelected ? <CheckSquare className="w-4 h-4 text-amber-600" /> : <Square className="w-4 h-4" />}
                                    </button>
                                  </div>
                                </div>

                                {/* Names */}
                                <div>
                                  <h3
                                    onClick={() => onSelectMember(member.id)}
                                    className="cursor-pointer font-serif text-base font-bold transition hover:underline"
                                    style={{ color: colors.text }}
                                  >
                                    {isBn ? member.banglaName || member.fullName : member.englishName || member.fullName}
                                  </h3>
                                  {member.nickname && (
                                    <span className="text-xs text-stone-500">
                                      ({isBn ? 'ডাকনাম:' : 'Nick:'} {member.nickname})
                                    </span>
                                  )}
                                  {listSpouses.length > 0 && <div className="mt-1 text-xs font-semibold text-rose-700 dark:text-rose-300">{isBn ? (member.gender === 'male' ? 'স্ত্রী: ' : 'স্বামী: ') : 'Spouse: '}{listSpouses.map((sp:any) => isBn ? sp.banglaName || sp.fullName : sp.englishName || sp.fullName).join(' • ')}</div>}
                                </div>

                                {/* Generational Ancestry Lineage Info */}
                                <div className="p-2.5 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200/80 dark:border-stone-800/80 space-y-1 text-xs">
                                  {father ? (
                                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-400">
                                      <span className="font-semibold">{isBn ? 'পিতা:' : 'Father:'}</span>
                                      <span className="font-serif font-bold text-stone-800 dark:text-stone-200">
                                        {isBn ? father.banglaName || father.fullName : father.englishName || father.fullName}
                                        {father.birthOrder === 1 && (
                                          <span className="ml-1 text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold">
                                            {isBn ? 'বড়' : '1st'}
                                          </span>
                                        )}
                                      </span>
                                    </div>
                                  ) : (
                                    <div className="text-[10px] text-stone-400">
                                      {effectiveGeneration(member) === 1 ? (isBn ? 'মূল আদি পুরুষ (Root)' : 'Root Ancestor') : (isBn ? 'পিতা অনুল্লিখিত' : 'Father unrecorded')}
                                    </div>
                                  )}

                                  {mother && (
                                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-400">
                                      <span className="font-semibold">{isBn ? 'মাতা:' : 'Mother:'}</span>
                                      <span className="font-serif font-bold text-stone-800 dark:text-stone-200">
                                        {isBn ? mother.banglaName || mother.fullName : mother.englishName || mother.fullName}
                                      </span>
                                    </div>
                                  )}
                                </div>

                                {/* Lifespan and Place */}
                                <div className="space-y-1 text-xs text-stone-500">
                                  <div className="flex items-center gap-1.5">
                                    <Calendar className="h-3.5 w-3.5 text-stone-400 shrink-0" />
                                    <span>{lifespan}</span>
                                  </div>

                                  {member.birth?.place?.district && (
                                    <div className="flex items-center gap-1.5">
                                      <MapPin className="h-3.5 w-3.5 text-stone-400 shrink-0" />
                                      <span>
                                        {member.birth.place.village && `${member.birth.place.village}, `}
                                        {member.birth.place.district}
                                      </span>
                                    </div>
                                  )}
                                </div>

                                {/* Identity Docs (NID and Birth Reg) */}
                                {(member.identityDocs?.nidNumber || member.identityDocs?.birthRegistrationNumber) && (
                                  <div className="pt-2 border-t text-[11px] space-y-1" style={{ borderColor: `${colors.border}40` }}>
                                    {member.identityDocs.nidNumber && (
                                      <div className="flex items-center justify-between font-mono">
                                        <span className="text-stone-400">NID:</span>
                                        <span className="text-stone-700 dark:text-stone-300 font-bold">
                                          {isRevealed
                                            ? member.identityDocs.nidNumber
                                            : `••••••••${member.identityDocs.nidNumber.slice(-4)}`}
                                        </span>
                                      </div>
                                    )}

                                    {member.identityDocs.birthRegistrationNumber && (
                                      <div className="flex items-center justify-between font-mono">
                                        <span className="text-stone-400">{isBn ? 'জন্ম সনদ:' : 'BRN:'}</span>
                                        <span className="text-stone-700 dark:text-stone-300 font-bold">
                                          {isRevealed
                                            ? member.identityDocs.birthRegistrationNumber
                                            : `••••••••${member.identityDocs.birthRegistrationNumber.slice(-4)}`}
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>

                              {/* Card Actions Bar */}
                              <div className="mt-4 flex items-center justify-between border-t pt-3 text-xs" style={{ borderColor: `${colors.border}40` }}>
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => onSelectMember(member.id)}
                                    className="font-bold hover:underline"
                                    style={{ color: colors.primary }}
                                  >
                                    {isBn ? 'সম্পূর্ণ প্রোফাইল' : 'View Profile'}
                                  </button>
                                  {(member.identityDocs?.nidNumber || member.identityDocs?.birthRegistrationNumber) && (
                                    <button
                                      onClick={() => toggleRevealNid(member.id)}
                                      className="p-1 text-stone-400 hover:text-stone-600 transition"
                                      title={isRevealed ? 'Hide ID' : 'Reveal ID'}
                                    >
                                      {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                    </button>
                                  )}
                                </div>

                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => onEditMember(member)}
                                    className="p-1.5 rounded-lg text-stone-400 hover:text-amber-600 hover:bg-black/5 dark:hover:bg-white/5 transition"
                                    title={isBn ? 'সম্পাদনা' : 'Edit'}
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>

                                  <button
                                    onClick={(e) => handleDelete(member, e)}
                                    className="p-1.5 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
                                    title={isBn ? 'মুছে ফেলুন' : 'Delete'}
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Floating Batch Selection Toolbar */}
      {selectedMemberIds.size > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 flex flex-wrap items-center justify-center gap-3 bg-stone-900/95 dark:bg-stone-800/95 text-white px-5 py-3 rounded-2xl shadow-2xl border border-stone-700 backdrop-blur-md animate-in slide-in-from-bottom-4">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold font-serif text-amber-300">
              {isBn
                ? `${toBanglaDigits(selectedMemberIds.size)} জন সদস্য চিহ্নিত`
                : `${selectedMemberIds.size} members selected`}
            </span>
          </div>

          <div className="h-4 w-[1px] bg-stone-700 hidden sm:block" />

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={selectAllFiltered}
              className="text-xs font-semibold px-2.5 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 transition"
            >
              {isBn ? 'সবাইকে চিহ্নিত করুন' : 'Select All'}
            </button>
            <button
              type="button"
              onClick={clearSelection}
              className="text-xs font-semibold px-2.5 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 transition"
            >
              {isBn ? 'বাতিল' : 'Clear'}
            </button>
            <button
              type="button"
              onClick={() => setIsBatchDeleteDialogOpen(true)}
              className="flex items-center gap-1.5 text-xs font-bold px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-md transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>
                {isBn
                  ? `নির্বাচিত ${toBanglaDigits(selectedMemberIds.size)} জন মুছুন`
                  : `Delete Selected (${selectedMemberIds.size})`}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* In-UI Single Member Deletion Modal */}
      {memberToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">
                  {isBn ? 'সদস্যকে রিসাইকেল বিনে পাঠাবেন?' : 'Move Member to Recycle Bin'}
                </h3>
                <p className="text-xs text-stone-500">
                  {memberToDelete.banglaName || memberToDelete.fullName}
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed bg-stone-50 dark:bg-stone-800/50 p-3.5 rounded-2xl border border-stone-200 dark:border-stone-700">
              {isBn
                ? 'ভুলে সংরক্ষিত এই সদস্যের তথ্য সম্পূর্ণ মুছে ফেলা হবে। সংশ্লিষ্ট পিতা-মাতা, সন্তান ও বৈবাহিক সম্পর্ক থেকে এই সদস্যকে নিরাপদে বিচ্ছিন্ন করা হবে।'
                : 'This member record will be permanently deleted and cleanly unlinked from parents, children, and marriages.'}
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setMemberToDelete(null)}
                className="px-4 py-2 text-xs font-semibold rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={async () => {
                  const id = memberToDelete.id;
                  setMemberToDelete(null);
                  setSelectedMemberIds(prev => {
                    const next = new Set(prev);
                    next.delete(id);
                    return next;
                  });
                  await deleteMember(id);
                }}
                className="px-4 py-2 text-xs font-bold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-sm flex items-center gap-1.5 transition"
              >
                <Trash2 className="h-4 w-4" />
                <span>{isBn ? 'হ্যাঁ, রিসাইকেল বিনে পাঠান' : 'Yes, Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-UI Batch Members Deletion Modal */}
      {isBatchDeleteDialogOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">
                  {isBn
                    ? `নির্বাচিত ${toBanglaDigits(selectedMemberIds.size)} জন সদস্য মুছবেন?`
                    : `Permanently Delete ${selectedMemberIds.size} Members?`}
                </h3>
                <p className="text-xs text-rose-500 font-semibold">
                  {isBn ? 'এই প্রক্রিয়াটি অপরিবর্তনীয়' : 'This action cannot be undone'}
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed bg-stone-50 dark:bg-stone-800/50 p-3.5 rounded-2xl border border-stone-200 dark:border-stone-700">
              {isBn
                ? 'ভুলবশত এন্ট্রি করা বা অপ্রয়োজনীয় নির্বাচিত সকল সদস্যের প্রোফাইল একসাথে মুছে ফেলা হবে। বংশবৃক্ষ এবং অন্যান্য সদস্যদের লিঙ্ক স্বয়ংক্রিয়ভাবে সুরক্ষিত ও পরিচ্ছন্ন থাকবে।'
                : 'All selected member profiles will be batch removed. Related genealogical links will be safely cleaned up without corrupting the family tree.'}
            </p>

            {/* List preview of members being deleted */}
            <div className="max-h-40 overflow-y-auto rounded-xl border border-stone-200 dark:border-stone-800 p-2 space-y-1 bg-stone-50/50 dark:bg-stone-900/50">
              {Array.from(selectedMemberIds).map(id => {
                const m = memberMap.get(id);
                if (!m) return null;
                return (
                  <div key={id} className="flex items-center justify-between text-xs py-1 px-2 rounded-lg bg-white dark:bg-stone-800">
                    <span className="font-serif font-bold text-stone-800 dark:text-stone-200 truncate">
                      {m.banglaName || m.fullName}
                    </span>
                    <span className="font-mono text-[10px] text-stone-400"></span>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsBatchDeleteDialogOpen(false)}
                className="px-4 py-2 text-xs font-semibold rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={async () => {
                  const ids = Array.from(selectedMemberIds);
                  await deleteMultipleMembers(ids);
                  clearSelection();
                  setIsBatchDeleteDialogOpen(false);
                }}
                className="px-5 py-2 text-xs font-bold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-md flex items-center gap-1.5 transition"
              >
                <Trash2 className="h-4 w-4" />
                <span>
                  {isBn
                    ? `হ্যাঁ, ${toBanglaDigits(selectedMemberIds.size)} জন মুছুন`
                    : `Yes, Delete ${selectedMemberIds.size} Members`}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
