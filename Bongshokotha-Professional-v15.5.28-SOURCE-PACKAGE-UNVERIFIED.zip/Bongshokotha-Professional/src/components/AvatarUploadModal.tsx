/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Camera & Avatar Upload / Cropper Utility
 */

import React, { useState, useRef } from 'react';
import { Camera, Upload, X, Check, RefreshCw } from 'lucide-react';
import { ensureCameraPermission } from '../services/devicePermissions';

interface AvatarUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveAvatar: (avatarDataUrl: string) => void;
  currentAvatar?: string;
  memberName: string;
  isBn: boolean;
}

export const AvatarUploadModal: React.FC<AvatarUploadModalProps> = ({
  isOpen,
  onClose,
  onSaveAvatar,
  currentAvatar,
  memberName,
  isBn
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(currentAvatar || null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        // Compress image using canvas
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const maxDim = 400;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > maxDim) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            }
          } else {
            if (height > maxDim) {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const compressed = canvas.toDataURL('image/jpeg', 0.85);
            setSelectedImage(compressed);
          }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      const allowed = await ensureCameraPermission();
      if (!allowed) {
        alert(isBn ? 'ক্যামেরা ব্যবহারের অনুমতি প্রয়োজন। Settings → ক্যামেরা ও দলিল স্ক্যানার থেকে অনুমতি দিন।' : 'Camera permission is required. Open Settings → Camera & Scanner to allow it.');
        return;
      }
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 640 }, facingMode: 'user' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      alert(isBn ? 'ক্যামেরা চালু করা যায়নি। অনুগ্রহ করে ডিভাইসের পারমিশন চেক করুন।' : 'Could not access camera. Please check device permissions.');
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = 400;
      canvas.height = 400;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, 400, 400);
        setSelectedImage(canvas.toDataURL('image/jpeg', 0.85));
      }
      stopCamera();
    }
  };

  const handleClose = () => {
    stopCamera();
    onClose();
  };

  const handleSave = () => {
    if (selectedImage) {
      onSaveAvatar(selectedImage);
    }
    handleClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md rounded-2xl border border-amber-900/15 bg-white p-6 shadow-2xl dark:border-stone-800 dark:bg-stone-900">
        <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
          <h3 className="font-serif font-bold text-base text-amber-950 dark:text-amber-100">
            {isBn ? `ছবি আপডেট: ${memberName}` : `Update Photo: ${memberName}`}
          </h3>
          <button onClick={handleClose} className="rounded-lg p-1 text-stone-400 hover:text-stone-700">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="my-6 flex flex-col items-center justify-center">
          {isCameraActive ? (
            <div className="relative h-64 w-64 overflow-hidden rounded-2xl bg-black shadow-inner">
              <video ref={videoRef} className="h-full w-full object-cover" autoPlay playsInline />
              <button
                type="button"
                onClick={capturePhoto}
                className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-white px-4 py-1.5 text-xs font-bold text-stone-900 shadow-md hover:bg-stone-100"
              >
                {isBn ? 'ছবি তুলুন' : 'Snap Photo'}
              </button>
            </div>
          ) : selectedImage ? (
            <div className="relative h-48 w-48 overflow-hidden rounded-full border-4 border-amber-800/30 shadow-lg dark:border-stone-700">
              <img src={selectedImage} alt={memberName} className="h-full w-full object-cover" />
            </div>
          ) : (
            <div className="flex h-48 w-48 flex-col items-center justify-center rounded-full border-2 border-dashed border-stone-300 bg-stone-50 text-stone-400 dark:border-stone-700 dark:bg-stone-800">
              <Camera className="h-10 w-10 text-stone-400" />
              <span className="mt-2 text-xs">{isBn ? 'কোনো ছবি নেই' : 'No photo chosen'}</span>
            </div>
          )}

          <div className="mt-6 flex flex-wrap gap-2 justify-center">
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => {
                stopCamera();
                fileInputRef.current?.click();
              }}
              className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-xs font-medium text-stone-800 hover:bg-stone-50 transition dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200"
            >
              <Upload className="h-4 w-4" />
              <span>{isBn ? 'গ্যালারি থেকে নির্বাচন' : 'Gallery Upload'}</span>
            </button>

            {!isCameraActive ? (
              <button
                type="button"
                onClick={startCamera}
                className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-xs font-medium text-stone-800 hover:bg-stone-50 transition dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200"
              >
                <Camera className="h-4 w-4" />
                <span>{isBn ? 'ক্যামেরা দিয়ে তুলুন' : 'Use Camera'}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={stopCamera}
                className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-medium text-rose-800 hover:bg-rose-100 transition"
              >
                <X className="h-4 w-4" />
                <span>{isBn ? 'ক্যামেরা বন্ধ' : 'Stop Camera'}</span>
              </button>
            )}
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200 dark:border-stone-800">
          <button
            type="button"
            onClick={handleClose}
            className="rounded-xl px-4 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 dark:text-stone-400 dark:hover:bg-stone-800"
          >
            {isBn ? 'বাতিল' : 'Cancel'}
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!selectedImage}
            className="inline-flex items-center gap-1.5 rounded-xl bg-amber-800 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-amber-900 transition disabled:opacity-50 dark:bg-amber-700"
          >
            <Check className="h-4 w-4" />
            <span>{isBn ? 'সংরক্ষণ করুন' : 'Apply Photo'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
