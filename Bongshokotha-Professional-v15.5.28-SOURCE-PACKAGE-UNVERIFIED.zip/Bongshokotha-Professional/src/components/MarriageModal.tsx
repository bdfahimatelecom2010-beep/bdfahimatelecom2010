/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Marriage & In-Law Record Creation & Editing Modal
 */

import React, { useState, useEffect } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { MarriageRecord, MarriageStatus, DatePrecision } from '../types/genealogy';
import { BANGLA_MONTHS, toBanglaDigits } from '../engine/banglaCalendar';
import {
  X,
  Heart,
  Calendar,
  MapPin,
  Save,
  Users,
  AlertCircle
} from 'lucide-react';

interface MarriageModalProps {
  isOpen: boolean;
  onClose: () => void;
  marriageToEdit?: MarriageRecord | null;
}

export const MarriageModal: React.FC<MarriageModalProps> = ({
  isOpen,
  onClose,
  marriageToEdit
}) => {
  const {
    members,
    marriages,
    addMarriage,
    updateMarriage,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const isEditing = !!marriageToEdit;

  const [serialNumber, setSerialNumber] = useState('');
  const [husbandId, setHusbandId] = useState('');
  const [wifeId, setWifeId] = useState('');
  const [status, setStatus] = useState<MarriageStatus>('current');
  const [statusDateDay, setStatusDateDay] = useState<number | ''>('');
  const [statusDateMonth, setStatusDateMonth] = useState<number | ''>('');
  const [statusDateYear, setStatusDateYear] = useState<number | ''>('');
  const [statusReason, setStatusReason] = useState('');
  const [statusPlace, setStatusPlace] = useState('');

  // Date
  const [day, setDay] = useState<number | ''>('');
  const [month, setMonth] = useState<number | ''>('');
  const [year, setYear] = useState<number | ''>('');
  const [precision, setPrecision] = useState<DatePrecision>('exact');

  // Place
  const [village, setVillage] = useState('');
  const [upazila, setUpazila] = useState('');
  const [district, setDistrict] = useState('');
  // Details are stored on this marriage record, never shared between a person's other marriages.
  const [husbandAddress, setHusbandAddress] = useState('');
  const [wifeAddress, setWifeAddress] = useState('');
  const [husbandFatherName, setHusbandFatherName] = useState('');
  const [husbandMotherName, setHusbandMotherName] = useState('');
  const [wifeFatherName, setWifeFatherName] = useState('');
  const [wifeMotherName, setWifeMotherName] = useState('');

  // Children
  const [selectedChildrenIds, setSelectedChildrenIds] = useState<string[]>([]);

  // Notes
  const [marriageNotes, setMarriageNotes] = useState('');

  useEffect(() => {
    if (marriageToEdit) {
      setSerialNumber(marriageToEdit.serialNumber || '');
      setHusbandId(marriageToEdit.husbandId || '');
      setWifeId(marriageToEdit.wifeId || '');
      setStatus(marriageToEdit.status || 'current');
      setStatusDateDay(marriageToEdit.statusDate?.day ?? '');
      setStatusDateMonth(marriageToEdit.statusDate?.month ?? '');
      setStatusDateYear(marriageToEdit.statusDate?.year ?? '');
      setStatusReason(marriageToEdit.statusReason || '');
      setStatusPlace(marriageToEdit.statusPlace || '');

      setDay(marriageToEdit.marriageDate?.day ?? '');
      setMonth(marriageToEdit.marriageDate?.month ?? '');
      setYear(marriageToEdit.marriageDate?.year ?? '');
      setPrecision(marriageToEdit.marriageDate?.precision || 'exact');

      setVillage(marriageToEdit.marriagePlace?.village || '');
      setUpazila(marriageToEdit.marriagePlace?.upazila || '');
      setDistrict(marriageToEdit.marriagePlace?.district || '');
      setHusbandAddress(marriageToEdit.husbandAddress?.fullAddress || '');
      setWifeAddress(marriageToEdit.wifeAddress?.fullAddress || '');
      setHusbandFatherName(marriageToEdit.husbandFatherName || '');
      setHusbandMotherName(marriageToEdit.husbandMotherName || '');
      setWifeFatherName(marriageToEdit.wifeFatherName || '');
      setWifeMotherName(marriageToEdit.wifeMotherName || '');

      setSelectedChildrenIds(marriageToEdit.childrenIds || []);
      setMarriageNotes(marriageToEdit.marriageNotes || '');
    } else {
      setSerialNumber(`MR-${String(marriages.length + 1).padStart(3, '0')}`);
      setHusbandId('');
      setWifeId('');
      setStatus('current');
      setStatusDateDay('');
      setStatusDateMonth('');
      setStatusDateYear('');
      setStatusReason('');
      setStatusPlace('');

      setDay('');
      setMonth('');
      setYear('');
      setPrecision('exact');

      setVillage('');
      setUpazila('');
      setDistrict('');
      setHusbandAddress('');
      setWifeAddress('');
      setHusbandFatherName('');
      setHusbandMotherName('');
      setWifeFatherName('');
      setWifeMotherName('');

      setSelectedChildrenIds([]);
      setMarriageNotes('');
    }
  }, [marriageToEdit, isOpen, marriages.length]);

  if (!isOpen) return null;

  const handleToggleChild = (childId: string) => {
    setSelectedChildrenIds(prev =>
      prev.includes(childId) ? prev.filter(id => id !== childId) : [...prev, childId]
    );
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!husbandId || !wifeId) {
      alert(isBn ? 'অনুগ্রহ করে স্বামী ও স্ত্রী উভয়কে নির্বাচন করুন।' : 'Please select both husband and wife.');
      return;
    }

    if (husbandId === wifeId) {
      alert(isBn ? 'স্বামী ও স্ত্রী একই ব্যক্তি হতে পারবেন না।' : 'Husband and wife cannot be the same person.');
      return;
    }

    // Marriage-specific child validation: never move a child from one union to
    // another just because the same parent has multiple marriages. Existing
    // conflicting parent/union links require explicit correction first.
    const selectedMarriageId = marriageToEdit?.id;
    for (const childId of selectedChildrenIds) {
      const child = members.find(m => m.id === childId);
      if (!child) continue;
      const fatherConflict = Boolean(child.fatherId && child.fatherId !== husbandId && child.fatherId !== wifeId);
      const motherConflict = Boolean(child.motherId && child.motherId !== husbandId && child.motherId !== wifeId);
      if (fatherConflict || motherConflict) {
        alert(isBn ? `সন্তান “${child.banglaName || child.fullName}”-এর সংরক্ষিত পিতা/মাতার তথ্য এই বিবাহের সঙ্গে মেলে না। আগে সম্পর্ক সংশোধন করুন।` : `Child “${child.englishName || child.fullName}” has a recorded parent that conflicts with this marriage.`);
        return;
      }
      const conflictingUnion = marriages.find(m => {
        if (m.id === selectedMarriageId) return false;
        if (!m.childrenIds?.includes(childId)) return false;
        const sameUnion = (m.husbandId === husbandId && m.wifeId === wifeId) || (m.husbandId === wifeId && m.wifeId === husbandId);
        return !sameUnion;
      });
      if (conflictingUnion) {
        alert(isBn ? `সন্তান “${child.banglaName || child.fullName}” ইতিমধ্যে অন্য একটি বিবাহের সন্তানের তালিকায় আছে। একই সন্তানকে একাধিক আলাদা বিবাহে যুক্ত করা যাবে না।` : `Child “${child.englishName || child.fullName}” is already assigned to another marriage.`);
        return;
      }
    }

    const marriageDate = {
      year: year ? Number(year) : null,
      month: month ? Number(month) : null,
      day: day ? Number(day) : null,
      precision
    };

    const marriagePlace = {
      village,
      upazila,
      district,
      country: 'বাংলাদেশ'
    };

    if (isEditing && marriageToEdit) {
      await updateMarriage({
        ...marriageToEdit,
        serialNumber,
        husbandId,
        wifeId,
        status,
        marriageDate,
        marriagePlace,
        husbandAddress: husbandAddress.trim() ? { fullAddress: husbandAddress.trim(), country: 'বাংলাদেশ' } : undefined,
        wifeAddress: wifeAddress.trim() ? { fullAddress: wifeAddress.trim(), country: 'বাংলাদেশ' } : undefined,
        husbandFatherName: husbandFatherName.trim() || undefined,
        husbandMotherName: husbandMotherName.trim() || undefined,
        wifeFatherName: wifeFatherName.trim() || undefined,
        wifeMotherName: wifeMotherName.trim() || undefined,
        childrenIds: selectedChildrenIds,
        marriageNotes,
        statusDate: (statusDateYear || statusDateMonth || statusDateDay) ? { year: statusDateYear ? Number(statusDateYear) : null, month: statusDateMonth ? Number(statusDateMonth) : null, day: statusDateDay ? Number(statusDateDay) : null, precision: 'exact' } : undefined,
        statusReason: statusReason || undefined,
        statusPlace: statusPlace || undefined
      });
    } else {
      await addMarriage({
        serialNumber,
        husbandId,
        wifeId,
        status,
        marriageDate,
        marriagePlace,
        husbandAddress: husbandAddress.trim() ? { fullAddress: husbandAddress.trim(), country: 'বাংলাদেশ' } : undefined,
        wifeAddress: wifeAddress.trim() ? { fullAddress: wifeAddress.trim(), country: 'বাংলাদেশ' } : undefined,
        husbandFatherName: husbandFatherName.trim() || undefined,
        husbandMotherName: husbandMotherName.trim() || undefined,
        wifeFatherName: wifeFatherName.trim() || undefined,
        wifeMotherName: wifeMotherName.trim() || undefined,
        childrenIds: selectedChildrenIds,
        marriageNotes,
        statusDate: (statusDateYear || statusDateMonth || statusDateDay) ? { year: statusDateYear ? Number(statusDateYear) : null, month: statusDateMonth ? Number(statusDateMonth) : null, day: statusDateDay ? Number(statusDateDay) : null, precision: 'exact' } : undefined,
        statusReason: statusReason || undefined,
        statusPlace: statusPlace || undefined
      });
    }

    onClose();
  };

  const potentialHusbands = members.filter(m => m.gender === 'male' || m.gender === 'unknown');
  const potentialWives = members.filter(m => m.gender === 'female' || m.gender === 'unknown');
  const potentialChildren = members.filter(m => m.id !== husbandId && m.id !== wifeId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl border border-amber-900/15 bg-white shadow-2xl dark:border-stone-800 dark:bg-stone-900 my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-200 px-6 py-4 dark:border-stone-800">
          <div>
            <h3 className="font-serif text-lg sm:text-xl font-bold text-amber-950 dark:text-amber-100 flex items-center gap-2">
              <Heart className="h-5 w-5 text-rose-600" />
              <span>{isEditing ? (isBn ? 'বৈবাহিক রেকর্ড সম্পাদনা' : 'Edit Marriage Record') : (isBn ? 'নতুন বৈবাহিক রেকর্ড যোগ' : 'Record New Marriage')}</span>
            </h3>
            <p className="text-[11px] text-stone-500">
              {isBn
                ? 'স্বতন্ত্র বৈবাহিক আইডি ও সুনির্দিষ্ট সন্তান সংযোগ নিশ্চিত করে।'
                : 'Maintains distinct marriage ID and segregated children links.'}
            </p>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-100 hover:text-stone-700 dark:hover:bg-stone-800 dark:hover:text-stone-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Serial & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                {isBn ? 'বৈবাহিক ক্রমিক (Marriage Serial):' : 'Marriage Serial (MR-001):'}
              </label>
              <input
                type="text"
                placeholder="MR-001"
                value={serialNumber}
                onChange={e => setSerialNumber(e.target.value)}
                className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs font-mono text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                {isBn ? 'বর্তমান বৈবাহিক স্থিতি (Status):' : 'Status:'}
              </label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as MarriageStatus)}
                className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2.5 text-xs text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
              >
                <option value="current">{isBn ? 'বর্তমান/বিবাহ বহাল (Current)' : 'Current'}</option>
                <option value="separated">{isBn ? 'পৃথক / আলাদা বসবাস (Separated)' : 'Separated / Living Apart'}</option>
                <option value="divorce_pending">{isBn ? 'বিচ্ছেদ প্রক্রিয়াধীন (Pending)' : 'Separation/Divorce Pending'}</option>
                <option value="divorced">{isBn ? 'বিবাহবিচ্ছেদ সম্পন্ন (Divorced)' : 'Divorced'}</option>
                <option value="talaq">{isBn ? 'তালাকপ্রাপ্ত (Talaq)' : 'Talaq'}</option>
                <option value="widowed">{isBn ? 'বিধবা / বিপত্নীক (Widowed)' : 'Widowed'}</option>
                <option value="annulled">{isBn ? 'বিবাহ বাতিলকৃত (Annulled)' : 'Annulled'}</option>
              </select>
            </div>
          </div>

          {/* Status-change details */}
          {status !== 'current' && (
            <div className="rounded-xl border border-rose-900/10 bg-rose-50/40 p-4 space-y-3 dark:border-stone-800 dark:bg-stone-950/30">
              <div>
                <div className="text-xs font-bold text-stone-800 dark:text-stone-200">{isBn ? 'অবস্থা পরিবর্তনের তথ্য (ঐচ্ছিক)' : 'Status-change details (optional)'}</div>
                <div className="text-[10px] text-stone-500 mt-0.5">{isBn ? 'পৃথক/আলাদা, বিচ্ছেদ, তালাক বা বাতিলের তারিখ, কারণ ও স্থান সংরক্ষণ করতে পারেন।' : 'Store the date, reason and place for separation, divorce, talaq or annulment.'}</div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <input type="number" min="1" max="31" placeholder={isBn ? 'দিন' : 'Day'} value={statusDateDay} onChange={e=>setStatusDateDay(e.target.value ? Number(e.target.value) : '')} className="rounded-lg border p-2 text-xs dark:bg-stone-900 dark:border-stone-700" />
                <input type="number" min="1" max="12" placeholder={isBn ? 'মাস' : 'Month'} value={statusDateMonth} onChange={e=>setStatusDateMonth(e.target.value ? Number(e.target.value) : '')} className="rounded-lg border p-2 text-xs dark:bg-stone-900 dark:border-stone-700" />
                <input type="number" min="1" max="9999" placeholder={isBn ? 'বছর' : 'Year'} value={statusDateYear} onChange={e=>setStatusDateYear(e.target.value ? Number(e.target.value) : '')} className="rounded-lg border p-2 text-xs dark:bg-stone-900 dark:border-stone-700" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input type="text" placeholder={isBn ? 'কারণ / মন্তব্য' : 'Reason / note'} value={statusReason} onChange={e=>setStatusReason(e.target.value)} className="rounded-lg border p-2 text-xs dark:bg-stone-900 dark:border-stone-700" />
                <input type="text" placeholder={isBn ? 'স্থান' : 'Place'} value={statusPlace} onChange={e=>setStatusPlace(e.target.value)} className="rounded-lg border p-2 text-xs dark:bg-stone-900 dark:border-stone-700" />
              </div>
            </div>
          )}

          {/* Husband & Wife Selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 rounded-xl border border-amber-800/20 bg-amber-50/50 p-4 dark:border-stone-800 dark:bg-stone-950/40">
            {/* Husband */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-amber-950 dark:text-amber-200">
                {isBn ? 'স্বামী নির্বাচন (Husband) *' : 'Select Husband *'}
              </label>
              <select
                required
                value={husbandId}
                onChange={e => setHusbandId(e.target.value)}
                className="w-full rounded-xl border border-stone-200 bg-white p-2.5 text-xs text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-900 dark:text-stone-100"
              >
                <option value="">{isBn ? '-- স্বামী নির্বাচন করুন --' : '-- Select Husband --'}</option>
                {potentialHusbands.map(h => (
                  <option key={h.id} value={h.id}>
                     — {isBn ? h.banglaName || h.fullName : h.englishName || h.fullName}
                  </option>
                ))}
              </select>
            </div>

            {/* Wife */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-amber-950 dark:text-amber-200">
                {isBn ? 'স্ত্রী নির্বাচন (Wife) *' : 'Select Wife *'}
              </label>
              <select
                required
                value={wifeId}
                onChange={e => setWifeId(e.target.value)}
                className="w-full rounded-xl border border-stone-200 bg-white p-2.5 text-xs text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-900 dark:text-stone-100"
              >
                <option value="">{isBn ? '-- স্ত্রী নির্বাচন করুন --' : '-- Select Wife --'}</option>
                {potentialWives.map(w => (
                  <option key={w.id} value={w.id}>
                     — {isBn ? w.banglaName || w.fullName : w.englishName || w.fullName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Per-marriage residence and in-law records */}
          <section className="space-y-3 rounded-xl border border-sky-200 bg-sky-50/60 p-4 dark:border-sky-900/50 dark:bg-sky-950/20">
            <div>
              <h4 className="text-sm font-bold text-sky-950 dark:text-sky-200">{isBn ? 'এই বিবাহের পৃথক ঠিকানা ও শ্বশুর-শাশুড়ির তথ্য' : 'This marriage: separate addresses & parents-in-law'}</h4>
              <p className="mt-1 text-[11px] text-stone-500">{isBn ? 'প্রতিটি বিবাহের জন্য আলাদা করে সংরক্ষিত হবে; অন্য বিবাহের তথ্যের সঙ্গে মিশবে না।' : 'Saved on this marriage only; details will not be mixed with another marriage.'}</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="space-y-1"><span className="text-xs font-semibold">{isBn ? 'স্বামীর ঠিকানা' : 'Husband address'}</span><textarea rows={2} value={husbandAddress} onChange={e=>setHusbandAddress(e.target.value)} placeholder={isBn ? 'গ্রাম, ডাকঘর, উপজেলা, জেলা...' : 'Village, post office, upazila, district...'} className="w-full rounded-lg border p-2.5 text-xs dark:border-stone-700 dark:bg-stone-900" /></label>
              <label className="space-y-1"><span className="text-xs font-semibold">{isBn ? 'স্ত্রীর ঠিকানা' : 'Wife address'}</span><textarea rows={2} value={wifeAddress} onChange={e=>setWifeAddress(e.target.value)} placeholder={isBn ? 'গ্রাম, ডাকঘর, উপজেলা, জেলা...' : 'Village, post office, upazila, district...'} className="w-full rounded-lg border p-2.5 text-xs dark:border-stone-700 dark:bg-stone-900" /></label>
              <label className="space-y-1"><span className="text-xs font-semibold">{isBn ? 'স্বামীর পিতার নাম (শ্বশুর)' : 'Husband’s father (father-in-law)'}</span><input value={husbandFatherName} onChange={e=>setHusbandFatherName(e.target.value)} className="w-full rounded-lg border p-2.5 text-xs dark:border-stone-700 dark:bg-stone-900" /></label>
              <label className="space-y-1"><span className="text-xs font-semibold">{isBn ? 'স্বামীর মাতার নাম (শাশুড়ি)' : 'Husband’s mother (mother-in-law)'}</span><input value={husbandMotherName} onChange={e=>setHusbandMotherName(e.target.value)} className="w-full rounded-lg border p-2.5 text-xs dark:border-stone-700 dark:bg-stone-900" /></label>
              <label className="space-y-1"><span className="text-xs font-semibold">{isBn ? 'স্ত্রীর পিতার নাম' : 'Wife’s father'}</span><input value={wifeFatherName} onChange={e=>setWifeFatherName(e.target.value)} className="w-full rounded-lg border p-2.5 text-xs dark:border-stone-700 dark:bg-stone-900" /></label>
              <label className="space-y-1"><span className="text-xs font-semibold">{isBn ? 'স্ত্রীর মাতার নাম' : 'Wife’s mother'}</span><input value={wifeMotherName} onChange={e=>setWifeMotherName(e.target.value)} className="w-full rounded-lg border p-2.5 text-xs dark:border-stone-700 dark:bg-stone-900" /></label>
            </div>
          </section>

          {/* Marriage Date & Place */}
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-stone-700 dark:text-stone-300">
              <Calendar className="h-4 w-4 text-amber-800" />
              <span>{isBn ? 'বিবাহের তারিখ ও স্থান:' : 'Date & Location of Marriage:'}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <input
                type="number"
                placeholder={isBn ? 'দিন' : 'Day'}
                value={day}
                onChange={e => setDay(e.target.value ? Number(e.target.value) : '')}
                className="rounded-lg border border-stone-200 p-2 text-xs dark:border-stone-700 dark:bg-stone-800"
              />
              <input
                type="number"
                placeholder={isBn ? 'মাস' : 'Month'}
                value={month}
                onChange={e => setMonth(e.target.value ? Number(e.target.value) : '')}
                className="rounded-lg border border-stone-200 p-2 text-xs dark:border-stone-700 dark:bg-stone-800"
              />
              <input
                type="number"
                placeholder={isBn ? 'বছর' : 'Year'}
                value={year}
                onChange={e => setYear(e.target.value ? Number(e.target.value) : '')}
                className="rounded-lg border border-stone-200 p-2 text-xs dark:border-stone-700 dark:bg-stone-800"
              />
              <select
                value={precision}
                onChange={e => setPrecision(e.target.value as DatePrecision)}
                className="rounded-lg border border-stone-200 p-2 text-xs dark:border-stone-700 dark:bg-stone-800"
              >
                <option value="exact">{isBn ? 'সঠিক' : 'Exact'}</option>
                <option value="approximate">{isBn ? 'আনুমানিক' : 'Approximate'}</option>
                <option value="unknown">{isBn ? 'অজানা' : 'Unknown'}</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
              <input
                type="text"
                placeholder={isBn ? 'গ্রাম / বিয়ের আসর' : 'Village / Venue'}
                value={village}
                onChange={e => setVillage(e.target.value)}
                className="rounded-lg border border-stone-200 p-2 text-xs dark:border-stone-700 dark:bg-stone-800"
              />
              <input
                type="text"
                placeholder={isBn ? 'উপজেলা / থানা' : 'Upazila'}
                value={upazila}
                onChange={e => setUpazila(e.target.value)}
                className="rounded-lg border border-stone-200 p-2 text-xs dark:border-stone-700 dark:bg-stone-800"
              />
              <input
                type="text"
                placeholder={isBn ? 'জেলা' : 'District'}
                value={district}
                onChange={e => setDistrict(e.target.value)}
                className="rounded-lg border border-stone-200 p-2 text-xs dark:border-stone-700 dark:bg-stone-800"
              />
            </div>
          </div>

          {/* Segregated Children Selection for This Union */}
          <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-800 dark:text-stone-200">
                {isBn ? 'এই নির্দিষ্ট বিবাহের সন্তানবর্গ নির্বাচন করুন:' : 'Select Children Specifically of This Union:'}
              </label>
              <span className="text-[10px] text-amber-800 dark:text-amber-400 font-semibold">
                {isBn
                  ? `নির্বাচিত: ${toBanglaDigits(selectedChildrenIds.length)} জন`
                  : `Selected: ${selectedChildrenIds.length}`}
              </span>
            </div>
            <p className="text-[11px] text-stone-500">
              {isBn
                ? 'একাধিক বিবাহের ক্ষেত্রে সন্তানবর্গ যেন ভুলক্রমে মিশ্রিত না হয়, সেজন্য নির্দিষ্ট সন্তান নির্বাচন করুন।'
                : 'Prevents conflating children between 1st and subsequent marriages.'}
            </p>

            <div className="max-h-36 overflow-y-auto rounded-xl border border-stone-200 p-2 space-y-1 bg-stone-50/50 dark:border-stone-800 dark:bg-stone-950/30">
              {potentialChildren.map(child => {
                const isChecked = selectedChildrenIds.includes(child.id);
                return (
                  <label
                    key={child.id}
                    className={`flex items-center gap-2 rounded-lg p-1.5 text-xs cursor-pointer transition ${
                      isChecked ? 'bg-amber-100/70 font-semibold dark:bg-amber-950/60' : 'hover:bg-stone-100 dark:hover:bg-stone-800'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => handleToggleChild(child.id)}
                      className="rounded text-amber-800 focus:ring-amber-700"
                    />
                    <span className="font-mono text-[10px] text-stone-500"></span>
                    <span>{isBn ? child.banglaName || child.fullName : child.englishName || child.fullName}</span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Marriage Notes */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
              {isBn ? 'বৈবাহিক ইতিবৃত্ত ও শশুরবাড়ির নোট:' : 'Marriage Notes & In-Law Details:'}
            </label>
            <textarea
              rows={2}
              placeholder={isBn ? 'দেনমোহর, কাজীর তথ্য বা পারিবারিক বিবরণ...' : 'Historical notes, registry details...'}
              value={marriageNotes}
              onChange={e => setMarriageNotes(e.target.value)}
              className="w-full rounded-xl border border-stone-200 bg-stone-50 p-2 text-xs text-stone-900 focus:border-amber-800 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
            />
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end gap-3 border-t border-stone-200 pt-4 dark:border-stone-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 dark:text-stone-400 dark:hover:bg-stone-800"
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>

            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-xl bg-amber-800 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-amber-900 transition dark:bg-amber-700 dark:hover:bg-amber-600"
            >
              <Save className="h-4 w-4" />
              <span>{isEditing ? (isBn ? 'রেকর্ড হালনাগাদ করুন' : 'Update Record') : (isBn ? 'বিবাহ সংরক্ষণ করুন' : 'Save Marriage')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
