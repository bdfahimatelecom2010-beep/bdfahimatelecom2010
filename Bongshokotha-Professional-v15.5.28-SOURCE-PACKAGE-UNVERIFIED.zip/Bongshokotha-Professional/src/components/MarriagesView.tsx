/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Marriages Registry & In-Law Heritage Architecture
 * 
 * Master Rules:
 * - "Marriage may change, Marriage ID and historical records must remain."
 * - "Children must not be incorrectly merged across marriages."
 * - "Marriage does NOT erase or merge biological lineage."
 */

import React, { useState } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { MarriageRecord } from '../types/genealogy';
import { getCanonicalChildrenForMarriage } from '../engine/relationshipIntegrity';
import { toBanglaDigits, formatGenealogyDate } from '../engine/banglaCalendar';
import {
  Heart,
  Plus,
  Users,
  Calendar,
  MapPin,
  FileText,
  Trash2,
  Edit3,
  ExternalLink,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

interface MarriagesViewProps {
  onOpenAddMarriage: () => void;
  onEditMarriage: (marriage: MarriageRecord) => void;
  onSelectMember: (memberId: string) => void;
}

export const MarriagesView: React.FC<MarriagesViewProps> = ({
  onOpenAddMarriage,
  onEditMarriage,
  onSelectMember
}) => {
  const {
    marriages,
    members,
    deleteMarriage,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const memberMap = new Map(members.map(m => [m.id, m]));

  const handleDelete = async (marriage: MarriageRecord) => {
    const confirmMsg = isBn
      ? `আপনি কি নিশ্চিত যে আপনি বৈবাহিক রেকর্ড ${marriage.serialNumber || marriage.id} স্থায়ীভাবে মুছে ফেলতে চান? সংশ্লিষ্ট স্বামী-স্ত্রীর প্রোফাইল থেকে লিংক সরানো হবে।`
      : `Are you sure you want to delete marriage record ${marriage.serialNumber || marriage.id}?`;

    if (window.confirm(confirmMsg)) {
      await deleteMarriage(marriage.id);
    }
  };

  const statusLabelsBn: { [key: string]: string } = {
    current: 'বর্তমান / বিবাহ বহাল',
    separated: 'পৃথক / আলাদা বসবাস',
    divorce_pending: 'বিচ্ছেদ প্রক্রিয়াধীন',
    divorced: 'বিবাহবিচ্ছেদ সম্পন্ন',
    talaq: 'তালাকপ্রাপ্ত',
    widowed: 'বিধবা / বিপত্নীক',
    annulled: 'বিবাহ বাতিলকৃত'
  };

  const statusLabelsEn: { [key: string]: string } = {
    current: 'Current / Active',
    separated: 'Separated / Living Apart',
    divorce_pending: 'Divorce Pending',
    divorced: 'Divorced',
    talaq: 'Talaq',
    widowed: 'Widowed',
    annulled: 'Annulled'
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Top Banner */}
      <div className="flex flex-col gap-4 rounded-2xl border border-amber-900/10 bg-white p-5 shadow-xs dark:border-stone-800 dark:bg-stone-900 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-amber-950 dark:text-amber-100">
            {isBn ? 'বৈবাহিক বন্ধন ও ইন-ল রেজিস্ট্রি' : 'Marriage & In-Law Registry'}
          </h2>
          <p className="text-xs text-stone-500">
            {isBn
              ? `মোট ${toBanglaDigits(marriages.length)}টি নথিভুক্ত বৈবাহিক রেকর্ড। বহুবিবাহের ক্ষেত্রে প্রতিটি বন্ধনের সন্তান ও দলিল স্বতন্ত্রভাবে সংরক্ষিত।`
              : `Total ${marriages.length} verified marriage records. Supports multiple marriages with segregated children & in-law lineages.`}
          </p>
        </div>

        <button
          onClick={onOpenAddMarriage}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber-800 px-4 py-2 text-xs sm:text-sm font-semibold text-white shadow-sm hover:bg-amber-900 transition dark:bg-amber-700 dark:hover:bg-amber-600"
        >
          <Plus className="h-4 w-4" />
          <span>{isBn ? 'নতুন বৈবাহিক রেকর্ড যোগ' : 'Record New Marriage'}</span>
        </button>
      </div>

      {/* Multiple Marriage Core Principle Alert */}
      <div className="rounded-xl border border-amber-900/20 bg-amber-50 p-4 text-xs text-stone-700 dark:border-stone-800 dark:bg-stone-900/80 dark:text-stone-300 flex items-start gap-3">
        <ShieldCheck className="h-5 w-5 text-amber-800 dark:text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-semibold text-amber-950 dark:text-amber-200">
            {isBn ? 'বহুবিবাহ ও ইন-ল স্বাতন্ত্র্যের নিয়ম:' : 'Multiple Marriage & Lineage Rule:'}
          </span>
          <p>
            {isBn
              ? 'বিবাহের মাধ্যমে কোনো সদস্যের জন্মসূত্রে প্রাপ্ত বংশপরিচয় বিলুপ্ত হয় না। একই ব্যক্তির একাধিক বিবাহের ক্ষেত্রে সন্তানবর্গ নির্দিষ্ট বিবাহ রেকর্ডের অধীনে সংরক্ষিত থাকে।'
              : 'A member who joins the family through marriage retains their biological parents, grandparents, and branch. Children belong specifically to their respective marriage.'}
          </p>
        </div>
      </div>

      {/* Marriage Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {marriages.length === 0 ? (
          <div className="col-span-full rounded-2xl border border-dashed border-stone-300 p-12 text-center text-xs text-stone-400 dark:border-stone-800">
            {isBn ? 'কোনো বৈবাহিক রেকর্ড নথিভুক্ত করা হয়নি।' : 'No marriage records recorded yet.'}
          </div>
        ) : (
          marriages.map(mar => {
            const husband = memberMap.get(mar.husbandId);
            const wife = memberMap.get(mar.wifeId);
            const children = getCanonicalChildrenForMarriage(mar, members);

            return (
              <div
                key={mar.id}
                className="flex flex-col justify-between rounded-2xl border border-stone-200/90 bg-white p-5 shadow-xs transition hover:border-amber-800/40 hover:shadow-md dark:border-stone-800 dark:bg-stone-900"
              >
                <div className="space-y-4">
                  {/* Top Bar: Serial & Status */}
                  <div className="flex items-center justify-between border-b border-stone-100 pb-3 dark:border-stone-800">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-amber-900 bg-amber-100/70 px-2 py-0.5 rounded-sm dark:bg-amber-950/70 dark:text-amber-300">
                        {mar.serialNumber || mar.id}
                      </span>
                      <span className="text-[11px] font-medium text-stone-500">
                        {isBn ? 'বিবাহ বন্ধন' : 'Union'}
                      </span>
                    </div>

                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        mar.status === 'current'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : mar.status === 'widowed'
                          ? 'bg-stone-200 text-stone-700 dark:bg-stone-800 dark:text-stone-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                      }`}
                    >
                      {isBn ? statusLabelsBn[mar.status] || mar.status : statusLabelsEn[mar.status] || mar.status}
                    </span>
                  </div>

                  {/* Husband & Wife Couple Panel */}
                  <div className="grid grid-cols-2 gap-3 bg-stone-50/70 p-3 rounded-xl dark:bg-stone-950/40">
                    {/* Husband */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-semibold text-stone-500 uppercase tracking-wider">
                        {isBn ? 'স্বামী' : 'Husband'}
                      </span>
                      {husband ? (
                        <div>
                          <div
                            onClick={() => onSelectMember(husband.id)}
                            className="cursor-pointer font-serif font-bold text-sm text-amber-950 hover:underline dark:text-amber-100"
                          >
                            {isBn ? husband.banglaName || husband.fullName : husband.englishName || husband.fullName}
                          </div>
                          <div className="text-[10px] text-stone-500 font-mono">
                            {husband.serialNumber}
                          </div>
                          {husband.originalLineageNote && (
                            <div className="text-[10px] text-stone-600 dark:text-stone-400 mt-0.5 italic truncate" title={husband.originalLineageNote}>
                              {husband.originalLineageNote}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-xs text-rose-500">Unknown ID: {mar.husbandId}</div>
                      )}
                    </div>

                    {/* Wife */}
                    <div className="space-y-1 border-l border-stone-200 pl-3 dark:border-stone-800">
                      <span className="text-[10px] font-semibold text-stone-500 uppercase tracking-wider">
                        {isBn ? 'স্ত্রী' : 'Wife'}
                      </span>
                      {wife ? (
                        <div>
                          <div
                            onClick={() => onSelectMember(wife.id)}
                            className="cursor-pointer font-serif font-bold text-sm text-amber-950 hover:underline dark:text-amber-100"
                          >
                            {isBn ? wife.banglaName || wife.fullName : wife.englishName || wife.fullName}
                          </div>
                          <div className="text-[10px] text-stone-500 font-mono">
                            {wife.serialNumber}
                          </div>
                          {wife.originalLineageNote && (
                            <div className="text-[10px] text-stone-600 dark:text-stone-400 mt-0.5 italic truncate" title={wife.originalLineageNote}>
                              {wife.originalLineageNote}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-xs text-rose-500">Unknown ID: {mar.wifeId}</div>
                      )}
                    </div>
                  </div>

                  {/* Details: Date, Place, Shoshurbari */}
                  <div className="space-y-1 text-xs text-stone-600 dark:text-stone-400">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-3.5 w-3.5 text-stone-400" />
                      <span>{isBn ? 'তারিখ:' : 'Date:'} {formatGenealogyDate(mar.marriageDate, language)}</span>
                    </div>
                    {mar.status !== 'current' && (mar.statusDate?.year || mar.statusDate?.month || mar.statusDate?.day) && (
                      <div className="flex items-center gap-2">
                        <Calendar className="h-3.5 w-3.5 text-rose-400" />
                        <span>{isBn ? 'অবস্থা পরিবর্তনের তারিখ:' : 'Status date:'} {formatGenealogyDate(mar.statusDate, language)}</span>
                      </div>
                    )}
                    {mar.statusReason && <div className="text-[11px] text-stone-500">{isBn ? 'কারণ/মন্তব্য: ' : 'Reason/note: '}{mar.statusReason}</div>}
                    {mar.statusPlace && <div className="text-[11px] text-stone-500">{isBn ? 'অবস্থা পরিবর্তনের স্থান: ' : 'Status place: '}{mar.statusPlace}</div>}

                    {(mar.marriagePlace?.district || mar.marriagePlace?.village) && (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3.5 w-3.5 text-stone-400" />
                        <span>
                          {isBn ? 'স্থান:' : 'Place:'} {[mar.marriagePlace.village, mar.marriagePlace.upazila, mar.marriagePlace.district].filter(Boolean).join(', ')}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Children Specifically of this Marriage */}
                  <div className="border-t border-stone-100 pt-3 dark:border-stone-800">
                    <div className="flex items-center justify-between text-xs font-semibold text-stone-700 dark:text-stone-300 mb-2">
                      <span>{isBn ? 'এই বন্ধনের সন্তানবর্গ:' : 'Children of this Marriage:'}</span>
                      <span className="font-mono text-[11px] text-amber-800 dark:text-amber-400">
                        {isBn ? toBanglaDigits(children.length) : children.length} {isBn ? 'জন' : ''}
                      </span>
                    </div>

                    {children.length === 0 ? (
                      <div className="text-[11px] text-stone-400 italic">
                        {isBn ? 'কোনো সন্তান নথিভুক্ত নেই' : 'No children recorded for this marriage'}
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-1.5">
                        {children.map(child => child && (
                          <button
                            key={child.id}
                            onClick={() => onSelectMember(child.id)}
                            className="inline-flex items-center gap-1 rounded-md bg-stone-100 px-2 py-1 text-[11px] font-medium text-stone-800 hover:bg-amber-100 hover:text-amber-950 transition dark:bg-stone-800 dark:text-stone-300"
                          >
                            <span>{isBn ? child.banglaName || child.fullName : child.englishName || child.fullName}</span>
                            
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Marriage Notes */}
                  {mar.marriageNotes && (
                    <div className="rounded-lg bg-stone-50 p-2.5 text-[11px] text-stone-600 dark:bg-stone-950/40 dark:text-stone-400">
                      <span className="font-medium text-stone-800 dark:text-stone-300">{isBn ? 'নোট:' : 'Notes:'} </span>
                      {mar.marriageNotes}
                    </div>
                  )}
                </div>

                {/* Card Action Footer */}
                <div className="mt-4 flex items-center justify-end gap-2 border-t border-stone-100 pt-3 dark:border-stone-800">
                  <button
                    onClick={() => onEditMarriage(mar)}
                    className="inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium text-stone-700 hover:bg-amber-100 hover:text-amber-950 transition dark:text-stone-300 dark:hover:bg-stone-800"
                  >
                    <Edit3 className="h-3.5 w-3.5" />
                    <span>{isBn ? 'সম্পাদনা' : 'Edit'}</span>
                  </button>
                  <button
                    onClick={() => handleDelete(mar)}
                    className="inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium text-rose-700 hover:bg-rose-100 transition dark:hover:bg-rose-950/50"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>{isBn ? 'মুছে ফেলুন' : 'Delete'}</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
