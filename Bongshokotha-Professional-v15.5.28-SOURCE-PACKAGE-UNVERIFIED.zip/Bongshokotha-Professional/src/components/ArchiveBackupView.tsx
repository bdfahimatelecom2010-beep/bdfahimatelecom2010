/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Offline Archive, Secure Backup, GEDCOM & Data Safety Center (Part 4)
 */

import React, { useRef, useState } from 'react';
import { useGenealogy } from '../context/GenealogyContext';
import { toBanglaDigits } from '../engine/banglaCalendar';
import { SafeRestoreDiffModal } from './archive/SafeRestoreDiffModal';
import { BongshokothaArchive } from '../services/storage';
import {
  Download,
  Upload,
  HardDrive,
  ShieldAlert,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  FileCheck,
  AlertTriangle,
  FileCode,
  Info
} from 'lucide-react';

export const ArchiveBackupView: React.FC = () => {
  const {
    family,
    members,
    marriages,
    exportArchiveJSON,
    importArchiveJSON,
    exportGedcomFile,
    importGedcomText,
    loadSampleDataset,
    resetToFactoryState,
    language
  } = useGenealogy();

  const isBn = language === 'bn';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const gedcomFileInputRef = useRef<HTMLInputElement>(null);

  const [pendingArchive, setPendingArchive] = useState<BongshokothaArchive | null>(null);
  const [isDiffModalOpen, setIsDiffModalOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ success?: boolean; message?: string } | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (parsed.format === 'BONGSHOKOTHA_ARCHIVE' && parsed.family) {
          setPendingArchive(parsed);
          setIsDiffModalOpen(true);
        } else {
          setStatusMessage({
            success: false,
            message: isBn ? 'অকার্যকর ফাইল ফরম্যাট। এটি কোনো বৈধ বংশকথা ব্যাকআপ নয়।' : 'Invalid file format. Not a valid Bongshokotha archive.'
          });
        }
      } catch (err) {
        setStatusMessage({
          success: false,
          message: isBn ? 'ফাইল পার্স করতে ব্যর্থ।' : 'Failed to parse JSON file.'
        });
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleGedcomFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const text = event.target?.result as string;
      const res = await importGedcomText(text);
      setStatusMessage(res);
    };
    reader.readAsText(file);
    if (gedcomFileInputRef.current) gedcomFileInputRef.current.value = '';
  };

  const handleLoadSample = async () => {
    const confirm = window.confirm(
      isBn
        ? 'আপনি কি "সিলেট চৌধুরী বংশ"-এর ৪ প্রজন্মের ঐতিহাসিক নমুনা ডেটাসেট লোড করতে চান? এটি একটি স্বতন্ত্র পারিবারিক স্পেসে সংরক্ষিত থাকবে।'
        : 'Do you want to load the 4-generation verified sample dataset of Chowdhury Bongsho? It will be loaded into its own family space without overwriting your custom data.'
    );
    if (confirm) {
      await loadSampleDataset();
      setStatusMessage({
        success: true,
        message: isBn ? 'নমুনা ডেটাসেট সফলভাবে লোড হয়েছে!' : 'Sample dataset loaded successfully!'
      });
    }
  };

  const handleFactoryReset = async () => {
    const first = window.confirm(
      isBn
        ? 'সতর্কতা: এটি সম্পূর্ণ লোকাল ডাটাবেস মুছে প্রাথমিক অবস্থায় ফিরিয়ে দেবে। আপনি কি এগিয়ে যেতে চান?'
        : 'WARNING: This will clear the local database and reset to factory state. Are you sure you want to proceed?'
    );
    if (!first) return;

    const second = window.prompt(
      isBn
        ? 'চূড়ান্ত নিশ্চিতকরণের জন্য টাইপ করুন: "DELETE"'
        : 'Type "DELETE" to confirm permanent factory reset:'
    );
    if (second === 'DELETE') {
      await resetToFactoryState();
      setStatusMessage({
        success: true,
        message: isBn ? 'সফলভাবে ফ্যাক্টরি রিসেট সম্পন্ন হয়েছে।' : 'Reset to factory state completed.'
      });
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Banner */}
      <div className="rounded-3xl border border-amber-900/10 bg-white p-5 shadow-xs dark:border-stone-800 dark:bg-stone-900">
        <h2 className="font-serif text-xl sm:text-2xl font-bold text-amber-950 dark:text-amber-100">
          {isBn ? 'তথ্য সংরক্ষণ, ব্যাকআপ ও রিস্টোর' : 'Archive, Backup & Data Preservation'}
        </h2>
        <p className="text-xs text-stone-500 mt-1">
          {isBn
            ? 'বংশকথা অফলাইন-ফার্স্ট প্রযুক্তিতে কাজ করে। আপনার পরিবারের তথ্য স্থায়ীভাবে ডিভাইসে সংরক্ষিত।'
            : 'Bongshokotha operates offline-first. Your family lineage is securely stored in your local persistent database.'}
        </p>
      </div>

      {statusMessage && (
        <div
          className={`rounded-2xl p-4 text-xs font-semibold ${
            statusMessage.success
              ? 'bg-emerald-50 text-emerald-900 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800'
              : 'bg-rose-50 text-rose-900 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800'
          }`}
        >
          {statusMessage.message}
        </div>
      )}

      {/* Backup & Export / Import Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Export Card */}
        <div className="flex flex-col justify-between rounded-3xl border border-amber-900/10 bg-white p-6 shadow-xs dark:border-stone-800 dark:bg-stone-900 space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                <Download className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-base text-amber-950 dark:text-amber-100">
                  {isBn ? 'বংশকথা পূর্ণাঙ্গ আর্কাইভ এক্সপোর্ট' : 'Export Bongshokotha Archive'}
                </h3>
                <p className="text-[11px] text-stone-500">
                  {isBn ? 'সম্পূর্ণ পরিবার, সদস্য, বৈবাহিক ও মহাফেজখানা রেকর্ড ডাউনলোড' : 'Download complete family records, links and settings'}
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed pt-2">
              {isBn
                ? `বর্তমান পরিবারের মোট ${toBanglaDigits(members.length)} জন সদস্য এবং ${toBanglaDigits(marriages.length)}টি বৈবাহিক রেকর্ডের একটি স্বয়ংসম্পূর্ণ ব্যাকআপ ফাইল তৈরি হবে, যা ভবিষ্যতে যেকোনো ডিভাইসে রিস্টোর করা যাবে।`
                : `Exports a full portable JSON/BKF archive of ${members.length} members and ${marriages.length} marriage records with full relationship graphs.`}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 pt-2">
            <button
              type="button"
              onClick={exportArchiveJSON}
              className="flex-1 inline-flex items-center justify-center gap-2 rounded-xl bg-amber-800 px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-amber-900 transition dark:bg-amber-700"
            >
              <Download className="h-4 w-4" />
              <span>{isBn ? 'পূর্ণাঙ্গ ব্যাকআপ (.bkf)' : 'Download .bkf Archive'}</span>
            </button>
            <button
              type="button"
              onClick={exportGedcomFile}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-stone-300 bg-stone-50 px-4 py-2.5 text-xs font-bold text-stone-700 hover:bg-stone-100 transition dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300"
            >
              <FileCode className="h-4 w-4" />
              <span>GEDCOM (.ged)</span>
            </button>
          </div>
        </div>

        {/* Import Card */}
        <div className="flex flex-col justify-between rounded-3xl border border-amber-900/10 bg-white p-6 shadow-xs dark:border-stone-800 dark:bg-stone-900 space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                <Upload className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-base text-amber-950 dark:text-amber-100">
                  {isBn ? 'নিরাপদ রিস্টোর (Safe Import & Diff)' : 'Safe Restore & Merge'}
                </h3>
                <p className="text-[11px] text-stone-500">
                  {isBn ? 'পূর্ববর্তী ব্যাকআপ ফাইল আপলোড করে তথ্য পুনরুদ্ধার' : 'Import a valid .bkf or .json archive file'}
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed pt-2">
              {isBn
                ? 'আমদানি করার পূর্বে ডিআইএফএফ বিশ্লেষণ ও সংঘাত নিরীক্ষা সম্পন্ন হয়, যাতে পূর্বের কোনো যাচাইকৃত তথ্য মুছে না যায়।'
                : 'Runs schema verification and diff analysis to guarantee existing verified facts are never silently replaced.'}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 pt-2">
            <input
              type="file"
              accept=".json,.bkf"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
            />
            <input
              type="file"
              accept=".ged,.gedcom"
              ref={gedcomFileInputRef}
              onChange={handleGedcomFileChange}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 inline-flex items-center justify-center gap-2 rounded-xl border border-amber-900/20 bg-amber-50/70 px-4 py-2.5 text-xs font-bold text-amber-950 shadow-xs hover:bg-amber-100 transition dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200"
            >
              <Upload className="h-4 w-4 text-amber-800 dark:text-amber-400" />
              <span>{isBn ? 'ব্যাকআপ ফাইল রিস্টোর' : 'Restore Backup (.bkf)'}</span>
            </button>

            <button
              type="button"
              onClick={() => gedcomFileInputRef.current?.click()}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-stone-300 bg-stone-50 px-4 py-2.5 text-xs font-bold text-stone-700 hover:bg-stone-100 transition dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300"
            >
              <FileCode className="h-4 w-4" />
              <span>আমদানি GEDCOM</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sample Dataset & Master Rules Protocols */}
      <div className="rounded-3xl border border-amber-900/10 bg-white p-6 shadow-xs dark:border-stone-800 dark:bg-stone-900 space-y-4">
        <h3 className="font-serif font-bold text-base text-amber-950 dark:text-amber-100 pb-2 border-b border-stone-100 dark:border-stone-800">
          {isBn ? 'নমুনা বংশলতিকা ও ডেটা সুরক্ষা প্রোটোকল' : 'Sample Lineage & Data Protocols'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Sample loader */}
          <div className="rounded-2xl border border-stone-200 p-4 space-y-2 dark:border-stone-800">
            <div className="flex items-center gap-2 text-amber-950 dark:text-amber-200 font-bold text-xs sm:text-sm">
              <Sparkles className="h-4 w-4 text-amber-700" />
              <span>{isBn ? 'সিলেট চৌধুরী বংশের নমুনা ডেটাসেট' : 'Chowdhury Bongsho Sample Dataset'}</span>
            </div>
            <p className="text-xs text-stone-600 dark:text-stone-400">
              {isBn
                ? '৪টি প্রজন্ম, বহুবিবাহ, বড়তরফ ও ছোটতরফ শাখা, বাংলা ক্যালেন্ডার এবং এনআইডি সহ সম্পূর্ণ যাচাইকৃত নমুনা রেকর্ড।'
                : 'Verified sample featuring 4 generations, multiple marriages, diverse branches, and precision dates.'}
            </p>
            <button
              type="button"
              onClick={handleLoadSample}
              className="mt-2 text-xs font-semibold text-amber-800 hover:underline dark:text-amber-400"
            >
              {isBn ? 'নমুনা ডেটাসেট লোড করুন →' : 'Reload Sample Dataset →'}
            </button>
          </div>

          {/* Destructive Factory Reset */}
          <div className="rounded-2xl border border-rose-200 bg-rose-50/30 p-4 space-y-2 dark:border-rose-900/40 dark:bg-rose-950/20">
            <div className="flex items-center gap-2 text-rose-900 dark:text-rose-300 font-bold text-xs sm:text-sm">
              <RotateCcw className="h-4 w-4 text-rose-700" />
              <span>{isBn ? 'ফ্যাক্টরি রিসেট (সতর্কতামূলক)' : 'Factory Reset (Destructive)'}</span>
            </div>
            <p className="text-xs text-stone-600 dark:text-stone-400">
              {isBn
                ? 'লোকাল স্টোরেজ সম্পূর্ণ মুছে ফেলা হবে। শুধুমাত্র সুস্পষ্ট দুই ধাপের অনুমোদনের পর কার্যকর হয়।'
                : 'Clears all local storage. Strictly guarded by dual-confirmation.'}
            </p>
            <button
              type="button"
              onClick={handleFactoryReset}
              className="mt-2 text-xs font-semibold text-rose-700 hover:underline dark:text-rose-400"
            >
              {isBn ? 'ফ্যাক্টরি রিসেট শুরু করুন →' : 'Initiate Factory Reset →'}
            </button>
          </div>
        </div>
      </div>

      {/* Safe Restore Diff Modal */}
      {isDiffModalOpen && pendingArchive && (
        <SafeRestoreDiffModal
          isOpen={isDiffModalOpen}
          onClose={() => {
            setIsDiffModalOpen(false);
            setPendingArchive(null);
          }}
          incomingArchive={pendingArchive}
          currentMembers={members}
          currentMarriages={marriages}
          onConfirmRestore={async (strategy) => {
            const res = await importArchiveJSON(JSON.stringify(pendingArchive), strategy);
            setStatusMessage(res);
          }}
          isBn={isBn}
        />
      )}
    </div>
  );
};
