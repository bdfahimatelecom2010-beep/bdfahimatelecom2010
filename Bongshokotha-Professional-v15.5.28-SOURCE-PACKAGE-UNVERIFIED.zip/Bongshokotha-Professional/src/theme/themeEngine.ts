/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * 116 HD Premium Themes Engine (Part 4)
 * 
 * Five Distinct Curated Collections:
 * 1. Traditional Bengal & Heritage (ঐতিহ্যবাহী বাংলা)
 * 2. Royal, Noble & Zamindari (রাজকীয় ও জমিদারি)
 * 3. Nature, Bengal Rivers & Seasons (ঋতু, নদ-নদী ও প্রকৃতি)
 * 4. Modern Midnight & OLED Dark (আধুনিক ডার্ক ও মধ্যরাত্রি)
 * 5. Minimal, Pastel & Paper Craft (নির্মল প্যাস্টেল ও লিনেন)
 */

export interface ThemeReadability {
  contrastRatio: number;
  accessibilityGrade: 'AAA' | 'AA';
  recommendedFont: string;
}

export interface ThemeComponentStyles {
  secondary: string;
  secondaryText: string;
  badge: { bg: string; text: string };
  navigation: { activeBg: string; activeText: string };
  header: { bg: string; text: string; border: string };
  buttons: { primaryBg: string; primaryText: string; primaryHover: string };
  formControls: { inputBg: string; inputBorder: string; inputText: string };
  treeVisualization: { nodeBg: string; nodeBorder: string; lineColor: string };
  archiveAppearance: { cardBg: string; cardBorder: string };
  profileAppearance: { heroBg: string };
  premium: { gradient: string; shadow: string; radius: string; glass: string };
}

export interface BongshoTheme {
  id: string;
  nameBn: string;
  nameEn: string;
  category: 'heritage' | 'royal' | 'nature' | 'dark' | 'minimal' | 'modern' | 'blue' | 'warm';
  categoryBn: string;
  isDark: boolean;
  colors: {
    primary: string;
    primaryHover: string;
    accent: string;
    bg: string;
    surface: string;
    card: string;
    text: string;
    textMuted: string;
    border: string;
    ring: string;
  };
  styles?: Partial<ThemeComponentStyles>;
  readability?: Partial<ThemeReadability>;
}

export function getFullTheme(theme: BongshoTheme): BongshoTheme & ThemeComponentStyles & { readability: ThemeReadability } {
  const isDark = theme.isDark;
  const c = theme.colors;

  const componentStyles: ThemeComponentStyles = {
    secondary: theme.styles?.secondary || (isDark ? '#38bdf8' : c.accent),
    secondaryText: theme.styles?.secondaryText || c.textMuted,
    badge: theme.styles?.badge || {
      bg: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.06)',
      text: c.primary
    },
    navigation: theme.styles?.navigation || {
      activeBg: c.primary,
      activeText: '#ffffff'
    },
    header: theme.styles?.header || {
      bg: isDark ? c.surface : '#ffffff',
      text: c.text,
      border: c.border
    },
    buttons: theme.styles?.buttons || {
      primaryBg: c.primary,
      primaryText: '#ffffff',
      primaryHover: c.primaryHover
    },
    formControls: theme.styles?.formControls || {
      inputBg: isDark ? c.card : '#ffffff',
      inputBorder: c.border,
      inputText: c.text
    },
    treeVisualization: theme.styles?.treeVisualization || {
      nodeBg: c.card,
      nodeBorder: c.primary,
      lineColor: c.primary
    },
    archiveAppearance: theme.styles?.archiveAppearance || {
      cardBg: isDark ? c.card : c.surface,
      cardBorder: c.border
    },
    profileAppearance: theme.styles?.profileAppearance || {
      heroBg: isDark ? c.surface : c.surface
    },
    premium: theme.styles?.premium || {
      gradient: `linear-gradient(135deg, ${c.primary} 0%, ${c.accent} 100%)`,
      shadow: isDark ? '0 18px 50px rgba(0,0,0,.38)' : '0 18px 50px rgba(15,23,42,.10)',
      radius: '1.25rem',
      glass: isDark ? 'rgba(15,23,42,.72)' : 'rgba(255,255,255,.78)'
    }
  };

  const readability: ThemeReadability = {
    contrastRatio: theme.readability?.contrastRatio || (isDark ? 11.2 : 8.6),
    accessibilityGrade: theme.readability?.accessibilityGrade || 'AAA',
    recommendedFont: theme.readability?.recommendedFont || 'SolaimanLipi, "Noto Serif Bengali", serif'
  };

  return {
    ...theme,
    ...componentStyles,
    readability
  };
}

export const BONGSHO_THEMES: BongshoTheme[] = [
  // ==========================================
  // COLLECTION 1: TRADITIONAL BENGAL & HERITAGE (10)
  // ==========================================
  {
    id: 'heritage',
    nameBn: 'জমিদারি সোনালী (Zamindari Gold)',
    nameEn: 'Zamindari Gold',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#78350f',
      primaryHover: '#451a03',
      accent: '#d97706',
      bg: '#fbf9f5',
      surface: '#f3efe6',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#78716c',
      border: '#e7e5e4',
      ring: '#92400e'
    }
  },
  {
    id: 'terracotta',
    nameBn: 'পোড়ামাটি লাল (Bengal Terracotta)',
    nameEn: 'Bengal Terracotta',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#9a3412',
      primaryHover: '#7c2d12',
      accent: '#ea580c',
      bg: '#fdf8f6',
      surface: '#f7ede8',
      card: '#ffffff',
      text: '#292524',
      textMuted: '#78716c',
      border: '#fed7aa',
      ring: '#c2410c'
    }
  },
  {
    id: 'ancient_parchment',
    nameBn: 'প্রাচীন পুথিপত্র (Ancient Parchment)',
    nameEn: 'Ancient Parchment',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#854d0e',
      primaryHover: '#713f12',
      accent: '#ca8a04',
      bg: '#fefce8',
      surface: '#fef9c3',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#71717a',
      border: '#fde047',
      ring: '#a16207'
    }
  },
  {
    id: 'rajbari_crimson',
    nameBn: 'রাজবাড়ি রক্তিম (Rajbari Crimson)',
    nameEn: 'Rajbari Crimson',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#881337',
      primaryHover: '#4c0519',
      accent: '#e11d48',
      bg: '#fff1f2',
      surface: '#ffe4e6',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#881337',
      border: '#fecdd3',
      ring: '#be123c'
    }
  },
  {
    id: 'padma_silt',
    nameBn: 'পদ্মার পলিমাটি (Padma Silt Clay)',
    nameEn: 'Padma Silt Clay',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#57534e',
      primaryHover: '#292524',
      accent: '#78716c',
      bg: '#fafaf9',
      surface: '#f5f5f4',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#78716c',
      border: '#e7e5e4',
      ring: '#44403c'
    }
  },
  {
    id: 'jamdani_weave',
    nameBn: 'জামদানি বুনন (Jamdani Weave)',
    nameEn: 'Jamdani Weave',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#a16207',
      primaryHover: '#854d0e',
      accent: '#eab308',
      bg: '#fffbeb',
      surface: '#fef3c7',
      card: '#ffffff',
      text: '#1f2937',
      textMuted: '#6b7280',
      border: '#fde68a',
      ring: '#ca8a04'
    }
  },
  {
    id: 'nilambari_silk',
    nameBn: 'নীলাম্বরি রেশম (Nilambari Silk)',
    nameEn: 'Nilambari Silk',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#1e3a8a',
      primaryHover: '#172554',
      accent: '#2563eb',
      bg: '#eff6ff',
      surface: '#dbeafe',
      card: '#ffffff',
      text: '#0f172a',
      textMuted: '#64748b',
      border: '#bfdbfe',
      ring: '#1d4ed8'
    }
  },
  {
    id: 'brass_kansa',
    nameBn: 'কাঁসা-পিতল ঐতিহ্য (Heritage Brass)',
    nameEn: 'Heritage Brass',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#713f12',
      primaryHover: '#422006',
      accent: '#d97706',
      bg: '#fffbeb',
      surface: '#fef3c7',
      card: '#ffffff',
      text: '#292524',
      textMuted: '#78716c',
      border: '#fde68a',
      ring: '#b45309'
    }
  },
  {
    id: 'sonargaon_muslin',
    nameBn: 'সোনারগাঁও মসলিন (Sonargaon Muslin)',
    nameEn: 'Sonargaon Muslin',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#52525b',
      primaryHover: '#27272a',
      accent: '#a1a1aa',
      bg: '#fafafa',
      surface: '#f4f4f5',
      card: '#ffffff',
      text: '#18181b',
      textMuted: '#71717a',
      border: '#e4e4e7',
      ring: '#3f3f46'
    }
  },
  {
    id: 'bengal_banyan',
    nameBn: 'বটবৃক্ষের ছায়া (Sacred Banyan)',
    nameEn: 'Sacred Banyan',
    category: 'heritage',
    categoryBn: 'ঐতিহ্যবাহী বাংলা',
    isDark: false,
    colors: {
      primary: '#365314',
      primaryHover: '#1a2e05',
      accent: '#65a30d',
      bg: '#f7fee7',
      surface: '#ecfccb',
      card: '#ffffff',
      text: '#1a2e05',
      textMuted: '#4d7c0f',
      border: '#d9f99d',
      ring: '#4d7c0f'
    }
  },

  // ==========================================
  // COLLECTION 2: ROYAL, NOBLE & ZAMINDARI (10)
  // ==========================================
  {
    id: 'nawabi_maroon',
    nameBn: 'নবাবী খয়েরি (Nawabi Maroon)',
    nameEn: 'Nawabi Maroon',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#4c0519',
      primaryHover: '#2a020d',
      accent: '#9f1239',
      bg: '#fff1f2',
      surface: '#ffe4e6',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#701a75',
      border: '#fecdd3',
      ring: '#be123c'
    }
  },
  {
    id: 'imperial_purple',
    nameBn: 'সম্রাট বেগুনি (Imperial Purple)',
    nameEn: 'Imperial Purple',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#581c87',
      primaryHover: '#3b0764',
      accent: '#9333ea',
      bg: '#faf5ff',
      surface: '#f3e8ff',
      card: '#ffffff',
      text: '#1e1b4b',
      textMuted: '#6b21a8',
      border: '#e9d5ff',
      ring: '#7e22ce'
    }
  },
  {
    id: 'mughal_emerald',
    nameBn: 'মুঘল পান্না (Mughal Emerald)',
    nameEn: 'Mughal Emerald',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#064e3b',
      primaryHover: '#022c22',
      accent: '#059669',
      bg: '#ecfdf5',
      surface: '#d1fae5',
      card: '#ffffff',
      text: '#064e3b',
      textMuted: '#047857',
      border: '#a7f3d0',
      ring: '#059669'
    }
  },
  {
    id: 'royal_sapphire',
    nameBn: 'রাজকীয় নীলা (Royal Sapphire)',
    nameEn: 'Royal Sapphire',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#172554',
      primaryHover: '#0b132b',
      accent: '#1d4ed8',
      bg: '#f0f9ff',
      surface: '#e0f2fe',
      card: '#ffffff',
      text: '#0f172a',
      textMuted: '#334155',
      border: '#bae6fd',
      ring: '#2563eb'
    }
  },
  {
    id: 'vintage_mahogany',
    nameBn: 'প্রাচীন মেহগনি (Vintage Mahogany)',
    nameEn: 'Vintage Mahogany',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#451a03',
      primaryHover: '#270e02',
      accent: '#92400e',
      bg: '#fdfaf7',
      surface: '#f7efe9',
      card: '#ffffff',
      text: '#292524',
      textMuted: '#78716c',
      border: '#e7d8ce',
      ring: '#78350f'
    }
  },
  {
    id: 'sovereign_gold',
    nameBn: 'সার্বভৌম স্বর্ণ (Sovereign Gold)',
    nameEn: 'Sovereign Gold',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#854d0e',
      primaryHover: '#533008',
      accent: '#eab308',
      bg: '#fefce8',
      surface: '#fef08a',
      card: '#ffffff',
      text: '#292524',
      textMuted: '#713f12',
      border: '#fde047',
      ring: '#ca8a04'
    }
  },
  {
    id: 'ivory_palace',
    nameBn: 'হাতির দাঁতের প্রাসাদ (Ivory Palace)',
    nameEn: 'Ivory Palace',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#57534e',
      primaryHover: '#292524',
      accent: '#a8a29e',
      bg: '#fffff8',
      surface: '#f5f5ee',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#78716c',
      border: '#e7e5dd',
      ring: '#78716c'
    }
  },
  {
    id: 'dynasty_bronze',
    nameBn: 'বংশানুক্রম ব্রোঞ্জ (Dynasty Bronze)',
    nameEn: 'Dynasty Bronze',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#78350f',
      primaryHover: '#451a03',
      accent: '#b45309',
      bg: '#fefaf6',
      surface: '#fbf0e4',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#78716c',
      border: '#fed7aa',
      ring: '#92400e'
    }
  },
  {
    id: 'gilded_velvet',
    nameBn: 'স্বর্ণমণ্ডিত মখমল (Gilded Velvet)',
    nameEn: 'Gilded Velvet',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#701a75',
      primaryHover: '#4a044e',
      accent: '#c026d3',
      bg: '#fdf4ff',
      surface: '#fae8ff',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#86198f',
      border: '#f5d0fe',
      ring: '#a21caf'
    }
  },
  {
    id: 'cooch_behar_ruby',
    nameBn: 'কোচবিহার পদ্মরাগ (Cooch Behar Ruby)',
    nameEn: 'Cooch Behar Ruby',
    category: 'royal',
    categoryBn: 'রাজকীয় ও জমিদারি',
    isDark: false,
    colors: {
      primary: '#991b1b',
      primaryHover: '#7f1d1d',
      accent: '#dc2626',
      bg: '#fef2f2',
      surface: '#fee2e2',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#991b1b',
      border: '#fecaca',
      ring: '#b91c1c'
    }
  },

  // ==========================================
  // COLLECTION 3: NATURE & BENGAL SEASONS (10)
  // ==========================================
  {
    id: 'sundarbans_mangrove',
    nameBn: 'সুন্দরবন ম্যানগ্রোভ (Sundarbans)',
    nameEn: 'Sundarbans Mangrove',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#14532d',
      primaryHover: '#052e16',
      accent: '#22c55e',
      bg: '#f0fdf4',
      surface: '#dcfce7',
      card: '#ffffff',
      text: '#052e16',
      textMuted: '#15803d',
      border: '#bbf7d0',
      ring: '#16a34a'
    }
  },
  {
    id: 'sharat_kashful',
    nameBn: 'শরতের কাশফুল (Autumn Kashful)',
    nameEn: 'Autumn Kashful',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#0369a1',
      primaryHover: '#075985',
      accent: '#38bdf8',
      bg: '#f0f9ff',
      surface: '#e0f2fe',
      card: '#ffffff',
      text: '#0c4a6e',
      textMuted: '#0284c7',
      border: '#bae6fd',
      ring: '#0284c7'
    }
  },
  {
    id: 'hemanta_harvest',
    nameBn: 'হেমন্তের সোনালী ধান (Golden Harvest)',
    nameEn: 'Golden Harvest',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#a16207',
      primaryHover: '#854d0e',
      accent: '#facc15',
      bg: '#fefce8',
      surface: '#fef08a',
      card: '#ffffff',
      text: '#292524',
      textMuted: '#713f12',
      border: '#fde047',
      ring: '#ca8a04'
    }
  },
  {
    id: 'basanta_palash',
    nameBn: 'বসন্তের পলাশ (Spring Palash)',
    nameEn: 'Spring Palash',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#c2410c',
      primaryHover: '#9a3412',
      accent: '#f97316',
      bg: '#fff7ed',
      surface: '#ffedd5',
      card: '#ffffff',
      text: '#292524',
      textMuted: '#9a3412',
      border: '#fed7aa',
      ring: '#ea580c'
    }
  },
  {
    id: 'monsoon_kodom',
    nameBn: 'বর্ষার কদম ফুল (Monsoon Rain)',
    nameEn: 'Monsoon Rain',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#0f766e',
      primaryHover: '#115e59',
      accent: '#14b8a6',
      bg: '#f0fdfa',
      surface: '#ccfbf1',
      card: '#ffffff',
      text: '#134e4a',
      textMuted: '#0f766e',
      border: '#99f6e4',
      ring: '#0d9488'
    }
  },
  {
    id: 'sylhet_teagarden',
    nameBn: 'সিলেটের চা বাগান (Sylhet Tea Garden)',
    nameEn: 'Sylhet Tea Garden',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#166534',
      primaryHover: '#14532d',
      accent: '#22c55e',
      bg: '#f0fdf4',
      surface: '#bbf7d0',
      card: '#ffffff',
      text: '#14532d',
      textMuted: '#16a34a',
      border: '#86efac',
      ring: '#15803d'
    }
  },
  {
    id: 'chalan_beel_lotus',
    nameBn: 'চলনবিল পদ্ম (Chalan Beel Lotus)',
    nameEn: 'Chalan Beel Lotus',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#be185d',
      primaryHover: '#9d174d',
      accent: '#ec4899',
      bg: '#fdf2f8',
      surface: '#fce7f3',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#9d174d',
      border: '#fbcfe8',
      ring: '#db2777'
    }
  },
  {
    id: 'hill_tracts_pine',
    nameBn: 'পার্বত্য পাইন (Hill Tracts)',
    nameEn: 'Hill Tracts Forest',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#1e3a5f',
      primaryHover: '#0f172a',
      accent: '#3b82f6',
      bg: '#f8fafc',
      surface: '#f1f5f9',
      card: '#ffffff',
      text: '#0f172a',
      textMuted: '#475569',
      border: '#e2e8f0',
      ring: '#2563eb'
    }
  },
  {
    id: 'coxs_coral',
    nameBn: 'কক্সবাজার প্রবাল (Cox’s Coral)',
    nameEn: 'Cox’s Coral Reef',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#0e7490',
      primaryHover: '#155e75',
      accent: '#06b6d4',
      bg: '#ecfeff',
      surface: '#cffafe',
      card: '#ffffff',
      text: '#164e63',
      textMuted: '#0891b2',
      border: '#a5f3fc',
      ring: '#0891b2'
    }
  },
  {
    id: 'boishakh_storm',
    nameBn: 'কালবৈশাখী মেঘ (Boishakh Storm)',
    nameEn: 'Boishakh Thunder',
    category: 'nature',
    categoryBn: 'ঋতু ও প্রকৃতি',
    isDark: false,
    colors: {
      primary: '#334155',
      primaryHover: '#1e293b',
      accent: '#64748b',
      bg: '#f8fafc',
      surface: '#f1f5f9',
      card: '#ffffff',
      text: '#0f172a',
      textMuted: '#475569',
      border: '#cbd5e1',
      ring: '#475569'
    }
  },

  // ==========================================
  // COLLECTION 4: MODERN MIDNIGHT & OLED DARK (10)
  // ==========================================
  {
    id: 'dark',
    nameBn: 'অম্বার ডার্ক (Amber Heritage Dark)',
    nameEn: 'Heritage Dark',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#d97706',
      primaryHover: '#f59e0b',
      accent: '#fbbf24',
      bg: '#0c0a09',
      surface: '#1c1917',
      card: '#292524',
      text: '#fafaf9',
      textMuted: '#a8a29e',
      border: '#44403c',
      ring: '#d97706'
    }
  },
  {
    id: 'obsidian_night',
    nameBn: 'কৃষ্ণশিলা রজনী (Obsidian Night)',
    nameEn: 'Obsidian Night',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#38bdf8',
      primaryHover: '#0ea5e9',
      accent: '#7dd3fc',
      bg: '#030712',
      surface: '#111827',
      card: '#1f2937',
      text: '#f9fafb',
      textMuted: '#9ca3af',
      border: '#374151',
      ring: '#38bdf8'
    }
  },
  {
    id: 'midnight_velvet',
    nameBn: 'মধ্যরাত্রি ভেলভেট (Midnight Velvet)',
    nameEn: 'Midnight Velvet',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#c084fc',
      primaryHover: '#a855f7',
      accent: '#e9d5ff',
      bg: '#0a0518',
      surface: '#170c32',
      card: '#241442',
      text: '#faf5ff',
      textMuted: '#d8b4fe',
      border: '#3b1c6e',
      ring: '#a855f7'
    }
  },
  {
    id: 'emerald_nocturne',
    nameBn: 'গভীর অরণ্য রাত (Forest Nocturne)',
    nameEn: 'Forest Nocturne',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#34d399',
      primaryHover: '#10b981',
      accent: '#6ee7b7',
      bg: '#021e14',
      surface: '#043424',
      card: '#064e3b',
      text: '#ecfdf5',
      textMuted: '#6ee7b7',
      border: '#059669',
      ring: '#34d399'
    }
  },
  {
    id: 'charcoal_minimal',
    nameBn: 'কাঠকয়লা মিনিমাল (Charcoal Dark)',
    nameEn: 'Charcoal Minimal',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#e2e8f0',
      primaryHover: '#f8fafc',
      accent: '#94a3b8',
      bg: '#0f172a',
      surface: '#1e293b',
      card: '#334155',
      text: '#f8fafc',
      textMuted: '#94a3b8',
      border: '#475569',
      ring: '#cbd5e1'
    }
  },
  {
    id: 'deep_crimson_dark',
    nameBn: 'রক্তিম নিশীথ (Crimson Eclipse)',
    nameEn: 'Crimson Eclipse',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#fb7185',
      primaryHover: '#f43f5e',
      accent: '#fda4af',
      bg: '#1c050c',
      surface: '#330816',
      card: '#4c0c20',
      text: '#fff1f2',
      textMuted: '#fda4af',
      border: '#881337',
      ring: '#f43f5e'
    }
  },
  {
    id: 'oled_pure_black',
    nameBn: 'পিওর ওলেড ব্ল্যাক (Pure OLED 0% Light)',
    nameEn: 'Pure OLED Black',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#fbbf24',
      primaryHover: '#f59e0b',
      accent: '#fde047',
      bg: '#000000',
      surface: '#121212',
      card: '#1c1c1c',
      text: '#ffffff',
      textMuted: '#a3a3a3',
      border: '#2a2a2a',
      ring: '#fbbf24'
    }
  },
  {
    id: 'twilight_indigo',
    nameBn: 'গোধূলি নীল (Twilight Indigo)',
    nameEn: 'Twilight Indigo',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#818cf8',
      primaryHover: '#6366f1',
      accent: '#a5b4fc',
      bg: '#0b0f19',
      surface: '#131b2e',
      card: '#1e2942',
      text: '#e0e7ff',
      textMuted: '#818cf8',
      border: '#312e81',
      ring: '#6366f1'
    }
  },
  {
    id: 'gothic_sepia_dark',
    nameBn: 'গথিক সেপিয়া (Gothic Sepia)',
    nameEn: 'Gothic Sepia',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#d4a373',
      primaryHover: '#faedcd',
      accent: '#ccd5ae',
      bg: '#16120e',
      surface: '#241e17',
      card: '#352c22',
      text: '#fefae0',
      textMuted: '#d4a373',
      border: '#4d4032',
      ring: '#d4a373'
    }
  },
  {
    id: 'cyber_gold',
    nameBn: 'সাইবার গোল্ড ডার্ক (Cyber Gold)',
    nameEn: 'Cyber Gold Dark',
    category: 'dark',
    categoryBn: 'আধুনিক ডার্ক ও মধ্যরাত্রি',
    isDark: true,
    colors: {
      primary: '#eab308',
      primaryHover: '#facc15',
      accent: '#fef08a',
      bg: '#09090b',
      surface: '#18181b',
      card: '#27272a',
      text: '#f4f4f5',
      textMuted: '#a1a1aa',
      border: '#3f3f46',
      ring: '#eab308'
    }
  },

  // ==========================================
  // COLLECTION 5: MINIMAL, PASTEL & PAPER CRAFT (10)
  // ==========================================
  {
    id: 'parchment',
    nameBn: 'হালকা পার্চমেন্ট (Light Parchment)',
    nameEn: 'Light Parchment',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#92400e',
      primaryHover: '#78350f',
      accent: '#b45309',
      bg: '#fcfaf7',
      surface: '#f5f0e6',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#78716c',
      border: '#e7e5e4',
      ring: '#92400e'
    }
  },
  {
    id: 'nordic_frost',
    nameBn: 'নর্ডিক হিম (Nordic Frost)',
    nameEn: 'Nordic Frost',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#0284c7',
      primaryHover: '#0369a1',
      accent: '#38bdf8',
      bg: '#f8fafc',
      surface: '#f1f5f9',
      card: '#ffffff',
      text: '#0f172a',
      textMuted: '#64748b',
      border: '#e2e8f0',
      ring: '#0284c7'
    }
  },
  {
    id: 'sage_herb',
    nameBn: 'মুনি গুল্ম (Sage Green)',
    nameEn: 'Sage Green',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#4d7c0f',
      primaryHover: '#3f6212',
      accent: '#84cc16',
      bg: '#fbfdf9',
      surface: '#f2f8ed',
      card: '#ffffff',
      text: '#1a2e05',
      textMuted: '#4d7c0f',
      border: '#d9f99d',
      ring: '#65a30d'
    }
  },
  {
    id: 'rose_quartz',
    nameBn: 'গোলাপী স্ফটিক (Rose Quartz)',
    nameEn: 'Rose Quartz',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#be185d',
      primaryHover: '#9d174d',
      accent: '#f43f5e',
      bg: '#fff5f7',
      surface: '#ffe4e8',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#be185d',
      border: '#fecdd3',
      ring: '#e11d48'
    }
  },
  {
    id: 'warm_sand',
    nameBn: 'উষ্ণ বালুকা (Warm Sand Dune)',
    nameEn: 'Warm Sand Dune',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#78350f',
      primaryHover: '#451a03',
      accent: '#d97706',
      bg: '#faf6f0',
      surface: '#f3ebe0',
      card: '#ffffff',
      text: '#292524',
      textMuted: '#78716c',
      border: '#e7d8ce',
      ring: '#b45309'
    }
  },
  {
    id: 'linen_canvas',
    nameBn: 'সাদা লিনেন ক্যানভাস (Pure Linen)',
    nameEn: 'Pure Linen Canvas',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#18181b',
      primaryHover: '#09090b',
      accent: '#71717a',
      bg: '#ffffff',
      surface: '#f4f4f5',
      card: '#ffffff',
      text: '#09090b',
      textMuted: '#71717a',
      border: '#e4e4e7',
      ring: '#27272a'
    }
  },
  {
    id: 'soft_lavender',
    nameBn: 'কোমল ল্যাভেন্ডার (Soft Lavender)',
    nameEn: 'Soft Lavender',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#7e22ce',
      primaryHover: '#6b21a8',
      accent: '#a855f7',
      bg: '#faf5ff',
      surface: '#f3e8ff',
      card: '#ffffff',
      text: '#1e1b4b',
      textMuted: '#7e22ce',
      border: '#e9d5ff',
      ring: '#9333ea'
    }
  },
  {
    id: 'cashmere_cream',
    nameBn: 'কাশ্মীরি ক্রিম (Cashmere Cream)',
    nameEn: 'Cashmere Cream',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#854d0e',
      primaryHover: '#713f12',
      accent: '#ca8a04',
      bg: '#faf8f5',
      surface: '#f4efe8',
      card: '#ffffff',
      text: '#1c1917',
      textMuted: '#78716c',
      border: '#e8ded4',
      ring: '#a16207'
    }
  },
  {
    id: 'kyoto_bamboo',
    nameBn: 'কিয়োটো বাঁশবন (Kyoto Bamboo)',
    nameEn: 'Kyoto Bamboo',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#2d6a4f',
      primaryHover: '#1b4332',
      accent: '#52b788',
      bg: '#f8faf8',
      surface: '#eaf4ee',
      card: '#ffffff',
      text: '#081c15',
      textMuted: '#40916c',
      border: '#d8f3dc',
      ring: '#2d6a4f'
    }
  },
  {
    id: 'monolith_classic',
    nameBn: 'একবর্ণীয় মোনোলিথ (Monolith Classic)',
    nameEn: 'Monolith Classic',
    category: 'minimal',
    categoryBn: 'নির্মল প্যাস্টেল ও লিনেন',
    isDark: false,
    colors: {
      primary: '#000000',
      primaryHover: '#262626',
      accent: '#525252',
      bg: '#ffffff',
      surface: '#f5f5f5',
      card: '#ffffff',
      text: '#000000',
      textMuted: '#525252',
      border: '#e5e5e5',
      ring: '#000000'
    }
  },
  // Collection 6: Additional accessibility / regional themes
  { id:'dhaka_teal', nameBn:'ঢাকা টিল', nameEn:'Dhaka Teal', category:'modern', categoryBn:'আধুনিক', isDark:false, colors:{primary:'#0f766e',primaryHover:'#115e59',accent:'#14b8a6',bg:'#f0fdfa',surface:'#ccfbf1',card:'#ffffff',text:'#134e4a',textMuted:'#5f7773',border:'#99f6e4',ring:'#0d9488'} },
  { id:'sundarbans_green', nameBn:'সুন্দরবন সবুজ', nameEn:'Sundarbans Green', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#166534',primaryHover:'#14532d',accent:'#22c55e',bg:'#f0fdf4',surface:'#dcfce7',card:'#ffffff',text:'#14532d',textMuted:'#4d7c5a',border:'#bbf7d0',ring:'#16a34a'} },
  { id:'meghna_blue', nameBn:'মেঘনা নীল', nameEn:'Meghna Blue', category:'blue', categoryBn:'নীল', isDark:false, colors:{primary:'#0369a1',primaryHover:'#075985',accent:'#0ea5e9',bg:'#f0f9ff',surface:'#e0f2fe',card:'#ffffff',text:'#0c4a6e',textMuted:'#52758a',border:'#bae6fd',ring:'#0284c7'} },
  { id:'baul_ochre', nameBn:'বাউল গেরুয়া', nameEn:'Baul Ochre', category:'warm', categoryBn:'উষ্ণ', isDark:false, colors:{primary:'#a16207',primaryHover:'#854d0e',accent:'#f59e0b',bg:'#fffbeb',surface:'#fef3c7',card:'#ffffff',text:'#422006',textMuted:'#78716c',border:'#fde68a',ring:'#ca8a04'} },
  { id:'lalbagh_rose', nameBn:'লালবাগ গোলাপি', nameEn:'Lalbagh Rose', category:'royal', categoryBn:'রাজকীয়', isDark:false, colors:{primary:'#be185d',primaryHover:'#9d174d',accent:'#ec4899',bg:'#fff1f2',surface:'#fce7f3',card:'#ffffff',text:'#500724',textMuted:'#9d5778',border:'#fbcfe8',ring:'#db2777'} },
  { id:'river_mist_dark', nameBn:'নদীর কুয়াশা ডার্ক', nameEn:'River Mist Dark', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#38bdf8',primaryHover:'#0ea5e9',accent:'#67e8f9',bg:'#07131c',surface:'#0c2230',card:'#123244',text:'#e0f2fe',textMuted:'#93c5fd',border:'#164e63',ring:'#38bdf8'} },
  { id:'forest_night', nameBn:'বনরাত্রি', nameEn:'Forest Night', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#4ade80',primaryHover:'#22c55e',accent:'#86efac',bg:'#07130b',surface:'#102419',card:'#173322',text:'#ecfdf5',textMuted:'#86efac',border:'#1f5132',ring:'#4ade80'} },
  { id:'paper_ink', nameBn:'কাগজ ও কালি', nameEn:'Paper & Ink', category:'minimal', categoryBn:'মিনিমাল', isDark:false, colors:{primary:'#27272a',primaryHover:'#18181b',accent:'#52525b',bg:'#fafafa',surface:'#f4f4f5',card:'#ffffff',text:'#18181b',textMuted:'#71717a',border:'#d4d4d8',ring:'#3f3f46'} },
  { id:'high_contrast_light', nameBn:'উচ্চ কনট্রাস্ট আলো', nameEn:'High Contrast Light', category:'minimal', categoryBn:'অ্যাক্সেসিবিলিটি', isDark:false, colors:{primary:'#000000',primaryHover:'#262626',accent:'#1d4ed8',bg:'#ffffff',surface:'#f5f5f5',card:'#ffffff',text:'#000000',textMuted:'#404040',border:'#000000',ring:'#1d4ed8'} },
  { id:'high_contrast_dark', nameBn:'উচ্চ কনট্রাস্ট ডার্ক', nameEn:'High Contrast Dark', category:'dark', categoryBn:'অ্যাক্সেসিবিলিটি', isDark:true, colors:{primary:'#ffff00',primaryHover:'#fde047',accent:'#00ffff',bg:'#000000',surface:'#080808',card:'#111111',text:'#ffffff',textMuted:'#f5f5f5',border:'#ffffff',ring:'#ffff00'} },

  // Collection 7: New Bangladesh regional / seasonal themes (12)
  { id:'padma_twilight', nameBn:'পদ্মা গোধূলি', nameEn:'Padma Twilight', category:'blue', categoryBn:'নীল', isDark:false, colors:{primary:'#1d4ed8',primaryHover:'#1e40af',accent:'#7c3aed',bg:'#eef2ff',surface:'#e0e7ff',card:'#ffffff',text:'#172554',textMuted:'#64748b',border:'#c7d2fe',ring:'#4f46e5'} },
  { id:'cox_bazar_sand', nameBn:'কক্সবাজার বালুকাবেলা', nameEn:'Cox’s Bazar Sand', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#b45309',primaryHover:'#92400e',accent:'#0ea5e9',bg:'#fffbeb',surface:'#fef3c7',card:'#ffffff',text:'#451a03',textMuted:'#78716c',border:'#fde68a',ring:'#d97706'} },
  { id:'sylhet_tea', nameBn:'সিলেট চা-বাগান', nameEn:'Sylhet Tea Garden', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#166534',primaryHover:'#14532d',accent:'#84cc16',bg:'#f7fee7',surface:'#ecfccb',card:'#ffffff',text:'#1a2e05',textMuted:'#4d7c0f',border:'#bef264',ring:'#65a30d'} },
  { id:'barisal_water', nameBn:'বরিশাল জলধারা', nameEn:'Barisal Waterway', category:'blue', categoryBn:'নীল', isDark:false, colors:{primary:'#0e7490',primaryHover:'#155e75',accent:'#06b6d4',bg:'#ecfeff',surface:'#cffafe',card:'#ffffff',text:'#083344',textMuted:'#4b7f8a',border:'#a5f3fc',ring:'#0891b2'} },
  { id:'rajshahi_mango', nameBn:'রাজশাহী আম্রবাগান', nameEn:'Rajshahi Mango', category:'warm', categoryBn:'উষ্ণ', isDark:false, colors:{primary:'#a16207',primaryHover:'#854d0e',accent:'#eab308',bg:'#fefce8',surface:'#fef9c3',card:'#ffffff',text:'#422006',textMuted:'#78716c',border:'#fde047',ring:'#ca8a04'} },
  { id:'rangpur_indigo', nameBn:'রংপুর নীলচাষ', nameEn:'Rangpur Indigo', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#3730a3',primaryHover:'#312e81',accent:'#2563eb',bg:'#eef2ff',surface:'#e0e7ff',card:'#ffffff',text:'#1e1b4b',textMuted:'#6366f1',border:'#c7d2fe',ring:'#4f46e5'} },
  { id:'chattogram_hill', nameBn:'চট্টগ্রাম পাহাড়', nameEn:'Chattogram Hills', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#166534',primaryHover:'#14532d',accent:'#0f766e',bg:'#f0fdf4',surface:'#dcfce7',card:'#ffffff',text:'#14532d',textMuted:'#4d7c5a',border:'#bbf7d0',ring:'#16a34a'} },
  { id:'monsoon_rain', nameBn:'বর্ষার বৃষ্টি', nameEn:'Monsoon Rain', category:'blue', categoryBn:'নীল', isDark:true, colors:{primary:'#38bdf8',primaryHover:'#0284c7',accent:'#22d3ee',bg:'#071923',surface:'#0b2a3a',card:'#12384a',text:'#e0f2fe',textMuted:'#93c5fd',border:'#164e63',ring:'#38bdf8'} },
  { id:'jute_golden', nameBn:'সোনালি পাট', nameEn:'Golden Jute', category:'warm', categoryBn:'উষ্ণ', isDark:false, colors:{primary:'#a16207',primaryHover:'#854d0e',accent:'#65a30d',bg:'#fefce8',surface:'#fef9c3',card:'#ffffff',text:'#3f2b0a',textMuted:'#78716c',border:'#fde68a',ring:'#ca8a04'} },
  { id:'jamuna_sky', nameBn:'যমুনা আকাশ', nameEn:'Jamuna Sky', category:'blue', categoryBn:'নীল', isDark:false, colors:{primary:'#0369a1',primaryHover:'#075985',accent:'#60a5fa',bg:'#eff6ff',surface:'#dbeafe',card:'#ffffff',text:'#172554',textMuted:'#52758a',border:'#bfdbfe',ring:'#2563eb'} },
  { id:'old_map_sepia', nameBn:'পুরোনো মানচিত্র', nameEn:'Old Map Sepia', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#7c2d12',primaryHover:'#9a3412',accent:'#b45309',bg:'#fff7ed',surface:'#ffedd5',card:'#fffaf2',text:'#431407',textMuted:'#78716c',border:'#fed7aa',ring:'#c2410c'} },
  { id:'midnight_heritage', nameBn:'মধ্যরাতের ঐতিহ্য', nameEn:'Midnight Heritage', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#fbbf24',primaryHover:'#f59e0b',accent:'#fb7185',bg:'#0c0a09',surface:'#1c1917',card:'#292524',text:'#fff7ed',textMuted:'#d6d3d1',border:'#44403c',ring:'#fbbf24'} },


  // Collection 8: 7 additional distinctly designed premium themes to complete the 116-theme catalog
  { id:'emerald_court', nameBn:'পান্না দরবার', nameEn:'Emerald Court', category:'royal', categoryBn:'রাজকীয়', isDark:false, colors:{primary:'#047857',primaryHover:'#065f46',accent:'#d1fae5',bg:'#f0fdf4',surface:'#d1fae5',card:'#ffffff',text:'#064e3b',textMuted:'#52756a',border:'#a7f3d0',ring:'#10b981'} },
  { id:'ruby_velvet', nameBn:'রুবি ভেলভেট', nameEn:'Ruby Velvet', category:'royal', categoryBn:'রাজকীয়', isDark:true, colors:{primary:'#fb7185',primaryHover:'#f43f5e',accent:'#fda4af',bg:'#1f0a12',surface:'#35101d',card:'#481525',text:'#fff1f2',textMuted:'#fda4af',border:'#881337',ring:'#fb7185'} },
  { id:'indigo_manuscript', nameBn:'ইন্ডিগো পাণ্ডুলিপি', nameEn:'Indigo Manuscript', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#4338ca',primaryHover:'#3730a3',accent:'#818cf8',bg:'#f5f3ff',surface:'#ede9fe',card:'#ffffff',text:'#1e1b4b',textMuted:'#6d6aa5',border:'#c4b5fd',ring:'#6366f1'} },
  { id:'copper_lineage', nameBn:'তাম্র ঐতিহ্য', nameEn:'Copper Heritage', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#9a3412',primaryHover:'#7c2d12',accent:'#c2410c',bg:'#fffaf5',surface:'#ffedd5',card:'#ffffff',text:'#431407',textMuted:'#7c5a4d',border:'#fdba74',ring:'#ea580c'} },
  { id:'linen_archive', nameBn:'লিনেন আর্কাইভ', nameEn:'Linen Archive', category:'minimal', categoryBn:'মিনিমাল', isDark:false, colors:{primary:'#57534e',primaryHover:'#44403c',accent:'#a8a29e',bg:'#faf8f4',surface:'#eeeae3',card:'#fffdf9',text:'#292524',textMuted:'#78716c',border:'#d6d3d1',ring:'#78716c'} },
  { id:'museum_bronze', nameBn:'জাদুঘর ব্রোঞ্জ', nameEn:'Museum Bronze', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#78350f',primaryHover:'#451a03',accent:'#b45309',bg:'#f8f5ef',surface:'#e7e0d2',card:'#fffdf8',text:'#2c1b10',textMuted:'#75665a',border:'#c9b99f',ring:'#a16207'} },
  { id:'royal_plum', nameBn:'রাজকীয় প্লাম', nameEn:'Royal Plum', category:'royal', categoryBn:'রাজকীয়', isDark:false, colors:{primary:'#7e22ce',primaryHover:'#6b21a8',accent:'#c084fc',bg:'#faf5ff',surface:'#f3e8ff',card:'#ffffff',text:'#3b0764',textMuted:'#7e5a95',border:'#d8b4fe',ring:'#a855f7'} },
  { id:'sapphire_ledger', nameBn:'নীলকান্ত লেজার', nameEn:'Sapphire Ledger', category:'blue', categoryBn:'নীল', isDark:false, colors:{primary:'#1d4ed8',primaryHover:'#1e40af',accent:'#0ea5e9',bg:'#f5f9ff',surface:'#dbeafe',card:'#ffffff',text:'#172554',textMuted:'#64748b',border:'#bfdbfe',ring:'#2563eb'} },


  // Collection 9: HD / Premium Studio themes (30) — complete the 116-theme catalog.
  { id:'royal_sapphire_hd', nameBn:'রাজকীয় নীলকান্ত HD', nameEn:'Royal Sapphire HD', category:'royal', categoryBn:'রাজকীয়', isDark:false, colors:{primary:'#1e40af',primaryHover:'#1e3a8a',accent:'#38bdf8',bg:'#f5f9ff',surface:'#dbeafe',card:'#ffffff',text:'#172554',textMuted:'#64748b',border:'#bfdbfe',ring:'#2563eb'} },
  { id:'golden_palace_hd', nameBn:'সোনালি প্রাসাদ HD', nameEn:'Golden Palace HD', category:'royal', categoryBn:'রাজকীয়', isDark:false, colors:{primary:'#92400e',primaryHover:'#78350f',accent:'#fbbf24',bg:'#fffdf5',surface:'#fef3c7',card:'#fffefa',text:'#3f2508',textMuted:'#7c6a4b',border:'#f5d58a',ring:'#d97706'} },
  { id:'burgundy_heritage_hd', nameBn:'বারগান্ডি ঐতিহ্য HD', nameEn:'Burgundy Heritage HD', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#7f1d1d',primaryHover:'#641414',accent:'#f59e0b',bg:'#fff8f6',surface:'#fee2e2',card:'#ffffff',text:'#3b0a0a',textMuted:'#7f4b4b',border:'#fecaca',ring:'#b91c1c'} },
  { id:'jade_mughal_hd', nameBn:'জেড মুঘল HD', nameEn:'Jade Mughal HD', category:'royal', categoryBn:'রাজকীয়', isDark:false, colors:{primary:'#065f46',primaryHover:'#064e3b',accent:'#34d399',bg:'#f0fdf8',surface:'#d1fae5',card:'#ffffff',text:'#052e25',textMuted:'#52756a',border:'#a7f3d0',ring:'#10b981'} },
  { id:'peacock_blue_hd', nameBn:'ময়ূর নীল HD', nameEn:'Peacock Blue HD', category:'blue', categoryBn:'নীল', isDark:false, colors:{primary:'#075985',primaryHover:'#0c4a6e',accent:'#22d3ee',bg:'#f0faff',surface:'#cffafe',card:'#ffffff',text:'#082f49',textMuted:'#527a8b',border:'#a5f3fc',ring:'#06b6d4'} },
  { id:'lotus_pink_hd', nameBn:'পদ্ম গোলাপ HD', nameEn:'Lotus Pink HD', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#be185d',primaryHover:'#9d174d',accent:'#f472b6',bg:'#fff7fb',surface:'#fce7f3',card:'#ffffff',text:'#500724',textMuted:'#9d5778',border:'#fbcfe8',ring:'#db2777'} },
  { id:'river_emerald_hd', nameBn:'নদী পান্না HD', nameEn:'River Emerald HD', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#047857',primaryHover:'#065f46',accent:'#2dd4bf',bg:'#f0fdfa',surface:'#ccfbf1',card:'#ffffff',text:'#053b33',textMuted:'#527d75',border:'#99f6e4',ring:'#14b8a6'} },
  { id:'monsoon_indigo_hd', nameBn:'বর্ষা ইন্ডিগো HD', nameEn:'Monsoon Indigo HD', category:'blue', categoryBn:'নীল', isDark:false, colors:{primary:'#3730a3',primaryHover:'#312e81',accent:'#60a5fa',bg:'#f5f7ff',surface:'#e0e7ff',card:'#ffffff',text:'#1e1b4b',textMuted:'#6366a3',border:'#c7d2fe',ring:'#4f46e5'} },
  { id:'terracotta_court_hd', nameBn:'টেরাকোটা দরবার HD', nameEn:'Terracotta Court HD', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#9a3412',primaryHover:'#7c2d12',accent:'#fb923c',bg:'#fffaf7',surface:'#ffedd5',card:'#ffffff',text:'#431407',textMuted:'#8a5c4b',border:'#fed7aa',ring:'#ea580c'} },
  { id:'muslin_ivory_hd', nameBn:'মসলিন আইভরি HD', nameEn:'Muslin Ivory HD', category:'minimal', categoryBn:'মিনিমাল', isDark:false, colors:{primary:'#57534e',primaryHover:'#44403c',accent:'#c4b5fd',bg:'#fcfbf8',surface:'#f3f0e9',card:'#fffefb',text:'#292524',textMuted:'#78716c',border:'#ded8cc',ring:'#8b5cf6'} },
  { id:'bengal_morning_hd', nameBn:'বাংলার ভোর HD', nameEn:'Bengal Morning HD', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#166534',primaryHover:'#14532d',accent:'#f59e0b',bg:'#f7fff8',surface:'#dcfce7',card:'#ffffff',text:'#163b23',textMuted:'#5c7d65',border:'#bbf7d0',ring:'#22c55e'} },
  { id:'palash_spring_hd', nameBn:'পলাশ বসন্ত HD', nameEn:'Palash Spring HD', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#c2410c',primaryHover:'#9a3412',accent:'#f43f5e',bg:'#fff8f5',surface:'#ffedd5',card:'#ffffff',text:'#431407',textMuted:'#8a6254',border:'#fed7aa',ring:'#f97316'} },
  { id:'kashful_white_hd', nameBn:'কাশফুল শুভ্র HD', nameEn:'Kashful White HD', category:'minimal', categoryBn:'মিনিমাল', isDark:false, colors:{primary:'#475569',primaryHover:'#334155',accent:'#38bdf8',bg:'#f8fafc',surface:'#eef2f7',card:'#ffffff',text:'#0f172a',textMuted:'#64748b',border:'#cbd5e1',ring:'#0ea5e9'} },
  { id:'tea_estate_hd', nameBn:'চা-বাগান রত্ন HD', nameEn:'Tea Estate Jewel HD', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#365314',primaryHover:'#1f3b08',accent:'#84cc16',bg:'#f7fee7',surface:'#ecfccb',card:'#ffffff',text:'#1a2e05',textMuted:'#5f7f31',border:'#bef264',ring:'#65a30d'} },
  { id:'delta_sky_hd', nameBn:'বদ্বীপ আকাশ HD', nameEn:'Delta Sky HD', category:'blue', categoryBn:'নীল', isDark:false, colors:{primary:'#0369a1',primaryHover:'#075985',accent:'#93c5fd',bg:'#f4faff',surface:'#dbeafe',card:'#ffffff',text:'#082f49',textMuted:'#52758a',border:'#bfdbfe',ring:'#3b82f6'} },
  { id:'archive_navy_hd', nameBn:'আর্কাইভ নেভি HD', nameEn:'Archive Navy HD', category:'modern', categoryBn:'আধুনিক', isDark:false, colors:{primary:'#1e3a8a',primaryHover:'#172554',accent:'#14b8a6',bg:'#f6f9ff',surface:'#e0e7ff',card:'#ffffff',text:'#0f172a',textMuted:'#64748b',border:'#c7d2fe',ring:'#2563eb'} },
  { id:'modern_cyan_hd', nameBn:'আধুনিক সায়ান HD', nameEn:'Modern Cyan HD', category:'modern', categoryBn:'আধুনিক', isDark:false, colors:{primary:'#0e7490',primaryHover:'#155e75',accent:'#22d3ee',bg:'#f0fdff',surface:'#cffafe',card:'#ffffff',text:'#083344',textMuted:'#527d88',border:'#a5f3fc',ring:'#06b6d4'} },
  { id:'royal_plum_hd', nameBn:'রাজকীয় বেগুনি HD', nameEn:'Royal Plum HD', category:'royal', categoryBn:'রাজকীয়', isDark:false, colors:{primary:'#6b21a8',primaryHover:'#581c87',accent:'#d8b4fe',bg:'#fcf7ff',surface:'#f3e8ff',card:'#ffffff',text:'#3b0764',textMuted:'#7e5a95',border:'#d8b4fe',ring:'#a855f7'} },
  { id:'rose_gold_hd', nameBn:'রোজ গোল্ড HD', nameEn:'Rose Gold HD', category:'warm', categoryBn:'উষ্ণ', isDark:false, colors:{primary:'#9f1239',primaryHover:'#881337',accent:'#fda4af',bg:'#fff8fa',surface:'#ffe4e6',card:'#ffffff',text:'#4c0519',textMuted:'#8f5268',border:'#fecdd3',ring:'#e11d48'} },
  { id:'charcoal_gold_hd', nameBn:'চারকোল গোল্ড HD', nameEn:'Charcoal Gold HD', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#fbbf24',primaryHover:'#f59e0b',accent:'#fde68a',bg:'#09090b',surface:'#18181b',card:'#27272a',text:'#fff7ed',textMuted:'#d4d4d8',border:'#3f3f46',ring:'#f59e0b'} },
  { id:'sapphire_night_hd', nameBn:'স্যাফায়ার নাইট HD', nameEn:'Sapphire Night HD', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#60a5fa',primaryHover:'#3b82f6',accent:'#22d3ee',bg:'#06111f',surface:'#0b1f35',card:'#12304d',text:'#eff6ff',textMuted:'#93c5fd',border:'#1e4b70',ring:'#60a5fa'} },
  { id:'emerald_night_hd', nameBn:'পান্না রাত্রি HD', nameEn:'Emerald Night HD', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#34d399',primaryHover:'#10b981',accent:'#a7f3d0',bg:'#04120d',surface:'#092319',card:'#103427',text:'#ecfdf5',textMuted:'#86efac',border:'#1b4d39',ring:'#34d399'} },
  { id:'crimson_night_hd', nameBn:'রক্তিম রাত্রি HD', nameEn:'Crimson Night HD', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#fb7185',primaryHover:'#f43f5e',accent:'#fecdd3',bg:'#18070c',surface:'#2b0d16',card:'#431521',text:'#fff1f2',textMuted:'#fda4af',border:'#6b1b2d',ring:'#fb7185'} },
  { id:'indigo_night_hd', nameBn:'ইন্ডিগো রাত্রি HD', nameEn:'Indigo Night HD', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#818cf8',primaryHover:'#6366f1',accent:'#c4b5fd',bg:'#080817',surface:'#11112b',card:'#1b1b3c',text:'#eef2ff',textMuted:'#a5b4fc',border:'#37376a',ring:'#818cf8'} },
  { id:'black_gold_hd', nameBn:'ব্ল্যাক গোল্ড HD', nameEn:'Black Gold HD', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#facc15',primaryHover:'#eab308',accent:'#fef08a',bg:'#050505',surface:'#111111',card:'#1b1b1b',text:'#fffdf2',textMuted:'#d4d4d4',border:'#3f3f46',ring:'#facc15'} },
  { id:'obsidian_cyan_hd', nameBn:'অবসিডিয়ান সায়ান HD', nameEn:'Obsidian Cyan HD', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#22d3ee',primaryHover:'#06b6d4',accent:'#67e8f9',bg:'#03080c',surface:'#07141c',card:'#0c2430',text:'#ecfeff',textMuted:'#67e8f9',border:'#164e63',ring:'#22d3ee'} },
  { id:'velvet_violet_hd', nameBn:'ভেলভেট ভায়োলেট HD', nameEn:'Velvet Violet HD', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#c084fc',primaryHover:'#a855f7',accent:'#f0abfc',bg:'#100714',surface:'#211026',card:'#35183c',text:'#fdf4ff',textMuted:'#d8b4fe',border:'#5b2a68',ring:'#c084fc'} },
  { id:'paper_sage_hd', nameBn:'পেপার সেজ HD', nameEn:'Paper Sage HD', category:'minimal', categoryBn:'মিনিমাল', isDark:false, colors:{primary:'#3f6212',primaryHover:'#365314',accent:'#84cc16',bg:'#fafdf5',surface:'#ecf4df',card:'#ffffff',text:'#1a2e05',textMuted:'#64704c',border:'#d2e2b5',ring:'#65a30d'} },
  { id:'porcelain_blue_hd', nameBn:'পোরসেলিন নীল HD', nameEn:'Porcelain Blue HD', category:'minimal', categoryBn:'মিনিমাল', isDark:false, colors:{primary:'#334155',primaryHover:'#1e293b',accent:'#60a5fa',bg:'#f8fbff',surface:'#edf3fa',card:'#ffffff',text:'#0f172a',textMuted:'#64748b',border:'#d5dee9',ring:'#3b82f6'} },
  { id:'sandstone_hd', nameBn:'বালুকাপাথর HD', nameEn:'Sandstone HD', category:'warm', categoryBn:'উষ্ণ', isDark:false, colors:{primary:'#92400e',primaryHover:'#78350f',accent:'#d97706',bg:'#fffcf7',surface:'#f5e9d6',card:'#fffdf9',text:'#451a03',textMuted:'#7c6550',border:'#e7cda7',ring:'#b45309'} },
  { id:'copper_blue_hd', nameBn:'তামা ও নীল HD', nameEn:'Copper & Blue HD', category:'modern', categoryBn:'আধুনিক', isDark:false, colors:{primary:'#0f4c5c',primaryHover:'#083344',accent:'#ea580c',bg:'#f7fbfc',surface:'#dff1f4',card:'#ffffff',text:'#102a33',textMuted:'#60747a',border:'#b8dce2',ring:'#0e7490'} },
  { id:'heritage_green_hd', nameBn:'সবুজ ঐতিহ্য HD', nameEn:'Heritage Green HD', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#166534',primaryHover:'#14532d',accent:'#ca8a04',bg:'#f8fcf6',surface:'#e3f0dc',card:'#ffffff',text:'#17331d',textMuted:'#607565',border:'#c4dcb9',ring:'#65a30d'} },
  // Collection 8: New distinctive premium themes requested for the redesigned release
  { id:'jamdani_pearl', nameBn:'জামদানি মুক্তা', nameEn:'Jamdani Pearl', category:'royal', categoryBn:'রাজকীয়', isDark:false, colors:{primary:'#6d28d9',primaryHover:'#5b21b6',accent:'#db2777',bg:'#fff7fb',surface:'#fce7f3',card:'#ffffff',text:'#3b0764',textMuted:'#8b5b82',border:'#f5d0fe',ring:'#a21caf'} },
  { id:'bronze_sunrise', nameBn:'ব্রোঞ্জ সূর্যোদয়', nameEn:'Bronze Sunrise', category:'heritage', categoryBn:'ঐতিহ্য', isDark:false, colors:{primary:'#78350f',primaryHover:'#451a03',accent:'#ea580c',bg:'#fff7ed',surface:'#fed7aa',card:'#fffbeb',text:'#3b1f0b',textMuted:'#92400e',border:'#fdba74',ring:'#f97316'} },
  { id:'neon_archives', nameBn:'নিয়ন আর্কাইভ', nameEn:'Neon Archives', category:'dark', categoryBn:'ডার্ক', isDark:true, colors:{primary:'#a78bfa',primaryHover:'#8b5cf6',accent:'#2dd4bf',bg:'#090b18',surface:'#15172b',card:'#1c2040',text:'#f5f3ff',textMuted:'#b4b8d5',border:'#3730a3',ring:'#2dd4bf'} },
  { id:'riverstone_sage', nameBn:'নদীপাথর সেজ', nameEn:'Riverstone Sage', category:'nature', categoryBn:'প্রকৃতি', isDark:false, colors:{primary:'#3f6212',primaryHover:'#365314',accent:'#0f766e',bg:'#f7faf5',surface:'#e7f0e4',card:'#ffffff',text:'#1f3427',textMuted:'#60766a',border:'#cbdcc7',ring:'#0f766e'} },
];

export function applyTheme(themeId: string): BongshoTheme & ThemeComponentStyles & { readability: ThemeReadability } {
  const baseTheme = BONGSHO_THEMES.find(t => t.id === themeId) || BONGSHO_THEMES[0];
  const fullTheme = getFullTheme(baseTheme);
  const root = document.documentElement;
  root.dataset.theme = fullTheme.id;
  root.dataset.themeMode = fullTheme.isDark ? 'dark' : 'light';

  if (fullTheme.isDark) {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }

  // Inject CSS custom properties (both standard and descriptive aliases)
  root.style.setProperty('--primary-theme-color', fullTheme.colors.primary);
  root.style.setProperty('--primary-hover-color', fullTheme.colors.primaryHover);
  root.style.setProperty('--accent-theme-color', fullTheme.colors.accent);
  root.style.setProperty('--secondary-theme-color', fullTheme.secondary);
  root.style.setProperty('--bg-theme-color', fullTheme.colors.bg);
  root.style.setProperty('--surface-theme-color', fullTheme.colors.surface);
  root.style.setProperty('--card-theme-color', fullTheme.colors.card);
  root.style.setProperty('--text-theme-color', fullTheme.colors.text);
  root.style.setProperty('--text-muted-color', fullTheme.colors.textMuted);
  root.style.setProperty('--border-theme-color', fullTheme.colors.border);
  root.style.setProperty('--badge-bg-color', fullTheme.badge.bg);
  root.style.setProperty('--badge-text-color', fullTheme.badge.text);
  root.style.setProperty('--nav-active-bg-color', fullTheme.navigation.activeBg);
  root.style.setProperty('--nav-active-text-color', fullTheme.navigation.activeText);
  root.style.setProperty('--header-bg-color', fullTheme.header.bg);
  root.style.setProperty('--header-text-color', fullTheme.header.text);
  root.style.setProperty('--btn-primary-bg-color', fullTheme.buttons.primaryBg);
  root.style.setProperty('--btn-primary-text-color', fullTheme.buttons.primaryText);
  root.style.setProperty('--tree-node-bg-color', fullTheme.treeVisualization.nodeBg);
  root.style.setProperty('--tree-node-border-color', fullTheme.treeVisualization.nodeBorder);
  root.style.setProperty('--tree-line-color', fullTheme.treeVisualization.lineColor);
  root.style.setProperty('--archive-card-bg-color', fullTheme.archiveAppearance.cardBg);
  root.style.setProperty('--profile-hero-bg-color', fullTheme.profileAppearance.heroBg);
  root.style.setProperty('--theme-premium-gradient', fullTheme.premium.gradient);
  root.style.setProperty('--theme-premium-shadow', fullTheme.premium.shadow);
  root.style.setProperty('--theme-premium-radius', fullTheme.premium.radius);
  root.style.setProperty('--theme-premium-glass', fullTheme.premium.glass);
  root.style.setProperty('--theme-overlay', fullTheme.isDark ? 'rgba(2,6,23,.78)' : 'rgba(255,255,255,.82)');
  root.style.setProperty('--theme-input-bg', fullTheme.formControls.inputBg);
  root.style.setProperty('--theme-input-text', fullTheme.formControls.inputText);
  root.style.setProperty('--theme-input-border', fullTheme.formControls.inputBorder);

  // Modern concise theme aliases for direct CSS variable propagation across tree and subcomponents
  root.style.setProperty('--theme-primary', fullTheme.colors.primary);
  root.style.setProperty('--theme-primary-hover', fullTheme.colors.primaryHover);
  root.style.setProperty('--theme-accent', fullTheme.colors.accent);
  root.style.setProperty('--theme-secondary', fullTheme.secondary);
  root.style.setProperty('--theme-bg', fullTheme.colors.bg);
  root.style.setProperty('--theme-surface', fullTheme.colors.surface);
  root.style.setProperty('--theme-card', fullTheme.colors.card);
  root.style.setProperty('--theme-text', fullTheme.colors.text);
  root.style.setProperty('--theme-text-muted', fullTheme.colors.textMuted);
  root.style.setProperty('--theme-border', fullTheme.colors.border);
  root.style.setProperty('--theme-tree-node-bg', fullTheme.treeVisualization.nodeBg);
  root.style.setProperty('--theme-tree-node-border', fullTheme.treeVisualization.nodeBorder);
  root.style.setProperty('--theme-tree-line', fullTheme.treeVisualization.lineColor);
  root.style.setProperty('--theme-tree-connector', fullTheme.treeVisualization.lineColor);

  // Exact standard root CSS variables as requested (--primary, --surface, --text, etc.)
  root.style.setProperty('--primary', fullTheme.colors.primary);
  root.style.setProperty('--primary-hover', fullTheme.colors.primaryHover);
  root.style.setProperty('--surface', fullTheme.colors.surface);
  root.style.setProperty('--text', fullTheme.colors.text);
  root.style.setProperty('--text-muted', fullTheme.colors.textMuted);
  root.style.setProperty('--accent', fullTheme.colors.accent);
  root.style.setProperty('--secondary', fullTheme.secondary);
  root.style.setProperty('--bg', fullTheme.colors.bg);
  root.style.setProperty('--card', fullTheme.colors.card);
  root.style.setProperty('--border', fullTheme.colors.border);
  root.style.setProperty('--tree-node-bg', fullTheme.treeVisualization.nodeBg);
  root.style.setProperty('--tree-node-border', fullTheme.treeVisualization.nodeBorder);
  root.style.setProperty('--tree-line', fullTheme.treeVisualization.lineColor);
  root.style.setProperty('--badge-bg', fullTheme.badge.bg);
  root.style.setProperty('--badge-text', fullTheme.badge.text);

  return fullTheme;
}

export function getThemeCssVariables(theme: BongshoTheme | (BongshoTheme & ThemeComponentStyles)): Record<string, string> {
  const fullTheme = 'treeVisualization' in theme ? (theme as BongshoTheme & ThemeComponentStyles) : getFullTheme(theme);
  return {
    '--primary-theme-color': fullTheme.colors.primary,
    '--primary-hover-color': fullTheme.colors.primaryHover,
    '--accent-theme-color': fullTheme.colors.accent,
    '--secondary-theme-color': fullTheme.secondary,
    '--bg-theme-color': fullTheme.colors.bg,
    '--surface-theme-color': fullTheme.colors.surface,
    '--card-theme-color': fullTheme.colors.card,
    '--text-theme-color': fullTheme.colors.text,
    '--text-muted-color': fullTheme.colors.textMuted,
    '--border-theme-color': fullTheme.colors.border,
    '--badge-bg-color': fullTheme.badge.bg,
    '--badge-text-color': fullTheme.badge.text,
    '--nav-active-bg-color': fullTheme.navigation.activeBg,
    '--nav-active-text-color': fullTheme.navigation.activeText,
    '--header-bg-color': fullTheme.header.bg,
    '--header-text-color': fullTheme.header.text,
    '--btn-primary-bg-color': fullTheme.buttons.primaryBg,
    '--btn-primary-text-color': fullTheme.buttons.primaryText,
    '--tree-node-bg-color': fullTheme.treeVisualization.nodeBg,
    '--tree-node-border-color': fullTheme.treeVisualization.nodeBorder,
    '--tree-line-color': fullTheme.treeVisualization.lineColor,
    '--archive-card-bg-color': fullTheme.archiveAppearance.cardBg,
    '--profile-hero-bg-color': fullTheme.profileAppearance.heroBg,
    '--theme-premium-gradient': fullTheme.premium.gradient,
    '--theme-premium-shadow': fullTheme.premium.shadow,
    '--theme-premium-radius': fullTheme.premium.radius,
    '--theme-premium-glass': fullTheme.premium.glass,
    '--theme-overlay': fullTheme.isDark ? 'rgba(2,6,23,.78)' : 'rgba(255,255,255,.82)',
    '--theme-input-bg': fullTheme.formControls.inputBg,
    '--theme-input-text': fullTheme.formControls.inputText,
    '--theme-input-border': fullTheme.formControls.inputBorder,
    '--theme-primary': fullTheme.colors.primary,
    '--theme-primary-hover': fullTheme.colors.primaryHover,
    '--theme-accent': fullTheme.colors.accent,
    '--theme-secondary': fullTheme.secondary,
    '--theme-bg': fullTheme.colors.bg,
    '--theme-surface': fullTheme.colors.surface,
    '--theme-card': fullTheme.colors.card,
    '--theme-text': fullTheme.colors.text,
    '--theme-text-muted': fullTheme.colors.textMuted,
    '--theme-border': fullTheme.colors.border,
    '--theme-tree-node-bg': fullTheme.treeVisualization.nodeBg,
    '--theme-tree-node-border': fullTheme.treeVisualization.nodeBorder,
    '--theme-tree-line': fullTheme.treeVisualization.lineColor,
    '--theme-tree-connector': fullTheme.treeVisualization.lineColor,
    // Exact standard CSS variables
    '--primary': fullTheme.colors.primary,
    '--primary-hover': fullTheme.colors.primaryHover,
    '--surface': fullTheme.colors.surface,
    '--text': fullTheme.colors.text,
    '--text-muted': fullTheme.colors.textMuted,
    '--accent': fullTheme.colors.accent,
    '--secondary': fullTheme.secondary,
    '--bg': fullTheme.colors.bg,
    '--card': fullTheme.colors.card,
    '--border': fullTheme.colors.border,
    '--tree-node-bg': fullTheme.treeVisualization.nodeBg,
    '--tree-node-border': fullTheme.treeVisualization.nodeBorder,
    '--tree-line': fullTheme.treeVisualization.lineColor,
    '--badge-bg': fullTheme.badge.bg,
    '--badge-text': fullTheme.badge.text
  };
}
