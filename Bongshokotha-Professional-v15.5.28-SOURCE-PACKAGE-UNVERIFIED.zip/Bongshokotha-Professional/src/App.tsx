/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * BONGSHOKOTHA / বংশকথা
 * Production-Grade Genealogy & Heritage Management Platform
 * 
 * User Requirements:
 * 1. "সদস্য ফরম মাত্র একটি পেজে দেখাবে, নতুন, সম্পাদনের সময়ও।" (MemberModal single-page)
 * 2. "থীম গুলো পুরা বংশ তালিকায় কাজ করবে।" (ThemeRegistry tokens applied across whole tree)
 * 3. "ইস্কেনের বামে ফিস্ট বাবে সব মেনু থাকবে।" (Fixed left sidebar menu for all navigation)
 * 4. "বিভিন্ন মোবাইল ছোট, মাঝাড়ি, বড়, বিশাল বড় মোবাইলে যেন সুন্দর ভাবে কাজ করে।" (Responsive layout)
 * 5. "সকল সদস্য মেনুতে প্রজন্ম হিসাবে দেখাবে, সর্বদা প্রজন্মের বড় সন্তানের সন্তানদের আগে দেখাবে।" (MembersView grouped by generation with eldest sibling descendants first)
 */

import React, { useState, useEffect, useRef } from 'react';
import { GenealogyProvider, useGenealogy } from './context/GenealogyContext';
import { ThemeRegistryProvider } from './context/ThemeRegistry';
import { Sidebar, NavTab } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { FamilyTreeView } from './components/FamilyTreeView';
import { MembersView } from './components/MembersView';
import { RelationshipFinderView } from './components/RelationshipFinderView';
import { MarriagesView } from './components/MarriagesView';
import { FamilyBookView } from './components/FamilyBookView';
import { FamilyArchiveView } from './components/FamilyArchiveView';
import { FamilyCalendarView } from './components/FamilyCalendarView';
import { PrintExportView } from './components/PrintExportView';
import { ImportExportView } from './components/ImportExportView';
import { SettingsView } from './components/SettingsView';
import { AdminCenterView } from './components/AdminCenterView';
import { MemberModal } from './components/MemberModal';
import { MarriageModal } from './components/MarriageModal';
import { MemberProfileModal } from './components/MemberProfileModal';
import { FamilyModal } from './components/FamilyModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { AvatarUploadModal } from './components/AvatarUploadModal';
import { Member, MarriageRecord } from './types/genealogy';
import { TreeDeciduous } from 'lucide-react';
import { LoginView, isBongshokothaAuthenticated } from './components/LoginView';
import { FamilyHubView } from './components/FamilyHubView';
import { RecycleBinView } from './components/RecycleBinView';
import { MyAccountView } from './components/MyAccountView';
import { MapView } from './components/MapView';
import { FamilyTreeSharingView } from './components/FamilyTreeSharingView';
import { clearSession, getSession, touchSession } from './services/security';

const BongshokothaApp: React.FC = () => {
  const { isLoading, language, theme, updateMember, members } = useGenealogy();
  const [authenticated, setAuthenticated] = useState(isBongshokothaAuthenticated());
  const logoutCloseTimerRef = useRef<number | null>(null);
  const [familySelected, setFamilySelected] = useState(localStorage.getItem('bongshokotha_family_selected_v1') === '1');

  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Modal states
  const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
  const [memberToEdit, setMemberToEdit] = useState<Member | null>(null);

  const [isMarriageModalOpen, setIsMarriageModalOpen] = useState(false);
  const [marriageToEdit, setMarriageToEdit] = useState<MarriageRecord | null>(null);

  const [inspectingMemberId, setInspectingMemberId] = useState<string | null>(null);
  const [isFamilyModalOpen, setIsFamilyModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);

  // Avatar upload modal
  const [avatarUploadMemberId, setAvatarUploadMemberId] = useState<string | null>(null);

  // Kinship target
  const [kinshipTargetId, setKinshipTargetId] = useState<string | null>(null);

  // Keyboard shortcut for Search (⌘K / Ctrl+K)
  useEffect(() => {
    const onLogout = () => { clearSession(); setAuthenticated(false); setFamilySelected(false); setIsMobileMenuOpen(false); localStorage.removeItem('bongshokotha_family_selected_v1'); if (logoutCloseTimerRef.current !== null) window.clearTimeout(logoutCloseTimerRef.current); logoutCloseTimerRef.current = window.setTimeout(() => { try { for (const key of Object.keys(sessionStorage)) if (key.startsWith('bongshokotha_temp_')) sessionStorage.removeItem(key); } catch {} }, 5 * 60_000); };
    window.addEventListener('bongshokotha:logout', onLogout);
    return () => { window.removeEventListener('bongshokotha:logout', onLogout); if (logoutCloseTimerRef.current !== null) window.clearTimeout(logoutCloseTimerRef.current); };
  }, []);

  useEffect(() => {
    if (!authenticated) return;
    const activity = () => { if (!touchSession(15)) { clearSession(); setAuthenticated(false); setFamilySelected(false); } };
    const events = ['pointerdown','keydown','touchstart','scroll'];
    events.forEach(name => window.addEventListener(name, activity, { passive: true }));
    const timer = window.setInterval(() => { const session = getSession(); if (!session || Date.now() - session.lastActivityAt >= 15 * 60_000) { clearSession(); setAuthenticated(false); setFamilySelected(false); } }, 15_000);
    return () => { events.forEach(name => window.removeEventListener(name, activity)); window.clearInterval(timer); };
  }, [authenticated]);

  // Mobile/browser Back navigates within the app and never exits the authenticated genealogy view directly.
  useEffect(() => {
    if (!authenticated || !familySelected) return;
    const marker = { bongshokothaApp: true, tab: activeTab };
    try { window.history.pushState(marker, '', window.location.href); } catch {}
    const onPopState = (event: PopStateEvent) => {
      if (isMobileMenuOpen) { setIsMobileMenuOpen(false); }
      else if (isSearchModalOpen) { setIsSearchModalOpen(false); }
      else if (isMemberModalOpen) { setIsMemberModalOpen(false); }
      else if (isMarriageModalOpen) { setIsMarriageModalOpen(false); }
      else if (inspectingMemberId) { setInspectingMemberId(null); }
      else { const tabCandidate: unknown = event.state?.tab; const validTabs: NavTab[] = ['dashboard', 'members', 'tree', 'relations', 'marriages', 'archive', 'book', 'calendar', 'import-export', 'print-export', 'settings', 'share', 'map', 'admin', 'my-account', 'recycle-bin']; const previousTab: NavTab = typeof tabCandidate === 'string' && validTabs.includes(tabCandidate as NavTab) ? tabCandidate as NavTab : 'dashboard'; setActiveTab(previousTab); }
      try { window.history.pushState({ bongshokothaApp: true, tab: event.state?.tab || 'dashboard' }, '', window.location.href); } catch {}
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [authenticated, familySelected, activeTab, isMobileMenuOpen, isSearchModalOpen, isMemberModalOpen, isMarriageModalOpen, inspectingMemberId]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchModalOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleOpenAddMember = () => {
    setMemberToEdit(null);
    setIsMemberModalOpen(true);
  };

  const handleEditMember = (member: Member) => {
    setMemberToEdit(member);
    setIsMemberModalOpen(true);
  };

  const handleOpenAddMarriage = () => {
    setMarriageToEdit(null);
    setIsMarriageModalOpen(true);
  };

  const handleEditMarriage = (marriage: MarriageRecord) => {
    setMarriageToEdit(marriage);
    setIsMarriageModalOpen(true);
  };

  const handleTraceRelationship = (memberId: string) => {
    setKinshipTargetId(memberId);
    setActiveTab('relations');
    setInspectingMemberId(null);
  };

  const handleAvatarSave = async (photoUrl: string) => {
    if (!avatarUploadMemberId) return;
    const m = members.find(item => item.id === avatarUploadMemberId);
    if (m) {
      await updateMember({
        ...m,
        profilePhoto: photoUrl
      });
    }
  };

  const avatarMember = members.find(m => m.id === avatarUploadMemberId);

  if (isLoading) {
    return (
      <div className="flex h-screen w-screen flex-col items-center justify-center bg-stone-100 dark:bg-stone-950 text-stone-700 dark:text-stone-300">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-800 text-amber-100 shadow-xl shadow-amber-950/20 animate-pulse">
          <TreeDeciduous className="h-10 w-10" />
        </div>
        <div className="mt-4 font-serif text-xl font-bold text-amber-950 dark:text-amber-100">
          বংশকথা • BONGSHOKOTHA
        </div>
        <p className="mt-1 text-xs text-stone-500 font-sans">
          ঐতিহাসিক তথ্যভাণ্ডার সক্রিয় হচ্ছে...
        </p>
      </div>
    );
  }

  if (!authenticated) {
    return <LoginView onLogin={() => { if (logoutCloseTimerRef.current !== null) { window.clearTimeout(logoutCloseTimerRef.current); logoutCloseTimerRef.current = null; } setAuthenticated(true); setFamilySelected(localStorage.getItem('bongshokotha_family_selected_v1') === '1'); }} />;
  }

  if (!familySelected) {
    return <FamilyHubView onOpenFamily={() => setFamilySelected(true)} />;
  }

  const customBackground = localStorage.getItem('bongshokotha_theme_background_v1') || '';

  return (
    <div className="min-h-screen bg-stone-100/70 dark:bg-stone-950 font-sans text-stone-900 dark:text-stone-100 transition-colors flex bg-cover bg-center bg-fixed" style={customBackground ? { backgroundImage: `linear-gradient(var(--theme-overlay),var(--theme-overlay)),url(${customBackground})` } : undefined}>
      {/* 1. FIXED LEFT SIDEBAR (Desktop permanent + Mobile slide drawer + Mobile bottom bar) */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddMember={handleOpenAddMember}
        onOpenSearch={() => setIsSearchModalOpen(true)}
        isMobileOpen={isMobileMenuOpen}
        setIsMobileOpen={setIsMobileMenuOpen}
      />

      {/* 2. MAIN APPLICATION CONTENT AREA (Offset by left sidebar on desktop) */}
      <div className="flex flex-col flex-1 w-full md:pl-64 lg:pl-72 min-h-screen transition-all">
        
        {/* Top Header */}
        <Header
          activeTab={activeTab}
          setActiveTab={(tab) => setActiveTab(tab as NavTab)}
          onOpenNewFamilyModal={() => setIsFamilyModalOpen(true)}
          onOpenAddMemberModal={handleOpenAddMember}
          onOpenSearchModal={() => setIsSearchModalOpen(true)}
          onToggleMobileMenu={() => setIsMobileMenuOpen(prev => !prev)}
        />

        {/* View Content (Responsive for Small, Medium, Large, and Huge Mobile Displays) */}
        <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-4 sm:pt-6 pb-8 md:pb-12 overflow-x-hidden">
          {activeTab === 'dashboard' && (
            <DashboardView
              onNavigate={(tab) => setActiveTab(tab as NavTab)}
              onOpenAddMember={handleOpenAddMember}
              onOpenAddMarriage={handleOpenAddMarriage}
              onSelectMember={(id) => setInspectingMemberId(id)}
            />
          )}

          {activeTab === 'members' && (
            <MembersView
              onOpenAddMember={handleOpenAddMember}
              onEditMember={handleEditMember}
              onSelectMember={(id) => setInspectingMemberId(id)}
            />
          )}

          {activeTab === 'tree' && (
            <FamilyTreeView
              onSelectMember={(id) => setInspectingMemberId(id)}
              onTraceRelationship={handleTraceRelationship}
              onOpenAddMember={handleOpenAddMember}
            />
          )}

          {activeTab === 'relations' && (
            <RelationshipFinderView
              initialPersonBId={kinshipTargetId || undefined}
              onSelectMember={(id) => setInspectingMemberId(id)}
            />
          )}

          {activeTab === 'marriages' && (
            <MarriagesView
              onOpenAddMarriage={handleOpenAddMarriage}
              onEditMarriage={handleEditMarriage}
              onSelectMember={(id) => setInspectingMemberId(id)}
            />
          )}

          {activeTab === 'book' && (
            <FamilyBookView
              onSelectMember={(id) => setInspectingMemberId(id)}
            />
          )}

          {activeTab === 'archive' && (
            <FamilyArchiveView
              onSelectMember={(id: string) => setInspectingMemberId(id)}
              onOpenUploadAvatar={(memberId: string) => setAvatarUploadMemberId(memberId)}
            />
          )}

          {activeTab === 'calendar' && (
            <FamilyCalendarView
              onSelectMember={(id) => setInspectingMemberId(id)}
            />
          )}

          {activeTab === 'print-export' && (
            <PrintExportView
              onNavigateToBook={() => setActiveTab('book')}
              onSelectMember={(id) => setInspectingMemberId(id)}
            />
          )}

          {activeTab === 'import-export' && (
            <ImportExportView
              onSelectMember={(id) => setInspectingMemberId(id)}
              onNavigateToTree={() => setActiveTab('tree')}
            />
          )}

          {activeTab === 'admin' && (
            <AdminCenterView />
          )}

          {activeTab === 'my-account' && <MyAccountView />}
          {activeTab === 'map' && <MapView />}
          {activeTab === 'share' && <FamilyTreeSharingView />}

          {activeTab === 'settings' && (
            <SettingsView
              onOpenNewFamilyModal={() => setIsFamilyModalOpen(true)}
              onSelectMember={(id) => setInspectingMemberId(id)}
            />
          )}

          {activeTab === 'recycle-bin' && <RecycleBinView />}
        </main>

        {/* Footer Branding Bar */}
        <footer className="no-print border-t border-stone-200/80 bg-white/70 py-6 text-center text-xs text-stone-500 dark:border-stone-800 dark:bg-stone-900/70 hidden md:block">
          <div className="mx-auto max-w-7xl px-4">
            <p className="font-serif font-semibold text-stone-900 dark:text-stone-100">
              {language === 'bn' ? 'বংশকথা — পারিবারিক ঐতিহ্য ও ইতিহাস সংরক্ষণাগার' : 'BONGSHOKOTHA — Heritage Lineage & Family History Platform'}
            </p>
            <p className="text-[11px] text-stone-400 mt-1">
              {language === 'bn'
                ? 'নাম পরিবর্তন হতে পারে, কিন্তু সদস্য ও বৈবাহিক আইডি অপরিবর্তনীয়। অফলাইন-ফার্স্ট স্থানীয় মেমরিতে সংরক্ষিত।'
                : 'Permanent Member IDs • Segregated In-Law Lineages • Offline-First Persistent Storage'}
            </p>
          </div>
        </footer>

      </div>

      {/* Global Modals */}
      <MemberModal
        isOpen={isMemberModalOpen}
        onClose={() => setIsMemberModalOpen(false)}
        memberToEdit={memberToEdit}
        onSavedMemberId={(id) => setInspectingMemberId(id)}
      />

      <MarriageModal
        isOpen={isMarriageModalOpen}
        onClose={() => setIsMarriageModalOpen(false)}
        marriageToEdit={marriageToEdit}
      />

      <MemberProfileModal
        memberId={inspectingMemberId}
        onClose={() => setInspectingMemberId(null)}
        onEdit={(m) => {
          setInspectingMemberId(null);
          handleEditMember(m);
        }}
        onNavigateToMember={(id) => setInspectingMemberId(id)}
        onTraceRelationship={handleTraceRelationship}
        onOpenAvatarModal={(id) => setAvatarUploadMemberId(id)}
      />

      <FamilyModal
        isOpen={isFamilyModalOpen}
        onClose={() => setIsFamilyModalOpen(false)}
      />

      <GlobalSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectMember={(id) => setInspectingMemberId(id)}
      />

      {avatarUploadMemberId && (
        <AvatarUploadModal
          isOpen={!!avatarUploadMemberId}
          onClose={() => setAvatarUploadMemberId(null)}
          memberName={avatarMember ? (language === 'bn' ? avatarMember.banglaName || avatarMember.fullName : avatarMember.englishName || avatarMember.fullName) : ''}
          currentAvatar={avatarMember?.profilePhoto}
          onSaveAvatar={handleAvatarSave}
          isBn={language === 'bn'}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <GenealogyProvider>
      <ThemeRegistryProvider>
        <BongshokothaApp />
      </ThemeRegistryProvider>
    </GenealogyProvider>
  );
}
